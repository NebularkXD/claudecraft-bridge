// ============================================================
// SPLEEF: a level on the server (/goto Spleef). Everyone starts on the top floor and breaks the
// blocks under the others; fall into the lava at the bottom and you're out, watching from an
// invisible floor up top. The last one left wins, then the floors are rebuilt for the next round.
//
// The map: 32 x 32 x 64. Lava at the bottom; floors one block thick with 4 blocks of air between
// them, inside stone walls (so the ocean round the map stays out of sight); a small invisible floor
// (with an invisible rail) high above for spectators.
// ============================================================
module.exports = function spleef(ctx) {
    const { Level, BLOCK: B, PLAYER_HEIGHT } = ctx;
    const W = 32, H = 32, D = 64;
    const LAVA_TOP = 3;                                          // lava fills y = 1..3 (bedrock at 0)
    const FLOORS = [50, 45, 40, 35, 30, 25, 20, 15, 10];         // one block thick, 4 of air between
    const FLOOR_BLOCKS = [B.PLANKS, B.COBBLESTONE, B.DIRT, B.ROCK, B.LOG, B.GRASS, B.IRON_ORE, B.GOLD_ORE, B.PLANKS];
    const SPECTATE_Y = 58;                                       // the invisible floor
    const WALL_TOP = 56;                                         // stone walls round the edge, up to here
    const inside = (x, z) => x >= 1 && x <= W - 2 && z >= 1 && z <= H - 2;
    const PLAT = { x0: 12, x1: 19, z0: 12, z1: 19 };              // 8 x 8, in the middle
    const MIN_PLAYERS = ctx.propInt('spleef-min-players', 2, 16, 2);
    const COUNTDOWN = 10, BETWEEN_ROUNDS = 5;
    const YELLOW = 0xFFFF55, RED = 0xFF5555, GOLD = 0xFFAA00, GREEN = 0x55FF55;
    const idx = (x, y, z) => (y * H + z) * W + x;
    const isFloorY = y => FLOORS.includes(y);

    const sp = { world: null, state: 'waiting', until: 0, alive: new Set(), lastCount: null };
    const here = () => sp.world ? ctx.worldPlayers(sp.world) : [];
    const say = (text, color) => ctx.broadcastWorld(sp.world, { t: 'chat', text, color });
    const eyeAt = (x, feetY, z) => ({ x, y: feetY + PLAYER_HEIGHT + 0.01, z, rotX: 0, rotY: 0 });
    const spectatorSpot = () => eyeAt(16 + (Math.random() - 0.5) * 4, SPECTATE_Y + 1, 16 + (Math.random() - 0.5) * 4);
    // spread out round the top floor, away from the edges
    const startSpot = i => { const a = i * 2.4, r = 4 + (i % 4) * 2.5;
        return eyeAt(16 + Math.cos(a) * r, FLOORS[0] + 1, 16 + Math.sin(a) * r); };

    function floorBlocks() {
        const list = [];
        FLOORS.forEach((y, i) => { for (let x = 1; x < W - 1; x++) for (let z = 1; z < H - 1; z++) list.push(x, y, z, FLOOR_BLOCKS[i % FLOOR_BLOCKS.length]); });
        return list;
    }
    function makeLevel() {
        const blocks = new Uint8Array(W * H * D);
        for (let x = 0; x < W; x++) for (let z = 0; z < H; z++) {
            blocks[idx(x, 0, z)] = B.BEDROCK;
            if (!inside(x, z)) { for (let y = 1; y <= WALL_TOP; y++) blocks[idx(x, y, z)] = B.ROCK; continue; }   // the walls
            for (let y = 1; y <= LAVA_TOP; y++) blocks[idx(x, y, z)] = B.LAVA;
        }
        const f = floorBlocks(); for (let i = 0; i < f.length; i += 4) blocks[idx(f[i], f[i + 1], f[i + 2])] = f[i + 3];
        // the spectators' invisible floor, with an invisible rail round it so nobody falls off
        for (let x = PLAT.x0 - 1; x <= PLAT.x1 + 1; x++) for (let z = PLAT.z0 - 1; z <= PLAT.z1 + 1; z++) {
            const edge = x < PLAT.x0 || x > PLAT.x1 || z < PLAT.z0 || z > PLAT.z1;
            if (!edge) blocks[idx(x, SPECTATE_Y, z)] = B.BARRIER;
            else for (let y = SPECTATE_Y; y <= SPECTATE_Y + 2; y++) blocks[idx(x, y, z)] = B.BARRIER;
        }
        const lv = new Level(W, H, D, blocks);
        lv.savedPlayer = startSpot(0);
        return lv;
    }
    // put the floors back (as one batch of block changes, so it's quick for everyone)
    function rebuildFloors() {
        const lv = sp.world.level, list = floorBlocks(), changed = [];
        for (let i = 0; i < list.length; i += 4) {
            const [x, y, z, b] = [list[i], list[i + 1], list[i + 2], list[i + 3]];
            if (lv.getTile(x, y, z) !== b) { lv.setTile(x, y, z, b); changed.push(x, y, z, b); }
        }
        if (changed.length) ctx.broadcastWorld(sp.world, { t: 'sets', list: changed });
    }
    const canBreakAny = p => sp.state === 'playing' && sp.alive.has(p.id);
    const updateRules = p => ctx.send(p, { t: 'levelRules', building: ctx.canBuildBase(p) && canBreakAny(p), hideNametags: false });
    const updateAll = () => here().forEach(updateRules);

    function startCountdown() {
        sp.state = 'countdown'; sp.until = Date.now() + COUNTDOWN * 1000; sp.lastCount = null;
        sp.alive.clear();
        rebuildFloors();
        here().forEach((p, i) => ctx.teleport(p, startSpot(i)));
        updateAll();
        say(`Spleef starts in ${COUNTDOWN} seconds!`, YELLOW);
    }
    function startRound() {
        sp.state = 'playing';
        sp.alive = new Set(here().map(p => p.id));
        updateAll();
        say('Go! Break the floor under the others: the last one standing wins!', GREEN);
    }
    function lost(p) {
        sp.alive.delete(p.id);
        say(`${p.name} lost!`, RED);
        ctx.teleport(p, spectatorSpot());
        updateRules(p);
    }
    function endRound() {
        const left = here().filter(p => sp.alive.has(p.id));
        say(left.length === 1 ? `${left[0].name} was the last man standing!` : 'Nobody was the last man standing!', GOLD);
        sp.state = 'over'; sp.until = Date.now() + BETWEEN_ROUNDS * 1000;
        sp.alive.clear();
        updateAll();
    }
    function tick() {
        if (!sp.world) return;
        const now = Date.now(), ps = here();
        // anyone in the lava: out (or, if already watching, just back up to the spectators)
        for (const p of ps) {
            const feet = p.y - PLAYER_HEIGHT;
            if (feet > LAVA_TOP + 1) continue;
            if (sp.state === 'playing' && sp.alive.has(p.id)) lost(p);
            else ctx.teleport(p, sp.state === 'playing' ? spectatorSpot() : startSpot(0));
        }
        if (sp.state === 'waiting') {
            if (ps.length >= MIN_PLAYERS) startCountdown();
        } else if (sp.state === 'countdown') {
            if (ps.length < MIN_PLAYERS) { sp.state = 'waiting'; say(`Not enough players: waiting for ${MIN_PLAYERS} to start.`, YELLOW); return; }
            const left = Math.ceil((sp.until - now) / 1000);
            if (left <= 3 && left >= 1 && left !== sp.lastCount) { sp.lastCount = left; say(`${left}...`, YELLOW); }
            if (now >= sp.until) startRound();
        } else if (sp.state === 'playing') {
            if (ps.filter(p => sp.alive.has(p.id)).length <= 1) endRound();
        } else if (sp.state === 'over') {
            if (now >= sp.until) sp.state = 'waiting';
        }
    }

    return {
        start() {
            sp.world = ctx.makeWorld('Spleef');
            sp.world.isSpleef = true;
            ctx.setWorldLevel(sp.world, makeLevel());
            setInterval(tick, 100);
            return sp.world;
        },
        canBreakAny,
        // only floor blocks, only broken (never placed), only by players still in the round
        canBreak(p, x, y, z, b) {
            return canBreakAny(p) && b === B.AIR && isFloorY(y) && inside(x, z) && FLOOR_BLOCKS.includes(sp.world.level.getTile(x, y, z));
        },
        whyNot(p, b) {
            if (b !== B.AIR) return 'In Spleef you can only break blocks, not place them.';
            if (sp.state === 'playing' && !sp.alive.has(p.id)) return 'You\'re out: watching until the next round.';
            if (sp.state !== 'playing') return 'Wait for the round to start!';
            return null;
        },
        onJoin(p) {
            if (sp.state === 'playing') {
                ctx.teleport(p, spectatorSpot());
                ctx.tell(p, 'Welcome to Spleef! A round is going on: watch from up here, you\'ll play in the next one.', YELLOW);
            } else {
                ctx.teleport(p, startSpot(here().length));
                ctx.tell(p, `Welcome to Spleef! Break the floor under the other players: fall into the lava and you lose, the last one standing wins. (Starts with ${MIN_PLAYERS} players)`, YELLOW);
            }
            updateRules(p);
        },
        onLeave(p) { sp.alive.delete(p.id); }
    };
};
