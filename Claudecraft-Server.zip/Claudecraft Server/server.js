// ============================================================
// MINECRAFT RECREATION - MULTIPLAYER SERVER
// Players connect over WebSockets from the game's Load level -> Join Server.. page.
//
// Setup (once, in this server folder):   npm install ws three @runonflux/nat-upnp@1.0.2
// For a link anyone can join without touching your router, install Cloudflare's cloudflared
// (winget install --id Cloudflare.cloudflared). The server starts the tunnel itself and shows
// the link, so you only need this one window.
// Run:                                   node server.js
// It asks which kind of server to run:
//   Regular      - normal building, with moderation (block checks, height limit, spam limits)
//   Anarchy      - zero moderation: any block anywhere, bedrock too, no limits
//   Minigame     - then pick a game: Hide and Seek
// Then how many bots to add (0-10, for testing): AI players that find their way around, build
// things, answer chat (and do what you ask: "Bot1 come here", "build a house", "stop"), follow
// the rules of the server type, and play Hide and Seek properly.
// Or skip the questions:  node server.js regular | anarchy | hideandseek  [bots]
//
// It uses the game's own code from main.js (world generation, the level, the .dat format).
// Set GAME_FILE if main.js isn't in the folder above this one.
// ============================================================
const fs = require('fs');
// If the server crashes, the error goes in crash-log.txt (and opens in Notepad when it was started
// from Start Server.bat, whose window is minimized)
function crashed(err) {
    const text = `Claudecraft server crashed at ${new Date().toLocaleString()}:\n\n${err && err.stack ? err.stack : err}\n`;
    try { process.stderr.write(text); } catch { /* nothing to write to */ }
    const file = require('path').join(__dirname, 'crash-log.txt');
    try { fs.writeFileSync(file, text); } catch { /* can't save it */ }
    if (process.env.GUI && process.platform === 'win32') {
        try { require('child_process').spawn('notepad', [file], { detached: true, stdio: 'ignore' }).unref(); } catch { /* open it by hand */ }
    }
    process.exitCode = 1;
    setTimeout(() => process.exit(1), 500);
}
process.on('uncaughtException', crashed);
process.on('unhandledRejection', crashed);

// Everything the server prints is also kept here for the control panel's Logs tab
const LOG = [];
let logCount = 0;
for (const kind of ['log', 'error']) {
    const original = console[kind].bind(console);
    console[kind] = (...args) => {
        original(...args);
        const text = args.map(a => (a instanceof Error ? a.stack || a.message : typeof a === 'string' ? a : JSON.stringify(a))).join(' ');
        LOG.push({ n: ++logCount, time: Date.now(), error: kind === 'error', text });
        if (LOG.length > 2000) LOG.shift();
    };
}
const path = require('path');
const readline = require('readline');
const os = require('os');
const { spawn, spawnSync } = require('child_process');
const https = require('https');
const http = require('http');
const { WebSocketServer } = require('ws');

// What this server can do. The game checks this and warns if the server is out of date.
const SERVER_VERSION = 3;
const SERVER_FEATURES = ['chat', 'modes', 'teleport', 'freeze', 'skins'];

// ---- server.properties: the server's settings ----
// A plain text file in this folder, one "setting=value" per line, like real Minecraft servers.
// Made with the defaults the first time the server runs; edit it in Notepad and restart.
// (Settings given when starting the server, like PORT=25566 node server.js, still win.)
const PROPERTIES_FILE = path.join(__dirname, 'server.properties');
const PROPERTY_LIST = [
    ['server-name', 'Claudecraft server', 'The server\'s name, shown on the website\'s Servers page'],
    ['description', 'A Claudecraft server', 'A short description, shown on the Servers page'],
    ['server-type', 'ask', 'regular, anarchy or hideandseek (ask = ask each time the server starts)'],
    ['bots', 'ask', 'How many bots to add for testing, 0 to 10 (ask = ask each time)'],
    ['max-players', '16', 'The most players at once (bots count too)'],
    ['rule-validation', 'default', 'Check every change against the rules (no cheating, spam limits, no blocks inside people):\n' +
        '# true = on, false = off, default = whatever the server type uses (on, except Anarchy)'],
    ['level-name', 'world', 'The world for Regular and Anarchy, saved as levels/<level-name>.dat (made if it doesn\'t exist)'],
    ['level-size', '256', 'How big a new world is: 64, 128, 256 or 512'],
    ['hide-and-seek-map', 'Hide and Seek', 'The map for Hide and Seek: levels/<hide-and-seek-map>.dat'],
    ['hide-seconds', '30', 'Hide and Seek: seconds the hiders get to hide'],
    ['seek-seconds', '300', 'Hide and Seek: seconds the seekers get to find everyone'],
    ['owner', '', 'YOUR Claudecraft username: you become the Owner (yellow nametag, every command). Blank = no owner'],
    ['public', 'true', 'true = people on the internet can join (Cloudflare tunnel, or your router), false = your home network only'],
    ['port', '25565', 'The port the server uses on this computer'],
    ['autosave-minutes', '5', 'How often the world is saved while people change it'],
    ['require-agree', 'true', 'true = players must type /agree to the rules (in rules.txt) before they can build'],
    ['open-control-panel', 'true', 'true = open the control panel in your browser when the server starts (Windows)'],
    ['minigames', 'true', 'false = no minigame levels at all (turns off Lava Survival and the Hide and Seek level)'],
    ['lava-survival', 'true', 'true = a Lava Survival level players can /goto (maps in the "lava survival" folder)'],
    ['hide-and-seek-level', 'true', 'true = the Hide and Seek map is played as Hide and Seek when players /goto it'],
    ['lava-build-seconds', '300', 'Lava Survival: seconds to build before the lava comes'],
    ['lava-flood-seconds', '240', 'Lava Survival: seconds the lava flows before the round ends'],
    ['lava-min-players', '1', 'Lava Survival: players needed to start a round']
];
function loadProperties() {
    let text = '';
    try { text = fs.readFileSync(PROPERTIES_FILE, 'utf8'); } catch { /* first run */ }
    const values = {};
    for (const line of text.split(/\r?\n/)) {
        const m = line.match(/^\s*([a-z0-9-]+)\s*=(.*)$/i);
        if (m) values[m[1].toLowerCase()] = m[2].trim();
    }
    // add any settings the file doesn't have yet (all of them the first time), with explanations
    const missing = PROPERTY_LIST.filter(([key]) => !(key in values));
    if (missing.length) {
        const lines = text ? [text.replace(/\s*$/, ''), ''] : ['# Claudecraft server settings. Edit, save, then restart the server.', ''];
        for (const [key, value, about] of missing) { lines.push('# ' + about, `${key}=${value}`, ''); values[key] = value; }
        try { fs.writeFileSync(PROPERTIES_FILE, lines.join('\n')); } catch (err) { console.error('Couldn\'t write server.properties:', err.message); }
        console.log(text ? `Added new settings to server.properties: ${missing.map(m => m[0]).join(', ')}` : 'Made server.properties with the default settings.');
    }
    return values;
}
const props = loadProperties();
const propText = (key, fallback) => (props[key] !== undefined && props[key] !== '' ? props[key] : fallback);
const propInt = (key, min, max, fallback) => { const n = parseInt(props[key], 10); return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback; };
const propBool = (key, fallback) => /^(true|yes|on|1)$/i.test(props[key] || '') ? true : /^(false|no|off|0)$/i.test(props[key] || '') ? false : fallback;

// ---- The server's folder: all of this server's levels, named after the server ----
// e.g. Server/Claudecraft Official!/world.dat. (Only characters Windows can't use in folder
// names are left out.) Each .dat in it is a level players can /goto.
const safeFolderName = n => String(n).replace(/[<>:"/\\|?*\x00-\x1F]/g, '').trim().replace(/[. ]+$/, '').slice(0, 60) || 'Claudecraft server';
const LEVELS_DIR = path.join(__dirname, safeFolderName(process.env.SERVER_NAME || propText('server-name', 'Claudecraft server')));
fs.mkdirSync(LEVELS_DIR, { recursive: true });
const cleanLevelName = name => String(name).replace(/[^A-Za-z0-9 _-]/g, '').trim().slice(0, 40);
const levelPath = name => path.join(LEVELS_DIR, cleanLevelName(name) + '.dat');
// levels from before the server had its own folder move into it (nothing is overwritten)
const oldPlaces = [[path.join(__dirname, 'level.dat'), levelPath(propText('level-name', 'world'))],
    [path.join(__dirname, 'Hide and Seek.dat'), levelPath(propText('hide-and-seek-map', 'Hide and Seek'))]];
const oldLevelsDir = path.join(__dirname, 'levels');
if (fs.existsSync(oldLevelsDir) && oldLevelsDir !== LEVELS_DIR) {
    for (const f of fs.readdirSync(oldLevelsDir)) if (f.endsWith('.dat')) oldPlaces.push([path.join(oldLevelsDir, f), path.join(LEVELS_DIR, f)]);
}
for (const [oldPath, newPath] of oldPlaces) {
    if (fs.existsSync(oldPath) && !fs.existsSync(newPath)) {
        fs.renameSync(oldPath, newPath);
        console.log(`Moved ${path.basename(oldPath)} into ${path.basename(LEVELS_DIR)}/`);
    }
}
// The rules players agree to (/rules, /agree) before they can build
const RULES_FILE = path.join(__dirname, 'rules.txt');
if (!fs.existsSync(RULES_FILE)) {
    fs.writeFileSync(RULES_FILE, ['1. Be kind to everyone.', '2. Don\'t wreck other people\'s builds.', '3. No spamming the chat.', '4. Have fun!'].join('\n') + '\n');
}
const readRules = () => { try { return fs.readFileSync(RULES_FILE, 'utf8').split(/\r?\n/).map(l => l.trim()).filter(Boolean).slice(0, 15); } catch { return []; } };

// ---- Settings ----
const PORT = Number(process.env.PORT) || propInt('port', 1, 65535, 25565);
const GAME_FILE = process.env.GAME_FILE || [path.join(__dirname, 'game', 'main.js'), path.join(__dirname, '..', 'main.js')].find(f => fs.existsSync(f))
    || path.join(__dirname, 'game', 'main.js');
const LEVEL_FILE = levelPath(propText('level-name', 'world'));                    // world for Regular and Anarchy
const HIDE_SEEK_FILE = levelPath(propText('hide-and-seek-map', 'Hide and Seek'));  // map for Hide and Seek
const sizeSetting = Number(process.env.LEVEL_SIZE) || propInt('level-size', 64, 512, 256);
const NEW_LEVEL_SIZE = { w: sizeSetting, h: sizeSetting, d: sizeSetting };        // size of a newly generated world
const SAVE_EVERY_MS = propInt('autosave-minutes', 1, 120, 5) * 60 * 1000;
// Let people on the internet join: Cloudflare tunnel, or opening the port on your router (UPnP).
// PUBLIC=0 node server.js, or public=false in server.properties, keeps it to your home network.
const MAKE_PUBLIC = process.env.PUBLIC !== undefined ? process.env.PUBLIC !== '0' : propBool('public', true);
// Cloudflare tunnel: 'auto' uses it if cloudflared is installed, 'off' never does.
// (CLOUDFLARED=path\\to\\cloudflared.exe if it's somewhere unusual.)
const TUNNEL = (process.env.TUNNEL || 'auto').toLowerCase();
// Your server's name and description, shown on the website's Servers page
const SERVER_NAME = (process.env.SERVER_NAME || propText('server-name', 'Claudecraft server')).slice(0, 40);
const SERVER_DESCRIPTION = propText('description', '').slice(0, 120);
// Website: with a Neocities API key (Neocities -> Settings -> API, saved in neocities_key.txt in
// this folder, or NEOCITIES_API_KEY), the server posts its current join link to your website as
// server.json, so the Servers page always shows it
const NEOCITIES_API = process.env.NEOCITIES_API_URL || 'https://neocities.org/api/upload';
// The server owner: their nametag is yellow. Only given to someone playing from this computer,
// your home network, or your home internet connection (anyone else using the name is renamed).
const OWNER_NAME = (process.env.OWNER_NAME || propText('owner', '')).trim();
const PLAYERS_FILE = path.join(__dirname, 'players.json');     // everyone who has played here
// The Levels page: levels people saved, kept here (each level's .dat and thumbnail, and a list)
const GALLERY_DIR = path.join(__dirname, 'gallery');
fs.mkdirSync(GALLERY_DIR, { recursive: true });
const STATUS_EVERY_MS = 2 * 60 * 1000;    // the website treats a server as gone after 5 minutes without one
const MAX_PLAYERS = propInt('max-players', 1, 100, 16);        // bots count toward this
const REQUIRE_AGREE = propBool('require-agree', true);          // /agree to the rules before building
const MAX_BOTS = 10;
const MAX_NAME_LENGTH = 16;
const CHAT_MAX = 64;
const YELLOW = 0xFFFF55, GREEN = 0x55FF55, RED = 0xFF5555, AQUA = 0x55FFFF;

// Moderation limits (Regular and Minigame; Anarchy has none)
const MAX_BLOCK_CHANGES_PER_SECOND = 20;
const MAX_MESSAGES_PER_SECOND = 60;
const CHAT_PER_5_SECONDS = 5;

// Hide and Seek
const HS = {
    MIN_PLAYERS: 2,            // players needed to start a round
    HIDE_SECONDS: propInt('hide-seconds', 5, 600, 30),    // time hiders get before the seeker is released
    SEEK_SECONDS: propInt('seek-seconds', 30, 3600, 300), // time the seekers get to find everyone
    BREAK_SECONDS: 10,         // break between rounds
    FOUND_VIEW_SECONDS: 1.0,   // how long a hider must stay in a seeker's view to be found
    VIEW_DISTANCE: 32,         // seekers can't find anyone further away than this
    VIEW_HALF_ANGLE: 35,       // degrees either side of where the seeker looks
    FOUND_BECOME_SEEKERS: true // found hiders join the seekers
};

// ---- Shared game code ----
// main.js ends with "new Game();", which needs a browser, so that line is left out.
const gameSource = fs.readFileSync(GAME_FILE, 'utf8').replace(/^new Game\(\);\s*$/m, '');
const game = (new Function('require', gameSource +
    '\nreturn { Level, BLOCK, HOTBAR, BUILD_LIMIT_Y, PLAYER_HEIGHT, VERSION, encodeLevel, decodeLevel, Player, THREE,' +
    ' setMapSize: (w, h, d) => { MAP_WIDTH = w; MAP_HEIGHT = h; MAP_DEPTH = d; } };'))(require);
const { Level, BLOCK, HOTBAR, BUILD_LIMIT_Y, PLAYER_HEIGHT } = game;
// The server hands out this same main.js to players. Versions before 0.0.22a_08 can't follow a
// join link, so players opening the server's link would just get single player.
const GAME_JOINS_FROM_LINK = gameSource.includes('readJoinLink');
const PLACEABLE = new Set(HOTBAR);
const BREAKABLE = new Set(Object.values(BLOCK).filter(b => b !== BLOCK.AIR && b !== BLOCK.BEDROCK && b !== BLOCK.WATER && b !== BLOCK.LAVA));
const ALL_BLOCKS = new Set(Object.values(BLOCK));

// ---- Server mode ----
const MODES = {
    regular: { name: 'Regular', moderated: true, building: true, saves: true, levelFile: LEVEL_FILE },
    anarchy: { name: 'Anarchy', moderated: false, building: true, saves: true, levelFile: LEVEL_FILE },
    hideandseek: { name: 'Minigame: Hide and Seek', moderated: true, building: false, saves: false, levelFile: HIDE_SEEK_FILE,
        hideNametags: true, minigame: 'hideandseek' }
};
let mode = null;

async function chooseMode() {
    const arg = (process.argv[2] || process.env.MODE || propText('server-type', 'ask')).toLowerCase().replace(/[^a-z]/g, '');
    if (MODES[arg]) return arg;
    if (process.env.GUI) { console.log('server-type is "ask", but there\'s no console to ask in: starting a Regular server. Set server-type in server.properties.'); return 'regular'; }
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const ask = q => new Promise(resolve => rl.question(q, a => resolve(a.trim().toLowerCase())));
    let choice = null;
    while (!choice) {
        const a = await ask('Which kind of server?\n  1) Regular (with moderation)\n  2) Anarchy (zero moderation)\n  3) Minigame\n> ');
        if (a === '1' || a.startsWith('r')) choice = 'regular';
        else if (a === '2' || a.startsWith('a')) choice = 'anarchy';
        else if (a === '3' || a.startsWith('m')) {
            const b = await ask('Which minigame?\n  1) Hide and Seek\n> ');
            if (b === '1' || b.startsWith('h')) choice = 'hideandseek';
        }
    }
    rl.close();
    return choice;
}

// How many bots to add (for testing)
async function chooseBots() {
    const arg = process.argv[3] !== undefined ? process.argv[3] : process.env.BOTS !== undefined ? process.env.BOTS : propText('bots', 'ask');
    if (arg !== undefined && /^\d+$/.test(String(arg))) return Math.min(MAX_BOTS, Number(arg));
    if (process.env.GUI) return 0;
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const ask = q => new Promise(resolve => rl.question(q, a => resolve(a.trim())));
    let n = null;
    while (n === null) {
        const a = await ask(`How many bots? (0-${MAX_BOTS}, for testing)\n> `);
        if (/^\d+$/.test(a) && Number(a) <= MAX_BOTS) n = Number(a);
    }
    rl.close();
    return n;
}

let level = null;                // the main level (bots and Hide and Seek live here)
let lava = null;                 // Lava Survival (a level on servers that build)
let mainWorld = null;
const players = new Map();       // id -> { ws, id, name, x, y, z, rx, ry, joined, ... }
let nextId = 1;

// ---- Levels (worlds) ----
// A server can have several levels loaded at once, each with the players on it. Movement,
// building and flowing water only reach the players on the same level; chat reaches everyone.
const worlds = new Map();        // lower-case name -> { name, file, level, changed, ticking, changes }
const levelNames = () => {
    let names = [];
    try { names = fs.readdirSync(LEVELS_DIR).filter(f => f.toLowerCase().endsWith('.dat')).map(f => f.slice(0, -4)); } catch { /* none */ }
    for (const w of worlds.values()) if (w.noSave && !names.includes(w.name)) names.push(w.name);    // e.g. Lava Survival
    return names.sort();
};

// Open a level by name (case doesn't matter). create: make a new one if there's no file.
async function openWorld(name, create = false) {
    const key = cleanLevelName(name).toLowerCase();
    if (!key) return null;
    if (worlds.has(key)) return worlds.get(key);
    const fileName = levelNames().find(n => n.toLowerCase() === key);
    let lv, file;
    if (fileName) {
        file = path.join(LEVELS_DIR, fileName + '.dat');
        console.log('Loading', file);
        lv = await game.decodeLevel(new Blob([fs.readFileSync(file)]));
    } else if (create) {
        file = levelPath(name);
        const { w, h, d } = NEW_LEVEL_SIZE;
        if (mode.minigame) console.log(`"${path.basename(file)}" isn't in ${path.basename(LEVELS_DIR)}/, so using a generated level instead.`);
        console.log(`Generating a new ${w}x${h}x${d} level...`);
        lv = new Level(w, h, d);
    } else return null;
    const world = { name: fileName || cleanLevelName(name), file, level: null, changed: false, ticking: false, changes: [] };
    setWorldLevel(world, lv);
    // the Hide and Seek map plays Hide and Seek, on any kind of server
    // (a Hide and Seek server always plays it; other servers only if their minigames are switched on)
    world.isHideSeek = (mode.minigame || (propBool('minigames', true) && propBool('hide-and-seek-level', true))) &&
        cleanLevelName(world.name).toLowerCase() === cleanLevelName(propText('hide-and-seek-map', 'Hide and Seek')).toLowerCase();
    if (world.isHideSeek) hideSeek.world = world;
    worlds.set(key, world);
    if (!fileName && mode.saves) await saveWorld(world);
    console.log(`Level "${world.name}" ready: ${lv.width}x${lv.height}x${lv.depth}`);
    return world;
}

// ---- Level presets (for new levels made from the control panel) ----
const PRESETS = ['flat', 'normal', 'hills', 'mountains', 'islands', 'empty'];
function makePresetLevel(preset, size) {
    const w = size, h = size, d = Math.min(size, 128);
    if (preset === 'normal') return new Level(w, h, d);                 // the game's own terrain
    const blocks = new Uint8Array(w * h * d);
    const set = (x, y, z, b) => { blocks[(y * h + z) * w + x] = b; };
    const SEA = 31;                                                      // water up to here (like normal levels)
    // smooth random hills: a few layers of interpolated random values
    let seed = (Math.random() * 2 ** 31) | 0;
    const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
    const layer = cell => {
        const gw = Math.ceil(w / cell) + 2, gh = Math.ceil(h / cell) + 2, g = Array.from({ length: gw * gh }, rnd);
        const sm = t => t * t * (3 - 2 * t);
        return (x, z) => {
            const gx = x / cell, gz = z / cell, ix = Math.floor(gx), iz = Math.floor(gz), fx = sm(gx - ix), fz = sm(gz - iz);
            const v = (a, b) => g[b * gw + a];
            return (v(ix, iz) * (1 - fx) + v(ix + 1, iz) * fx) * (1 - fz) + (v(ix, iz + 1) * (1 - fx) + v(ix + 1, iz + 1) * fx) * fz;
        };
    };
    const big = layer(48), mid = layer(16), small = layer(6);
    const noise = (x, z) => big(x, z) * 0.6 + mid(x, z) * 0.3 + small(x, z) * 0.1;      // 0..1
    for (let z = 0; z < h; z++) for (let x = 0; x < w; x++) {
        let top;
        // flat: grass just above sea level, like normal land, so there's plenty of room to build
        // (half the level's height would put it at the build limit on bigger levels)
        if (preset === 'flat') top = Math.min(SEA + 1, Math.floor(d / 2));
        else if (preset === 'empty') top = 0;
        else if (preset === 'hills') top = Math.round(30 + noise(x, z) * 16);
        else if (preset === 'mountains') top = Math.round(26 + Math.pow(noise(x, z), 1.6) * (d * 0.55));
        else {                                                           // islands: several bits of land, open sea near the edges
            const dx = x / w - 0.5, dz = z / h - 0.5, edge = Math.min(1, Math.sqrt(dx * dx + dz * dz) * 2);
            top = Math.round(14 + (mid(x, z) * 0.6 + big(x, z) * 0.3 + small(x, z) * 0.1) * 36 - edge * edge * 12);
        }
        top = Math.max(1, Math.min(d - 2, top));
        set(x, 0, z, BLOCK.BEDROCK);
        if (preset === 'empty') continue;
        for (let y = 1; y <= top; y++) {
            const below = top - y;
            const beach = preset !== 'flat' && top <= SEA + 1;
            const peak = preset === 'mountains' && top > SEA + 20;             // bare stone up high
            set(x, y, z, below >= 4 || peak ? BLOCK.ROCK : beach ? BLOCK.SAND : below === 0 ? (top >= SEA || preset === 'flat' ? BLOCK.GRASS : BLOCK.DIRT) : BLOCK.DIRT);
        }
        if (preset !== 'flat') for (let y = top + 1; y <= SEA; y++) set(x, y, z, BLOCK.WATER);
    }
    if (preset === 'empty') {                                           // a small platform to start on
        const c = Math.floor(w / 2), cz = Math.floor(h / 2);
        for (let x = c - 4; x <= c + 4; x++) for (let z = cz - 4; z <= cz + 4; z++) set(x, 32, z, BLOCK.ROCK);
    }
    return new Level(w, h, d, blocks);
}

// Make a new level from a preset, or add an uploaded .dat, then tell everyone it's there
async function addLevel(name, { preset, size, dat }) {
    name = cleanLevelName(name);
    if (!name) return { error: 'Give the level a name (letters, numbers, spaces, - or _).' };
    if (levelNames().some(n => n.toLowerCase() === name.toLowerCase())) return { error: `There's already a level called "${name}".` };
    let lv;
    if (dat) {
        try { lv = await game.decodeLevel(new Blob([dat])); } catch { return { error: 'That file isn\'t a level the game can open.' }; }
    } else {
        if (!PRESETS.includes(preset)) return { error: 'Pick a preset.' };
        size = [64, 128, 256].includes(Number(size)) ? Number(size) : 128;
        console.log(`Making level "${name}" (${preset}, ${size}x${size})...`);
        lv = makePresetLevel(preset, size);
    }
    const file = levelPath(name);
    const blob = await encodeKeepingSpawn(lv);
    fs.writeFileSync(file, Buffer.from(await blob.arrayBuffer()));
    console.log(`Added level "${name}" (${lv.width}x${lv.height}x${lv.depth})`);
    announce(`Added level ${name}`, AQUA);
    return { message: `Added level "${name}". Players can go there with /goto ${name}.` };
}

// Put a level into a world (and send the changes its flowing water and lava make to its players)
function setWorldLevel(world, lv) {
    world.level = lv;
    world.changes = [];
    world.version = (world.version || 0) + 1;          // any change: the packed copy is out of date
    lv.addListener({ tileChanged: (x, y, z) => {
        if (world.level !== lv) return;
        world.version++;
        if (world.ticking) world.changes.push([x, y, z]);
    } });
}
// The level packed as a .dat for sending to players, reused until something on it changes
// (packing a big level pauses the whole server for a moment, so it's done as rarely as possible)
async function packWorld(world) {
    if (world.packed && world.packedVersion === world.version) return world.packed;
    const version = world.version;
    const blob = await encodeKeepingSpawn(world.level);
    world.packed = blob; world.packedVersion = version;
    return blob;
}
// A level that isn't a file of its own (Lava Survival): never saved
function makeWorld(name) {
    const world = { name, file: null, level: null, changed: false, ticking: false, changes: [], noSave: true };
    worlds.set(cleanLevelName(name).toLowerCase(), world);
    return world;
}

async function loadOrCreateLevel() {
    mainWorld = await openWorld(mode.minigame ? propText('hide-and-seek-map', 'Hide and Seek') : propText('level-name', 'world'), true);
    level = mainWorld.level;
}

// Save a level as a .dat, keeping its built-in spawn point (where players start)
function encodeKeepingSpawn(lv) {
    const sp = lv.savedPlayer;
    const who = sp ? { position: { x: sp.x, y: sp.y, z: sp.z }, rotation: { x: sp.rotX || 0, y: sp.rotY || 0 } } : null;
    return game.encodeLevel(lv, who);
}

async function saveWorld(world) {
    if (!mode.saves || world.noSave) return;
    const blob = await encodeKeepingSpawn(world.level);
    const tmp = world.file + '.tmp';
    fs.writeFileSync(tmp, Buffer.from(await blob.arrayBuffer()));
    fs.renameSync(tmp, world.file);   // replace in one step so a crash can't leave half a file
    world.changed = false;
    console.log(`Level "${world.name}" saved`);
    broadcastWorld(world, { t: 'chat', text: `Saved level ${world.name}`, color: 0xA0A0A0 });
}
async function saveAllWorlds() { for (const w of worlds.values()) if (w.changed) await saveWorld(w); }

// Spawn: the spot saved in the level file (e.g. the Hide and Seek hub), or the dry ground
// nearest the middle of the map
function findSpawn(level = mainWorld.level) {
    if (level.savedPlayer) return { ...level.savedPlayer };
    // No spawn saved in the level: stand on the ground near the middle. "The ground" is the most
    // common height of dry land around the middle, so you don't land on top of a tower or a tree.
    const cx = Math.floor(level.width / 2), cz = Math.floor(level.height / 2);
    const topAt = (x, z) => {
        for (let y = level.depth - 1; y > 0; y--) {
            const t = level.getTile(x, y, z);
            if (t === BLOCK.AIR) continue;
            return (t === BLOCK.WATER || t === BLOCK.LAVA || t === BLOCK.LEAVES) ? -1 : y;
        }
        return -1;
    };
    const R = Math.min(24, Math.floor(Math.min(level.width, level.height) / 2) - 1);
    const counts = new Map();
    for (let x = cx - R; x <= cx + R; x += 2) for (let z = cz - R; z <= cz + R; z += 2) {
        const y = topAt(x, z);
        if (y > 0) counts.set(y, (counts.get(y) || 0) + 1);
    }
    const ground = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];
    const max = Math.max(level.width, level.height) / 2;
    for (let r = 0; r < max; r++) {
        for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) {
            if (Math.abs(dx) !== r && Math.abs(dz) !== r) continue;
            const x = cx + dx, z = cz + dz;
            if (x < 0 || z < 0 || x >= level.width || z >= level.height) continue;
            const y = topAt(x, z);
            // the ground height (or anywhere dry, if this map has no common ground height)
            if (y > 0 && (!ground || y === ground[0]) && level.getTile(x, y + 1, z) === BLOCK.AIR && level.getTile(x, y + 2, z) === BLOCK.AIR) {
                return { x: x + 0.5, y: y + 1 + PLAYER_HEIGHT + 0.01, z: z + 0.5, rotX: 0, rotY: 0 };
            }
        }
    }
    return { x: cx + 0.5, y: level.depth - 1 + PLAYER_HEIGHT, z: cz + 0.5, rotX: 0, rotY: 0 };
}

// ---- The owner ----
// Who counts as "the server owner's own connection": this computer, a device on your home
// network, or (through the tunnel, where Cloudflare says who's really connecting) your home
// internet connection's public address.
const ownerAddresses = new Set((process.env.OWNER_IPS || '').split(',').map(a => a.trim()).filter(Boolean));
async function learnOwnerAddresses() {
    for (const url of ['https://api.ipify.org', 'https://api64.ipify.org']) {
        const ip = await new Promise(resolve => {
            const req = https.get(url, { timeout: 5000 }, res => { let b = ''; res.on('data', d => { b += d; }); res.on('end', () => resolve(b.trim())); });
            req.on('timeout', () => { req.destroy(); resolve(null); }); req.on('error', () => resolve(null));
        });
        if (ip && /^[0-9a-f.:]+$/i.test(ip)) ownerAddresses.add(ip);
    }
}
function isHomeAddress(ip) {
    ip = String(ip || '').replace(/^::ffff:/, '');
    if (ip === '127.0.0.1' || ip === '::1') return true;
    if (/^\d+\.\d+\.\d+\.\d+$/.test(ip)) {
        const [a, b] = ip.split('.').map(Number);
        return a === 10 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
    }
    return /^(fe80|fc|fd)/i.test(ip);           // IPv6 home-network addresses
}
// The part of an address that identifies a home connection: all of an IPv4 address, or the
// first half of an IPv6 one (the home network's prefix; the rest changes now and then for privacy)
function homeKey(ip) {
    ip = String(ip || '').trim().replace(/^::ffff:/, '').toLowerCase();
    if (!ip.includes(':')) return ip;
    // expand "::" so every address has 8 groups, then keep the first 4
    const [l, r = ''] = ip.split('::');
    const left = l ? l.split(':') : [], right = ip.includes('::') && r ? r.split(':') : [];
    const groups = ip.includes('::') ? [...left, ...Array(8 - left.length - right.length).fill('0'), ...right] : ip.split(':');
    return groups.slice(0, 4).map(g => parseInt(g || '0', 16).toString(16)).join(':') + '::/64';
}
function canBeOwner(req) {
    const viaTunnel = req.headers['cf-connecting-ip'];
    if (viaTunnel) {
        const key = homeKey(viaTunnel);
        return [...ownerAddresses].some(a => homeKey(a) === key);
    }
    return isHomeAddress(req.socket.remoteAddress);
}

// ---- Everyone who has played (shown on the website's Players page) ----
let playerDb = {};
try { playerDb = JSON.parse(fs.readFileSync(PLAYERS_FILE, 'utf8')) || {}; } catch { playerDb = {}; }
const isGuestName = name => /^(Guest|Player)\d+$/.test(name);
function recordPlayer(p) {
    if (p.bot || isGuestName(p.name)) return;
    const key = p.name.toLowerCase(), now = new Date().toISOString();
    const before = playerDb[key] || {};
    const skinHash = p.skin ? require('crypto').createHash('sha1').update(p.skin).digest('hex').slice(0, 12) : null;
    playerDb[key] = { name: p.name, owner: !!p.owner || before.owner || false,
        firstSeen: before.firstSeen || now, lastSeen: now, skin: skinHash, agreed: !!(before.agreed || p.agreed),
        rank: before.rank || 'player', banned: !!before.banned, lastPos: before.lastPos };
    // a new or changed skin: put a copy on the website for the Players page
    if (skinHash && skinHash !== before.skin) uploadFileToWebsite(`skins/${key}.png`, Buffer.from(p.skin.slice(22), 'base64'), 'image/png');
    try { fs.writeFileSync(PLAYERS_FILE, JSON.stringify(playerDb, null, 2)); } catch (err) { console.error('Couldn\'t save players.json:', err.message); }
    publishPlayersSoon();
}

// ---- Skins ----
// A skin arrives as a small PNG (a data: address). Only real PNG images of 64x32 or 64x64,
// under about 28 KB, are accepted.
function cleanSkin(s) {
    if (typeof s !== 'string' || !s.startsWith('data:image/png;base64,') || s.length > 40000) return null;
    const png = Buffer.from(s.slice(22), 'base64');
    if (png.length < 24 || png.toString('hex', 0, 8) !== '89504e470d0a1a0a' || png.toString('ascii', 12, 16) !== 'IHDR') return null;
    const w = png.readUInt32BE(16), h = png.readUInt32BE(20);
    return w === 64 && (h === 32 || h === 64) ? s : null;
}

// ---- Sending ----
const send = (p, msg) => {
    if (p.bot) { p.onMessage(msg); return; }           // bots get messages directly
    if (p.ws.readyState === 1) p.ws.send(JSON.stringify(msg));
};
const joinedPlayers = () => [...players.values()].filter(p => p.joined);
const broadcast = (msg, except) => { for (const p of joinedPlayers()) if (p !== except) send(p, msg); };
// only the players on one level
const worldPlayers = world => joinedPlayers().filter(p => p.world === world);
// what's allowed on the level a player is on (no building and hidden nametags in Hide and Seek)
const canBuildHere = p => mode.building && p.agreed && !(p.world && p.world.isHideSeek) && !(p.world && p.world.isLava && !(lava && lava.canBuild(p)));
const nametagsHiddenHere = p => !!mode.hideNametags || !!(p.world && p.world.isHideSeek);
const broadcastWorld = (world, msg, except) => { for (const p of worldPlayers(world)) if (p !== except) send(p, msg); };
const announce = (text, color = YELLOW) => { broadcast({ t: 'chat', text, color }); console.log('[' + text + ']'); };
// ---- Ranks: Owner > Admin > Mod > Player. Each has its own nametag and chat colour. ----
const RANKS = ['player', 'mod', 'admin', 'owner'];
const RANK_INFO = {
    player: { title: 'Player', color: 0xFFFFFF },
    mod: { title: 'Mod', color: 0x55FF55 },          // can /kick
    admin: { title: 'Admin', color: 0xFF5555 },      // can also /ban, /unban and give out Player/Mod
    owner: { title: 'Owner', color: 0xFFFF55 }       // everything
};
const rankOf = p => p.bot ? 'player' : p.owner ? 'owner' : ((playerDb[String(p.name).toLowerCase()] || {}).rank || 'player');
const rankAtLeast = (p, r) => RANKS.indexOf(rankOf(p)) >= RANKS.indexOf(r);
// Blocks a player can place beyond the usual nine: Admins and the Owner get water, lava and the
// ores; on Anarchy servers everyone gets water and lava
const STAFF_BLOCKS = [BLOCK.WATER, BLOCK.LAVA, BLOCK.COAL_ORE, BLOCK.IRON_ORE, BLOCK.GOLD_ORE];
function extraBlocksFor(p) {
    if (!mode.building || p.bot) return [];
    let list = rankAtLeast(p, 'admin') ? STAFF_BLOCKS.slice() : !mode.moderated ? [BLOCK.WATER, BLOCK.LAVA] : [];
    // Lava Survival: nobody places water or lava (not even Admins and the Owner)
    if (p.world && p.world.isLava) list = list.filter(b => b !== BLOCK.WATER && b !== BLOCK.LAVA);
    return list;
}
const playerInfo = p => ({ id: p.id, name: p.name, owner: !!p.owner, tagColor: RANK_INFO[rankOf(p)].color,
    skin: p.skin || undefined, x: p.x, y: p.y, z: p.z, rx: p.rx, ry: p.ry });
const teleport = (p, s) => {
    Object.assign(p, { x: s.x, y: s.y, z: s.z, rx: s.rotX || 0, ry: s.rotY || 0 });
    send(p, { t: 'teleport', x: s.x, y: s.y, z: s.z, rx: s.rotX || 0, ry: s.rotY || 0 });
};

// ---- Receiving ----
function cleanName(name) {
    const s = String(name || '').replace(/[^\x20-\x7E]/g, '').trim().slice(0, MAX_NAME_LENGTH);
    return s || 'Player';
}
const isNum = v => typeof v === 'number' && Number.isFinite(v);
const isInt = v => Number.isInteger(v);

async function onHello(p, msg) {
    if (p.joined) return;
    if (joinedPlayers().length >= MAX_PLAYERS) {
        send(p, { t: 'kick', reason: 'The server is full' });
        p.ws.close();
        return;
    }
    // names must be unique, so add a number if someone already has it
    let name = cleanName(msg.name), n = 2;
    // the owner's name: only for the owner's own connection
    if (name.toLowerCase() === OWNER_NAME.toLowerCase()) {
        if (p.canBeOwner && !joinedPlayers().some(o => o.owner)) { name = OWNER_NAME; p.owner = true; }
        else {
            name = 'Guest' + Math.floor(100 + Math.random() * 900);
            p.renamedFromOwner = true;
            console.log(`Someone tried to join as ${OWNER_NAME} from ${p.address || 'an unknown address'}, which isn't this computer, ` +
                `your home network or your home internet (${[...ownerAddresses].join(', ') || 'not looked up yet'}). Renamed to ${name}.`);
        }
    }
    while (joinedPlayers().some(o => o.name === name)) name = cleanName(msg.name).slice(0, MAX_NAME_LENGTH - 2) + n++;
    if ((playerDb[name.toLowerCase()] || {}).banned) {
        send(p, { t: 'kick', reason: 'You are banned from this server' });
        console.log(`${name} tried to join but is banned`);
        p.ws.close();
        return;
    }
    p.name = name;
    p.skin = cleanSkin(msg.skin);
    p.world = mainWorld;
    // Everyone starts on the main map. If you left while on the main map, you're back where you
    // were (and looking the same way); if you left from another level, you start at the spawn.
    const lastPos = !mode.minigame && (playerDb[p.name.toLowerCase()] || {}).lastPos;
    let returning = null;
    if (lastPos && String(lastPos.level).toLowerCase() === mainWorld.name.toLowerCase() &&
        [lastPos.x, lastPos.y, lastPos.z, lastPos.rx, lastPos.ry].every(isNum)) {
        const w = mainWorld;
        {
            const lv = w.level;
            returning = { x: Math.max(0.5, Math.min(lv.width - 0.5, lastPos.x)), y: Math.max(1, Math.min(lv.depth + 8, lastPos.y)),
                z: Math.max(0.5, Math.min(lv.height - 0.5, lastPos.z)), rotX: lastPos.rx, rotY: lastPos.ry };
        }
    }
    // the rules: a player who hasn't agreed yet can't build (bots and earlier agreers can)
    p.agreed = !REQUIRE_AGREE || !!p.owner || !!(playerDb[p.name.toLowerCase()] && playerDb[p.name.toLowerCase()].agreed);   // (the owner made the rules)
    const spawn = returning || findSpawn(p.world.level);
    Object.assign(p, { x: spawn.x, y: spawn.y, z: spawn.z, rx: spawn.rotX || 0, ry: spawn.rotY || 0 });
    send(p, { t: 'welcome', id: p.id, name: p.name, spawn, version: game.VERSION, serverVersion: SERVER_VERSION,
        serverName: SERVER_NAME, description: SERVER_DESCRIPTION, respawn: respawnFor(p, p.world),
        liquids: mode.building && !mode.moderated,            // Anarchy: water and lava blocks to place
        extraBlocks: extraBlocksFor(p),                       // blocks beyond the usual nine (by rank)
        features: SERVER_FEATURES, mode: mode.name, building: canBuildHere(p), hideNametags: nametagsHiddenHere(p),
        level: p.world.name });
    // the level, as a .dat file, sent as one binary message
    const blob = await packWorld(p.world);
    if (p.ws.readyState !== 1) return;
    p.ws.send(Buffer.from(await blob.arrayBuffer()));
    send(p, { t: 'players', list: worldPlayers(p.world).map(playerInfo) });
    p.joined = true;
    broadcastWorld(p.world, { t: 'join', ...playerInfo(p) }, p);
    announce(`${p.name} joined the game`);
    if (p.owner) announce(`${p.name} is the server owner`, YELLOW);
    if (p.renamedFromOwner) send(p, { t: 'chat', text: `That name belongs to the server owner, so you're ${p.name} here.`, color: YELLOW });
    recordPlayer(p);
    publishSoon();
    send(p, { t: 'chat', text: `Welcome to ${SERVER_NAME}! You're on "${p.world.name}". Type /help for commands.`, color: AQUA });
    if (!p.agreed && mode.building) showRules(p, true);
    botsGreet(p);
    if (p.world.isHideSeek) hideSeek.onJoin(p);
}

function onMove(p, msg) {
    if (!p.joined || ![msg.x, msg.y, msg.z, msg.rx, msg.ry].every(isNum)) return;
    // keep positions inside (or just around) the map
    const lv = p.world.level;
    p.x = Math.max(-1, Math.min(lv.width + 1, msg.x));
    p.y = Math.max(-64, Math.min(lv.depth + 64, msg.y));
    p.z = Math.max(-1, Math.min(lv.height + 1, msg.z));
    p.rx = Math.max(-1.6, Math.min(1.6, msg.rx));
    p.ry = msg.ry % (Math.PI * 2);
    broadcastWorld(p.world, { t: 'move', id: p.id, x: p.x, y: p.y, z: p.z, rx: p.rx, ry: p.ry }, p);
}

// Remove a whole connected body of water or lava (owner only: placing that liquid into it).
// It's done in parts so a huge flood doesn't freeze the server, and sent in bundles.
const DRAIN_MAX = 250000;
async function drainLiquid(p, x0, y0, z0, liquid) {
    const world = p.world, lv = world.level, W = lv.width, H = lv.height, D = lv.depth;
    if (world.draining) { tell(p, 'Still removing the last one...', YELLOW); return; }
    world.draining = true;
    const name = liquid === BLOCK.WATER ? 'water' : 'lava';
    try {
        // find the connected blocks first (marking them so none is counted twice)
        const seen = new Uint8Array(W * H * D), found = [];
        const idx = (x, y, z) => (y * H + z) * W + x;
        const queue = [x0, y0, z0]; seen[idx(x0, y0, z0)] = 1;
        for (let q = 0; q < queue.length && found.length < DRAIN_MAX * 3; q += 3) {
            const x = queue[q], y = queue[q + 1], z = queue[q + 2];
            found.push(x, y, z);
            for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
                const nx = x + dx, ny = y + dy, nz = z + dz;
                if (nx < 0 || ny < 0 || nz < 0 || nx >= W || ny >= D || nz >= H) continue;
                const k = idx(nx, ny, nz);
                if (seen[k] || lv.getTile(nx, ny, nz) !== liquid) continue;
                seen[k] = 1; queue.push(nx, ny, nz);
            }
            if (queue.length > 3 * 3000000) break;          // (never runs away on a giant sea)
        }
        // then remove them, a part at a time, telling everyone on the level in bundles
        let removed = 0;
        for (let i = 0; i < found.length; i += 3 * 5000) {
            const list = [];
            for (let j = i; j < Math.min(found.length, i + 3 * 5000); j += 3) {
                const x = found[j], y = found[j + 1], z = found[j + 2];
                if (lv.getTile(x, y, z) !== liquid) continue;
                lv.setTile(x, y, z, BLOCK.AIR);
                list.push(x, y, z, BLOCK.AIR);
                removed++;
            }
            if (list.length) broadcastWorld(world, { t: 'sets', list });
            await new Promise(r => setImmediate(r));        // let everything else run in between
        }
        world.changed = true;
        const more = found.length / 3 >= DRAIN_MAX ? ` (the most at once: place ${name} in it again to remove more)` : '';
        tell(p, `Removed ${removed.toLocaleString('en-US')} ${name} blocks${more}`, GREEN);
        console.log(`${p.name} removed ${removed} ${name} blocks on "${world.name}"`);
    } finally { world.draining = false; }
}

function onSetBlock(p, msg) {
    if (!p.joined) return;
    const { x, y, z, b } = msg;
    if (![x, y, z, b].every(isInt)) return;
    const level = p.world.level;        // the level this player is on
    if (x < 0 || z < 0 || y < 0 || x >= level.width || z >= level.height || y >= level.depth) return;
    const current = level.getTile(x, y, z);
    // The owner placing water into water (or lava into lava) removes all of it that's connected
    if (p.owner && (b === BLOCK.WATER || b === BLOCK.LAVA) && current === b && p.agreed && mode.building && !p.world.isLava) {
        drainLiquid(p, x, y, z, b).catch(err => console.error('Draining failed:', err));
        return;
    }
    let allowed;
    if (!p.agreed) {
        allowed = false;                                   // hasn't agreed to the rules yet
        const now = Date.now();
        if (now - (p.rulesNagAt || 0) > 5000) { p.rulesNagAt = now; send(p, { t: 'chat', text: 'Type /agree to accept the rules before building. (/rules to read them)', color: YELLOW }); }
    } else if (!mode.building || p.world.isHideSeek || (p.world.isLava && !lava.canBuild(p))) {
        allowed = false;                                   // minigames: the map can't be changed (Lava Survival: only while playing)
        // Lava Survival: say why (now and then, not on every click)
        const why = p.world.isLava && lava.whyNoBuilding(p);
        const now = Date.now();
        if (why && now - (p.lavaNagAt || 0) > 4000) { p.lavaNagAt = now; send(p, { t: 'chat', text: why, color: YELLOW }); }
    } else if (!mode.moderated) {
        allowed = ALL_BLOCKS.has(b);                       // anarchy: any real block, anywhere
    } else {
        const now = Date.now();
        p.blockBudget = Math.min(MAX_BLOCK_CHANGES_PER_SECOND, p.blockBudget + (now - p.blockBudgetAt) / 1000 * MAX_BLOCK_CHANGES_PER_SECOND);
        p.blockBudgetAt = now;
        // never a solid block inside someone (saplings are fine: they can be walked through)
        const extra = extraBlocksFor(p).includes(b);
        const liquid = b === BLOCK.WATER || b === BLOCK.LAVA;
        const inSomeone = b !== BLOCK.AIR && b !== BLOCK.SAPLING && !liquid && worldPlayers(p.world).some(o =>
            x + 1 > o.x - 0.3 && x < o.x + 0.3 && z + 1 > o.z - 0.3 && z < o.z + 0.3 && y + 1 > o.y - PLAYER_HEIGHT && y < o.y + 0.1);
        allowed = !inSomeone && y >= 1 && p.blockBudget >= 1 && (
            (b === BLOCK.AIR && BREAKABLE.has(current)) ||
            ((PLACEABLE.has(b) || extra) && y <= BUILD_LIMIT_Y && (current === BLOCK.AIR || current === BLOCK.WATER || current === BLOCK.LAVA)));
        if (allowed) p.blockBudget -= 1;
    }
    if (!allowed) {
        send(p, { t: 'set', x, y, z, b: current });   // undo it on their screen
        return;
    }
    level.setTile(x, y, z, b);
    p.world.changed = true;
    broadcastWorld(p.world, { t: 'set', x, y, z, b });
    if (p.world.isLava && b !== BLOCK.AIR) lava.onBlockPlaced(p, x, y, z);
}

function onSkin(p, msg) {
    if (!p.joined) return;
    const now = Date.now();
    if (now - (p.skinAt || 0) < 3000) return;            // not too often
    p.skinAt = now;
    p.skin = cleanSkin(msg.skin);
    broadcastWorld(p.world, { t: 'skin', id: p.id, skin: p.skin || undefined }, p);
    recordPlayer(p);
}

// ---- Commands (typed in chat, starting with /) ----
const tell = (p, text, color = AQUA) => send(p, { t: 'chat', text, color });

function showRules(p, firstTime) {
    const rules = readRules();
    tell(p, `Rules of ${SERVER_NAME}:`, YELLOW);
    for (const line of rules) tell(p, line, 0xFFFFFF);
    if (!p.agreed) tell(p, firstTime ? 'Type /agree to accept the rules and start building.' : 'Type /agree to accept them.', YELLOW);
}

// Remember where a player is (level, position, where they're looking) for next time
// A level's spawn point (R takes players there; spots set with Y stay in their own game only)
function respawnFor(p, world) { return findSpawn(world.level); }

function rememberPosition(p) {
    if (p.bot || mode.minigame || !p.world || !p.joined) return;
    const entry = playerDb[String(p.name).toLowerCase()];
    if (!entry || ![p.x, p.y, p.z, p.rx, p.ry].every(isNum)) return;
    entry.lastPos = { level: p.world.name, x: p.x, y: p.y, z: p.z, rx: p.rx, ry: p.ry };
}
const savePlayerDb = () => { try { fs.writeFileSync(PLAYERS_FILE, JSON.stringify(playerDb, null, 2)); } catch (err) { console.error('Couldn\'t save players.json:', err.message); } };
const findOnline = name => joinedPlayers().find(o => !o.bot && o.name.toLowerCase() === String(name).toLowerCase());

// Give someone a rank (by: who's doing it, or null for the control panel). Returns a message.
function setRank(by, name, rank) {
    rank = String(rank || '').toLowerCase();
    if (!RANKS.includes(rank) || rank === 'owner') return { error: 'Ranks you can give: player, mod, admin.' };
    const key = String(name).toLowerCase();
    if (!playerDb[key]) return { error: `Nobody called "${name}" has played here.` };
    if (key === OWNER_NAME.toLowerCase()) return { error: 'The owner\'s rank can\'t change.' };
    // Admins can only give Player or Mod, and can't change other Admins
    if (by && !rankAtLeast(by, 'owner') && (rank === 'admin' || playerDb[key].rank === 'admin')) return { error: 'Only the owner can make or change Admins.' };
    playerDb[key].rank = rank;
    savePlayerDb();
    const online = findOnline(name);
    if (online) {
        send(online, { t: 'extraBlocks', list: extraBlocksFor(online) });
        broadcastWorld(online.world, { t: 'rank', id: online.id, tagColor: RANK_INFO[rank].color }, online);
        tell(online, `You're now ${RANK_INFO[rank].title}.`, RANK_INFO[rank].color);
    }
    console.log(`${playerDb[key].name} is now ${RANK_INFO[rank].title}` + (by ? ` (by ${by.name})` : ' (from the control panel)'));
    return { message: `${playerDb[key].name} is now ${RANK_INFO[rank].title}.` };
}
function kickPlayer(by, name, reason) {
    const target = findOnline(name);
    if (!target) return { error: `${name} isn't online.` };
    if (target.owner || (by && RANKS.indexOf(rankOf(target)) >= RANKS.indexOf(rankOf(by)))) return { error: 'You can\'t kick someone of your rank or higher.' };
    send(target, { t: 'kick', reason: reason || 'Kicked from the server' });
    setTimeout(() => target.ws.close(), 200);
    announce(`${target.name} was kicked` + (reason ? `: ${reason}` : ''), RED);
    return { message: `Kicked ${target.name}.` };
}
function banPlayer(by, name, banned) {
    const key = String(name).toLowerCase();
    if (!playerDb[key]) return { error: `Nobody called "${name}" has played here.` };
    if (key === OWNER_NAME.toLowerCase()) return { error: 'The owner can\'t be banned.' };
    if (by && banned && RANKS.indexOf(playerDb[key].rank || 'player') >= RANKS.indexOf(rankOf(by))) return { error: 'You can\'t ban someone of your rank or higher.' };
    playerDb[key].banned = banned;
    savePlayerDb();
    if (banned && findOnline(name)) kickPlayer(null, name, 'You are banned from this server');
    console.log(`${playerDb[key].name} was ${banned ? 'banned' : 'unbanned'}` + (by ? ` by ${by.name}` : ' from the control panel'));
    return { message: `${playerDb[key].name} is ${banned ? 'banned' : 'no longer banned'}.` };
}

async function onCommand(p, text) {
    const [cmd, ...rest] = text.slice(1).split(/\s+/);
    const arg = rest.join(' ').trim();
    console.log(`<${p.name}> ${text}`);
    switch ((cmd || '').toLowerCase()) {
        case 'help': {
            let list = '/goto <level>, /levels, /who, /rules, /agree';
            if (p.world && p.world.isLava) list += ', /skip (vote to start the lava now)';
            if (rankAtLeast(p, 'mod')) list += ', /kick <name>';
            if (rankAtLeast(p, 'admin')) list += ', /ban <name>, /unban <name>, /rank <name> <player|mod' + (rankAtLeast(p, 'owner') ? '|admin' : '') + '>';
            tell(p, 'Commands: ' + list);
            break;
        }
        case 'who':
            tell(p, 'Online: ' + joinedPlayers().map(o => o.name + (rankOf(o) === 'player' ? '' : ' (' + RANK_INFO[rankOf(o)].title + ')') + ' on ' + o.world.name).join(', '));
            break;
        case 'kick': case 'ban': case 'unban': case 'rank': {
            const need = cmd.toLowerCase() === 'kick' ? 'mod' : 'admin';
            if (!rankAtLeast(p, need)) { tell(p, `You need to be ${RANK_INFO[need].title} or higher for /${cmd}.`, RED); break; }
            const [who, ...more] = rest;
            if (!who) { tell(p, `Who? Type /${cmd} <name>` + (cmd.toLowerCase() === 'rank' ? ' <player|mod|admin>' : ''), YELLOW); break; }
            const c = cmd.toLowerCase();
            const out = c === 'kick' ? kickPlayer(p, who, more.join(' ')) : c === 'rank' ? setRank(p, who, more[0]) : banPlayer(p, who, c === 'ban');
            tell(p, out.error || out.message, out.error ? RED : GREEN);
            break;
        }
        case 'levels': {
            const names = levelNames();
            tell(p, 'Levels: ' + names.map(n => n.toLowerCase() === p.world.name.toLowerCase() ? n + ' (you\'re here)' : n).join(', '));
            break;
        }
        case 'rules':
            showRules(p, false);
            break;
        case 'agree':
            if (p.agreed) { tell(p, 'You\'ve already agreed to the rules.'); break; }
            p.agreed = true;
            if (!p.bot) { const key = p.name.toLowerCase(); if (playerDb[key]) { playerDb[key].agreed = true; try { fs.writeFileSync(PLAYERS_FILE, JSON.stringify(playerDb, null, 2)); } catch { /* next save */ } } }
            send(p, { t: 'canBuild', on: canBuildHere(p) });
            tell(p, 'Thanks! You can build now.', GREEN);
            break;
        case 'goto':
            await gotoLevel(p, arg);
            break;
        case 'skip':
            if (p.world && p.world.isLava && lava) lava.skip(p);
            else tell(p, '/skip only works in Lava Survival.', RED);
            break;
        default:
            tell(p, `Unknown command "/${cmd}". Type /help for commands.`, RED);
    }
}

// Send a player the level of a world they're on: "Going to <title>", the level, who's there
async function sendLevelTo(p, world, title) {
    const spawn = findSpawn(world.level);
    Object.assign(p, { x: spawn.x, y: spawn.y, z: spawn.z, rx: spawn.rotX || 0, ry: spawn.rotY || 0 });
    send(p, { t: 'changeLevel', name: title, spawn, respawn: respawnFor(p, world) });
    const blob = await packWorld(world);
    if (p.ws.readyState !== 1) return;
    p.ws.send(Buffer.from(await blob.arrayBuffer()));
    send(p, { t: 'players', list: worldPlayers(world).filter(o => o !== p).map(playerInfo) });
    send(p, { t: 'levelRules', building: canBuildHere(p), hideNametags: nametagsHiddenHere(p) });
    send(p, { t: 'extraBlocks', list: extraBlocksFor(p) });          // e.g. no water or lava in Lava Survival
}

// /goto: move a player to another level on this server (they stay connected; chat stays shared)
async function gotoLevel(p, name) {
    if (mode.minigame) { tell(p, 'You can\'t change levels during a minigame.', RED); return; }
    if (!name) { tell(p, 'Which level? Type /goto <level>. (/levels lists them)', YELLOW); return; }
    const target = await openWorld(name, false);
    if (!target) { tell(p, `There's no level called "${name}". Levels: ${levelNames().join(', ')}`, RED); return; }
    if (target === p.world) { tell(p, `You're already on "${target.name}".`); return; }
    if (!p.joined || p.ws.readyState !== 1) return;
    broadcastWorld(p.world, { t: 'leave', id: p.id }, p);            // gone from the old level
    if (p.world.isHideSeek) { hideSeek.onLeave(p); send(p, { t: 'freeze', on: false }); }
    if (p.world.isLava) lava.onLeave(p);
    p.world = target;
    await sendLevelTo(p, target, target.name);
    broadcastWorld(target, { t: 'join', ...playerInfo(p) }, p);       // arrives on the new level
    if (target.isHideSeek) hideSeek.onJoin(p);
    if (target.isLava) lava.onJoin(p);
    announce(`${p.name} went to ${target.name}`, AQUA);
}

function onChat(p, msg) {
    if (!p.joined) return;
    const text = String(msg.text || '').replace(/[^\x20-\x7E]/g, '').trim().slice(0, CHAT_MAX);
    if (!text) return;
    if (text.startsWith('/')) { onCommand(p, text).catch(err => console.error('Command error:', err)); return; }
    if (p.world && p.world.isLava && lava && lava.onChat(p, text)) return;          // a map vote
    if (mode.moderated) {
        // at most CHAT_PER_5_SECONDS messages in any 5 seconds
        const now = Date.now();
        p.chatTimes = (p.chatTimes || []).filter(t => now - t < 5000);
        if (p.chatTimes.length >= CHAT_PER_5_SECONDS) {
            send(p, { t: 'chat', text: 'You are sending messages too fast', color: YELLOW });
            return;
        }
        p.chatTimes.push(now);
    }
    const rank = rankOf(p);
    broadcast({ t: 'chat', text: (rank === 'player' ? '' : `[${RANK_INFO[rank].title}] `) + `${p.name}: ${text}`, color: RANK_INFO[rank].color });
    console.log(`<${p.name}> ${text}`);
    botsHear(p, text);                // bots may answer
}

// ============================================================
// HIDE AND SEEK
// Rounds: everyone is sent to spawn, a random seeker is picked and frozen with a black screen
// while the hiders hide, chat counts down 3, 2, 1, then the seekers hunt. A hider is found by
// staying in a seeker's view (close enough, inside their field of view, nothing in the way)
// for FOUND_VIEW_SECONDS. Seekers win if everyone is found, hiders win if time runs out.
// ============================================================
const hideSeek = {
    world: null,               // the Hide and Seek level (the whole server, or one level on a normal server)
    players() { return this.world ? worldPlayers(this.world) : []; },
    // game messages only go to the players on that level
    say(text, color = YELLOW) { if (this.world) broadcastWorld(this.world, { t: 'chat', text, color }); console.log('[Hide and Seek] ' + text); },
    state: 'waiting',          // waiting | starting | hiding | seeking | over
    seekers: new Set(), hiders: new Set(), inRound: new Set(),
    endsAt: 0, lastCountdown: null, viewTime: new Map(), lastSeekerId: null,

    onJoin(p) {
        if (this.state === 'hiding' || this.state === 'seeking') {
            send(p, { t: 'chat', text: 'A round is in progress. You\'ll join the next one.', color: AQUA });
        } else {
            send(p, { t: 'chat', text: `Hide and Seek: rounds start with at least ${HS.MIN_PLAYERS} players.`, color: AQUA });
        }
    },

    onLeave(p) {
        const wasSeeker = this.seekers.delete(p.id);
        const wasHider = this.hiders.delete(p.id);
        this.inRound.delete(p.id);
        this.viewTime.delete(p.id);
        if (this.state !== 'hiding' && this.state !== 'seeking') return;
        if (wasSeeker && this.seekers.size === 0) this.endRound(`The seeker left! Hiders win.`, GREEN);
        else if (wasHider && this.hiders.size === 0) this.endRound('No hiders left. Seekers win!', GREEN);
    },

    names(ids) { return [...ids].map(id => players.get(id)).filter(Boolean).map(p => p.name).join(', '); },

    startRound() {
        const list = this.players();
        if (list.length < HS.MIN_PLAYERS) { this.state = 'waiting'; return; }
        // pick a seeker at random, avoiding last round's first seeker when possible
        const choices = list.length > 1 ? list.filter(p => p.id !== this.lastSeekerId) : list;
        const seeker = choices[Math.floor(Math.random() * choices.length)];
        this.lastSeekerId = seeker.id;
        this.seekers = new Set([seeker.id]);
        this.hiders = new Set(list.filter(p => p !== seeker).map(p => p.id));
        this.inRound = new Set(list.map(p => p.id));
        this.viewTime.clear();
        this.roundId = (this.roundId || 0) + 1;
        const spawn = findSpawn(this.world.level);
        for (const p of list) teleport(p, spawn);
        send(seeker, { t: 'freeze', on: true, blind: true, text: 'You are the seeker! Wait while the others hide...' });
        this.state = 'hiding';
        this.endsAt = Date.now() + HS.HIDE_SECONDS * 1000;
        this.lastCountdown = null;
        this.say(`A new round of Hide and Seek is starting!`, AQUA);
        this.say(`${seeker.name} is the seeker!`, RED);
        this.say(`Hiders, you have ${HS.HIDE_SECONDS} seconds to hide!`);
    },

    releaseSeekers() {
        for (const id of this.seekers) { const p = players.get(id); if (p) send(p, { t: 'freeze', on: false }); }
        this.state = 'seeking';
        this.endsAt = Date.now() + HS.SEEK_SECONDS * 1000;
        this.lastCountdown = null;
        this.say(`Ready or not, here comes ${this.names(this.seekers)}!`, RED);
    },

    endRound(text, color = GREEN) {
        for (const id of this.seekers) { const p = players.get(id); if (p) send(p, { t: 'freeze', on: false }); }
        this.say(text, color);
        this.state = 'over';
        this.endsAt = Date.now() + HS.BREAK_SECONDS * 1000;
        this.lastCountdown = null;
        this.say(`Next round in ${HS.BREAK_SECONDS} seconds.`);
    },

    // Can this seeker see this hider right now? (distance, field of view, line of sight)
    canSee(seeker, hider, halfAngle = HS.VIEW_HALF_ANGLE) {
        const dir = [-Math.sin(seeker.ry) * Math.cos(seeker.rx), Math.sin(seeker.rx), -Math.cos(seeker.ry) * Math.cos(seeker.rx)];
        const cosLimit = Math.cos(halfAngle * Math.PI / 180);
        // check the hider's feet, middle and head: seeing any of them counts
        for (const dy of [-PLAYER_HEIGHT + 0.3, -0.8, 0]) {
            const tx = hider.x - seeker.x, ty = hider.y + dy - seeker.y, tz = hider.z - seeker.z;
            const dist = Math.hypot(tx, ty, tz);
            if (dist > HS.VIEW_DISTANCE || dist < 0.01) continue;
            if ((tx * dir[0] + ty * dir[1] + tz * dir[2]) / dist < cosLimit) continue;
            // walk along the line: any solid block (leaves too) blocks the view
            let blocked = false;
            for (let s = 0.3; s < dist - 0.3; s += 0.25) {
                const k = s / dist;
                if (this.world.level.isSolidTile(Math.floor(seeker.x + tx * k), Math.floor(seeker.y + ty * k), Math.floor(seeker.z + tz * k))) { blocked = true; break; }
            }
            if (!blocked) return true;
        }
        return false;
    },

    // Countdown messages: the last 3, 2, 1 seconds of a phase (plus a few earlier warnings)
    countdown(secondsLeft, marks, say) {
        const s = Math.ceil(secondsLeft);
        if (s !== this.lastCountdown && marks.includes(s)) { this.lastCountdown = s; say(s); }
    },

    tick(dt) {
        const now = Date.now(), left = (this.endsAt - now) / 1000;
        if (this.state === 'waiting') {
            if (this.players().length >= HS.MIN_PLAYERS) {
                this.state = 'starting';
                this.endsAt = now + HS.BREAK_SECONDS * 1000;
                this.say(`Enough players! The first round starts in ${HS.BREAK_SECONDS} seconds.`, AQUA);
            }
        } else if (this.state === 'starting' || this.state === 'over') {
            if (this.players().length < HS.MIN_PLAYERS) {
                this.state = 'waiting';
                this.say(`Not enough players. Waiting for ${HS.MIN_PLAYERS}...`);
            } else if (left <= 0) this.startRound();
        } else if (this.state === 'hiding') {
            this.countdown(left, [10, 3, 2, 1], s => this.say(s <= 3 ? `${s}...` : `${s} seconds left to hide!`, s <= 3 ? RED : YELLOW));
            if (left <= 0) this.releaseSeekers();
        } else if (this.state === 'seeking') {
            this.countdown(left, [60, 30, 10, 3, 2, 1], s => this.say(s <= 3 ? `${s}...` : `${s} seconds left!`));
            // anyone in a seeker's view long enough is found
            for (const hid of [...this.hiders]) {
                const h = players.get(hid);
                if (!h) continue;
                let finder = null;
                for (const sid of this.seekers) { const sk = players.get(sid); if (sk && this.canSee(sk, h)) { finder = sk; break; } }
                const t = finder ? (this.viewTime.get(hid) || 0) + dt : 0;
                this.viewTime.set(hid, t);
                if (finder && t >= HS.FOUND_VIEW_SECONDS) {
                    this.hiders.delete(hid);
                    this.viewTime.delete(hid);
                    if (HS.FOUND_BECOME_SEEKERS) this.seekers.add(hid);
                    const n = this.hiders.size;
                    this.say(`${h.name} was found by ${finder.name}! (${n} hider${n === 1 ? '' : 's'} left)`, RED);
                    if (HS.FOUND_BECOME_SEEKERS && n > 0) send(h, { t: 'chat', text: 'You are now a seeker. Go find the others!', color: AQUA });
                    if (h.bot) onChat(h, { text: pick(['Aw, you found me!', 'Noooo', 'How did you see me?!']) });
                }
            }
            if (this.hiders.size === 0) this.endRound('Everyone was found. Seekers win!', RED);
            else if (left <= 0) this.endRound(`Time's up! Hiders win: ${this.names(this.hiders)}`, GREEN);
        }
    }
};

// ============================================================
// PUBLIC ADDRESS
// A program can't create its own public IP: that comes from your internet provider and belongs
// to your router. What the server can do is ask the router to forward the port to it (UPnP, the
// same thing as setting up port forwarding by hand) and look up your public IP, then print the
// address people should use. It also spots the cases where that can't work.
// ============================================================
let upnp = null, upnpTtl = 0;

// This computer's address on your home network (for people on the same Wi-Fi)
function lanAddress() {
    for (const list of Object.values(os.networkInterfaces())) {
        for (const a of list || []) if (a.family === 'IPv4' && !a.internal) return a.address;
    }
    return 'localhost';
}

// Private, local and shared-provider (CGNAT) addresses can't be reached from the internet
function isPrivateIp(ip) {
    const p = String(ip || '').split('.').map(Number);
    if (p.length !== 4 || p.some(n => !(n >= 0 && n <= 255))) return true;
    return p[0] === 10 || p[0] === 127 || (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
        (p[0] === 192 && p[1] === 168) || (p[0] === 100 && p[1] >= 64 && p[1] <= 127) || (p[0] === 169 && p[1] === 254);
}

// Your public IP, as the internet sees it
function fetchPublicIp() {
    return new Promise(resolve => {
        const req = https.get('https://api.ipify.org', { timeout: 5000 }, res => {
            let body = '';
            res.on('data', d => { body += d; });
            res.on('end', () => resolve(/^\d+\.\d+\.\d+\.\d+$/.test(body.trim()) ? body.trim() : null));
        });
        req.on('timeout', () => { req.destroy(); resolve(null); });
        req.on('error', () => resolve(null));
    });
}

// Ask the router to forward PORT to this computer. Some routers refuse a permanent mapping, so
// fall back to a 2-hour one that's renewed every hour.
async function openRouterPort() {
    let Client;
    try { ({ Client } = require('@runonflux/nat-upnp')); } catch {
        return { ok: false, why: 'the UPnP library isn\'t installed (npm install @runonflux/nat-upnp@1.0.2)' };
    }
    upnp = new Client({ timeout: 5000 });
    const map = ttl => upnp.createMapping({ public: PORT, private: PORT, protocol: 'TCP', description: 'Minecraft Classic recreation', ttl });
    try {
        try { await map(0); upnpTtl = 0; } catch { await map(7200); upnpTtl = 7200; }
        if (upnpTtl) setInterval(() => map(upnpTtl).catch(() => {}), 60 * 60 * 1000);
        const routerIp = await upnp.getPublicIp().catch(() => null);
        return { ok: true, routerIp };
    } catch (err) {
        upnp.close(); upnp = null;
        return { ok: false, why: 'your router didn\'t answer a UPnP request (it may be turned off in the router\'s settings)' };
    }
}

async function closeRouterPort() {
    if (!upnp) return;
    try { await upnp.removeMapping({ public: PORT, protocol: 'TCP' }); } catch { /* the router forgets it eventually anyway */ }
    upnp.close(); upnp = null;
}

// ============================================================
// THE GAME, SERVED BY THIS SERVER
// Opening the server's address in a browser (e.g. the tunnel link) gives you the game, set to
// join this server. The game files are read from the folder main.js is in.
// ============================================================
const GAME_DIR = path.dirname(GAME_FILE);
const GAME_FILES = { '/main.js': 'text/javascript', '/terrain.png': 'image/png', '/char.png': 'image/png',
    '/clouds.png': 'image/png', '/default.gif': 'image/gif' };
const GAME_PAGE = [
    '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width, initial-scale=1"><title>Claudecraft</title>',
    '<style>html,body{margin:0;height:100%;overflow:hidden;background:#000}canvas{display:block}',
    '#problem{position:fixed;inset:0;z-index:10;padding:24px;color:#fff;background:#000;font:14px/1.5 Verdana,Arial,sans-serif;white-space:pre-wrap}',
    '#problem[hidden]{display:none}</style></head><body><div id="problem" hidden></div>',
    '<script type="module">',
    'const box = document.getElementById("problem");',
    'const report = t => { box.hidden = false; box.textContent = "The game couldn\'t start.\\n\\n" + t; };',
    'window.addEventListener("error", e => report("Error in " + (e.filename || "the game").split("/").pop() + " line " + e.lineno + ": " + e.message));',
    'let THREE = null;',
    'for (const url of ["https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js", "https://unpkg.com/three@0.160.0/build/three.module.js",',
    '    "https://cdnjs.cloudflare.com/ajax/libs/three.js/0.160.0/three.module.min.js"]) { try { THREE = await import(url); break; } catch {} }',
    'if (!THREE) report("three.js (the 3D library) couldn\'t be downloaded.");',
    'else {',
    '    window.require = name => { if (name === "three") return THREE; throw new Error("Unknown module: " + name); };',
    '    // join this server straight away (unless the link already says what to do)',
    '    if (!new URLSearchParams(location.search).has("join")) history.replaceState(null, "", "?join" + (location.search ? "&" + location.search.slice(1) : ""));',
    '    const s = document.createElement("script"); s.src = "main.js?v=" + Date.now(); s.onerror = () => report("main.js couldn\'t be loaded."); document.body.appendChild(s);',
    '}',
    '</script></body></html>'].join('\n');

// ============================================================
// THE LEVELS PAGE (gallery)
// Players save levels with a name, description and thumbnail. They're kept in the gallery
// folder and uploaded to your website, where anyone can play or download them. Playing one
// counts a visit; visits are sent to the website shortly after, like the player count.
// The website reaches the server through a small helper page (/bridge.html) that it loads
// invisibly, since pages on Neocities can't connect to other sites themselves.
// ============================================================
const GALLERY_FILE = path.join(GALLERY_DIR, 'gallery.json');
let gallery = {};
try { gallery = JSON.parse(fs.readFileSync(GALLERY_FILE, 'utf8')) || {}; } catch { gallery = {}; }
const saveGallery = () => { try { fs.writeFileSync(GALLERY_FILE, JSON.stringify(gallery, null, 2)); } catch (err) { console.error('Couldn\'t save gallery.json:', err.message); } };
const recentByAddress = new Map();      // rate limits: address -> time of last publish
const visitSeen = new Map();            // "address level" -> time, so reloading doesn't add visits

function publishLevelsSoon() {
    if (!neocitiesKey() || publishLevelsSoon.timer) return;
    publishLevelsSoon.timer = setTimeout(() => { publishLevelsSoon.timer = null; publishLevels(); }, 10000);
}
function publishLevels() {
    const list = Object.values(gallery).sort((a, b) => b.created.localeCompare(a.created))
        .map(l => ({ id: l.id, name: l.name, description: l.description, author: l.author, created: l.created, visits: l.visits, thumb: l.thumb }));
    return uploadToWebsite('levels.json', { updated: new Date().toISOString(), levels: list });
}

async function apiPublish(body, address) {
    const now = Date.now();
    if (now - (recentByAddress.get(address) || 0) < 30000) return { ok: false, error: 'Please wait a little before saving another level.' };
    const name = String(body.name || '').replace(/[^\x20-\x7E]/g, '').trim().slice(0, 32);
    const description = String(body.description || '').replace(/[^\x20-\x7E]/g, '').trim().slice(0, 100);
    const author = /^[A-Za-z0-9_]{2,16}$/.test(body.author || '') ? body.author : null;
    if (!author) return { ok: false, error: 'You need to be logged in to save levels.' };
    if (!name) return { ok: false, error: 'Give your level a name.' };
    if (typeof body.dat !== 'string' || body.dat.length > 3000000) return { ok: false, error: 'That level is too big.' };
    const m = /^data:image\/(jpeg|png);base64,([A-Za-z0-9+/=]+)$/.exec(String(body.thumb || ''));
    if (!m || m[2].length > 300000) return { ok: false, error: 'The thumbnail is missing or too big.' };
    const dat = Buffer.from(body.dat, 'base64');
    // only real levels: it must open like any level file, at a sensible size
    try {
        const lv = await game.decodeLevel(new Blob([dat]));
        if (lv.width > 512 || lv.height > 512 || lv.depth > 512) throw new Error('too big');
    } catch { return { ok: false, error: 'That isn\'t a level file the game can open.' }; }
    recentByAddress.set(address, now);
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24) || 'level';
    const id = slug + '-' + require('crypto').randomBytes(3).toString('hex');
    const ext = m[1] === 'png' ? 'png' : 'jpg', thumbBytes = Buffer.from(m[2], 'base64');
    fs.writeFileSync(path.join(GALLERY_DIR, id + '.dat'), dat);
    fs.writeFileSync(path.join(GALLERY_DIR, id + '.' + ext), thumbBytes);
    gallery[id] = { id, name, description, author, created: new Date().toISOString(), visits: 0, thumb: id + '.' + ext };
    saveGallery();
    console.log(`${author} saved a level to the Levels page: "${name}"`);
    // the website gets the level (as text, which Neocities always accepts), the thumbnail and the list
    await uploadFileToWebsite(`gallery/${id}.txt`, dat.toString('base64'), 'text/plain');
    await uploadFileToWebsite(`gallery/${id}.${ext}`, thumbBytes, ext === 'png' ? 'image/png' : 'image/jpeg');
    await publishLevels();
    return { ok: true, id };
}

function apiVisit(body, address) {
    const lv = gallery[String(body.id || '')];
    if (!lv) return { ok: false, error: 'No such level.' };
    const key = address + ' ' + lv.id, now = Date.now();
    if (now - (visitSeen.get(key) || 0) > 10 * 60 * 1000) {      // one visit per person per level every 10 minutes
        visitSeen.set(key, now);
        lv.visits++;
        saveGallery();
        publishLevelsSoon();
    }
    return { ok: true, visits: lv.visits };
}

// The helper page the website loads invisibly: passes the website's requests to this server
const BRIDGE_PAGE = [
    '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Claudecraft</title></head><body><script>',
    'window.addEventListener("message", async e => {',
    '    const m = e.data;',
    '    if (!m || m.type !== "claudecraft-bridge" || !["publish", "visit"].includes(m.action)) return;',
    '    let out;',
    '    try {',
    '        const res = await fetch("/api/" + m.action, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(m.body || {}) });',
    '        out = await res.json();',
    '    } catch (err) { out = { ok: false, error: "The server didn\'t answer." }; }',
    '    e.source.postMessage({ type: "claudecraft-bridge-reply", id: m.id, ...out }, e.origin);',
    '});',
    'parent.postMessage({ type: "claudecraft-bridge-ready" }, "*");',
    '</script></body></html>'].join('\n');

function handleApi(req, res, action) {
    const chunks = []; let size = 0;
    req.on('data', d => { size += d.length; if (size > 4000000) req.destroy(); else chunks.push(d); });
    req.on('end', async () => {
        let body = {};
        try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { /* treated as empty */ }
        const address = String(req.headers['cf-connecting-ip'] || req.socket.remoteAddress || '');
        let out;
        try { out = action === 'publish' ? await apiPublish(body, address) : apiVisit(body, address); }
        catch (err) { console.error('Levels page error:', err); out = { ok: false, error: 'Something went wrong on the server.' }; }
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(out));
    });
}

// ============================================================
// THE CONTROL PANEL (like MCGalaxy's window, in your browser)
// http://localhost:<port>/admin?key=... opens when the server starts. It only works from this
// computer (never through the tunnel link) and with the secret key in admin_key.txt.
// ============================================================
const ADMIN_KEY_FILE = path.join(__dirname, 'admin_key.txt');
let ADMIN_KEY;
try { ADMIN_KEY = fs.readFileSync(ADMIN_KEY_FILE, 'utf8').trim(); } catch { /* made below */ }
if (!/^[0-9a-f]{32}$/.test(ADMIN_KEY || '')) { ADMIN_KEY = require('crypto').randomBytes(16).toString('hex'); fs.writeFileSync(ADMIN_KEY_FILE, ADMIN_KEY + '\n'); }
const startedAt = Date.now();
let stopServer = null;           // set once the server is running

function adminAllowed(req, url) {
    if (req.headers['cf-connecting-ip']) return false;                     // came through the tunnel: never
    const ip = String(req.socket.remoteAddress || '').replace(/^::ffff:/, '');
    if (ip !== '127.0.0.1' && ip !== '::1') return false;                  // only this computer
    const key = url.searchParams.get('key') || req.headers['x-admin-key'] || '';
    return key.length === ADMIN_KEY.length && require('crypto').timingSafeEqual(Buffer.from(key), Buffer.from(ADMIN_KEY));
}

function adminState(since) {
    return {
        server: { name: SERVER_NAME, description: SERVER_DESCRIPTION, type: mode.name, port: PORT, link: publicUrl,
            version: game.VERSION, uptime: Math.round((Date.now() - startedAt) / 1000), maxPlayers: MAX_PLAYERS },
        online: joinedPlayers().map(o => ({ name: o.name, rank: rankOf(o), level: o.world ? o.world.name : '', bot: !!o.bot })),
        players: Object.values(playerDb).map(e => ({ name: e.name, rank: e.name.toLowerCase() === OWNER_NAME.toLowerCase() ? 'owner' : e.rank || 'player',
            banned: !!e.banned, lastSeen: e.lastSeen, online: !!findOnline(e.name) })).sort((a, b) => a.name.localeCompare(b.name)),
        levels: levelNames().map(n => { const w = worlds.get(n.toLowerCase()); return { name: n, loaded: !!w, players: w ? worldPlayers(w).length : 0, main: w === mainWorld }; }),
        presets: PRESETS,
        logs: LOG.filter(l => l.n > since)
    };
}

function handleAdmin(req, res, url) {
    const reply = (code, data) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(data)); };
    if (!adminAllowed(req, url)) { reply(403, { error: 'The control panel only works on the server computer, with its key.' }); return; }
    const action = url.pathname.replace('/admin/api/', '');
    if (req.method === 'GET' && action === 'state') { reply(200, adminState(Number(url.searchParams.get('since')) || 0)); return; }
    const chunks = []; let size = 0;
    req.on('data', d => { size += d.length; if (size > 25 * 1024 * 1024) req.destroy(); else chunks.push(d); });
    req.on('end', async () => {
        const raw = Buffer.concat(chunks);
        let body = {};
        if (action !== 'upload') { try { body = JSON.parse(raw.toString('utf8') || '{}'); } catch { /* empty */ } }
        let out;
        try {
            if (action === 'chat') {
                const text = String(body.text || '').replace(/[^\x20-\x7E]/g, '').trim().slice(0, 200);
                if (text) { broadcast({ t: 'chat', text: '[Console] ' + text, color: 0xFF55FF }); console.log('[Console] ' + text); }
                out = {};
            } else if (action === 'rank') out = setRank(null, body.name, body.rank);
            else if (action === 'kick') out = kickPlayer(null, body.name, body.reason);
            else if (action === 'ban') out = banPlayer(null, body.name, !!body.banned);
            else if (action === 'level') out = await addLevel(body.name, { preset: body.preset, size: body.size });
            else if (action === 'upload') out = await addLevel(url.searchParams.get('name') || '', { dat: raw });
            else if (action === 'save') { await saveAllWorlds(); out = { message: 'Everything is saved.' }; }
            else if (action === 'stop') { reply(200, { message: 'Stopping...' }); setTimeout(() => stopServer && stopServer(), 300); return; }
            else out = { error: 'Unknown action' };
        } catch (err) { console.error('Control panel error:', err); out = { error: 'Something went wrong: ' + err.message }; }
        reply(200, out);
    });
}

function serveHttp(req, res) {
    let pathname;
    try { pathname = new URL(req.url, 'http://server').pathname; } catch { res.writeHead(400); res.end(); return; }
    if (pathname === '/admin' || pathname.startsWith('/admin/api/')) {
        const url = new URL(req.url, 'http://server');
        if (pathname.startsWith('/admin/api/')) { handleAdmin(req, res, url); return; }
        if (!adminAllowed(req, url)) { res.writeHead(403, { 'Content-Type': 'text/plain' }); res.end('The control panel only works on the server computer, with its key.'); return; }
        fs.readFile(path.join(__dirname, 'dashboard.html'), (err, data) => {
            if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('dashboard.html is missing from the server folder.'); return; }
            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
            res.end(data);
        });
        return;
    }
    if (pathname === '/bridge.html') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
        res.end(BRIDGE_PAGE);
        return;
    }
    if (req.method === 'POST' && (pathname === '/api/publish' || pathname === '/api/visit')) {
        handleApi(req, res, pathname === '/api/publish' ? 'publish' : 'visit');
        return;
    }
    if (pathname === '/' || pathname === '/game.html' || pathname === '/index.html') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
        res.end(GAME_PAGE);
        return;
    }
    const type = GAME_FILES[pathname];                 // only the game's own files, nothing else
    if (!type) { res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Not found'); return; }
    fs.readFile(path.join(GAME_DIR, pathname.slice(1)), (err, data) => {
        if (err) {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.end(`${pathname.slice(1)} is missing. Put it next to main.js on the server computer.`);
            return;
        }
        res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-cache' });
        res.end(data);
    });
}

// ============================================================
// POSTING THE SERVER'S LINK TO YOUR WEBSITE
// Uploads server.json to your Neocities site through its API: the server's name, type, player
// count and current link, refreshed every few minutes, and marked offline when you stop it.
// ============================================================
let publicUrl = null;
function neocitiesKey() {
    if (process.env.NEOCITIES_API_KEY) return process.env.NEOCITIES_API_KEY.trim();
    try { return fs.readFileSync(path.join(__dirname, 'neocities_key.txt'), 'utf8').trim() || null; } catch { return null; }
}
// Update the website soon after a real player joins or leaves (a few changes close together
// only cause one upload)
let publishTimer = null;
function publishSoon() {
    if (!publicUrl || !neocitiesKey() || publishTimer) return;
    publishTimer = setTimeout(() => { publishTimer = null; publishStatus(true); }, 5000);
}

// Upload one JSON file to the website
function uploadToWebsite(filename, data) {
    return uploadFileToWebsite(filename, JSON.stringify(data, null, 2), 'application/json');
}
// Upload one file to the website (filename can include a folder, like skins/name.png)
async function uploadFileToWebsite(filename, content, type) {
    const key = neocitiesKey();
    if (!key) return false;
    const form = new FormData();
    form.append(filename, new Blob([content], { type }), path.basename(filename));
    try {
        const res = await fetch(NEOCITIES_API, { method: 'POST', headers: { Authorization: 'Bearer ' + key }, body: form,
            signal: AbortSignal.timeout(15000) });
        if (!res.ok) { console.log(`Couldn't update your website (${res.status}): ${(await res.text()).slice(0, 200)}`); return false; }
        return true;
    } catch (err) {
        console.log(`Couldn't update your website: ${err.message}`);
        return false;
    }
}

// The Players page list: everyone who has played (not guests or bots), owner flagged
let playersTimer = null;
function publishPlayersSoon() {
    if (!neocitiesKey() || playersTimer) return;
    playersTimer = setTimeout(() => { playersTimer = null; publishPlayers(); }, 10000);
}
function publishPlayers() {
    const list = Object.values(playerDb).map(e => ({ name: e.name, owner: !!e.owner, lastSeen: e.lastSeen, skin: e.skin || null }))
        .sort((a, b) => (b.owner - a.owner) || a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));
    return uploadToWebsite('players.json', { updated: new Date().toISOString(), players: list });
}

async function publishStatus(online) {
    const key = neocitiesKey();
    if (!key || !publicUrl) return false;
    const status = {
        online, name: SERVER_NAME, description: SERVER_DESCRIPTION, type: mode.name, url: publicUrl,
        players: joinedPlayers().filter(p => !p.bot).length, bots: bots.length, maxPlayers: MAX_PLAYERS,
        version: game.VERSION, updated: new Date().toISOString()
    };
    return uploadToWebsite('server.json', status);
}

// ---- Cloudflare quick tunnel ----
// cloudflared gives a free https://something.trycloudflare.com link that forwards to this
// server, with no account and no router settings. The server runs it in the background and
// reads the link from its output. Its log goes to cloudflared.log in the server folder.
let tunnelProcess = null;

function findCloudflared() {
    const candidates = [process.env.CLOUDFLARED, path.join(__dirname, 'cloudflared.exe'), path.join(__dirname, 'cloudflared'),
        'cloudflared', 'C:\\Program Files (x86)\\cloudflared\\cloudflared.exe', 'C:\\Program Files\\cloudflared\\cloudflared.exe'].filter(Boolean);
    for (const c of candidates) {
        try {
            const r = spawnSync(c, ['--version'], { timeout: 5000, windowsHide: true });
            if (r.status === 0) return c;
        } catch { /* not this one */ }
    }
    return null;
}

// If cloudflared isn't installed, fetch it (Windows: one file, from Cloudflare's official GitHub releases)
async function getCloudflared() {
    const found = findCloudflared(); if (found) return found;
    if (process.platform !== 'win32') return null;
    const dest = path.join(__dirname, 'cloudflared.exe');
    try {
        console.log('Downloading cloudflared (for your public join link), one time only...');
        const res = await fetch('https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe', { redirect: 'follow' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        fs.writeFileSync(dest + '.part', Buffer.from(await res.arrayBuffer())); fs.renameSync(dest + '.part', dest);
        return findCloudflared();
    } catch (e) { console.log('Couldn\'t download cloudflared: ' + e.message); try { fs.unlinkSync(dest + '.part'); } catch { /* none */ } return null; }
}

async function startTunnel() {
    const cmd = await getCloudflared();
    if (!cmd) return { ok: false, why: 'cloudflared isn\'t installed (get it from github.com/cloudflare/cloudflared/releases)' };
    const log = fs.createWriteStream(path.join(__dirname, 'cloudflared.log'));
    const child = spawn(cmd, ['tunnel', '--no-autoupdate', '--url', `http://127.0.0.1:${PORT}`],
        { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    tunnelProcess = child;
    return new Promise(resolve => {
        let done = false;
        const finish = r => { if (!done) { done = true; resolve(r); } };
        const onData = d => {
            log.write(d);
            const m = String(d).match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);
            if (m) finish({ ok: true, url: m[0] });
        };
        child.stdout.on('data', onData);
        child.stderr.on('data', onData);
        child.on('error', () => finish({ ok: false, why: 'cloudflared couldn\'t be started' }));
        child.on('exit', () => {
            tunnelProcess = null;
            if (done) console.log('The Cloudflare tunnel stopped, so the link no longer works. Restart the server for a new one.');
            finish({ ok: false, why: 'cloudflared stopped before giving a link (see cloudflared.log)' });
        });
        setTimeout(() => finish({ ok: false, why: 'cloudflared took too long to give a link (see cloudflared.log)' }), 30000);
    });
}

function stopTunnel() { if (tunnelProcess) { tunnelProcess.kill(); tunnelProcess = null; } }

// Windows: put the link on the clipboard so it can be pasted straight into Join Server
function copyToClipboard(text) {
    if (process.platform !== 'win32') return false;
    try { const c = spawn('clip', [], { windowsHide: true }); c.on('error', () => {}); c.stdin.end(text); return true; } catch { return false; }
}

async function setupPublicAccess() {
    const lan = lanAddress();
    const line = '='.repeat(66);
    const out = [line, 'HOW PEOPLE JOIN', line];
    out.push(`  This computer:                localhost:${PORT}`);
    out.push(`  Same Wi-Fi / home network:    ${lan}:${PORT}`);
    if (!MAKE_PUBLIC) {
        out.push('  Internet:                     off (started with PUBLIC=0)');
        console.log(out.join('\n') + '\n' + line);
        return;
    }
    // A Cloudflare tunnel first: it works on any connection and needs no router settings
    let tunnelNote = null;
    if (TUNNEL !== 'off') {
        console.log('Starting the Cloudflare tunnel...');
        const t = await startTunnel();
        if (t.ok) {
            publicUrl = t.url;
            const copied = copyToClipboard(t.url);
            out.push(`  Anyone on the internet:       ${t.url}`);
            out.push(`    Open it in a browser to play, or paste it into Join Server${copied ? ' (it\'s copied to your clipboard)' : ''}.`);
            out.push('    It\'s a new link every time the server starts. Anyone with it can join.');
            if (neocitiesKey()) out.push('    Your website\'s Servers page will show this link.');
            else out.push('    Tip: save your Neocities API key in neocities_key.txt to show it on your website.');
            console.log(out.join('\n') + '\n' + line);
            return;
        }
        tunnelNote = t.why === 'cloudflared isn\'t installed'
            ? 'Tip: install cloudflared (winget install --id Cloudflare.cloudflared) for a join link that needs no router setup.'
            : `Cloudflare tunnel didn't work: ${t.why}. Trying your router instead.`;
        console.log(tunnelNote);
    }
    console.log('Opening the port on your router and looking up your public address...');
    const [router, publicIp] = await Promise.all([openRouterPort(), fetchPublicIp()]);
    if (router.ok && publicIp && router.routerIp && router.routerIp !== publicIp && isPrivateIp(router.routerIp)) {
        // the router's "outside" address isn't really public: the provider shares one address
        out.push(`  Internet:                     NOT POSSIBLE from this connection`);
        out.push('    Your internet provider shares one public address between many customers');
        out.push(`    (CGNAT: your router's outside address is ${router.routerIp}), so nobody outside can`);
        out.push('    reach this computer directly. Options: a tunnel service such as playit.gg, asking');
        out.push('    your provider for a public IP, or running the server on a rented server (VPS).');
    } else if (router.ok && publicIp) {
        out.push(`  Anyone on the internet:       ${publicIp}:${PORT}`);
        out.push('    (Port opened on your router automatically. Ask a friend outside your home to test it:');
        out.push('    joining your own public address from inside your home often doesn\'t work, even when');
        out.push('    it works for everyone else.)');
    } else {
        out.push(`  Internet:                     not open yet` + (publicIp ? ` (your public address is ${publicIp}:${PORT})` : ''));
        out.push(`    Couldn't open the port automatically: ${router.why}.`);
        out.push(`    Fix: turn on UPnP in your router's settings, or set up port forwarding by hand:`);
        out.push(`    forward TCP port ${PORT} to ${lan}.`);
    }
    out.push('  Also: if Windows asks whether to allow Node.js through the firewall, allow it.');
    console.log(out.join('\n') + '\n' + line);
}

// ============================================================
// BOTS (for testing)
// Server-side players that walk with the game's own movement code (gravity, jumping, swimming)
// and do everything through the same checks as real players, so they follow each server
// type's rules. They find their way with pathfinding, build real structures from blueprints,
// answer what people say in chat (and do what they're asked: follow, stop, build), and play
// Hide and Seek properly: hiders pick covered spots and run if a seeker gets close, seekers
// search likely hiding places and look all around.
// ============================================================
const bots = [];
const pick = list => list[Math.floor(Math.random() * list.length)];
const rand = (a, b) => a + Math.random() * (b - a);
const BOT_DEBUG = !!process.env.BOT_DEBUG;   // BOT_DEBUG=1 prints what bots are thinking
const dbg = (...a) => { if (BOT_DEBUG) console.log('[bot]', ...a); };
const BOT_REACH = 6;                 // how far a bot can place blocks from (players get 5)
const BOT_PLACE_SECONDS = 0.3;       // time between blocks while building
const MAX_PATHS_PER_TICK = 2;        // pathfinding is the expensive part, so it's shared out
let pathsThisTick = 0;
const NATURAL_GROUND = new Set([BLOCK.GRASS, BLOCK.DIRT, BLOCK.SAND, BLOCK.GRAVEL, BLOCK.ROCK]);
const botSites = [];                 // where bots have built (so they don't build on each other)
const forgetSite = site => { const i = botSites.indexOf(site); if (i >= 0) botSites.splice(i, 1); };

// ---- Where a bot can stand and walk ----
const inMap = (x, z) => x >= 1 && z >= 1 && x < level.width - 1 && z < level.height - 1;
// room for a body: not solid, not lava (water is fine, bots can swim)
function passable(x, y, z) {
    return level.getTile(x, y, z) !== BLOCK.LAVA && !level.isSolidTile(x, y, z);
}
// swimming at the surface: feet in water with air (or a non-water gap) above
const isSwimSpot = (x, y, z) => level.getTile(x, y, z) === BLOCK.WATER && level.getTile(x, y + 1, z) !== BLOCK.WATER;
// feet at (x, y, z): solid ground below (not leaves) or swimming at the surface, room for the body
function standable(x, y, z) {
    if (!inMap(x, z) || y < 1 || y >= level.depth - 2 || !passable(x, y, z) || !passable(x, y + 1, z)) return false;
    if (level.isSolidTile(x, y - 1, z)) return level.getTile(x, y - 1, z) !== BLOCK.LEAVES;
    return isSwimSpot(x, y, z);
}
// dry ground to stand on (for building sites and hiding places)
const dryStand = (x, y, z) => standable(x, y, z) && level.isSolidTile(x, y - 1, z) && level.getTile(x, y, z) !== BLOCK.WATER;
// highest place to stand in a column (the open ground, not inside caves)
function topStand(x, z) {
    for (let y = Math.min(level.depth - 3, BUILD_LIMIT_Y + 1); y >= 1; y--) {
        if (level.isSolidTile(x, y - 1, z) || level.getTile(x, y - 1, z) === BLOCK.WATER) return dryStand(x, y, z) ? y : -1;
    }
    return -1;
}

// A small binary heap for the pathfinder's open list
class Heap {
    constructor() { this.a = []; }
    push(n) { const a = this.a; a.push(n); let i = a.length - 1; while (i > 0) { const pi = (i - 1) >> 1; if (a[pi].f <= n.f) break; a[i] = a[pi]; i = pi; } a[i] = n; }
    pop() {
        const a = this.a, top = a[0], last = a.pop();
        if (a.length) { let i = 0; for (;;) { let c = 2 * i + 1; if (c >= a.length) break; if (c + 1 < a.length && a[c + 1].f < a[c].f) c++; if (a[c].f >= last.f) break; a[i] = a[c]; i = c; } a[i] = last; }
        return top;
    }
    get size() { return this.a.length; }
}

// A* over standing spots: steps 1 block sideways, up 1 (a jump) or down up to 3. Returns a list
// of cells to walk through, a partial path toward the goal if it can't reach it, null if
// there's nowhere to go, or 'busy' if this tick's pathfinding budget is used up.
function findPath(sx, sy, sz, gx, gz, gy = null, maxNodes = 6000, force = false) {
    if (pathsThisTick >= MAX_PATHS_PER_TICK && !force) return 'busy';
    pathsThisTick++;
    if (!standable(sx, sy, sz)) {       // mid-jump or half in a block: use the nearest place to stand
        const alt = [sy - 1, sy + 1, sy - 2, sy + 2, sy - 3, sy + 3, sy + 4].find(y => standable(sx, y, sz));
        if (alt === undefined) return null;
        sy = alt;
    }
    const W = level.width, H = level.height;
    const key = (x, y, z) => (y * H + z) * W + x;
    const h = (x, y, z) => Math.abs(x - gx) + Math.abs(z - gz) + (gy === null ? 0 : Math.abs(y - gy));
    const open = new Heap(), gScore = new Map(), came = new Map(), closed = new Set();
    const start = { x: sx, y: sy, z: sz, g: 0, f: h(sx, sy, sz) };
    open.push(start); gScore.set(key(sx, sy, sz), 0);
    let best = start, bestH = start.f, count = 0, goal = null;
    while (open.size && count < maxNodes) {
        const n = open.pop();
        const k = key(n.x, n.y, n.z);
        if (closed.has(k)) continue;
        closed.add(k); count++;
        const hn = h(n.x, n.y, n.z);
        if (hn < bestH) { bestH = hn; best = n; }
        if (n.x === gx && n.z === gz && (gy === null || Math.abs(n.y - gy) <= 1)) { goal = n; break; }
        for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const nx = n.x + dx, nz = n.z + dz;
            for (const dy of [0, 1, -1, -2, -3]) {
                const ny = n.y + dy;
                if (!standable(nx, ny, nz)) continue;
                if (dy === 1 && !passable(n.x, n.y + 2, n.z)) break;          // no room to jump
                if (dy < 0) {                                                 // room to drop down
                    let clear = true;
                    for (let yy = ny + 2; yy <= n.y + 1; yy++) if (!passable(nx, yy, nz)) { clear = false; break; }
                    if (!clear) break;
                }
                const nk = key(nx, ny, nz);
                const g = n.g + 1 + (dy === 1 ? 0.5 : 0) + (dy < 0 ? -dy * 0.2 : 0) + (level.getTile(nx, ny, nz) === BLOCK.WATER ? 3 : 0);
                if (g < (gScore.has(nk) ? gScore.get(nk) : Infinity)) {
                    gScore.set(nk, g); came.set(nk, n);
                    open.push({ x: nx, y: ny, z: nz, g, f: g + h(nx, ny, nz) });
                }
                break;      // only one place to stand per column step
            }
        }
    }
    let end = goal || best;
    if (end === start) return goal ? [] : null;
    const path = [];
    while (end && end !== start) { path.push({ x: end.x, y: end.y, z: end.z }); end = came.get(key(end.x, end.y, end.z)); }
    path.reverse();
    path.reached = !!goal;
    return path;
}

// ---- Bot basics ----
const feetOf = p => ({ x: Math.floor(p.player.position.x), y: Math.floor(p.player.position.y - PLAYER_HEIGHT + 0.01), z: Math.floor(p.player.position.z) });
const syncBot = p => {
    const v = p.player.position;
    Object.assign(p, { x: v.x, y: v.y, z: v.z, rx: p.player.rotation.x, ry: p.player.rotation.y });
};
// Turn a bot to look at a point
const face = (pl, tx, ty, tz) => {
    const v = pl.position, dx = tx - v.x, dy = ty - v.y, dz = tz - v.z;
    pl.rotation.y = Math.atan2(-dx, -dz);
    pl.rotation.x = Math.atan2(dy, Math.hypot(dx, dz));
};
const botSay = (p, text, delay = rand(800, 2500)) => setTimeout(() => { if (players.has(p.id)) onChat(p, { text }); }, delay);

// Plan a walk to (x, z). Returns true (on the way), false (no way there) or 'busy' (try again
// next tick).
function goTo(p, x, z, y = null, maxNodes = 6000) {
    const f = feetOf(p);
    const path = findPath(f.x, f.y, f.z, Math.floor(x), Math.floor(z), y, maxNodes);
    if (path === 'busy') return 'busy';
    if (!path || (!path.reached && path.length === 0)) return false;
    p.path = path; p.pathIndex = 0; p.pathGoal = { x: Math.floor(x), z: Math.floor(z), y };
    p.progressAt = Date.now(); p.repaths = 0;
    return true;
}

// Walk along the planned path. Returns true when there's nothing left to walk.
function followPath(p, input) {
    if (!p.path || p.pathIndex >= p.path.length) return true;
    const pl = p.player, now = Date.now();
    const wp = p.path[p.pathIndex];
    const feet = pl.position.y - PLAYER_HEIGHT;
    const dx = wp.x + 0.5 - pl.position.x, dz = wp.z + 0.5 - pl.position.z;
    // reached it, or already gone past it toward the next one (so it doesn't circle back)
    const prev = p.pathIndex > 0 ? p.path[p.pathIndex - 1] : null;
    const passed = prev && ((wp.x - prev.x) * -dx + (wp.z - prev.z) * -dz) > 0.05;
    if ((Math.hypot(dx, dz) < 0.5 || passed) && Math.abs(feet - wp.y) < 1.3) {
        p.pathIndex++; p.progressAt = now;
        return p.pathIndex >= p.path.length;
    }
    face(pl, wp.x + 0.5, pl.position.y, wp.z + 0.5);
    pl.rotation.x = 0;
    input.forward = true;
    if (wp.y > feet + 0.4 || pl.blockedAhead() || pl.isInMaterial(BLOCK.WATER) || pl.isInMaterial(BLOCK.LAVA)) input.jump = true;
    // stuck for a while: plan again from here, and give up after a few tries
    if (now - p.progressAt > 3000) {
        p.progressAt = now;
        if (++p.repaths > 3 || !p.pathGoal) { p.path = null; return true; }
        const r = goTo(p, p.pathGoal.x, p.pathGoal.z, p.pathGoal.y);
        if (r === false) { p.path = null; return true; }
    }
    return false;
}

// A random spot on open ground between minR and maxR from (cx, cz), or null
function randomSpot(cx, cz, minR, maxR) {
    for (let i = 0; i < 40; i++) {
        const a = Math.random() * Math.PI * 2, r = rand(minR, maxR);
        const x = Math.floor(cx + Math.cos(a) * r), z = Math.floor(cz + Math.sin(a) * r);
        if (!inMap(x, z)) continue;
        const y = topStand(x, z);
        if (y > 0) return { x, y, z };
    }
    return null;
}

// ---- Building ----
// Blueprints: lists of blocks relative to the corner of the site, at floor level (y = 0 is the
// first layer above the ground), built bottom-up. Only hotbar blocks, so they're allowed on
// Regular servers too.
const B = BLOCK;
const BLUEPRINTS = {
    house: { w: 5, d: 5, h: 5, name: 'a house', blocks() {
        const out = [];
        for (let y = 0; y < 3; y++) for (let x = 0; x < 5; x++) for (let z = 0; z < 5; z++) {
            if (x > 0 && x < 4 && z > 0 && z < 4) continue;                      // inside
            if (x === 2 && z === 0 && y < 2) continue;                            // door
            if ((x === 0 || x === 4) && z === 2 && y === 1) continue;             // windows
            const corner = (x === 0 || x === 4) && (z === 0 || z === 4);
            out.push([x, y, z, corner ? B.LOG : B.PLANKS]);
        }
        for (let x = 0; x < 5; x++) for (let z = 0; z < 5; z++) out.push([x, 3, z, B.PLANKS]);   // roof
        for (let x = 1; x < 4; x++) for (let z = 1; z < 4; z++) out.push([x, 4, z, B.PLANKS]);
        return out;
    } },
    tower: { w: 5, d: 5, h: 9, name: 'a watchtower', blocks() {
        const out = [];
        for (let y = 0; y < 6; y++) for (let x = 1; x < 4; x++) for (let z = 1; z < 4; z++) {
            if (x === 2 && z === 2) continue;                                     // hollow middle
            if (x === 2 && z === 1 && y < 2) continue;                            // doorway
            out.push([x, y, z, B.COBBLESTONE]);
        }
        for (let x = 0; x < 5; x++) for (let z = 0; z < 5; z++) out.push([x, 6, z, B.COBBLESTONE]);   // lookout floor
        for (let x = 0; x < 5; x++) for (let z = 0; z < 5; z++) {
            const edge = x === 0 || x === 4 || z === 0 || z === 4;
            if (edge && (x + z) % 2 === 0) out.push([x, 7, z, B.COBBLESTONE]);    // battlements
        }
        return out;
    } },
    wall: { w: 9, d: 1, h: 3, name: 'a wall', blocks() {
        const out = [];
        for (let y = 0; y < 3; y++) for (let x = 0; x < 9; x++) {
            if (y === 2 && x % 2 === 1) continue;
            out.push([x, y, 0, (x === 0 || x === 8) ? B.LOG : B.COBBLESTONE]);
        }
        return out;
    } },
    garden: { w: 5, d: 5, h: 2, name: 'a garden', blocks() {
        const out = [];
        for (let x = 0; x < 5; x++) for (let z = 0; z < 5; z++) {
            const edge = x === 0 || x === 4 || z === 0 || z === 4;
            if (edge) out.push([x, 0, z, B.LOG]);
        }
        for (let x = 1; x < 4; x++) for (let z = 1; z < 4; z++) out.push([x, 0, z, B.SAPLING]);
        return out;
    } },
    tree: { w: 5, d: 5, h: 7, name: 'a tree', blocks() {
        const out = [];
        for (let y = 0; y < 5; y++) out.push([2, y, 2, B.LOG]);
        for (let y = 3; y < 5; y++) for (let x = 0; x < 5; x++) for (let z = 0; z < 5; z++) {
            if (x === 2 && z === 2) continue;
            if ((x === 0 || x === 4) && (z === 0 || z === 4)) continue;
            out.push([x, y, z, B.LEAVES]);
        }
        for (let x = 1; x < 4; x++) for (let z = 1; z < 4; z++) out.push([x, 5, z, B.LEAVES]);
        out.push([2, 6, 2, B.LEAVES]);
        return out;
    } },
    // Anarchy only: a tower of whatever blocks
    chaos: { w: 2, d: 2, h: 10, name: 'a chaos tower', anarchyOnly: true, blocks() {
        const out = [], all = [B.ROCK, B.COBBLESTONE, B.PLANKS, B.LOG, B.GOLD_ORE, B.IRON_ORE, B.COAL_ORE, B.BEDROCK, B.SAND, B.GRAVEL];
        for (let y = 0; y < 9; y++) for (let x = 0; x < 2; x++) for (let z = 0; z < 2; z++) out.push([x, y, z, pick(all)]);
        return out;
    } }
};

// Find a flat, open, natural spot for a blueprint near (cx, cz). Returns { x, y, z } (y = floor
// level) or null.
function findBuildSite(bp, cx, cz, skip = []) {
    const spawn = findSpawn();
    for (let tries = 0; tries < 240; tries++) {
        // close by first, then further out
        const a = Math.random() * Math.PI * 2, r = rand(4, 10 + tries * 0.18);
        const bumpy = tries < 120 ? 2 : 3;       // fill in deeper dips if nothing flatter is found
        const ox = Math.floor(cx + Math.cos(a) * r), oz = Math.floor(cz + Math.sin(a) * r);
        if (!inMap(ox - 2, oz - 2) || !inMap(ox + bp.w + 2, oz + bp.d + 2)) continue;
        if (Math.hypot(ox - spawn.x, oz - spawn.z) < 12) continue;                         // keep spawn clear
        if (botSites.concat(skip).some(s => Math.abs(s.x - ox) < s.w + bp.w + 4 && Math.abs(s.z - oz) < s.d + bp.d + 4)) continue;
        let lo = Infinity, hi = -Infinity, ok = true;
        for (let x = ox - 1; x <= ox + bp.w && ok; x++) for (let z = oz - 1; z <= oz + bp.d && ok; z++) {
            const y = topStand(x, z);
            if (y < 1 || !NATURAL_GROUND.has(level.getTile(x, y - 1, z))) { ok = false; break; }
            lo = Math.min(lo, y); hi = Math.max(hi, y);
        }
        if (!ok || hi - lo > bumpy || hi + bp.h > BUILD_LIMIT_Y) continue;
        return { x: ox, y: hi, z: oz, w: bp.w, d: bp.d };
    }
    return null;
}

// The full list of blocks to place for a blueprint at a site: first fill any dips under it
// so it sits level, then the blueprint itself, lowest layer first
function buildQueue(bp, site) {
    const q = [];
    for (let x = site.x; x < site.x + bp.w; x++) for (let z = site.z; z < site.z + bp.d; z++) {
        for (let y = topStand(x, z); y < site.y; y++) q.push({ x, y, z, b: B.DIRT });
    }
    const blocks = bp.blocks().map(([x, y, z, b]) => ({ x: site.x + x, y: site.y + y, z: site.z + z, b }));
    blocks.sort((a, b) => a.y - b.y);
    return q.concat(blocks);
}

// ---- Tasks ----
// A bot always has one task: { kind, ... } run by tickTask, or null (it then picks one).
const TASK_WORDS = { wander: 'walking around', idle: 'chilling', follow: 'following', build: 'building',
    hide: 'hiding, obviously', seek: 'looking for hiders', mingle: 'waiting for the next round', wait: 'waiting' };

function startBuild(p, bpName, cx, cz, requester = null) {
    const bp = BLUEPRINTS[bpName];
    if (!mode.building || !bp || (bp.anarchyOnly && mode.moderated)) return false;
    // find a site the bot can actually walk to (not up a cliff or across the sea)
    const f = feetOf(p), skip = [];
    let site = null;
    for (let i = 0; i < 5 && !site; i++) {
        const s = findBuildSite(bp, cx, cz, skip);
        if (!s) break;
        const ws = workSpot(s, { x: s.x, y: s.y, z: s.z });
        const path = ws && findPath(f.x, f.y, f.z, ws.x, ws.z, ws.y, 10000, true);
        if (path && path !== 'busy' && (path.reached || (path.length === 0 && Math.hypot(ws.x - f.x, ws.z - f.z) < 2))) site = s;
        else { skip.push(s); dbg(p.name, 'skipping unreachable site for', bp.name, s.x, s.y, s.z); }
    }
    if (!site) return false;
    botSites.push(site);
    p.task = { kind: 'build', bp, site, queue: buildQueue(bp, site), nextPlace: 0, failures: 0, requester };
    return true;
}

// The spot to stand at to place a block: free ground around the building (up against its
// walls is fine) whose eye position is closest to the block, height included
function workSpot(site, blk) {
    const cands = [];
    for (let x = site.x - 2; x <= site.x + site.w + 1; x++) for (let z = site.z - 2; z <= site.z + site.d + 1; z++) {
        const inFootprint = x >= site.x && x < site.x + site.w && z >= site.z && z < site.z + site.d;
        if (inFootprint) continue;
        const y = topStand(x, z);
        if (y > 0) cands.push({ x, y, z, d: Math.hypot(x + 0.5 - (blk.x + 0.5), y + PLAYER_HEIGHT - (blk.y + 0.5), z + 0.5 - (blk.z + 0.5)) });
    }
    cands.sort((a, b) => a.d - b.d);
    return cands[0] || null;
}

// count a failed attempt, at most one a second (so a few bad ticks in a row don't end the build)
const fail = (t, now) => { if (now - (t.lastFail || 0) > 1000) { t.failures++; t.lastFail = now; } };

function tickBuild(p, input, now) {
    const t = p.task;
    if (!t.queue.length || t.failures > 8) {
        dbg(p.name, 'build of', t.bp.name, t.queue.length ? 'gave up, ' + t.queue.length + ' left' : 'finished');
        if (t.queue.length === 0) botSay(p, t.requester ? `Done! ${pick(['Here\'s', 'Check out'])} ${t.bp.name}, ${t.requester}.` : `Finished ${t.bp.name}!`);
        p.task = null;
        return;
    }
    const blk = t.queue[0];
    if (level.getTile(blk.x, blk.y, blk.z) === blk.b) { t.queue.shift(); return; }
    if (BOT_DEBUG && now - (t.lastLog || 0) > 2000) {
        t.lastLog = now;
        const e = p.player.position;
        dbg(p.name, t.bp.name, 'left', t.queue.length, 'next', blk, 'dist', Math.hypot(blk.x + 0.5 - e.x, blk.y + 0.5 - e.y, blk.z + 0.5 - e.z).toFixed(1),
            'feet', feetOf(p), 'path', p.path ? p.pathIndex + '/' + p.path.length : '-', 'fails', t.failures, 'site', t.site.x, t.site.y, t.site.z);
    }
    const eye = p.player.position;
    const dist = Math.hypot(blk.x + 0.5 - eye.x, blk.y + 0.5 - eye.y, blk.z + 0.5 - eye.z);
    // standing inside the building's footprint would block its own blocks: step outside first
    const f = feetOf(p), st = t.site;
    const insideSite = f.x >= st.x && f.x < st.x + st.w && f.z >= st.z && f.z < st.z + st.d;
    if (dist > BOT_REACH - 0.5 || insideSite) {
        // walk to the nearest work spot for this block
        if (p.path && p.pathIndex < p.path.length) { followPath(p, input); return; }
        const ws = workSpot(t.site, blk);
        if (!ws) { fail(t, now); dbg(p.name, 'no work spot'); return; }
        const r = goTo(p, ws.x, ws.z, ws.y);
        const f = feetOf(p);
        dbg(p.name, 'to work spot', ws, 'from', f, 'standable here:', standable(f.x, f.y, f.z), 'result', r === true ? 'path ' + p.path.length + (p.path.reached ? ' reached' : ' partial') : r);
        if (r === false) fail(t, now);
        return;
    }
    p.path = null;
    if (now < t.nextPlace) { face(p.player, blk.x + 0.5, blk.y + 0.5, blk.z + 0.5); return; }
    t.nextPlace = now + BOT_PLACE_SECONDS * 1000;
    // never place a block where someone is standing: try the other blocks and come back to it
    const blocked = joinedPlayers().some(o => Math.abs(o.x - (blk.x + 0.5)) < 0.8 && Math.abs(o.z - (blk.z + 0.5)) < 0.8 &&
        o.y - PLAYER_HEIGHT < blk.y + 1 && o.y > blk.y);
    if (blocked) {
        // someone's in the way: do other blocks first and wait for them to move (up to 30 seconds)
        if (!t.blockedSince) t.blockedSince = now;
        if (now - t.blockedSince > 30000) { t.failures = 99; return; }
        t.queue.push(t.queue.shift());
        return;
    }
    t.blockedSince = 0;
    face(p.player, blk.x + 0.5, blk.y + 0.5, blk.z + 0.5);
    onSetBlock(p, { x: blk.x, y: blk.y, z: blk.z, b: blk.b });
    if (level.getTile(blk.x, blk.y, blk.z) === blk.b) t.queue.shift();
    else { fail(t, now); t.queue.push(t.queue.shift()); }      // try it again later
}

// ---- Hide and Seek: hiding places ----
// Hiding spots are found once (the minigame map never changes): places to stand with a roof
// over them and walls around, scored by how covered they are.
let hidingSpots = null;
function coverScore(x, y, z) {
    let score = 0;
    for (let yy = y + 2; yy <= y + 5; yy++) if (level.isSolidTile(x, yy, z)) { score += 3; break; }   // a roof
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]) {
        for (let k = 1; k <= 2; k++) if (level.isSolidTile(x + dx * k, y + 1, z + dz * k)) { score += 0.6; break; }  // walls
    }
    return score;
}
function findHidingSpots() {
    const spots = [];
    for (let i = 0; i < 6000; i++) {
        const x = 2 + Math.floor(Math.random() * (level.width - 4)), z = 2 + Math.floor(Math.random() * (level.height - 4));
        for (let y = 1; y < Math.min(level.depth - 3, 62); y++) {
            if (!dryStand(x, y, z)) continue;
            const s = coverScore(x, y, z);
            if (s >= 3.6) spots.push({ x, y, z, score: s });
        }
    }
    console.log(`Bots found ${spots.length} hiding places on this map`);
    return spots;
}

// Pick a hiding spot: well covered, away from spawn (or from a seeker), not next to another
// hider's spot, and reachable in time. Tries a few, best first.
function chooseHidingSpot(p, awayFrom, maxWalk) {
    if (!hidingSpots) hidingSpots = findHidingSpots();
    const taken = bots.filter(o => o !== p && o.hideSpot).map(o => o.hideSpot);
    const cands = hidingSpots.filter(s => {
        const d = Math.hypot(s.x - awayFrom.x, s.z - awayFrom.z);
        return d > 12 && d < 70 && !taken.some(t => Math.hypot(t.x - s.x, t.z - s.z) < 6);
    }).map(s => ({ ...s, rank: s.score + Math.min(Math.hypot(s.x - awayFrom.x, s.z - awayFrom.z), 50) / 12 + rand(0, 2) }));
    cands.sort((a, b) => b.rank - a.rank);
    return { cands: cands.slice(0, 8), maxWalk };
}

// ---- Thinking: what each bot does next ----
function chooseTask(p, now) {
    const players2 = joinedPlayers().filter(o => !o.bot);
    const roll = Math.random();
    if (mode.building && now > (p.nextBuildAt || 0) && roll < 0.25) {
        p.nextBuildAt = now + rand(90000, 180000);
        const names = Object.keys(BLUEPRINTS).filter(n => !BLUEPRINTS[n].anarchyOnly || !mode.moderated);
        const name = pick(names);
        if (startBuild(p, name, p.x, p.z)) {
            if (Math.random() < 0.5) botSay(p, pick([`I'm going to build ${BLUEPRINTS[name].name}`, `Time to build ${BLUEPRINTS[name].name}!`]));
            return;
        }
    }
    if (roll < 0.35 && players2.length) {                       // go hang out near someone
        const o = pick(players2);
        p.task = { kind: 'follow', targetId: o.id, until: now + rand(10000, 25000), quiet: true };
        return;
    }
    if (roll < 0.55) { p.task = { kind: 'idle', until: now + rand(2000, 6000) }; return; }
    const spot = randomSpot(p.x, p.z, 8, 30);
    p.task = spot ? { kind: 'wander', spot } : { kind: 'idle', until: now + 2000 };
}

function tickTask(p, input, now) {
    const t = p.task, pl = p.player;
    if (t.kind === 'idle' || t.kind === 'wait') {
        if (Math.random() < 0.02) pl.rotation.y += rand(-0.8, 0.8);         // glance around
        if (now > t.until) p.task = null;
    } else if (t.kind === 'wander') {
        if (!t.planned) {
            const r = goTo(p, t.spot.x, t.spot.z, t.spot.y);
            if (r === 'busy') return;
            if (r === false) { p.task = null; return; }
            t.planned = true;
        }
        if (followPath(p, input)) p.task = Math.random() < 0.5 ? { kind: 'idle', until: now + rand(1000, 4000) } : null;
    } else if (t.kind === 'follow') {
        const o = players.get(t.targetId);
        if (!o || now > t.until) { p.task = null; p.path = null; return; }
        const d = Math.hypot(o.x - p.x, o.z - p.z);
        if (d < 3) { p.path = null; face(pl, o.x, o.y, o.z); return; }
        if (!p.path || p.pathIndex >= p.path.length || now - (t.planAt || 0) > 1500) {
            const r = goTo(p, o.x, o.z, Math.floor(o.y - PLAYER_HEIGHT + 0.01));
            if (r !== 'busy') t.planAt = now;
        }
        followPath(p, input);
    } else if (t.kind === 'build') {
        tickBuild(p, input, now);
    }
}

// Hide and Seek: hiders go to a covered spot and stay put (running if a seeker gets close),
// seekers check likely hiding places one by one and look all around at each
const checkedSpots = new Set();      // shared by all seeker bots this round (4x4 areas)
let checkedRound = 0;

function tickHideSeek(p, input, now, role) {
    const pl = p.player;
    if (checkedRound !== hideSeek.roundId) { checkedRound = hideSeek.roundId; checkedSpots.clear(); }
    if (role === 'hide') {
        if (p.hideRound !== hideSeek.roundId) {                // new round: choose a spot
            const left = Math.max(5, (hideSeek.endsAt - now) / 1000);
            p.hideRound = hideSeek.roundId; p.hideSpot = null; p.hidePlan = chooseHidingSpot(p, findSpawn(), left * 3.2);
            p.path = null; p.fleeAt = 0;
        }
        if (!p.hideSpot && p.hidePlan) {                        // try candidates until one is reachable in time
            const c = p.hidePlan.cands.shift();
            if (!c) { p.hidePlan = null; const s = randomSpot(p.x, p.z, 15, 40); if (s) { p.hideSpot = s; goTo(p, s.x, s.z, s.y); } return; }
            const r = goTo(p, c.x, c.z, c.y, 15000);
            if (r === 'busy') { p.hidePlan.cands.unshift(c); return; }
            if (r === true && p.path.reached && p.path.length <= p.hidePlan.maxWalk) {
                p.hideSpot = c; p.hidePlan = null;
                dbg(p.name, 'hiding at', c.x, c.y, c.z, 'cover', c.score.toFixed(1), 'roof', coverScore(c.x, c.y, c.z) >= 3, 'walk', p.path.length);
            }
            else p.path = null;
            return;
        }
        if (!followPath(p, input)) return;                    // still on the way
        // in place: keep still, glance around now and then, and run if a seeker comes close
        if (Math.random() < 0.01) pl.rotation.y += rand(-1, 1);
        if (hideSeek.state === 'seeking' && now > (p.fleeAt || 0)) {
            for (const sid of hideSeek.seekers) {
                const sk = players.get(sid);
                if (!sk || Math.hypot(sk.x - p.x, sk.z - p.z) > 10) continue;
                if (hideSeek.canSee({ x: p.x, y: p.y, z: p.z, rx: 0, ry: pl.rotation.y }, sk, 120) && !(hideSeek.viewTime.get(p.id) > 0)) {
                    p.fleeAt = now + 20000;
                    if (Math.random() < 0.5) {
                        dbg(p.name, 'running away from', sk.name);
                        p.hidePlan = chooseHidingSpot(p, sk, 60); p.hideSpot = null;
                        if (Math.random() < 0.3) botSay(p, pick(['Nope!', 'Too close!', 'Can\'t catch me!']), 200);
                    }
                    break;
                }
            }
        }
    } else if (role === 'seek') {
        // anyone in a wide view? stop and look straight at them so they get found
        let seen = null, best = Infinity;
        for (const hid of hideSeek.hiders) {
            const h = players.get(hid);
            if (!h) continue;
            const d = Math.hypot(h.x - p.x, h.z - p.z);
            if (d < best && hideSeek.canSee(p, h, 100)) { best = d; seen = h; }
        }
        if (seen) {
            if (p.lastSeen !== seen.id) { p.lastSeen = seen.id; dbg(p.name, 'spotted', seen.name, 'at', Math.hypot(seen.x - p.x, seen.z - p.z).toFixed(1), 'blocks'); }
            p.path = null; p.sweep = null; face(pl, seen.x, seen.y - 0.8, seen.z); return;
        }
        if (p.sweep) {                                             // looking all around
            pl.rotation.y += Math.PI * 2 * 0.05 / 1.6; pl.rotation.x = -0.1;
            if (now > p.sweep) p.sweep = null;
            return;
        }
        if (p.path && p.pathIndex < p.path.length) {
            if (followPath(p, input)) { p.sweep = now + 1600; markChecked(p.x, p.z); }
            return;
        }
        // next place to check: the nearest likely hiding spot nobody has checked yet
        if (!hidingSpots) hidingSpots = findHidingSpots();
        const cands = hidingSpots.filter(s => !checkedSpots.has(areaKey(s.x, s.z)))
            .map(s => ({ s, d: Math.hypot(s.x - p.x, s.z - p.z) - s.score })).sort((a, b) => a.d - b.d).slice(0, 4);
        for (const c of cands) {
            const r = goTo(p, c.s.x, c.s.z, c.s.y, 12000);
            if (r === 'busy') return;
            if (r === true) { markChecked(c.s.x, c.s.z, 0); dbg(p.name, 'checking', c.s.x, c.s.y, c.s.z, 'walk', p.path.length); return; }
            markChecked(c.s.x, c.s.z, 0);
        }
        if (!cands.length) { const s = randomSpot(p.x, p.z, 10, 40); if (s) goTo(p, s.x, s.z, s.y); }
    }
}
const areaKey = (x, z) => (Math.floor(x / 4) << 16) | Math.floor(z / 4);
function markChecked(x, z, r = 4) {
    for (let dx = -r; dx <= r; dx += 4) for (let dz = -r; dz <= r; dz += 4) checkedSpots.add(areaKey(x + dx, z + dz));
}

// ---- Chat: bots answer what people say ----
// Each message is matched against these, in order. Bots answer if they're named in it, or
// (for general messages like "hi") one bot answers. Bots never answer other bots.
const CHAT_RULES = [
    { re: /\b(come here|follow me|come to me|over here|come with me)\b/, act: 'follow' },
    { re: /\b(stop|stay|wait|halt|freeze)\b/, act: 'stop' },
    { re: /\bbuild(?: me)?(?: a| an| the)? ?(house|tower|watchtower|wall|garden|tree|something|anything|chaos tower)?\b/, act: 'build' },
    { re: /\b(go away|leave me alone|shoo|go away bot)\b/, act: 'leave' },
    { re: /\bjump\b/, act: 'jump' },
    { re: /\b(what are|what r|wat r|whatcha|what're) (you|u) doing\b|\bwyd\b/, act: 'doing' },
    { re: /\bwhere (are|r) (you|u)\b|\bwhere you at\b/, act: 'where' },
    { re: /\b(what'?s|what is) your name\b|\bwho are (you|u)\b/, act: 'name' },
    { re: /\b(are|r) (you|u) (a )?(bot|ai|robot|real|human)\b/, act: 'bot' },
    { re: /\bhow (are|r) (you|u)\b|\bhow'?s it going\b|\bsup\b/, act: 'howareyou' },
    { re: /\b(found you|i see you|gotcha|i found you)\b/, act: 'found' },
    { re: /\b(thanks|thank you|thx|ty)\b/, act: 'thanks' },
    { re: /\b(stupid|dumb|noob|trash|bad bot|idiot)\b/, act: 'insult' },
    { re: /\b(good bot|nice|cool|awesome|great job|well done)\b/, act: 'praise' },
    { re: /\b(hi|hello|hey|yo|hiya|howdy|greetings)\b/, act: 'hi' },
    { re: /\b(bye|goodbye|cya|see ya|later)\b/, act: 'bye' },
    { re: /\b(lol|lmao|haha|xd)\b/, act: 'lol' },
    { re: /\?\s*$/, act: 'question' }
];

function botsHear(speaker, text) {
    if (speaker.bot || !bots.length) return;
    const lower = text.toLowerCase();
    const named = bots.filter(b => new RegExp('\\b' + b.name.toLowerCase() + '\\b').test(lower));
    const everyone = /\b(bots|everyone|everybody|all of you|guys)\b/.test(lower);
    const rule = CHAT_RULES.find(r => r.re.test(lower));
    let listeners;
    if (named.length) listeners = named;
    else if (everyone) listeners = bots.slice();
    else if (rule && ['hi', 'bye', 'howareyou', 'question', 'lol', 'found'].includes(rule.act) && Math.random() < 0.8) {
        // one bot answers general chatter (the nearest one)
        listeners = [bots.slice().sort((a, b) => Math.hypot(a.x - speaker.x, a.z - speaker.z) - Math.hypot(b.x - speaker.x, b.z - speaker.z))[0]];
    } else if (bots.length === 1 && rule) listeners = bots.slice();
    else return;
    listeners.forEach((b, i) => respond(b, speaker, rule ? rule.act : 'unknown', lower, i * 700));
}

function respond(p, speaker, act, lower, extraDelay) {
    const name = speaker.name, now = Date.now();
    const say = text => botSay(p, text, rand(900, 2600) + extraDelay);
    const inRound = p.world && p.world.isHideSeek && (hideSeek.state === 'hiding' || hideSeek.state === 'seeking') && hideSeek.inRound.has(p.id);
    const isHider = hideSeek.hiders.has(p.id), isSeeker = hideSeek.seekers.has(p.id);
    switch (act) {
        case 'hi': say(pick([`Hi ${name}!`, `Hey ${name}`, `Hello ${name}!`, `Yo ${name}`])); break;
        case 'bye': say(pick([`Bye ${name}!`, 'See you!', 'Later!'])); break;
        case 'howareyou': say(pick(['Pretty good!', 'Good, thanks!', `Doing great, ${TASK_WORDS[p.task ? p.task.kind : 'idle']}`])); break;
        case 'thanks': say(pick(['No problem!', 'Anytime!', 'You\'re welcome!'])); break;
        case 'insult': say(pick(['Hey, I\'m trying my best!', 'Rude :(', 'I\'m still learning!'])); break;
        case 'praise': say(pick(['Thanks!', ':)', 'Thank you!'])); break;
        case 'lol': if (Math.random() < 0.5) say(pick(['lol', 'haha', 'xD'])); break;
        case 'name': say(`I'm ${p.name}, one of the bots on this server.`); break;
        case 'bot': say(pick(['Yep, I\'m a bot. Beep boop.', 'I\'m a bot, but a friendly one!'])); break;
        case 'doing': {
            const t = p.task;
            if (inRound) say(isHider ? 'Hiding, obviously!' : 'Looking for everyone!');
            else if (t && t.kind === 'build') say(`Building ${t.bp.name} (${t.queue.length} blocks to go)`);
            else if (t && t.kind === 'follow' && players.get(t.targetId)) say(`Following ${players.get(t.targetId).name}`);
            else say(`Just ${TASK_WORDS[t ? t.kind : 'idle']}`);
            break;
        }
        case 'where':
            if (inRound && isHider) say(pick(['Not telling!', 'Somewhere you\'ll never look...', 'Wouldn\'t you like to know!', 'Close... or am I?']));
            else say(`I'm at ${Math.floor(p.x)}, ${Math.floor(p.y)}, ${Math.floor(p.z)}`);
            break;
        case 'found':
            if (isHider) say(pick(['Where?? You don\'t see me!', 'Nice try!', 'Lies!']));
            else if (isSeeker) say(pick(['Good job!', 'Nice!']));
            break;
        case 'follow':
            if (inRound) { say(isHider ? 'Nice try, I\'m staying hidden!' : 'I\'m busy seeking!'); break; }
            p.task = { kind: 'follow', targetId: speaker.id, until: now + 60000 };
            p.path = null;
            say(pick(['On my way!', 'Coming!', `Okay ${name}, I'll follow you`]));
            break;
        case 'stop':
            if (inRound) { say('Can\'t stop now, we\'re playing!'); break; }
            if (p.task && p.task.kind === 'build') forgetSite(p.task.site);
            p.task = { kind: 'wait', until: now + 30000 }; p.path = null;
            say(pick(['Okay, I\'ll wait here.', 'Stopping!', 'Alright.']));
            break;
        case 'leave': {
            const s = randomSpot(p.x, p.z, 25, 50);
            p.task = s ? { kind: 'wander', spot: s } : { kind: 'idle', until: now + 5000 };
            p.path = null;
            say(pick(['Fine :(', 'Okay, okay, I\'m going!', 'Bye then!']));
            break;
        }
        case 'jump':
            p.jumpUntil = now + 2500;
            say(pick(['Wheee!', 'Boing!', '*jumps*']));
            break;
        case 'build': {
            if (!mode.building) { say('Building is turned off on this server.'); break; }
            if (inRound) { say('Not during a round!'); break; }
            const m = lower.match(/\bbuild(?: me)?(?: a| an| the)? ?(house|tower|watchtower|wall|garden|tree|chaos tower)?\b/);
            let what = m && m[1] ? m[1].replace('watchtower', 'tower').replace('chaos tower', 'chaos') : null;
            if (what === 'chaos' && mode.moderated) what = null;
            if (!what) what = pick(['house', 'tower', 'garden', 'tree']);
            if (p.task && p.task.kind === 'build') forgetSite(p.task.site);
            if (startBuild(p, what, speaker.x, speaker.z, name)) say(pick([`Sure! Building ${BLUEPRINTS[what].name} near you.`, `On it, one ${what} coming up!`]));
            else say('I can\'t find a flat enough spot around here. Try somewhere more open?');
            break;
        }
        case 'question': say(pick(['Hmm, good question.', 'I\'m not sure!', 'Maybe?', 'Ask me something easier :)'])); break;
        default: say(pick(['Hm?', 'Cool!', 'I\'m not sure what you mean.', 'Okay!']));
    }
}

// A bot says hi when a real player joins
function botsGreet(newcomer) {
    if (newcomer.bot || !bots.length || Math.random() < 0.3) return;
    botSay(pick(bots), pick([`Welcome, ${newcomer.name}!`, `Hi ${newcomer.name}!`, `Hey ${newcomer.name}, welcome!`]), rand(1500, 3500));
}

function createBot(n) {
    const spawn = findSpawn();
    const pl = Object.create(game.Player.prototype);   // the game's player physics, without a screen
    Object.assign(pl, {
        level, position: new game.THREE.Vector3(spawn.x + rand(-2, 2), spawn.y, spawn.z + rand(-2, 2)),
        velocity: new game.THREE.Vector3(), rotation: { x: 0, y: rand(0, Math.PI * 2) },
        onGround: false, swimming: false, swimTickAccum: 0, moveDir: new game.THREE.Vector3()
    });
    const now = Date.now();
    const p = {
        id: nextId++, name: 'Bot' + n, bot: true, joined: true, player: pl, frozen: false, world: mainWorld, agreed: true,
        blockBudget: MAX_BLOCK_CHANGES_PER_SECOND, blockBudgetAt: now,
        task: null, path: null, pathIndex: 0, progressAt: now, hideRound: 0, hideSpot: null,
        nextBuildAt: now + rand(20000, 60000), nextChat: now + rand(40000, 120000)
    };
    p.onMessage = msg => {
        if (msg.t === 'teleport') {
            pl.position.set(msg.x, msg.y, msg.z); pl.velocity.set(0, 0, 0);
            pl.rotation.x = msg.rx || 0; pl.rotation.y = msg.ry || 0;
            p.path = null; p.task = null; syncBot(p);
        } else if (msg.t === 'freeze') p.frozen = !!msg.on;
    };
    syncBot(p);
    players.set(p.id, p);
    bots.push(p);
    broadcastWorld(mainWorld, { t: 'join', ...playerInfo(p) }, p);
    announce(`${p.name} joined the game`);
    if (p.world.isHideSeek) hideSeek.onJoin(p);
}

const IDLE_CHAT = {
    regular: ['Anyone want to build something together?', 'This place is looking good', 'Ask me to build something!', 'Nice day for building'],
    anarchy: ['ANARCHY!', 'No rules here', 'Anyone want to see my chaos tower?', 'mine now'],
    hideandseek: ['Good luck everyone!', 'I know a good spot...', 'Ready for the next round?']
};

function tickBot(p, dt) {
    const pl = p.player, now = Date.now();
    const input = {};
    let role = null;
    if (p.world && p.world.isHideSeek) {
        const st = hideSeek.state;
        if (hideSeek.seekers.has(p.id) && st === 'seeking') role = 'seek';
        else if (hideSeek.hiders.has(p.id) && (st === 'hiding' || st === 'seeking')) role = 'hide';
    }
    if (p.frozen) {
        if (Math.random() < 0.01) pl.rotation.y += rand(-0.5, 0.5);
    } else if (role) {
        tickHideSeek(p, input, now, role);
    } else {
        if (mode.minigame && p.task && p.task.kind === 'build') p.task = null;
        if (!p.task) {
            if (p.world && p.world.isHideSeek) {           // between rounds: stay around spawn
                const s = findSpawn(), spot = randomSpot(s.x, s.z, 2, 10);
                p.task = spot && Math.random() < 0.5 ? { kind: 'wander', spot } : { kind: 'idle', until: now + rand(2000, 6000) };
            } else chooseTask(p, now);
        }
        if (p.task) tickTask(p, input, now);
    }
    if (now < (p.jumpUntil || 0)) input.jump = true;
    if (BOT_DEBUG) {
        const k = p.task ? p.task.kind + (p.task.bp ? ':' + p.task.bp.name : '') : 'none';
        if (k !== p.lastTaskKind) { dbg(p.name, 'task', p.lastTaskKind, '->', k); p.lastTaskKind = k; }
    }

    pl.update(dt, input);
    if (pl.position.y < -10) {                               // fell out of the world: back to spawn
        const s = findSpawn(); pl.position.set(s.x, s.y, s.z); pl.velocity.set(0, 0, 0); p.path = null;
    }
    syncBot(p);
    broadcastWorld(mainWorld, { t: 'move', id: p.id, x: p.x, y: p.y, z: p.z, rx: p.rx, ry: p.ry }, p);

    if (now > p.nextChat) {
        p.nextChat = now + rand(60000, 180000);
        onChat(p, { text: pick(IDLE_CHAT[mode.minigame || (mode.moderated ? 'regular' : 'anarchy')]) });
    }
    // Anarchy bots now and then drop a random block (sometimes water or lava) wherever they are
    if (!mode.moderated && mode.building && now > (p.nextMischief || now + 1)) {
        p.nextMischief = now + rand(30000, 90000);
        const f = feetOf(p), dx = Math.round(-Math.sin(p.ry) * 2), dz = Math.round(-Math.cos(p.ry) * 2);
        onSetBlock(p, { x: f.x + dx, y: f.y, z: f.z + dz, b: pick([B.WATER, B.LAVA, B.GOLD_ORE, B.BEDROCK, B.LOG]) });
    }
    if (p.nextMischief === undefined) p.nextMischief = now + rand(30000, 90000);
}

function tickAllBots() {
    pathsThisTick = 0;
    // a different bot goes first each tick, so pathfinding is shared fairly
    const start = (tickAllBots.n = ((tickAllBots.n || 0) + 1)) % Math.max(1, bots.length);
    for (let i = 0; i < bots.length; i++) {
        try { tickBot(bots[(start + i) % bots.length], 0.05); } catch (err) { console.error('Bot error:', err); }
    }
}

// ---- Server ----
async function main() {
    if (!OWNER_NAME) console.log('No owner set: put YOUR Claudecraft username after "owner=" in server.properties, then restart, to become the Owner.\n');
    mode = MODES[await chooseMode()];
    // rule-validation in server.properties can turn the checks on or off for any server type
    const rv = propText('rule-validation', 'default');
    if (/^(true|false)$/i.test(rv)) mode = { ...mode, moderated: /^true$/i.test(rv) };
    const botCount = await chooseBots();
    console.log(`Server: "${SERVER_NAME}" - ${mode.name}, rule checks ${mode.moderated ? 'on' : 'off'}, ` +
        `up to ${MAX_PLAYERS} players, bots: ${botCount} (settings in server.properties)`);
    await loadOrCreateLevel();
    // Lava Survival: its own level (/goto Lava Survival) on servers where people build
    const lavaFiles = ['lava_survival.js', 'lava_maps.js'].filter(f => !fs.existsSync(path.join(__dirname, f)));
    if (mode.building && propBool('minigames', true) && propBool('lava-survival', true) && lavaFiles.length) {
        console.log(`Lava Survival is off: put ${lavaFiles.join(' and ')} in the Server folder (next to server.js) to turn it on.`);
    } else if (mode.building && propBool('minigames', true) && propBool('lava-survival', true)) {
        lava = require('./lava_survival.js')({
            game, BLOCK, PLAYER_HEIGHT, propInt, levelsDir: LEVELS_DIR, findSpawn, worldPlayers, broadcastWorld, send, tell, teleport,
            canBuildBase: p => mode.building && p.agreed, sendLevelTo, makeWorld, setWorldLevel
        });
        if (await lava.start()) console.log('Lava Survival is ready: players can /goto Lava Survival');
    }
    game.setMapSize(level.width, level.height, level.depth);   // the shared player physics keeps bots inside the map
    // one port for both: the game itself (web pages) and the game's connection (WebSocket)
    const httpServer = http.createServer(serveHttp);
    const wss = new WebSocketServer({ server: httpServer, maxPayload: 64 * 1024 });
    await new Promise((resolve, reject) => {
        httpServer.once('error', err => reject(err.code === 'EADDRINUSE'
            ? new Error(`Port ${PORT} is already in use. Is another copy of the server still running? Close it, or start this one with a different PORT.`)
            : err));
        httpServer.listen(PORT, resolve);
    });
    console.log(`Server version ${SERVER_VERSION} (${SERVER_FEATURES.join(', ')})`);
    console.log(`Server running on port ${PORT}.`);
    // the control panel: open it in the browser (Windows), or print where it is
    const panel = `http://localhost:${PORT}/admin?key=${ADMIN_KEY}`;
    console.log(`Control panel: ${panel}`);
    if (process.platform === 'win32' && propBool('open-control-panel', true)) {
        try { spawn('cmd', ['/c', 'start', '', panel], { windowsHide: true, detached: true, stdio: 'ignore' }).unref(); } catch { /* open it by hand */ }
    }
    // which game it hands to players (the newest main.js must be in this exact place)
    console.log(`Game: ${GAME_FILE} (version ${game.VERSION})`);
    learnOwnerAddresses();              // so the owner is recognised through the tunnel too
    if (neocitiesKey()) { publishPlayers(); publishLevels(); }
    // the game's images are handed out from the same folder as main.js
    const missingFiles = Object.keys(GAME_FILES).map(f => f.slice(1)).filter(f => !fs.existsSync(path.join(GAME_DIR, f)));
    if (missingFiles.length) {
        const bar = '!'.repeat(66);
        console.log([bar, `WARNING: missing from ${GAME_DIR}: ${missingFiles.join(', ')}`,
            'Players joining from the link or your website get the game from that folder, so without',
            'these it starts with no textures and no text. Copy them there (next to main.js), then',
            'restart the server.', bar].join('\n'));
    }
    if (!GAME_JOINS_FROM_LINK) {
        const bar = '!'.repeat(66);
        console.log([bar, `WARNING: the main.js in ${GAME_DIR} is an old version (${game.VERSION}).`,
            'Players who open this server\'s link or click it on your website will get single player',
            'instead of joining. Put the newest main.js (0.0.22a_08 or later) in that folder, then',
            'restart the server.', bar].join('\n'));
    }
    await setupPublicAccess();

    wss.on('connection', (ws, req) => {
        const p = { ws, id: nextId++, name: 'Player', joined: false, canBeOwner: canBeOwner(req),
            address: String(req.headers['cf-connecting-ip'] || req.socket.remoteAddress || ''), blockBudget: MAX_BLOCK_CHANGES_PER_SECOND, blockBudgetAt: Date.now(),
            msgCount: 0, msgWindow: Date.now() };
        players.set(p.id, p);
        ws.on('message', (data, isBinary) => {
            if (mode.moderated) {
                // flood protection: too many messages in one second gets you disconnected
                const now = Date.now();
                if (now - p.msgWindow > 1000) { p.msgWindow = now; p.msgCount = 0; }
                if (++p.msgCount > MAX_MESSAGES_PER_SECOND) { send(p, { t: 'kick', reason: 'Too many messages' }); ws.close(); return; }
            }
            if (isBinary) return;
            let msg;
            try { msg = JSON.parse(data.toString()); } catch { return; }
            if (!msg || typeof msg !== 'object') return;
            try {
                if (msg.t === 'hello') onHello(p, msg).catch(err => console.error('Join failed:', err));
                else if (msg.t === 'move') onMove(p, msg);
                else if (msg.t === 'set') onSetBlock(p, msg);
                else if (msg.t === 'chat') onChat(p, msg);
                else if (msg.t === 'skin') onSkin(p, msg);
            } catch (err) { console.error('Bad message from', p.name, err); }
        });
        ws.on('close', () => {
            players.delete(p.id);
            if (p.joined) {
                if (p.world) broadcastWorld(p.world, { t: 'leave', id: p.id });
                rememberPosition(p);
                savePlayerDb();
                announce(`${p.name} left the game`);
                publishSoon();
                if (p.world && p.world.isHideSeek) hideSeek.onLeave(p);
                if (p.world && p.world.isLava && lava) lava.onLeave(p);
            }
        });
        ws.on('error', () => {});
    });

    // The server runs the world: flowing water and lava (water and lava making stone) and grass,
    // 10 times a second, and sends every change to everyone (players' games don't run these
    // themselves while connected, so everybody sees the same world)
    setInterval(() => {
        for (const world of worlds.values()) {
            world.ticking = true;
            // (grass only grows and dies where someone is; liquids always flow)
            try { world.level.tick(performance.now(), worldPlayers(world).length > 0); } catch (err) { console.error('World tick error:', err); }
            world.ticking = false;
            if (!world.changes.length) continue;
            if (mode.saves) world.changed = true;
            // all of this tick's changes in one message: [x, y, z, block, x, y, z, block, ...]
            const list = [];
            for (const [x, y, z] of world.changes.splice(0)) list.push(x, y, z, world.level.getTile(x, y, z));
            broadcastWorld(world, { t: 'sets', list });
        }
    }, 100);

    // bots join once the server is up, and think/move 20 times a second
    for (let i = 1; i <= botCount; i++) createBot(i);
    if (botCount > 0) setInterval(tickAllBots, 50);
    // tell the website about this server now, and keep it up to date
    if (publicUrl && neocitiesKey()) {
        if (await publishStatus(true)) console.log('Your website now shows this server.');
        setInterval(() => publishStatus(true), STATUS_EVERY_MS);
    }

    {   // Hide and Seek rounds, wherever the Hide and Seek level is
        let last = Date.now();
        setInterval(() => { const now = Date.now(); hideSeek.tick((now - last) / 1000); last = now; }, 100);
    }
    if (mode.saves) {
        setInterval(() => { saveAllWorlds().catch(err => console.error('Save failed:', err)); }, SAVE_EVERY_MS);
    }
    // save when the server is stopped (Ctrl+C)
    process.on('exit', stopTunnel);   // never leave cloudflared running on its own
    // Stopping: Ctrl+C, or closing the window (Windows gives a few seconds' warning, which Node
    // reports as SIGHUP). Tell the website first, since that's the quickest and matters most to
    // players, then save the level and tidy up.
    let stopping = false;
    const stop = stopServer = async () => {
        if (stopping) return;
        stopping = true;
        console.log('Stopping...');
        for (const p of joinedPlayers()) rememberPosition(p);
        savePlayerDb();
        try {
            if (publicUrl && neocitiesKey()) await publishStatus(false);   // website: offline
            await saveAllWorlds();
            await closeRouterPort();      // close the port again on the router
            stopTunnel();
        } finally { process.exit(0); }
    };
    for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP', 'SIGBREAK']) process.on(sig, stop);
}

main().catch(crashed);
