@echo off
rem Starts the Claudecraft server (minimized); the control panel opens in your browser.
rem First run: installs what the server needs. If the server ever crashes, it restarts by itself.
cd /d "%~dp0"
rem (the first time, the window opens normally: the server asks which kind of server you want)
if not "%~1"=="run" if not exist "server.properties" ( start "Claudecraft Server" cmd /k ""%~f0" run" & exit /b )
if not "%~1"=="run" ( start "Claudecraft Server" /min cmd /k ""%~f0" run" & exit /b )
title Claudecraft Server
where node >nul 2>nul
if errorlevel 1 (
    echo Node.js isn't installed. Get the LTS version from https://nodejs.org , install it, then run this again.
    pause & exit /b
)
if not exist "node_modules\ws" (
    echo Installing what the server needs ^(one time only^)...
    call npm install --no-audit --no-fund
    if not exist "node_modules\ws" ( echo Couldn't install. Check your internet connection and try again. & pause & exit /b )
)
set GUI=1
:run
node server.js
if %errorlevel%==0 goto stopped
echo.
echo The server stopped unexpectedly ^(see crash-log.txt^). Restarting in 10 seconds... close this window to stop.
timeout /t 10 >nul
goto run
:stopped
echo The server has stopped. You can close this window.
