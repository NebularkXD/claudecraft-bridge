// ============================================================
// LAVA SURVIVAL
// A level on the server ("Lava Survival", /goto it) that runs rounds on the maps in the
// "lava survival" folder:
//   1. Build: a few minutes to build a base.
//   2. Flood: lava pours in from the top middle and spreads. Blocks touching lava melt (weaker
//      ones sooner). Touching lava costs a life; after 3 you spectate. The 6x6x6 area round
//      the spawn is always safe.
//   3. Results: points for blocks placed, how high up you are, and how well you survived,
//      listed from least to most.
//   4. Vote: three different maps; type 1, 2 or 3 in chat. The winner is next.
// ============================================================
const fs = require('fs');
const path = require('path');

module.exports = function lavaSurvival(ctx) {
    const { game, BLOCK: B, PLAYER_HEIGHT } = ctx;
    const ORANGE = 0xFF8800, YELLOW = 0xFFFF55, AQUA = 0x55FFFF, RED = 0xFF5555, GREEN = 0x55FF55, GREY = 0xA0A0A0;
    // (LAVA_TEST_* only for automated tests: much shorter rounds)
    const BUILD_SECONDS = Number(process.env.LAVA_TEST_BUILD) || ctx.propInt('lava-build-seconds', 30, 1800, 300);
    const FLOOD_SECONDS = Number(process.env.LAVA_TEST_FLOOD) || ctx.propInt('lava-flood-seconds', 30, 1800, 240);
    const MIN_PLAYERS = ctx.propInt('lava-min-players', 1, 16, 1);
    const VOTE_SECONDS = Number(process.env.LAVA_TEST_VOTE) || 20, RESULTS_SECONDS = process.env.LAVA_TEST_VOTE ? 2 : 6, LIVES = 3;
    // seconds a block can touch lava before it melts (weaker blocks melt sooner); never for bedrock
    const MELT = {
        [B.LEAVES]: 2, [B.SAPLING]: 2,
        [B.PLANKS]: 8, [B.LOG]: 8,
        [B.DIRT]: 15, [B.GRASS]: 15, [B.SAND]: 15, [B.GRAVEL]: 15,
        [B.COBBLESTONE]: 40,
        [B.ROCK]: 60, [B.COAL_ORE]: 60, [B.IRON_ORE]: 60, [B.GOLD_ORE]: 60
    };

    const folder = path.join(ctx.levelsDir, 'lava survival');
    const mapNames = () => { try { return fs.readdirSync(folder).filter(f => f.toLowerCase().endsWith('.dat')).map(f => f.slice(0, -4)).sort(); } catch { return []; } };

    // Fill the folder with the preset maps: the first time, and again whenever the presets
    // change (only the presets are remade; maps you added yourself are left alone)
    async function makePresetMaps() {
        fs.mkdirSync(folder, { recursive: true });
        const presets = require('./lava_maps.js')(B);
        const versionFile = path.join(folder, 'presets-version.txt');
        let made = 0;
        try { made = Number(fs.readFileSync(versionFile, 'utf8').trim()) || 0; } catch { /* never made */ }
        if (made === presets.version) return;
        console.log(`${made ? 'Updating' : 'Making'} ${presets.names.length} Lava Survival maps in "${path.basename(ctx.levelsDir)}/lava survival"...`);
        for (const name of presets.names) {
            const { blocks, spawn } = presets.build(name);
            const lv = new game.Level(presets.size.w, presets.size.h, presets.size.d, blocks);
            const who = { position: { x: spawn.x, y: spawn.y + PLAYER_HEIGHT + 0.01, z: spawn.z }, rotation: { x: 0, y: 0 } };
            fs.writeFileSync(path.join(folder, name + '.dat'), Buffer.from(await (await game.encodeLevel(lv, who)).arrayBuffer()));
        }
        fs.writeFileSync(versionFile, String(presets.version) + '\n');
    }

    const ls = {
        world: null, state: 'waiting', mapName: null, endsAt: 0, lastCount: null,
        round: new Map(),          // player id -> { lives, deaths, placed, out, safeUntil }
        votes: new Map(), options: [], melting: new Map(), safe: null,
        skips: new Set(),          // players who typed /skip this build phase
        players() { return this.world ? ctx.worldPlayers(this.world) : []; },
        say(text, color = YELLOW) { if (this.world) ctx.broadcastWorld(this.world, { t: 'chat', text, color }); console.log('[Lava Survival] ' + text); },
        entry(p) { if (!this.round.has(p.id)) this.round.set(p.id, { lives: LIVES, deaths: 0, placed: 0, out: false, safeUntil: 0 }); return this.round.get(p.id); }
    };

    // Is (x, y, z) in the safe area round the spawn? (grow: also its walls, so they never melt)
    function inSafe(x, y, z, grow = 0) {
        const s = ls.safe;
        return !!s && x >= s.x0 - grow && x <= s.x1 + grow && y >= s.y0 - grow && y <= s.y1 + grow && z >= s.z0 - grow && z <= s.z1 + grow;
    }

    // Load a map from the folder into the Lava Survival level (fresh every round)
    async function loadMap(name) {
        const file = path.join(folder, name + '.dat');
        const lv = await game.decodeLevel(new Blob([fs.readFileSync(file)]));
        const sp = lv.savedPlayer || ctx.findSpawn(lv);
        const fx = Math.floor(sp.x), fy = Math.floor(sp.y - PLAYER_HEIGHT + 0.01), fz = Math.floor(sp.z);
        ls.safe = { x0: fx - 3, x1: fx + 2, y0: fy, y1: fy + 5, z0: fz - 3, z1: fz + 2 };   // 6 x 6 x 6
        lv.liquidBlocked = (x, y, z) => inSafe(x, y, z);
        lv.savedPlayer = sp;
        ls.mapName = name;
        ls.melting.clear();
        ctx.setWorldLevel(ls.world, lv);
        // melting: any block next to lava starts heating up
        lv.addListener({
            tileChanged: (x, y, z) => {
                if (lv.getTile(x, y, z) !== B.LAVA) return;
                for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
                    const nx = x + dx, ny = y + dy, nz = z + dz;
                    if (MELT[lv.getTile(nx, ny, nz)] && !inSafe(nx, ny, nz, 1)) {
                        const k = (ny * lv.height + nz) * lv.width + nx;
                        if (!ls.melting.has(k)) ls.melting.set(k, Date.now());
                    }
                }
            }
        });
        console.log(`Lava Survival map: ${name}`);
    }

    // Send the current map to one player, or to everyone on the level
    const sendMap = p => ctx.sendLevelTo(p, ls.world, ls.mapName);

    function canBuild(p) {
        const e = ls.round.get(p.id);
        return (ls.state === 'building' || ls.state === 'flooding') && !!e && !e.out;
    }
    function whyNoBuilding(p) {
        if (!ctx.canBuildBase(p)) return 'Type /agree to accept the rules first, then you can build. (/rules to read them)';
        const e = ls.round.get(p.id);
        if (e && e.out) return 'You\'re out of lives: you\'re spectating until the next round.';
        if (ls.state === 'results' || ls.state === 'voting' || ls.state === 'loading') return 'The round is over: you can build again when the next one starts.';
        if (!e) return 'You\'ll join in when the next round starts.';
        return null;
    }
    const updateBuild = p => ctx.send(p, { t: 'levelRules', building: ctx.canBuildBase(p) && canBuild(p), hideNametags: false });

    function startBuilding() {
        ls.state = 'building';
        ls.skips.clear();
        ls.endsAt = Date.now() + BUILD_SECONDS * 1000;
        ls.lastCount = null;
        ls.round.clear();
        for (const p of ls.players()) { ls.entry(p); updateBuild(p); }
        ls.say(`Lava Survival on ${ls.mapName}! You've got ${fmt(BUILD_SECONDS)} to build a base before the lava comes.`, ORANGE);
        ls.say(`You have ${LIVES} lives. The area round the spawn is safe from lava.`);
    }

    function startFlood() {
        ls.state = 'flooding';
        ls.skips.clear();
        ls.endsAt = Date.now() + FLOOD_SECONDS * 1000;
        ls.lastCount = null;
        // the lava starts a few blocks above whatever is in the middle of the map (and above the
        // safe area, if that's in the middle), so it doesn't spend ages falling from the sky
        const lv = ls.world.level, cx = Math.floor(lv.width / 2), cz = Math.floor(lv.height / 2);
        let top = lv.depth - 3;
        while (top > 0 && lv.getTile(cx, top, cz) === B.AIR) top--;
        let y = top + 4;
        const s = ls.safe;
        if (cx >= s.x0 - 1 && cx <= s.x1 + 1 && cz >= s.z0 - 1 && cz <= s.z1 + 1) y = Math.max(y, s.y1 + 3);
        y = Math.min(lv.depth - 2, y);
        lv.setTile(cx, y, cz, B.LAVA);               // the server's world ticks make it spread (and tell everyone)
        ctx.broadcastWorld(ls.world, { t: 'set', x: cx, y, z: cz, b: B.LAVA });
        ls.say('THE LAVA IS COMING!', RED);
    }

    // /skip: when more than half of the players here have voted, the lava starts straight away
    const skipsNeeded = () => Math.floor(ls.players().length / 2) + 1;
    function checkSkips() {
        if (ls.state !== 'building' || !ls.skips.size) return;
        if (ls.skips.size >= skipsNeeded()) { ls.say('Majority voted to skip!', ORANGE); startFlood(); }
    }

    function die(p, e) {
        e.deaths++;
        e.lives--;
        e.safeUntil = Date.now() + 2000;
        ls.say(`${p.name} melted in magma`, ORANGE);
        if (e.lives > 0) ctx.tell(p, `You've got ${e.lives} ${e.lives === 1 ? 'life' : 'lives'} left`, YELLOW);
        else { e.out = true; ctx.tell(p, 'You\'re out of lives! You\'re spectating now.', RED); updateBuild(p); }
        ctx.teleport(p, ls.world.level.savedPlayer);
    }

    function points(p, e) {
        const lv = ls.world.level;
        const height = e.out ? 0 : Math.max(0, Math.min(lv.depth, Math.floor(p.y - PLAYER_HEIGHT)));
        const survival = e.out ? 0 : [100, 60, 30][e.deaths] || 0;
        return { total: e.placed + height * 2 + survival, height, survival };
    }

    function finishRound() {
        ls.state = 'results';
        ls.endsAt = Date.now() + RESULTS_SECONDS * 1000;
        const scores = ls.players().filter(p => ls.round.has(p.id)).map(p => {
            const e = ls.round.get(p.id), s = points(p, e);
            const how = e.out ? 'out of lives' : ['survived the whole thing', 'died once', 'died twice'][e.deaths];
            return { name: p.name, total: s.total, text: `${p.name}: ${s.total} points (${e.placed} blocks, height ${s.height}, ${how})` };
        }).sort((a, b) => a.total - b.total);          // least to most
        ls.say('The round is over! Points, from least to most:', AQUA);
        for (const s of scores) ls.say(s.text, 0xFFFFFF);
        if (scores.length) ls.say(`${scores[scores.length - 1].name} wins with ${scores[scores.length - 1].total} points!`, GREEN);
        else ls.say('Nobody played this round.', GREY);
    }

    function startVote() {
        ls.state = 'voting';
        ls.endsAt = Date.now() + VOTE_SECONDS * 1000;
        ls.votes.clear();
        const pool = mapNames().filter(n => n !== ls.mapName);
        const all = pool.length >= 3 ? pool : mapNames();
        ls.options = [];
        while (ls.options.length < Math.min(3, all.length)) {          // three different maps
            const m = all[Math.floor(Math.random() * all.length)];
            if (!ls.options.includes(m)) ls.options.push(m);
        }
        ls.say(`Vote for the next map! Type 1, 2 or 3 in chat (${VOTE_SECONDS} seconds):`, AQUA);
        ls.options.forEach((m, i) => ls.say(`${i + 1}) ${m}`, 0xFFFFFF));
    }

    async function finishVote() {
        const count = ls.options.map((_, i) => [...ls.votes.values()].filter(v => v === i).length);
        const best = Math.max(...count);
        const tied = ls.options.filter((_, i) => count[i] === best);
        const next = tied[Math.floor(Math.random() * tied.length)];
        ls.say(`Next map: ${next}!` + (best ? ` (${best} vote${best === 1 ? '' : 's'})` : ''), GREEN);
        ls.state = 'loading';
        await loadMap(next);
        for (const p of ls.players()) await sendMap(p);
        ls.state = 'waiting';
    }

    const fmt = s => s >= 60 ? `${Math.floor(s / 60)} minute${s >= 120 ? 's' : ''}${s % 60 ? ' ' + (s % 60) + ' seconds' : ''}` : `${s} seconds`;
    function countdown(left, marks, say) {
        const s = Math.ceil(left);
        if (s !== ls.lastCount && marks.includes(s)) { ls.lastCount = s; say(s); }
    }

    let busy = false;
    async function tick() {
        if (!ls.world || busy) return;
        busy = true;
        try {
            const now = Date.now(), left = (ls.endsAt - now) / 1000, here = ls.players();
            if (ls.state === 'waiting') {
                if (here.length >= MIN_PLAYERS) startBuilding();
            } else if (ls.state === 'building') {
                countdown(left, [240, 180, 120, 60, 30, 10, 3, 2, 1], s => ls.say(s <= 3 ? `${s}...` : `The lava comes in ${fmt(s)}!`, s <= 10 ? RED : YELLOW));
                if (!here.length) ls.state = 'waiting';
                else if (left <= 0) startFlood();
            } else if (ls.state === 'flooding') {
                countdown(left, [120, 60, 30, 10], s => ls.say(`${fmt(s)} of lava left!`));
                // melting: blocks that have touched lava long enough become lava
                const lv = ls.world.level;
                for (const [k, since] of ls.melting) {
                    const x = k % lv.width, z = Math.floor(k / lv.width) % lv.height, y = Math.floor(k / (lv.width * lv.height));
                    const t = lv.getTile(x, y, z);
                    if (!MELT[t]) { ls.melting.delete(k); continue; }
                    if (now - since >= MELT[t] * 1000) {
                        ls.melting.delete(k);
                        lv.setTile(x, y, z, B.LAVA);
                        ctx.broadcastWorld(ls.world, { t: 'set', x, y, z, b: B.LAVA });     // everyone sees it melt
                    }
                }
                // lives
                for (const p of here) {
                    const e = ls.entry(p);
                    const fx = Math.floor(p.x), fz = Math.floor(p.z), feet = Math.floor(p.y - PLAYER_HEIGHT + 0.01);
                    const inLava = [feet, feet + 1].some(y => lv.getTile(fx, y, fz) === B.LAVA);
                    if (!inLava || now < e.safeUntil) continue;
                    if (e.out) ctx.teleport(p, lv.savedPlayer);                 // spectators just go back to safety
                    else die(p, e);
                }
                const playing = here.filter(p => !ls.entry(p).out);
                if (left <= 0 || (here.length && !playing.length) || !here.length) finishRound();
            } else if (ls.state === 'results') {
                if (left <= 0) startVote();
            } else if (ls.state === 'voting') {
                if (left <= 0) await finishVote();
            }
        } catch (err) { console.error('Lava Survival error:', err); }
        busy = false;
    }

    return {
        async start() {
            await makePresetMaps();
            const names = mapNames();
            if (!names.length) return null;
            ls.world = ctx.makeWorld('Lava Survival');
            ls.world.isLava = true;
            await loadMap(names[Math.floor(Math.random() * names.length)]);
            setInterval(tick, 100);
            return ls.world;
        },
        canBuild,
        whyNoBuilding,
        onBlockPlaced(p, x, y, z) {
            const e = ls.round.get(p.id);
            if (e) e.placed++;
            // placed right next to lava: it starts melting too
            const lv = ls.world.level, t = lv.getTile(x, y, z);
            if (MELT[t] && !inSafe(x, y, z, 1) && [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]].some(([dx, dy, dz]) => lv.getTile(x + dx, y + dy, z + dz) === B.LAVA)) {
                const k = (y * lv.height + z) * lv.width + x;
                if (!ls.melting.has(k)) ls.melting.set(k, Date.now());
            }
        },
        onJoin(p) {
            if (ls.state === 'building' || ls.state === 'flooding') ls.entry(p);
            updateBuild(p);
            const what = ls.state === 'building' ? 'Build a base before the lava comes!'
                : ls.state === 'flooding' ? 'The lava is already flowing: find somewhere safe!'
                : 'A new round starts soon.';
            ctx.tell(p, `Welcome to Lava Survival on ${ls.mapName}! ${what}`, ORANGE);
            if (!ctx.canBuildBase(p)) ctx.tell(p, 'Type /agree to accept the rules, so you can build. (/rules to read them)', YELLOW);
        },
        onLeave(p) {
            ls.round.delete(p.id); ls.votes.delete(p.id);
            ls.skips.delete(p.id);
            setTimeout(checkSkips, 0);           // one fewer player: the votes left might be a majority now
        },
        // /skip: vote to skip the rest of the build time
        skip(p) {
            if (ls.state !== 'building') { ctx.tell(p, 'You can only /skip during the build time.', RED); return; }
            if (ls.skips.has(p.id)) { ctx.tell(p, `You've already voted to skip (${ls.skips.size}/${skipsNeeded()}).`, YELLOW); return; }
            ls.skips.add(p.id);
            ls.say(`${p.name} voted to skip the build time (${ls.skips.size}/${skipsNeeded()})`, YELLOW);
            checkSkips();
        },
        // chat: during the vote, "1", "2" or "3" is a vote (and isn't shown to everyone)
        onChat(p, text) {
            if (ls.state !== 'voting' || !/^[123]$/.test(text.trim())) return false;
            const i = Number(text.trim()) - 1;
            if (i >= ls.options.length) return false;
            ls.votes.set(p.id, i);
            ctx.tell(p, `You voted for ${ls.options[i]}.`, GREEN);
            return true;
        },
        state: () => ls,
        mapNames
    };
};
