CLAUDECRAFT SERVER
==================
Run your own Claudecraft server: your friends join with a link, from any computer.

WHAT YOU NEED
  - A Windows computer that stays on while people play.
  - Node.js (free): https://nodejs.org  (download the LTS version and install it)

START IT
  1. Unzip this folder somewhere (for example your Documents).
  2. Double-click "Start Server.bat".
     The first time, it installs what it needs (about a minute) and downloads cloudflared,
     which gives your server a public link. The control panel opens in your browser.
  3. Open server.properties (made on the first start) and put YOUR Claudecraft username
     after  owner=   so you become the Owner. Restart the server.
  4. Share the join link the server shows (https://....trycloudflare.com). Friends paste it
     under Join Server on the play page, or just open it. It changes each time you restart.
     Your server also shows up on the website's Servers page by itself while it's running
     (list-on-website=false keeps it off). Keep server_token.txt secret: it's what lets only
     your server change its entry on the list.

SETTINGS (server.properties)
  Every setting is explained inside the file. The main ones:
    server-name=          what your server is called
    owner=                YOUR username (the Owner gets every command)
    server-type=          regular, anarchy or hide-and-seek
    max-players=          how many people can join
    minigames=            false = no minigame levels at all
    lava-survival=        true/false: the Lava Survival level
    hide-and-seek-level=  true/false: the Hide and Seek map plays as Hide and Seek

  Minigame maps: the maps folder has the ones that come with the server. They're copied into
  your server's "lava survival" and "hide and seek" folders, where you can add your own .dat
  levels too. Lava Survival votes on 3 maps each round; Hide and Seek plays a different map
  each round.
    spleef=               true/false: the Spleef level (break the floor under the others)
    versions=             true/false: /version lets players switch to older versions of
                          Minecraft (0.0.19a so far), each with its own world
    require-agree=        players type /agree to accept your rules before building
    list-on-website=      true/false: show your server on the website's Servers page
  Restart the server after changing a setting.

RUNNING IT
  - The control panel (opens automatically) shows players, chat, ranks and levels.
  - In-game commands: /help, /goto <level>, /levels, /rank, /kick, /ban, /rules, /version.
  - /version 0.0.19a switches you to Minecraft Classic 0.0.19a, in its own world (saved as
    versions/world19.dat in your server's folder). /goto world19 shows players on 0.32 a copy
    of it that catches up every hour. /version 0.32 goes back.
  - Levels are saved automatically. Put .dat files in the server folder to add levels.
  - If the server ever crashes it restarts by itself; see crash-log.txt for what happened.
  - To stop it: the Stop button in the control panel, or close the server window.

HELP
  https://claudecraft.neocities.org/help.html  and the Servers board on the forums.
