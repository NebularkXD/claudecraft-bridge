CLAUDECRAFT SERVER
==================
Run your own Claudecraft server: your friends join with a link, from any computer.

WHAT YOU NEED
  - A Windows computer that stays on while people play.
  - Node.js (free): https://nodejs.org  (download the LTS version and install it)

START IT
  1. Unzip this folder somewhere (for example your Documents).
  2. Double-click "Start Server.bat".
     The first time, it installs what it needs (about a minute) and downloads cloudflared,
     which gives your server a public link. The control panel opens in your browser.
  3. Open server.properties (made on the first start) and put YOUR Claudecraft username
     after  owner=   so you become the Owner. Restart the server.
  4. Share the join link the server shows (https://....trycloudflare.com). Friends paste it
     under Join Server on the play page, or just open it. It changes each time you restart.

SETTINGS (server.properties)
  Every setting is explained inside the file. The main ones:
    server-name=          what your server is called
    owner=                YOUR username (the Owner gets every command)
    server-type=          regular, anarchy or hide-and-seek
    max-players=          how many people can join
    minigames=            false = no minigame levels at all
    lava-survival=        true/false: the Lava Survival level
    hide-and-seek-level=  true/false: the Hide and Seek map plays as Hide and Seek
    require-agree=        players type /agree to accept your rules before building
  Restart the server after changing a setting.

RUNNING IT
  - The control panel (opens automatically) shows players, chat, ranks and levels.
  - In-game commands: /help, /goto <level>, /levels, /rank, /kick, /ban, /rules.
  - Levels are saved automatically. Put .dat files in the server folder to add levels.
  - If the server ever crashes it restarts by itself; see crash-log.txt for what happened.
  - To stop it: the Stop button in the control panel, or close the server window.

HELP
  https://claudecraft.neocities.org/help.html  and the Servers board on the forums.
