const THREE = require('three');

// ============================================================
// MINECRAFT RECREATION
// VERSION: 0.0.27a_05
// - Mobs no longer have the "TEST" nametag over them (a leftover test feature).
// ============================================================

const VERSION = "0.0.27a_05";

const CHUNK_SIZE = 16;

// Current level size (x, z, y). These change when a new level is generated or loaded.
let MAP_WIDTH = 256;
let MAP_HEIGHT = 256;
let MAP_DEPTH = 256;

// Sizes offered by Generate new level...
const LEVEL_SIZES = [
    { label: 'Small', w: 128, h: 128, d: 128 },
    { label: 'Normal', w: 256, h: 256, d: 256 },
    { label: 'Huge', w: 512, h: 512, d: 512 }
];
const LEVEL_FILE_MAGIC = 0x4D435243; // "MCRC"
const LEVEL_FILE_VERSION = 2;      // 2 adds the player's position and look direction
const LEVEL_SLOTS = 5;
const SAVE_NAME_MAX = 32;         // a level's name on the Levels page
const SAVE_DESC_MAX = 100;        // and its description
const SERVER_ADDRESS_MAX = 80;    // longest server address you can type
const DEFAULT_PORT = 25565;       // used when the address has no port
const OLD_SERVER_WARNING = 'This server is out of date: update and restart server.js to chat';
const CHAT_MAX = 64;              // longest chat message
const CHAT_SHOW_SECONDS = 10;     // how long a new message stays on screen
const CHAT_WIDTH = 320;           // widest a chat line gets, in font pixels; longer messages wrap
const CHAT_HISTORY = 100;         // messages kept
const CHAT_LINES_OPEN = 20;       // lines shown while the chat line is open
const NET_SEND_MS = 50;           // how often your position is sent to the server (20 times a second)
const LEVEL_NAME_MAX = 24;      // longest slot name shown (taken from the file name)

// Saved levels live in the browser's IndexedDB. Each slot has a small "meta-N" record
// (name and size, for the menus) and a "data-N" record (the compressed level).
const LevelStore = {
    db: null,
    open() {
        if (this.db) return Promise.resolve(this.db);
        return new Promise((resolve, reject) => {
            const req = indexedDB.open('mc-recreation-levels', 1);
            req.onupgradeneeded = () => req.result.createObjectStore('levels');
            req.onsuccess = () => { this.db = req.result; resolve(this.db); };
            req.onerror = () => reject(req.error);
        });
    },
    // Runs one read or write on the store; resolves with its result (or null) when it's done
    async run(mode, action) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction('levels', mode);
            const req = action(tx.objectStore('levels'));
            tx.oncomplete = () => resolve(req.result === undefined ? null : req.result);
            tx.onerror = () => reject(tx.error);
        });
    },
    get(key) { return this.run('readonly', st => st.get(key)); },
    put(key, value) { return this.run('readwrite', st => st.put(value, key)); },
    remove(key) { return this.run('readwrite', st => st.delete(key)); },
    async slotNames() {
        const names = [];
        for (let i = 0; i < LEVEL_SLOTS; i++) {
            const meta = await this.get('meta-' + i);
            names.push(meta ? meta.name : null);
        }
        return names;
    }
};

// Level <-> bytes: a 20-byte header (magic, version, width, height, depth) then the blocks
// Level <-> bytes. Version 2: a 20-byte header (magic, version, width, height, depth), then the
// player (x, y, z, look up/down, look left/right as 5 floats), then the blocks.
// Version 1 files (no player) still load.
async function encodeLevel(level, player) {
    const header = new Int32Array([LEVEL_FILE_MAGIC, LEVEL_FILE_VERSION, level.width, level.height, level.depth]);
    const p = player
        ? [player.position.x, player.position.y, player.position.z, player.rotation.x, player.rotation.y]
        : [NaN, NaN, NaN, 0, 0];
    const playerData = new Float32Array(p);
    const blob = new Blob([header, playerData, level.blocks]);
    if (typeof CompressionStream !== 'undefined') {
        try {
            return await new Response(blob.stream().pipeThrough(new CompressionStream('gzip'))).blob();
        } catch (err) { console.warn('Compression failed, saving uncompressed', err); }
    }
    return blob;
}

async function decodeLevel(blob) {
    let buf = new Uint8Array(await blob.arrayBuffer());
    if (buf[0] === 0x1f && buf[1] === 0x8b) { // gzip
        const ds = new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'));
        buf = new Uint8Array(await new Response(ds).arrayBuffer());
    }
    const header = new Int32Array(buf.buffer.slice(buf.byteOffset, buf.byteOffset + 20));
    const [magic, version, w, h, d] = header;
    if (magic !== LEVEL_FILE_MAGIC || (version !== 1 && version !== 2)) throw new Error('Not a level');
    const dataStart = version === 2 ? 40 : 20;
    if (buf.length !== dataStart + w * h * d) throw new Error('Level data is the wrong size');
    const level = new Level(w, h, d, buf.slice(dataStart));
    if (version === 2) {
        const p = new Float32Array(buf.buffer.slice(buf.byteOffset + 20, buf.byteOffset + 40));
        if (p.every(Number.isFinite)) level.savedPlayer = { x: p[0], y: p[1], z: p[2], rotX: p[3], rotY: p[4] };
    }
    return level;
}

const JUMP_FORCE = 8.4;       // 0.42 blocks per tick, Minecraft's jump
const MC_GRAVITY = 0.08;      // Minecraft gravity, blocks per tick added to fall speed each tick
const MC_AIR_DRAG = 0.98;     // Minecraft vertical air drag, kept per tick
const PLAYER_HEIGHT = 1.62;
const PLAYER_WIDTH = 0.6;
const PLAYER_SPEED = 4.317;
const REACH_DISTANCE = 5;
const MAX_MOVE_STEP = 0.45;       // the furthest the player moves in one collision check (blocks)
const THIRD_PERSON_DISTANCE = 2.5; // how far behind you the camera sits in third person (F5)
const LIMB_SPEED = 0.8;           // how fast the arms and legs swing through their motion
const OWNER_TAG_COLOR = 0xFFFF55;  // the server owner's nametag (yellow)
const NAMETAG_PIXEL = 0.04;       // size of one font pixel in blocks
const HEAD_TURN_LIMIT = 50 * Math.PI / 180; // how far the head turns before the body follows
const BODY_TURN_EASE = 0.25;      // share of the gap the body closes each tick toward your view while walking
const LIMB_EASE = 0.4;            // share of the gap the walk animation closes each tick (old Minecraft: 0.4; lower = slower wind-down)
const MOUSE_MAX_JUMP = 400;       // a single mouse movement bigger than this (pixels) is ignored
const MOUSE_SETTLE_MS = 150;      // ignore mouse movement this long after the mouse is captured or released

// Water physics, in Minecraft units (blocks per tick, 20 ticks per second)
const SWIM_TICK = 1 / 20;
const SWIM_UP = 0.04;            // upward push per tick while holding jump in water (Minecraft value)
const SWIM_ACCEL = 0.025;        // sideways acceleration per tick in water (Minecraft uses 0.02)
const WATER_DRAG = 0.8;          // velocity kept per tick in water
const WATER_SINK = 0.02;         // downward pull per tick in water
const SWIM_AIR_ACCEL = 0.02;     // sideways acceleration per tick while bobbing above the water
const SWIM_AIR_DRAG = 0.91;      // sideways velocity kept per tick while bobbing above the water
const SWIM_AIR_GRAVITY = 0.08;   // gravity per tick while your body is above the water
const SWIM_CLIMB = 0.3;          // upward speed per tick when climbing out onto an edge (hold jump)
const SWIM_CLIMB_CLEARANCE = 2.2; // how high above you must be open to climb (lets you climb a shore 1 block above the water)
const LAVA_DRAG = 0.5;           // velocity kept per tick in lava (Minecraft value)
const LAVA_ACCEL = 0.02;         // sideways acceleration per tick in lava (Minecraft value)
const SWIM_BOB_HEIGHT = 1.15;    // eye height above the water where buoyancy and gravity balance
const SWIM_BUOYANCY = 0.06;      // upward push per tick for each block of your body under water
const SWIM_BOB_DAMP = 0.97;      // vertical velocity kept per tick while bobbing (light drag)
const SWIM_KICK = 0.04;          // swim kick at the bottom of each bob (varies +-25%)
const SWIM_FLOAT_LINE = 0.4;     // Minecraft's float check starts this far above your feet

const TICK_RATE = 20;
const MS_PER_TICK = 1000 / TICK_RATE;

// Chunk sections (16x16x16) and how far they're drawn
// Render distance settings, cycled with F. Sections beyond the distance aren't drawn, and
// the fog fades things out between fogStart and fogEnd.
const RENDER_DISTANCES = [
    // skyFog: how much the sky blends into the fog colour (1 = sky is all fog)
    { name: 'Far', dist: 512, fogStart: 64, fogEnd: 512, skyFog: 0.0 },
    { name: 'Normal', dist: 224, fogStart: 24, fogEnd: 224, skyFog: 1.0 },
    { name: 'Short', dist: 96, fogStart: 6, fogEnd: 96, skyFog: 1.0 },
    { name: 'Tiny', dist: 40, fogStart: 0, fogEnd: 40, skyFog: 1.0 }
];
const UNLOAD_MARGIN = 64;                  // sections this far past the render distance are freed
const CHUNK_BUILD_BUDGET_MS = 4;           // time per frame spent building new sections
const FOG_COLOR = 0xEAF4FF;                // Classic's fog is a pale blue-white haze
const SKY_COLOR = 0x81CCFF;
const UNCAPPED_FPS = false;                // true = draw as fast as possible (frames beyond the screen's refresh are wasted)
const BACKGROUND_BUILD_MS = 2;             // time per frame for rebuilding scenery after big changes (not your own edits)
const NET_APPLY_MS = 1.5;                  // time per frame for applying block changes from a server

// Shade multipliers are written as on-screen brightness (like Classic). The renderer works
// in linear light, so convert them first or the shading gets washed out.
function shade(v) { return Math.pow(v, 2.2); }

// Brightness of each face (on-screen), and the multiplier for spots out of the sky's light
const FACE_SHADE = { top: 1.0, northSouth: 0.85, eastWest: 0.72, bottom: 0.6 };
const SHADOW_SHADE = 0.7;

// Darkness inside liquids: a fixed amount for water and for lava (not depth based)
const WATER_DARKEN = 0.65;          // anything in water, at any depth
const LAVA_DARKEN = 0.55;           // anything in lava


// Clouds (clouds.png): height above the water, size and drift, like Classic
const CLOUD_HEIGHT_ABOVE_WATER = 34; // Classic: 2 above a 64-tall level, i.e. 34 above the water
const CLOUD_BLOCKS_PER_PIXEL = 8;
const CLOUD_SPEED = 0.6;       // blocks per second

const WATER_TINT = 0x5A78FF;   // multiplies the water texture to make it bluer
const WATER_OPACITY = 0.65;

const WATER_UV = [13, 0];
const LAVA_UV = [14, 1];
const BEDROCK_UV = [1, 1];
const SEA_LEVEL = 32;

// Height limit: the highest block you can place. Standing on top of it puts your eyes
// exactly level with the clouds, so the clouds sit at that eye height.
const BUILD_LIMIT_Y = Math.floor(SEA_LEVEL + CLOUD_HEIGHT_ABOVE_WATER - PLAYER_HEIGHT) - 1;
const CLOUD_Y = BUILD_LIMIT_Y + 1 + PLAYER_HEIGHT;

// ---- Terrain tuning ----
const WATER_FRACTION = 0.30;     // share of the map below the water line (lakes and waterways)
const MIN_LAKE_SIZE = 16;        // water patches with fewer columns than this are filled in
const PLATEAU_FLAT_RADIUS = 2;   // land must be the same height this far around to count as flat
const PLATEAU_MIN_SIZE = 60;     // smallest flat area (in columns) that can become a gravel plateau
const PLATEAU_MAX_SIZE = 3000;   // flat areas bigger than this (huge lowlands) are left alone
const PLATEAU_EDGE_SPREAD = 3;   // plateau gravel spreads this far past the flat core over level ground
const PLATEAU_CHANCE = 0.25;      // share of qualifying flat areas that become gravel
const GRAVEL_FLOOR_COVERAGE = 0.2; // share of lake/sea floor covered in gravel patches
const CLIFF_SMOOTHING = 4;       // blur radius for the cliff noise (higher = smoother ledge lines)
const TERRAIN_MAX = 5;           // roughly how many blocks above the water the highest ground reaches
const BEACH_WIDTH = 4;           // max horizontal distance from ocean for sand
const MIN_ISLAND_SIZE = 12;      // land patches with fewer columns than this become water
const BEACH_MAX_ABOVE_WATER = 1; // sand surface may be 0 to this many blocks above the water
const MAX_WATER_DEPTH = 5;       // deepest the ocean gets, in blocks of water
const CLIFF_STEP = 3;            // height of each big cliff ledge
const CLIFF_LEVELS = [0.0, 0.4, 0.75];      // cliff-noise values where a big ledge starts
const SMALL_CLIFF_STEP = 2;      // height of each small cliff ledge
const SMALL_CLIFF_LEVELS = [0.05, 0.5];     // small-cliff-noise values where a small ledge starts
const CLIFF_SHORE_DIST = 5;      // cliffs only appear this many blocks or more from the water
const BEACH_COVERAGE = 0.5;      // roughly the share of low shoreline that gets a sandy beach
const SHELF_WIDTH = 8;           // how far the sandy shelf reaches out under the water from a beach
const GRAVEL_MAX_HOLE = 30;      // holes up to this many columns get gravel in their bottom

const BLOCK = {
    AIR: 0,
    ROCK: 1,
    GRASS: 2,
    DIRT: 3,
    COBBLESTONE: 4,
    PLANKS: 5,
    SAPLING: 6,
    WATER: 7,
    BEDROCK: 8,
    LAVA: 9,
    SAND: 10,
    GRAVEL: 11,
    LOG: 12,
    LEAVES: 13,
    COAL_ORE: 14,
    IRON_ORE: 15,
    GOLD_ORE: 16
};

const BLOCK_UVS = {
    [BLOCK.ROCK]: [1, 0],
    [BLOCK.DIRT]: [2, 0],
    [BLOCK.COBBLESTONE]: [0, 1],
    [BLOCK.PLANKS]: [4, 0],
    [BLOCK.SAPLING]: [15, 0],
    [BLOCK.WATER]: WATER_UV,
    [BLOCK.BEDROCK]: BEDROCK_UV,
    [BLOCK.LAVA]: LAVA_UV,
    [BLOCK.SAND]: [2, 1],
    [BLOCK.GRAVEL]: [3, 1],
    [BLOCK.LOG]: [4, 1],      // side texture; top and bottom use LOG_TOP_UV
    [BLOCK.LEAVES]: [6, 1],
    [BLOCK.GOLD_ORE]: [0, 2],
    [BLOCK.IRON_ORE]: [1, 2],
    [BLOCK.COAL_ORE]: [2, 2]
};

// How dark a spot is because of the liquid it's in (1 = not in a liquid)
function liquidDarkness(level, x, y, z) {
    const t = level.getTile(x, y, z);
    if (t === BLOCK.LAVA) return LAVA_DARKEN;
    if (t === BLOCK.WATER) return WATER_DARKEN;
    return 1;
}

const LOG_TOP_UV = [5, 1];

// Texture for one face of a block. ny is the face normal's y (1 = top, -1 = bottom, 0 = side).
function faceUV(type, ny) {
    if (type === BLOCK.GRASS) return ny === 1 ? [0, 0] : ny === -1 ? [2, 0] : [3, 0];
    if (type === BLOCK.LOG) return ny !== 0 ? LOG_TOP_UV : BLOCK_UVS[BLOCK.LOG];
    return BLOCK_UVS[type] || [2, 0];
}

// Blocks you can see through, so the faces of blocks next to them still get drawn
function isSeeThrough(type) {
    return type === BLOCK.AIR || type === BLOCK.WATER || type === BLOCK.LAVA ||
        type === BLOCK.SAPLING || type === BLOCK.LEAVES;
}

// Texture coordinates [u0, v0, u1, v1] of a 16x16 tile in terrain.png, pulled in by e so
// neighbouring tiles don't bleed in
function tileUV(col, row, e) {
    return [col / 16 + e, 1 - (row + 1) / 16 + e, (col + 1) / 16 - e, 1 - row / 16 - e];
}

// A BufferGeometry from plain arrays (colors are optional)
function makeGeometry(positions, uvs, colors, indices) {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    if (colors) geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geo.setIndex(indices);
    return geo;
}

// A sapling's two crossed quads, centred on the origin and 1 block tall
function plantCrossGeometry(col, row, e, withColors) {
    const d = 0.353553;
    const positions = [-d, -0.5, -d, d, -0.5, d, d, 0.5, d, -d, 0.5, -d, d, -0.5, -d, -d, -0.5, d, -d, 0.5, d, d, 0.5, -d];
    const [u0, v0, u1, v1] = tileUV(col, row, e);
    const uvs = [u0, v0, u1, v0, u1, v1, u0, v1, u0, v0, u1, v0, u1, v1, u0, v1];
    return makeGeometry(positions, uvs, withColors ? new Array(24).fill(1) : null, [0, 1, 2, 0, 2, 3, 4, 5, 6, 4, 6, 7]);
}

// The six faces of a block: their normal and four corners, in the order they're always built
const BLOCK_FACES = [
    { n: [0, 1, 0], c: [[0, 1, 0], [0, 1, 1], [1, 1, 1], [1, 1, 0]] },
    { n: [0, -1, 0], c: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]] },
    { n: [0, 0, 1], c: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]] },
    { n: [0, 0, -1], c: [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]] },
    { n: [1, 0, 0], c: [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]] },
    { n: [-1, 0, 0], c: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]] }
];

// Movement keys and the input each one drives
const MOVE_KEYS = { KeyW: 'forward', KeyS: 'backward', KeyA: 'left', KeyD: 'right', Space: 'jump' };

const HOTBAR = [BLOCK.DIRT, BLOCK.ROCK, BLOCK.COBBLESTONE, BLOCK.PLANKS, BLOCK.SAPLING, BLOCK.SAND, BLOCK.GRAVEL, BLOCK.LOG, BLOCK.LEAVES];
const LIQUID_BLOCKS = [BLOCK.WATER, BLOCK.LAVA];   // extra blocks on servers that allow them (Anarchy)
// every block a server can give beyond the usual nine (it says which: e.g. Admins get them all)
const EXTRA_BLOCKS = [BLOCK.WATER, BLOCK.LAVA, BLOCK.COAL_ORE, BLOCK.IRON_ORE, BLOCK.GOLD_ORE];

let seedState = BigInt(Date.now()) ^ BigInt(Math.floor(Math.random() * 0xFFFFFFFF));
function getUniqueSeed() {
    seedState = (seedState * 0x5DEECE66Dn + 0xBn) & ((1n << 48n) - 1n);
    return Number(seedState);
}

class JavaRandom {
    constructor(seed) {
        this.setSeed(seed === undefined ? getUniqueSeed() : seed);
    }
    setSeed(seed) {
        this.seed = (BigInt(seed) ^ 0x5DEECE66Dn) & ((1n << 48n) - 1n);
    }
    next(bits) {
        this.seed = (this.seed * 0x5DEECE66Dn + 0xBn) & ((1n << 48n) - 1n);
        return Number(this.seed >> (48n - BigInt(bits)));
    }
    nextInt(bound) {
        if (bound === undefined) return this.next(32) | 0;
        if ((bound & -bound) === bound) {
            return Number((BigInt(bound) * BigInt(this.next(31))) >> 31n);
        }
        let bits, val;
        do {
            bits = this.next(31);
            val = bits % bound;
        } while (bits - val + (bound - 1) < 0);
        return val;
    }
    nextFloat() {
        return this.next(24) / 16777216;
    }
}

// Fast 32-bit random numbers (xorshift) for things that run constantly, like block ticks.
// JavaRandom is kept for world generation.
class FastRandom {
    constructor(seed = (Math.random() * 0xFFFFFFFF) >>> 0) {
        this.s = (seed >>> 0) || 0x9E3779B9;
    }
    nextU32() {
        let x = this.s;
        x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
        this.s = x >>> 0;
        return this.s;
    }
    nextInt(bound) { return this.nextU32() % bound; }
    nextFloat() { return this.nextU32() / 4294967296; }
}

class NoiseMap {
    constructor(levels) {
        this.random = new JavaRandom();
        this.seed = this.random.nextInt();
        this.levels = 0;
        this.fuzz = 16;
        this.levels = levels;
    }

    read(width, height) {
        const random = new JavaRandom();
        const tmp = new Int32Array(width * height);
        const level = this.levels;
        let step = width >> level;

        for (let y = 0; y < height; y += step) {
            for (let x = 0; x < width; x += step) {
                tmp[x + y * width] = (random.nextInt(256) - 128) * this.fuzz;
            }
        }

        for (step = width >> level; step > 1; step = Math.trunc(step / 2)) {
            const val = 256 * (step << level);
            const ss = Math.trunc(step / 2);

            for (let y = 0; y < height; y += step) {
                for (let x = 0; x < width; x += step) {
                    const ul = tmp[(x + 0) % width + ((y + 0) % height) * width];
                    const ur = tmp[(x + step) % width + ((y + 0) % height) * width];
                    const dl = tmp[(x + 0) % width + ((y + step) % height) * width];
                    const dr = tmp[(x + step) % width + ((y + step) % height) * width];
                    const m = Math.trunc((ul + dl + ur + dr) / 4) + random.nextInt(val * 2) - val;
                    tmp[x + ss + (y + ss) * width] = m;
                }
            }

            for (let y = 0; y < height; y += step) {
                for (let x = 0; x < width; x += step) {
                    const c = tmp[x + y * width];
                    const r = tmp[(x + step) % width + y * width];
                    const d = tmp[x + ((y + step) % height) * width];
                    const mu = tmp[((x + ss) & (width - 1)) + (((y + ss - step) & (height - 1)) * width)];
                    const ml = tmp[((x + ss - step) & (width - 1)) + (((y + ss) & (height - 1)) * width)];
                    const m = tmp[(x + ss) % width + ((y + ss) % height) * width];
                    const u = Math.trunc((c + r + m + mu) / 4) + random.nextInt(val * 2) - val;
                    const l = Math.trunc((c + d + m + ml) / 4) + random.nextInt(val * 2) - val;
                    tmp[x + ss + y * width] = u;
                    tmp[x + (y + ss) * width] = l;
                }
            }
        }

        const result = new Int32Array(width * height);
        for (let y = 0; y < height; ++y) {
            for (let x = 0; x < width; ++x) {
                result[x + y * width] = Math.trunc(tmp[(x % width) + (y % height) * width] / 512) + 128;
            }
        }
        return result;
    }
}

// Box blur of a w*h field with radius r, using a summed-area table.
function boxBlur(src, w, h, r) {
    const sw = w + 1;
    const sat = new Float64Array(sw * (h + 1));
    for (let z = 0; z < h; z++)
        for (let x = 0; x < w; x++)
            sat[(x + 1) + (z + 1) * sw] = src[x + z * w] + sat[x + (z + 1) * sw] + sat[(x + 1) + z * sw] - sat[x + z * sw];
    const out = new Float32Array(w * h);
    for (let z = 0; z < h; z++) {
        for (let x = 0; x < w; x++) {
            const x0 = Math.max(0, x - r), x1 = Math.min(w - 1, x + r);
            const z0 = Math.max(0, z - r), z1 = Math.min(h - 1, z + r);
            const sum = sat[(x1 + 1) + (z1 + 1) * sw] - sat[x0 + (z1 + 1) * sw]
                - sat[(x1 + 1) + z0 * sw] + sat[x0 + z0 * sw];
            out[x + z * w] = sum / ((x1 - x0 + 1) * (z1 - z0 + 1));
        }
    }
    return out;
}

// Rescales a field to [-1, 1] by its min and max.
function renormalize(arr) {
    let min = Infinity, max = -Infinity;
    for (let i = 0; i < arr.length; i++) { if (arr[i] < min) min = arr[i]; if (arr[i] > max) max = arr[i]; }
    const span = (max - min) || 1;
    const out = new Float32Array(arr.length);
    for (let i = 0; i < arr.length; i++) out[i] = ((arr[i] - min) / span) * 2 - 1;
    return out;
}


// Reads a NoiseMap and rescales it to the range [-1, 1] so thresholds are predictable.
// Higher levels = smaller, more frequent features.
function normalizedNoise(levels, w, h) {
    const raw = new NoiseMap(levels).read(w, h);
    let min = Infinity, max = -Infinity;
    for (let i = 0; i < raw.length; i++) {
        if (raw[i] < min) min = raw[i];
        if (raw[i] > max) max = raw[i];
    }
    const span = (max - min) || 1;
    const out = new Float32Array(raw.length);
    for (let i = 0; i < raw.length; i++) out[i] = ((raw[i] - min) / span) * 2 - 1;
    return out;
}

class LevelGen {
    constructor(width, height, depth) {
        this.width = width;
        this.height = height;
        this.depth = depth;
        this.random = new JavaRandom();
    }

    // Runs the whole generator in one go
    generateMap() {
        const steps = this.generateSteps();
        let r = steps.next();
        while (!r.done) r = steps.next();
        return r.value;
    }

    // The generator, a step at a time: yields [stage name, progress 0..1 within that stage]
    // so the loading screen can show it, and returns the finished block array
    *generateSteps() {
        const w = this.width, h = this.height, d = this.depth;
        const n = w * h;
        const WATER_TOP = SEA_LEVEL - 1; // highest water block; a surface block here is level with the water

        // Classic height noise: two coarse heightmaps, and a selector that decides where the
        // second one is allowed to raise the ground. max() of the two makes flat-topped plateaus.
        // Noise detail is tied to real distance, not map size, so a huge map has more hills and
        // lakes rather than the same few stretched out (one base feature per ~128 blocks)
        // Noise level that gives features about `size` blocks across on this map
        const lv = (size) => Math.max(0, Math.min(6, Math.round(Math.log2(w / size))));
        const heightmap1 = new NoiseMap(lv(128)).read(w, h);
        const heightmap2 = new NoiseMap(lv(128)).read(w, h);
        const cf = new NoiseMap(lv(64)).read(w, h);
        const lakeN = normalizedNoise(lv(32), w, h);  // scattered lakes and dips
        const roughN = normalizedNoise(lv(32), w, h); // small wobble for ragged coasts and terrace edges
        // Where the sharp surface cliffs/ledges go: low frequency and blurred so ledges run in
        // long clean lines instead of ragged patches
        const cliffN = renormalize(boxBlur(normalizedNoise(lv(64), w, h), w, h, CLIFF_SMOOTHING));
        const smallCliffN = renormalize(boxBlur(normalizedNoise(lv(32), w, h), w, h, 3));
        const floorGravelN = normalizedNoise(lv(32), w, h); // gravel patches on lake and sea floors
        // Sea floor shape: broad rolling ridges and dips, plus finer bumps
        const seaFloorN = renormalize(boxBlur(normalizedNoise(lv(32), w, h), w, h, 2));
        const seaDetailN = normalizedNoise(lv(16), w, h);
        const dirtN = normalizedNoise(lv(16), w, h);
        const beachMaskN = normalizedNoise(lv(64), w, h); // stretches of shore with or without beach

        yield ['Raising..', 0];
        // ---- Step 1: Raw height field and land mask ----
        const combined = new Float32Array(n);
        for (let i = 0; i < n; i++) {
            const dh1 = heightmap1[i];
            let dh2 = heightmap2[i];
            if (cf[i] < 128) dh2 = dh1;
            combined[i] = Math.max(dh1, dh2);
        }
        // Rescale by percentiles so every seed has a similar spread, whatever the noise amplitude
        const sortedC = Float32Array.from(combined).sort();
        const lo = sortedC[Math.floor(n * 0.02)], hi = sortedC[Math.floor(n * 0.98)];
        const span = (hi - lo) || 1;

        const raw = new Float32Array(n);
        for (let z = 0; z < h; z++) {
            for (let x = 0; x < w; x++) {
                const i = x + z * w;
                let v = ((combined[i] - lo) / span) * 2 - 1;
                v += lakeN[i] * 0.45;
                v += roughN[i] * 0.12;
                raw[i] = v;
            }
        }
        // Water level is placed by percentile so the amount of water is consistent between seeds
        const sorted = Float32Array.from(raw).sort();
        const threshold = sorted[Math.floor(n * WATER_FRACTION)];
        const peak = sorted[Math.floor(n * 0.995)];
        const step = Math.max(1e-6, (peak - threshold) / TERRAIN_MAX);
        // Whole-block terrace value: 0 = level with the water, negative = under water
        const terrace = new Int32Array(n);
        const land = new Uint8Array(n);
        for (let i = 0; i < n; i++) {
            terrace[i] = Math.floor((raw[i] - threshold) / step);
            land[i] = terrace[i] >= 0 ? 1 : 0;
        }

        yield ['Eroding..', 0];
        // ---- Step 2: Water bodies ----
        // Everything below the water line is water (lakes, rivers and seas). "ocean" below means
        // any water column. Tiny puddles become land and tiny specks of land become water.
        const ocean = new Uint8Array(n);
        for (let i = 0; i < n; i++) ocean[i] = land[i] ? 0 : 1;
        const queue = new Int32Array(n);

        const neighbours4 = (i) => {
            const x = i % w, z = (i / w) | 0;
            return [
                x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1,
                z > 0 ? i - w : -1, z < h - 1 ? i + w : -1
            ];
        };
        // Grows the connected patch containing start into list (marking it in mark), through
        // neighbours that pass ok(j, i). Returns the patch size.
        const growPatch = (start, mark, list, ok) => {
            let ph = 0, pt = 0;
            mark[start] = 1; list[pt++] = start;
            while (ph < pt) {
                const i = list[ph++];
                for (const j of neighbours4(i)) if (j >= 0 && !mark[j] && ok(j, i)) { mark[j] = 1; list[pt++] = j; }
            }
            return pt;
        };
        const visited = new Uint8Array(n);
        const patch = new Int32Array(n);
        // Flood-fills each connected patch of `mask` and flips patches smaller than minSize
        const removeSmallPatches = (mask, other, minSize) => {
            visited.fill(0);
            for (let start = 0; start < n; start++) {
                if (!mask[start] || visited[start]) continue;
                const pt = growPatch(start, visited, patch, j => mask[j]);
                if (pt < minSize) {
                    for (let k = 0; k < pt; k++) { mask[patch[k]] = 0; other[patch[k]] = 1; }
                }
            }
        };
        removeSmallPatches(ocean, land, MIN_LAKE_SIZE);
        removeSmallPatches(land, ocean, MIN_ISLAND_SIZE);

        // ---- Step 3: Distance fields (8-neighbour BFS) ----
        const bfs = (isSource) => {
            const dist = new Int32Array(n).fill(-1);
            let bh = 0, bt = 0;
            for (let i = 0; i < n; i++) {
                if (isSource(i)) { dist[i] = 0; queue[bt++] = i; }
            }
            while (bh < bt) {
                const i = queue[bh++];
                const x = i % w, z = (i / w) | 0;
                for (let dz = -1; dz <= 1; dz++) {
                    for (let dx = -1; dx <= 1; dx++) {
                        if (dx === 0 && dz === 0) continue;
                        const nx = x + dx, nz = z + dz;
                        if (nx < 0 || nz < 0 || nx >= w || nz >= h) continue;
                        const j = nx + nz * w;
                        if (dist[j] < 0) { dist[j] = dist[i] + 1; queue[bt++] = j; }
                    }
                }
            }
            return dist;
        };
        const distToOcean = bfs(i => ocean[i] === 1); // for land columns: 1 = touching the ocean
        const distToLand = bfs(i => land[i] === 1);   // for ocean columns: 1 = touching land

        // ---- Step 4: Heights ----
        // Straight from the terrace value, like Classic: land rises in whole-block steps from the
        // water line and the sea floor drops the same way.
        const heights = new Int32Array(n);
        for (let i = 0; i < n; i++) {
            if (ocean[i]) {
                // Uneven sea floor between 1 and MAX_WATER_DEPTH blocks deep: shallow near land,
                // deeper offshore, with rolling ridges and dips on top
                const dl = distToLand[i] < 0 ? 30 : distToLand[i];
                const base = 1 + Math.min(dl, 12) / 12 * (MAX_WATER_DEPTH - 2.5);
                let depth = Math.round(base + seaFloorN[i] * 1.6 + seaDetailN[i] * 0.6);
                depth = Math.max(1, Math.min(depth, MAX_WATER_DEPTH));
                heights[i] = WATER_TOP - depth;
            } else {
                // Filled-in lakes have negative terrace values and become flat ground at the water line
                let hh = WATER_TOP + Math.max(0, terrace[i]);

                // Sharp surface cliffs: hard thresholds on two cliff noises make sudden walls.
                // They're all-or-nothing past CLIFF_SHORE_DIST so they stay sheer, while
                // shores and beaches stay low.
                const dist = distToOcean[i] < 0 ? 50 : distToOcean[i];
                if (dist >= CLIFF_SHORE_DIST) {
                    for (const t of CLIFF_LEVELS) if (cliffN[i] > t) hh += CLIFF_STEP;
                    for (const t of SMALL_CLIFF_LEVELS) if (smallCliffN[i] > t) hh += SMALL_CLIFF_STEP;
                }

                heights[i] = Math.min(hh, d - 3);
            }
        }

        // 4d: cleanup. Fill single-column holes and flatten single-column spikes, on land and
        // on the sea floor (each only compared against neighbours of the same kind).
        for (let pass = 0; pass < 2; pass++) {
            const src = Int32Array.from(heights);
            for (let z = 0; z < h; z++) {
                for (let x = 0; x < w; x++) {
                    const i = x + z * w;
                    let mn = Infinity, mx = -Infinity, cnt = 0;
                    const check = (nx, nz) => {
                        if (nx < 0 || nz < 0 || nx >= w || nz >= h) return;
                        const j = nx + nz * w;
                        if (ocean[j] !== ocean[i]) return;
                        const v = src[j];
                        if (v < mn) mn = v;
                        if (v > mx) mx = v;
                        cnt++;
                    };
                    check(x - 1, z); check(x + 1, z); check(x, z - 1); check(x, z + 1);
                    if (cnt < 2) continue;
                    if (src[i] > mx) heights[i] = mx;       // spike: lower to its tallest neighbour
                    else if (src[i] < mn) heights[i] = mn;  // hole: raise to its lowest neighbour
                }
            }
        }


        yield ['Watering..', 0];
        // ---- Step 5: Beaches and the sandy shelf in front of them ----
        // Only some stretches of coast get a beach; the cutoff is a percentile so coverage is steady.
        const sortedB = Float32Array.from(beachMaskN).sort();
        const beachCutoff = sortedB[Math.floor(n * (1 - BEACH_COVERAGE))];
        const isBeach = new Uint8Array(n);
        for (let i = 0; i < n; i++) {
            if (ocean[i]) continue;
            const hh = heights[i];
            if (beachMaskN[i] >= beachCutoff && distToOcean[i] <= BEACH_WIDTH &&
                hh >= WATER_TOP && hh <= WATER_TOP + BEACH_MAX_ABOVE_WATER) {
                isBeach[i] = 1;
            }
        }
        // Spread sand over the connected low ground behind each beach so it isn't patchy
        {
            const beachTop = WATER_TOP + BEACH_MAX_ABOVE_WATER;
            let bh = 0, bt = 0;
            for (let i = 0; i < n; i++) if (isBeach[i]) queue[bt++] = i;
            while (bh < bt) {
                const i = queue[bh++];
                for (const j of neighbours4(i)) {
                    if (j < 0 || ocean[j] || isBeach[j]) continue;
                    if (heights[j] > beachTop || distToOcean[j] > BEACH_WIDTH + 6) continue;
                    isBeach[j] = 1;
                    queue[bt++] = j;
                }
            }
        }
        // Clean up: grass mostly surrounded by sand becomes sand too
        for (let pass = 0; pass < 8; pass++) {
            let changed = 0;
            for (let i = 0; i < n; i++) {
                if (ocean[i] || isBeach[i]) continue;
                const nb = neighbours4(i); // left, right, up, down
                const sandy = (j) => j >= 0 && (isBeach[j] || ocean[j]);
                let sandN = 0, beachN4 = 0;
                for (const j of nb) {
                    if (sandy(j)) sandN++;
                    if (j >= 0 && isBeach[j]) beachN4++;
                }
                // Sandwiched between sand on opposite sides, or mostly surrounded by sand
                const sandwiched = (sandy(nb[0]) && sandy(nb[1])) || (sandy(nb[2]) && sandy(nb[3]));
                if (beachN4 >= 1 && (sandN >= 3 || sandwiched) && (beachN4 >= 2 || sandwiched)) {
                    isBeach[i] = 1;
                    if (heights[i] > WATER_TOP + BEACH_MAX_ABOVE_WATER) heights[i] = WATER_TOP + BEACH_MAX_ABOVE_WATER;
                    changed++;
                }
            }
            if (!changed) break;
        }

        // The sand carries on under the water and slopes down gently instead of dropping off
        const shelfDist = new Int32Array(n).fill(-1);
        {
            let sh = 0, st = 0;
            for (let i = 0; i < n; i++) if (isBeach[i]) { shelfDist[i] = 0; queue[st++] = i; }
            while (sh < st) {
                const i = queue[sh++];
                if (shelfDist[i] >= SHELF_WIDTH) continue;
                for (const j of neighbours4(i)) {
                    if (j >= 0 && ocean[j] && shelfDist[j] < 0) {
                        shelfDist[j] = shelfDist[i] + 1;
                        queue[st++] = j;
                    }
                }
            }
        }
        const isShelf = new Uint8Array(n);
        for (let i = 0; i < n; i++) {
            if (!ocean[i] || shelfDist[i] <= 0) continue;
            // 1 block deep for the first 2 columns, then 1 block deeper every 2 columns
            const shelfH = WATER_TOP - 1 - Math.floor((shelfDist[i] - 1) / 2);
            if (shelfH > heights[i]) heights[i] = shelfH;
            isShelf[i] = 1;
        }

        yield ['Soiling..', 0];
        // ---- Step 6: Gravel in the bottom of little holes ----
        // Priority flood from the sea: fill[i] is the level water would have to rise to before it
        // could drain out of column i. Where fill is above the ground, the column sits in a hole.
        const fill = new Int32Array(n).fill(-1);
        const buckets = [];
        for (let k = 0; k < d; k++) buckets.push([]);
        for (let i = 0; i < n; i++) {
            if (ocean[i]) { fill[i] = WATER_TOP; buckets[WATER_TOP].push(i); }
        }
        for (let lvl = 0; lvl < d; lvl++) {
            const bucket = buckets[lvl];
            while (bucket.length) {
                const i = bucket.pop();
                for (const j of neighbours4(i)) {
                    if (j < 0 || fill[j] >= 0) continue;
                    fill[j] = Math.max(heights[j], lvl);
                    buckets[fill[j]].push(j);
                }
            }
        }
        // Group hole columns into separate holes; small ones get gravel on their lowest blocks
        const isGravel = new Uint8Array(n);
        const holeSeen = new Uint8Array(n);
        const holeCols = new Int32Array(n);
        for (let start = 0; start < n; start++) {
            if (ocean[start] || holeSeen[start] || fill[start] <= heights[start]) continue;
            let hh2 = 0, ht = 0;
            holeSeen[start] = 1; holeCols[ht++] = start;
            let minH = heights[start];
            while (hh2 < ht) {
                const i = holeCols[hh2++];
                if (heights[i] < minH) minH = heights[i];
                for (const j of neighbours4(i)) {
                    if (j >= 0 && !ocean[j] && !holeSeen[j] && fill[j] > heights[j]) {
                        holeSeen[j] = 1; holeCols[ht++] = j;
                    }
                }
            }
            if (ht > GRAVEL_MAX_HOLE) continue;
            for (let k = 0; k < ht; k++) {
                const i = holeCols[k];
                if (heights[i] === minH && !isBeach[i]) isGravel[i] = 1;
            }
        }

        // ---- Surface block per column ----
        const sortedFG = Float32Array.from(floorGravelN).sort();
        const floorGravelCut = sortedFG[Math.floor(n * (1 - GRAVEL_FLOOR_COVERAGE))];
        const surface = new Uint8Array(n);
        for (let i = 0; i < n; i++) {
            if (ocean[i]) {
                // Sandy shelf off beaches, otherwise dirt with patches of gravel
                if (isShelf[i]) surface[i] = BLOCK.SAND;
                else surface[i] = floorGravelN[i] > floorGravelCut ? BLOCK.GRAVEL : BLOCK.DIRT;
            }
            else if (isBeach[i]) surface[i] = BLOCK.SAND;
            else if (isGravel[i]) surface[i] = BLOCK.GRAVEL;
            else surface[i] = BLOCK.GRASS;
        }

        // ---- Gravel plateaus on long flat stretches ----
        // 1. Flat cores: land columns where everything within PLATEAU_FLAT_RADIUS is land at the
        //    same height. 2. From the cores, spread over all connected land at that height to get
        //    the whole flat. 3. Flats of the right size are turned to gravel, some of the time.
        const PR = PLATEAU_FLAT_RADIUS;
        const flatArea = new Uint8Array(n);
        for (let z = PR; z < h - PR; z++) {
            for (let x = PR; x < w - PR; x++) {
                const i = x + z * w;
                if (ocean[i]) continue;
                const hh = heights[i];
                let flat = true;
                for (let dz = -PR; dz <= PR && flat; dz++) {
                    for (let dx = -PR; dx <= PR; dx++) {
                        const j = i + dx + dz * w;
                        if (ocean[j] || heights[j] !== hh) { flat = false; break; }
                    }
                }
                if (!flat) continue;
                for (let dz = -PR; dz <= PR; dz++)
                    for (let dx = -PR; dx <= PR; dx++) flatArea[i + dx + dz * w] = 1;
            }
        }
        {
            const seen = new Uint8Array(n);
            const cols = new Int32Array(n);
            for (let start = 0; start < n; start++) {
                if (!flatArea[start] || seen[start]) continue;
                const hh = heights[start];
                let ct = growPatch(start, seen, cols, j => flatArea[j] && heights[j] === hh);
                if (ct < PLATEAU_MIN_SIZE || ct > PLATEAU_MAX_SIZE) continue;
                if (this.random.nextFloat() >= PLATEAU_CHANCE) continue;
                // Spread a few columns further over the same flat ground so the edges follow the
                // land's shape instead of the square search window
                const dist = new Map();
                for (let k = 0; k < ct; k++) dist.set(cols[k], 0);
                let gh = 0;
                while (gh < ct) {
                    const i = cols[gh++];
                    const di = dist.get(i);
                    if (di >= PLATEAU_EDGE_SPREAD) continue;
                    for (const j of neighbours4(i)) {
                        if (j >= 0 && !ocean[j] && !dist.has(j) && heights[j] === hh) {
                            dist.set(j, di + 1);
                            cols[ct++] = j;
                        }
                    }
                }
                for (let k = 0; k < ct; k++) surface[cols[k]] = BLOCK.GRAVEL;
            }
        }

        // ---- No gravel on cliffs ----
        // Gravel is one block thick, so above a drop its side would show as a thin grey strip.
        // Check each connected gravel patch as a whole: if any part of it is above a lower
        // neighbour, the whole patch goes back to grass (dirt under water). Land gravel next to
        // water is fine.
        {
            const seen = new Uint8Array(n);
            const patchCols = new Int32Array(n);
            for (let start = 0; start < n; start++) {
                if (surface[start] !== BLOCK.GRAVEL || seen[start]) continue;
                const wet = ocean[start];
                let onCliff = false;
                const pt = growPatch(start, seen, patchCols, (j, i) => {
                    if (surface[j] === BLOCK.GRAVEL && ocean[j] === wet) return true;
                    if (heights[j] < heights[i] && (wet || !ocean[j])) onCliff = true;   // a drop next to the patch
                    return false;
                });
                if (!onCliff) continue;
                for (let k = 0; k < pt; k++) surface[patchCols[k]] = wet ? BLOCK.DIRT : BLOCK.GRASS;
            }
        }

        // ---- Step 7: Fill the block array ----
        const blocks = new Uint8Array(w * h * d);
        for (let x = 0; x < w; ++x) {
            if ((x & 7) === 0) yield ['Soiling..', x / w];
            for (let z = 0; z < h; ++z) {
                const col = x + z * w;
                const dh = heights[col];
                const surf = surface[col];
                const dirtDepth = 2 + Math.floor((dirtN[col] + 1) * 1.5); // 2..5 blocks of dirt
                const rh = Math.max(1, dh - dirtDepth);
                // Beach sand is 3 deep, shelf sand 2 deep. All gravel is just the surface block.
                const subDepth = surf === BLOCK.SAND ? (ocean[col] ? 2 : 3) : 0;

                for (let y = 0; y < d; ++y) {
                    const i = (y * h + z) * w + x;
                    let id = BLOCK.AIR;

                    if (y === 0) {
                        id = BLOCK.BEDROCK;
                    } else if (y < dh) {
                        if (y <= rh) id = BLOCK.ROCK;
                        else if (y >= dh - subDepth) id = surf;
                        else id = BLOCK.DIRT;
                    } else if (y === dh) {
                        id = surf;
                    } else if (y < SEA_LEVEL) {
                        id = BLOCK.WATER;
                    }

                    blocks[i] = id;
                }
            }
        }

        // ---- Step 8: Underground caves (lava pools in the deepest ones) ----
        const count = Math.trunc(Math.trunc(w * h * d / 256) / 64);
        for (let i = 0; i < count; ++i) {
            if ((i & 15) === 0) yield ['Carving..', i / count];
            let x = this.random.nextFloat() * w;
            let y = this.random.nextFloat() * d;
            let z = this.random.nextFloat() * h;
            const length = Math.trunc(this.random.nextFloat() + this.random.nextFloat() * 150.0);
            let dir1 = this.random.nextFloat() * Math.PI * 2.0, dira1 = 0.0;
            let dir2 = this.random.nextFloat() * Math.PI * 2.0, dira2 = 0.0;
            for (let l = 0; l < length; ++l) {
                x += Math.sin(dir1) * Math.cos(dir2);
                z += Math.cos(dir1) * Math.cos(dir2);
                y += Math.sin(dir2);
                dir1 += dira1 * 0.2;
                dira1 = dira1 * 0.9 + (this.random.nextFloat() - this.random.nextFloat());
                dir2 = (dir2 + dira2 * 0.5) * 0.5;
                dira2 = dira2 * 0.9 + (this.random.nextFloat() - this.random.nextFloat());
                const size = Math.sin(l * Math.PI / length) * 2.5 + 1.0;
                for (let xx = Math.trunc(x - size); xx <= Math.trunc(x + size); ++xx) {
                    for (let yy = Math.trunc(y - size); yy <= Math.trunc(y + size); ++yy) {
                        for (let zz = Math.trunc(z - size); zz <= Math.trunc(z + size); ++zz) {
                            const xd = xx - x, yd = yy - y, zd = zz - z;
                            if (xd * xd + yd * yd * 2.0 + zd * zd < size * size &&
                                xx >= 1 && yy >= 1 && zz >= 1 &&
                                xx < w - 1 && yy < d - 1 && zz < h - 1) {
                                const ii = (yy * h + zz) * w + xx;
                                if (blocks[ii] === BLOCK.ROCK) {
                                    blocks[ii] = yy < 10 ? BLOCK.LAVA : BLOCK.AIR;
                                }
                            }
                        }
                    }
                }
            }
        }

        // ---- Ores: veins of coal, iron and gold in the stone ----
        // [block, abundance (%), highest y the vein may start at]
        const ores = [
            [BLOCK.COAL_ORE, 90, SEA_LEVEL + 20],
            [BLOCK.IRON_ORE, 70, SEA_LEVEL + 20],
            [BLOCK.GOLD_ORE, 50, SEA_LEVEL + 20]
        ];
        for (const [ore, abundance, maxY] of ores) {
            yield ['Carving..', 1];
            this.placeOreVeins(blocks, ore, abundance, maxY);
        }

        yield ['Melting..', 1];

        // ---- Step 9: Trees ----
        yield ['Planting..', 0];
        this.plantTrees(blocks);
        yield ['Planting..', 1];

        return blocks;
    }

    // Classic-style ore veins: a wandering line through the stone, thickest in the middle,
    // turning stone it passes into ore
    placeOreVeins(blocks, ore, abundance, maxY) {
        const w = this.width, h = this.height, d = this.depth;
        const rockLayers = Math.min(d, maxY);
        const count = Math.trunc(w * h * rockLayers / 256 / 64 * abundance / 100);
        for (let i = 0; i < count; i++) {
            let x = this.random.nextFloat() * w;
            let y = this.random.nextFloat() * rockLayers;
            let z = this.random.nextFloat() * h;
            const length = Math.trunc((this.random.nextFloat() + this.random.nextFloat()) * 75 * abundance / 100);
            let dir1 = this.random.nextFloat() * Math.PI * 2, dira1 = 0;
            let dir2 = this.random.nextFloat() * Math.PI * 2, dira2 = 0;
            for (let l = 0; l < length; l++) {
                x += Math.sin(dir1) * Math.cos(dir2);
                z += Math.cos(dir1) * Math.cos(dir2);
                y += Math.sin(dir2);
                dir1 += dira1 * 0.2;
                dira1 = dira1 * 0.9 + (this.random.nextFloat() - this.random.nextFloat());
                dir2 = (dir2 + dira2 * 0.5) * 0.5;
                dira2 = dira2 * 0.9 + (this.random.nextFloat() - this.random.nextFloat());
                const size = Math.sin(l * Math.PI / length) * abundance / 100 + 1;
                for (let xx = Math.trunc(x - size); xx <= Math.trunc(x + size); xx++) {
                    for (let yy = Math.trunc(y - size); yy <= Math.trunc(y + size); yy++) {
                        for (let zz = Math.trunc(z - size); zz <= Math.trunc(z + size); zz++) {
                            const xd = xx - x, yd = yy - y, zd = zz - z;
                            if (xd * xd + yd * yd * 2 + zd * zd >= size * size) continue;
                            if (xx < 1 || yy < 1 || zz < 1 || xx >= w - 1 || yy >= d - 1 || zz >= h - 1) continue;
                            const ii = (yy * h + zz) * w + xx;
                            if (blocks[ii] === BLOCK.ROCK) blocks[ii] = ore;
                        }
                    }
                }
            }
        }
    }

    // Groves of oak trees on grass, scattered the way Classic did it: pick a grove centre,
    // then random-walk around it trying to plant.
    plantTrees(blocks) {
        const w = this.width, h = this.height, d = this.depth;
        const idx = (x, y, z) => (y * h + z) * w + x;
        const groves = Math.trunc(w * h / 4000);
        for (let g = 0; g < groves; g++) {
            const gx = this.random.nextInt(w);
            const gz = this.random.nextInt(h);
            for (let j = 0; j < 20; j++) {
                let x = gx, z = gz;
                for (let k = 0; k < 20; k++) {
                    x += this.random.nextInt(6) - this.random.nextInt(6);
                    z += this.random.nextInt(6) - this.random.nextInt(6);
                    if (x < 2 || z < 2 || x >= w - 2 || z >= h - 2) continue;
                    if (this.random.nextFloat() >= 0.25) continue;
                    // Find the ground
                    let y = d - 1;
                    while (y > 0 && blocks[idx(x, y, z)] === BLOCK.AIR) y--;
                    if (blocks[idx(x, y, z)] !== BLOCK.GRASS) continue;
                    const height = this.random.nextInt(2) + 4; // 4 or 5 logs
                    this.growTree(blocks, x, y + 1, z, height);
                }
            }
        }
    }

    // Tree shape: trunk of `height` logs, two full 3x3 leaf layers around the top two logs,
    // and a + of leaves on top. (x, y, z) is the bottom of the trunk.
    growTree(blocks, x, y, z, height) {
        const w = this.width, h = this.height, d = this.depth;
        const idx = (xx, yy, zz) => (yy * h + zz) * w + xx;
        const top = y + height; // the + layer sits just above the last log
        if (top >= d || x < 1 || z < 1 || x >= w - 1 || z >= h - 1) return false;

        // Check there's room: the trunk column below the leaves, then the 3x3 area above that
        for (let yy = y; yy <= top; yy++) {
            const r = yy >= top - 2 ? 1 : 0;
            for (let xx = x - r; xx <= x + r; xx++)
                for (let zz = z - r; zz <= z + r; zz++)
                    if (blocks[idx(xx, yy, zz)] !== BLOCK.AIR) return false;
        }

        blocks[idx(x, y - 1, z)] = BLOCK.DIRT;

        // Two full 3x3 layers
        for (let yy = top - 2; yy <= top - 1; yy++)
            for (let xx = x - 1; xx <= x + 1; xx++)
                for (let zz = z - 1; zz <= z + 1; zz++)
                    blocks[idx(xx, yy, zz)] = BLOCK.LEAVES;

        // + on top
        blocks[idx(x, top, z)] = BLOCK.LEAVES;
        blocks[idx(x - 1, top, z)] = BLOCK.LEAVES;
        blocks[idx(x + 1, top, z)] = BLOCK.LEAVES;
        blocks[idx(x, top, z - 1)] = BLOCK.LEAVES;
        blocks[idx(x, top, z + 1)] = BLOCK.LEAVES;

        // Trunk, running up into the leaves
        for (let yy = y; yy < y + height; yy++) blocks[idx(x, yy, z)] = BLOCK.LOG;
        return true;
    }
}

class Level {
    // Pass blocks to use an existing (loaded) level instead of generating a new one
    constructor(w, h, d, blocks) {
        this.width = w; this.height = h; this.depth = d;
        this.lightDepths = new Int32Array(w * h);
        this.levelListeners = [];
        this.activeLiquids = new Map();
        // flowing liquids waiting their turn, in time order (water and lava wait different times)
        this.liquidQueues = { 500: [], 1000: [] };
        this.liquidHeads = { 500: 0, 1000: 0 };
        this.random = new FastRandom(); // block ticks
        if (blocks) {
            this.blocks = blocks;
        } else {
            console.log('Running LevelGen...');
            this.blocks = new LevelGen(w, h, d).generateMap();
            console.log('LevelGen done.');
        }
        this.calcLightDepths(0, 0, w, h);
    }

    calcLightDepths(x0, z0, x1, z1) {
        for (let x = x0; x < x0 + x1; ++x) {
            for (let z = z0; z < z0 + z1; ++z) {
                const oldDepth = this.lightDepths[x + z * this.width];
                let y = this.depth - 1;
                while (y > 0 && !this.isLightBlocker(x, y, z)) y--;
                this.lightDepths[x + z * this.width] = y;
                if (oldDepth !== y) {
                    const yl0 = oldDepth < y ? oldDepth : y;
                    const yl1 = oldDepth > y ? oldDepth : y;
                    for (let i = 0; i < this.levelListeners.length; i++) {
                        if (this.levelListeners[i].lightColumnChanged)
                            this.levelListeners[i].lightColumnChanged(x, z, yl0, yl1);
                    }
                }
            }
        }
    }

    hasAdjacentAir(x, y, z) {
        if (this.getTile(x - 1, y, z) === BLOCK.AIR) return true;
        if (this.getTile(x + 1, y, z) === BLOCK.AIR) return true;
        if (this.getTile(x, y - 1, z) === BLOCK.AIR) return true;
        if (this.getTile(x, y, z - 1) === BLOCK.AIR) return true;
        if (this.getTile(x, y, z + 1) === BLOCK.AIR) return true;
        return false;
    }

    enqueueLiquid(x, y, z, type, now) {
        // spreads into air, and reacts with the other liquid next to it
        const other = type === BLOCK.WATER ? BLOCK.LAVA : BLOCK.WATER;
        const touchesOther = [[-1, 0, 0], [1, 0, 0], [0, -1, 0], [0, 1, 0], [0, 0, -1], [0, 0, 1]]
            .some(([dx, dy, dz]) => this.getTile(x + dx, y + dy, z + dz) === other);
        if (!this.hasAdjacentAir(x, y, z) && !touchesOther) return;
        const idx = (y * this.height + z) * this.width + x;
        if (this.activeLiquids.has(idx)) return;
        const delay = (type === BLOCK.WATER) ? 500 : 1000;
        this.activeLiquids.set(idx, now + delay);
        this.liquidQueues[delay].push(idx, now + delay);
    }

    addListener(l) { this.levelListeners.push(l); }

    isLightBlocker(x, y, z) {
        const type = this.getTile(x, y, z);
        return type !== BLOCK.AIR && type !== BLOCK.SAPLING && type !== BLOCK.WATER && type !== BLOCK.LEAVES;
    }

    // force: also allow the bottom bedrock layer (used for changes a server sends, e.g. Anarchy)
    setTile(x, y, z, type, force = false) {
        if (x < 0 || y < 0 || z < 0 || x >= this.width || y >= this.depth || z >= this.height) return false;
        if (y === 0 && !force) return false;
        const index = (y * this.height + z) * this.width + x;
        if (this.blocks[index] === type) return false;
        this.blocks[index] = type;
        this.calcLightDepths(x, z, 1, 1);

        const now = performance.now();
        if (type === BLOCK.WATER || type === BLOCK.LAVA) {
            this.enqueueLiquid(x, y, z, type, now);
        }

        const neighbors = [
            [x - 1, y, z], [x + 1, y, z],
            [x, y - 1, z], [x, y + 1, z],
            [x, y, z - 1], [x, y, z + 1]
        ];
        for (const [nx, ny, nz] of neighbors) {
            if (nx >= 0 && ny >= 0 && nz >= 0 && nx < this.width && ny < this.depth && nz < this.height) {
                const nt = this.blocks[(ny * this.height + nz) * this.width + nx];
                if (nt === BLOCK.WATER || nt === BLOCK.LAVA) {
                    this.enqueueLiquid(nx, ny, nz, nt, now);
                }
            }
        }

        for (let i = 0; i < this.levelListeners.length; i++) {
            if (this.levelListeners[i].tileChanged) this.levelListeners[i].tileChanged(x, y, z);
        }
        return true;
    }

    isLit(x, y, z) {
        if (x < 0 || y < 0 || z < 0 || x >= this.width || y >= this.depth || z >= this.height) return true;
        return y >= this.lightDepths[x + z * this.width];
    }

    getTile(x, y, z) {
        if (x < 0 || y < 0 || z < 0 || x >= this.width || y >= this.depth || z >= this.height) return BLOCK.AIR;
        return this.blocks[(y * this.height + z) * this.width + x];
    }

    isSolidTile(x, y, z) {
        if (x < 0 || z < 0 || x >= this.width || z >= this.height) return true;
        const type = this.getTile(x, y, z);
        return type !== BLOCK.AIR && type !== BLOCK.SAPLING && type !== BLOCK.WATER && type !== BLOCK.LAVA;
    }

    isUnderwater(x, y, z) {
        for (let cy = y + 1; cy < this.depth; ++cy) {
            const t = this.getTile(x, cy, z);
            if (t === BLOCK.WATER) return true;
            if (t !== BLOCK.AIR && t !== BLOCK.SAPLING) return false;
        }
        return false;
    }

    // random: false skips grass growing and dying (e.g. a level on a server nobody is on)
    tick(now, random = true) {
        // only the liquids that are due (each queue is in time order)
        const toProcess = [];
        for (const delay of [500, 1000]) {
            const q = this.liquidQueues[delay];
            let h = this.liquidHeads[delay];
            while (h < q.length && q[h + 1] <= now) { if (this.activeLiquids.get(q[h]) === q[h + 1]) toProcess.push(q[h]); h += 2; }
            if (h > 4096 && h * 2 > q.length) { q.splice(0, h); h = 0; }      // drop the used-up start now and then
            this.liquidHeads[delay] = h;
        }

        for (const idx of toProcess) {
            this.activeLiquids.delete(idx);
            const x = idx % this.width;
            const z = Math.trunc(idx / this.width) % this.height;
            const y = Math.trunc(idx / (this.width * this.height));

            const type = this.blocks[idx];
            if (type !== BLOCK.WATER && type !== BLOCK.LAVA) continue;

            const other = type === BLOCK.WATER ? BLOCK.LAVA : BLOCK.WATER;
            const checkAndSpread = (nx, ny, nz) => {
                if (nx < 0 || ny < 0 || nz < 0 || nx >= this.width || ny >= this.depth || nz >= this.height) return;
                if (this.liquidBlocked && this.liquidBlocked(nx, ny, nz)) return;     // e.g. a safe area
                const nb = this.blocks[(ny * this.height + nz) * this.width + nx];
                if (nb === BLOCK.AIR) this.setTile(nx, ny, nz, type);
                else if (nb === other) this.setTile(nx, ny, nz, BLOCK.ROCK);   // water and lava make stone
            };
            // above: never spreads up, but the other liquid there still turns to stone
            if (y + 1 < this.depth && this.blocks[((y + 1) * this.height + z) * this.width + x] === other) this.setTile(x, y + 1, z, BLOCK.ROCK);

            checkAndSpread(x, y - 1, z);
            checkAndSpread(x - 1, y, z);
            checkAndSpread(x + 1, y, z);
            checkAndSpread(x, y, z - 1);
            checkAndSpread(x, y, z + 1);
        }

        const numTicks = random ? 14000 : 0;
        for (let i = 0; i < numTicks; i++) {
            const x = this.random.nextInt(this.width);
            const z = this.random.nextInt(this.height);
            const y = this.random.nextInt(this.depth);
            const type = this.getTile(x, y, z);

            if (type === BLOCK.DIRT) {
                if (this.isLit(x, y, z) && !this.isUnderwater(x, y, z)) {
                    this.setTile(x, y, z, BLOCK.GRASS);
                }
            } else if (type === BLOCK.GRASS) {
                if (!this.isLit(x, y, z) || this.isUnderwater(x, y, z)) {
                    this.setTile(x, y, z, BLOCK.DIRT);
                }
            }
        }
    }
}

class ChunkMeshBuilder {
    constructor(level, solidMaterial, waterMaterial, lavaMaterial, plantMaterial) {
        this.level = level;
        this.solidMaterial = solidMaterial;
        this.plantMaterial = plantMaterial || solidMaterial;
        this.waterMaterial = waterMaterial;
        this.lavaMaterial = lavaMaterial;
    }

    // Builds the meshes for one 16x16x16 section. Returns null if it has nothing to draw.
    buildChunkMesh(cx, cy, cz) {
        const y0 = cy * CHUNK_SIZE, y1 = Math.min(this.level.depth, y0 + CHUNK_SIZE);
        const buffer = () => ({ p: [], u: [], c: [], i: [], used: false });
        const solid = buffer(), water = buffer(), lava = buffer(), plant = buffer();
        for (let lx = 0; lx < CHUNK_SIZE; lx++) {
            for (let y = y0; y < y1; y++) {
                for (let lz = 0; lz < CHUNK_SIZE; lz++) {
                    const wx = cx * CHUNK_SIZE + lx, wz = cz * CHUNK_SIZE + lz;
                    const type = this.level.getTile(wx, y, wz);
                    if (type === BLOCK.AIR) continue;
                    if (type === BLOCK.SAPLING) this.addPlantFaces(plant, type, wx, y, wz);
                    else if (type === BLOCK.WATER) this.addLiquidFaces(water, type, wx, y, wz);
                    else if (type === BLOCK.LAVA) this.addLiquidFaces(lava, type, wx, y, wz);
                    else {
                        solid.used = true;
                        for (const f of BLOCK_FACES) this.addFace(solid, type, wx, y, wz, f);
                    }
                }
            }
        }
        const parts = [[plant, this.plantMaterial], [solid, this.solidMaterial], [lava, this.lavaMaterial], [water, this.waterMaterial]];
        if (!parts.some(([b]) => b.used)) return null;

        const group = new THREE.Group();
        for (const [b, material] of parts) {
            if (!b.used) continue;
            const mesh = new THREE.Mesh(makeGeometry(b.p, b.u, b.c, b.i), material);
            if (b === water) mesh.renderOrder = 1;   // water draws after everything else
            group.add(mesh);
        }
        // Sections never move, so work out their matrices once instead of every frame
        group.matrixAutoUpdate = false;
        group.updateMatrix();
        for (const child of group.children) {
            child.matrixAutoUpdate = false;
            child.updateMatrix();
        }
        return group;
    }

    // One quad: the 4 corners of face f of the block at (x, y, z); corners on the top sit at yTop
    pushQuad(b, f, x, y, yTop, z, col, row, light) {
        const idx = b.p.length / 3;
        for (const [ox, oy, oz] of f.c) b.p.push(x + ox, oy ? yTop : y, z + oz);
        const [u0, v0, u1, v1] = tileUV(col, row, 0.0005);
        if (f.n[1] === 1) b.u.push(u0, v0, u0, v1, u1, v1, u1, v0);
        else b.u.push(u0, v0, u1, v0, u1, v1, u0, v1);
        const lc = shade(light);
        for (let k = 0; k < 4; k++) b.c.push(lc, lc, lc);
        b.i.push(idx, idx + 1, idx + 2, idx, idx + 2, idx + 3);
    }

    // Water and lava: faces only where they meet something see-through and not the same liquid.
    // The top is 1/16 lower when there's no more of the liquid above.
    addLiquidFaces(b, type, wx, y, wz) {
        b.used = true;
        const topType = this.level.getTile(wx, y + 1, wz);
        const yTop = (topType !== type) ? (y + 15 / 16) : (y + 1);
        const [col, row] = BLOCK_UVS[type];
        for (const f of BLOCK_FACES) {
            const [nx, ny, nz] = f.n;
            const nb = this.level.getTile(wx + nx, y + ny, wz + nz);
            if (nb === type || this.level.isSolidTile(wx + nx, y + ny, wz + nz)) continue;
            let light = (ny === 1 ? FACE_SHADE.top : FACE_SHADE.northSouth);
            if (type === BLOCK.WATER) light *= this.level.isLit(wx, y + 1, wz) ? 1.0 : SHADOW_SHADE;
            this.pushQuad(b, f, wx, y, yTop, wz, col, row, light);
        }
    }

    // Saplings: two crossed quads
    addPlantFaces(b, type, wx, y, wz) {
        b.used = true;
        const idx = b.p.length / 3;
        const d = 0.353553;
        const x0 = wx + 0.5 - d, x1 = wx + 0.5 + d;
        const z0 = wz + 0.5 - d, z1 = wz + 0.5 + d;
        b.p.push(x0, y, z0, x1, y, z1, x1, y + 1, z1, x0, y + 1, z0,
            x1, y, z0, x0, y, z1, x0, y + 1, z1, x1, y + 1, z0);
        const [u0, v0, u1, v1] = tileUV(...BLOCK_UVS[type], 0.0005);
        b.u.push(u0, v0, u1, v0, u1, v1, u0, v1, u0, v0, u1, v0, u1, v1, u0, v1);
        const sky = this.level.isLit(wx, y + 1, wz) ? 1.0 : SHADOW_SHADE;
        const lc = shade(FACE_SHADE.northSouth * sky);
        for (let i = 0; i < 8; i++) b.c.push(lc, lc, lc);
        b.i.push(idx, idx + 1, idx + 2, idx, idx + 2, idx + 3, idx + 4, idx + 5, idx + 6, idx + 4, idx + 6, idx + 7);
    }

    // A solid block's face, drawn only if the neighbour on that side can be seen through
    addFace(b, type, wx, y, wz, f) {
        const [nx, ny, nz] = f.n;
        if (!isSeeThrough(this.level.getTile(wx + nx, y + ny, wz + nz))) return;
        if (y + ny < 0) return; // never seen: the underside of the bottom layer
        const [col, row] = faceUV(type, ny);
        const faceMult = ny === 1 ? FACE_SHADE.top : ny === -1 ? FACE_SHADE.bottom
            : nz !== 0 ? FACE_SHADE.northSouth : FACE_SHADE.eastWest;
        const sky = this.level.isLit(wx + nx, y + ny, wz + nz) ? 1.0 : SHADOW_SHADE;
        // faces looking into water or lava are darker
        const light = faceMult * sky * liquidDarkness(this.level, wx + nx, y + ny, wz + nz);
        this.pushQuad(b, f, wx, y, y + 1, wz, col, row, light);
    }
}

class BlockParticles {
    constructor(scene, texture) {
        this.scene = scene;
        this.texture = texture;
        this.particles = [];
        this.level = null;
        // One shared material for every particle (the texture area is in each one's UVs).
        // Cutout (not blended) and writing depth, so water behind a particle can't draw over it.
        this.material = new THREE.MeshBasicMaterial({
            map: texture, transparent: false, depthWrite: true, alphaTest: 0.1, side: THREE.DoubleSide
        });
    }
    static uvForBlock(type) {
        return faceUV(type, 0);
    }
    spawn(x, y, z, type, count) {
        if (type === BLOCK.AIR || type === BLOCK.WATER || type === BLOCK.LAVA || type === BLOCK.BEDROCK) return;
        const [tc, tr] = BlockParticles.uvForBlock(type);
        const tile = 1 / 16;
        const eps = 0.5 / 256;
        const uMin = tc * tile + eps, uMax = (tc + 1) * tile - eps;
        const vMin = 1 - (tr + 1) * tile + eps, vMax = 1 - tr * tile - eps;
        const tileW = uMax - uMin, tileH = vMax - vMin;
        const n = count == null ? (12 + Math.floor(Math.random() * 9)) : count;
        for (let i = 0; i < n; i++) {
            const frac = 0.20 + Math.random() * 0.20;
            const sU = tileW * frac, sV = tileH * frac;
            const su = uMin + Math.random() * (tileW - sU);
            const sv = vMin + Math.random() * (tileH - sV);
            const geo = new THREE.PlaneGeometry(0.12 + Math.random() * 0.08, 0.12 + Math.random() * 0.08);
            const uvs = geo.attributes.uv;
            uvs.setXY(0, su, sv + sV); uvs.setXY(1, su + sU, sv + sV);
            uvs.setXY(2, su, sv); uvs.setXY(3, su + sU, sv);
            uvs.needsUpdate = true;
            const mesh = new THREE.Mesh(geo, this.material);
            mesh.position.set(x + 0.2 + Math.random() * 0.6, y + 0.2 + Math.random() * 0.6, z + 0.2 + Math.random() * 0.6);
            const light = type === BLOCK.LEAVES;
            // Leaves: softer burst, weak gravity and air drag, so they drift down lightly
            const burst = light ? 3.5 : 4.0;
            this.particles.push({
                mesh,
                vx: (Math.random() - 0.5) * burst,
                vy: light ? 1.2 + Math.random() * 1.6 : 1.0 + Math.random() * 2.0,
                vz: (Math.random() - 0.5) * burst,
                life: light ? 2.0 + Math.random() * 1.0 : 1.0 + Math.random() * 0.5,
                onGround: false,
                rotSpeed: (Math.random() - 0.5) * (light ? 4 : 8),
                gravity: light ? 2.5 : 14,
                drag: light ? 1.8 : 0,            // fraction of speed lost per second in the air
                maxFall: light ? 0.9 : Infinity   // leaves drift down slowly
            });
            this.scene.add(mesh);
        }
    }
    update(dt, camera) {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.life -= dt;
            if (p.life <= 0) {
                this.scene.remove(p.mesh);
                p.mesh.geometry.dispose();
                this.particles.splice(i, 1);
                continue;
            }
            if (!p.onGround) {
                p.vy -= p.gravity * dt;
                if (p.drag > 0) {
                    const keep = Math.max(0, 1 - p.drag * dt);
                    p.vx *= keep; p.vz *= keep;
                    if (p.vy > 0) p.vy *= keep;
                }
                if (p.vy < -p.maxFall) p.vy = -p.maxFall;
            }
            const nextX = p.mesh.position.x + p.vx * dt;
            const nextY = p.mesh.position.y + p.vy * dt;
            const nextZ = p.mesh.position.z + p.vz * dt;
            const bx = Math.floor(nextX), by = Math.floor(nextY - 0.05), bz = Math.floor(nextZ);
            if (this.level && this.level.isSolidTile(bx, by, bz)) {
                p.mesh.position.y = by + 1.02;
                p.vy = 0; p.onGround = true;
                p.mesh.position.x = nextX; p.mesh.position.z = nextZ;
                p.vx *= Math.max(0, 1 - 10 * dt);
                p.vz *= Math.max(0, 1 - 10 * dt);
            } else {
                p.onGround = false;
                p.mesh.position.set(nextX, nextY, nextZ);
            }
            if (camera) p.mesh.quaternion.copy(camera.quaternion);
            p.mesh.rotation.z += p.rotSpeed * dt;
        }
    }
    setLevel(level) { this.level = level; }
}

// Keeps preview UVs inside their tile without visibly trimming it (~1/64 of a texture pixel)
const PREVIEW_UV_EPS = 1 / 16384;

class BlockPreview {
    constructor(texture) {
        this.scene = new THREE.Scene();

        // Orthographic Camera for perfect true isometric view without perspective distortion
        const frustumSize = 1.6;
        this.camera = new THREE.OrthographicCamera(
            -frustumSize / 2, frustumSize / 2,
            frustumSize / 2, -frustumSize / 2,
            0.1, 100
        );

        const dist = 10;
        this.camera.position.set(dist, dist, dist);
        this.camera.lookAt(0, 0, 0);

        this.texture = texture;
        this.mesh = null;
        this.currentType = -1;

        this.size = 112;
        this.margin = 20;
    }

    faceUVs(geo, faceIndex, col, row) {
        const [u0, v0, u1, v1] = tileUV(col, row, PREVIEW_UV_EPS);
        const base = faceIndex * 4;
        const uv = geo.attributes.uv;
        uv.setXY(base + 0, u0, v1); uv.setXY(base + 1, u1, v1);
        uv.setXY(base + 2, u0, v0); uv.setXY(base + 3, u1, v0);
    }

    buildMesh(type) {
        if (this.mesh) {
            this.scene.remove(this.mesh);
            this.mesh.geometry.dispose();
            this.mesh.material.dispose();
            this.mesh = null;
        }
        if (type === BLOCK.AIR) return;

        if (type === BLOCK.SAPLING) {
            const geo = plantCrossGeometry(...BLOCK_UVS[type], PREVIEW_UV_EPS, true);
            const mat = new THREE.MeshBasicMaterial({
                map: this.texture, vertexColors: true, transparent: true, alphaTest: 0.1, side: THREE.DoubleSide
            });
            this.mesh = new THREE.Mesh(geo, mat);
        } else {
            const geo = new THREE.BoxGeometry(1, 1, 1);
            // BoxGeometry faces, 4 vertices each: +x, -x, +y, -y, +z, -z. Flat shading per face.
            const faceNy = [0, 0, 1, -1, 0, 0];
            const faceShade = [FACE_SHADE.eastWest, FACE_SHADE.eastWest, FACE_SHADE.top,
                FACE_SHADE.bottom, FACE_SHADE.northSouth, FACE_SHADE.northSouth];
            const cols = [];
            for (let f = 0; f < 6; f++) {
                this.faceUVs(geo, f, ...faceUV(type, faceNy[f]));
                const sl = shade(faceShade[f]);
                for (let v = 0; v < 4; v++) cols.push(sl, sl, sl);
            }
            geo.attributes.uv.needsUpdate = true;
            geo.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
            const mat = new THREE.MeshBasicMaterial({
                map: this.texture, vertexColors: true, transparent: true, alphaTest: 0.1,
                side: type === BLOCK.LEAVES ? THREE.DoubleSide : THREE.FrontSide
            });
            this.mesh = new THREE.Mesh(geo, mat);
        }

        this.mesh.rotation.set(0, 0, 0);
        this.scene.add(this.mesh);
        this.currentType = type;
    }

    setType(type) {
        if (type !== this.currentType) {
            this.buildMesh(type);
        }
    }
}

class Player {
    constructor(level) {
        this.level = level;

        let sx = Math.floor(MAP_WIDTH / 2);
        let sz = Math.floor(MAP_HEIGHT / 2);
        let sy = MAP_DEPTH;
        let found = false;

        // Spiral outward from center to find a valid dry land spawn point
        for (let r = 0; r < MAP_WIDTH / 2 && !found; r++) {
            for (let dx = -r; dx <= r && !found; dx++) {
                for (let dz = -r; dz <= r && !found; dz++) {
                    if (Math.abs(dx) !== r && Math.abs(dz) !== r) continue;

                    const tx = sx + dx;
                    const tz = sz + dz;
                    if (tx < 0 || tx >= MAP_WIDTH || tz < 0 || tz >= MAP_HEIGHT) continue;

                    for (let y = MAP_DEPTH - 1; y > 0; y--) {
                        const t = level.getTile(tx, y, tz);
                        if (t !== BLOCK.AIR) {
                            if (t === BLOCK.GRASS || t === BLOCK.DIRT || t === BLOCK.ROCK ||
                                t === BLOCK.SAND || t === BLOCK.GRAVEL) {
                                sx = tx;
                                sz = tz;
                                // position.y is eye height: feet go on top of block y
                                sy = y + 1 + PLAYER_HEIGHT + 0.01;
                                found = true;
                            }
                            break;
                        }
                    }
                }
            }
        }

        if (!found) sy = MAP_DEPTH - 1 + PLAYER_HEIGHT; // nowhere dry: drop in from the top

        this.position = new THREE.Vector3(sx + 0.5, sy, sz + 0.5);
        this.velocity = new THREE.Vector3();
        this.rotation = { x: 0, y: 0 };
        this.onGround = false;
        this.swimming = false; // stays true while bobbing above the water until you land on something
        this.swimTickAccum = 0;
        this.moveDir = new THREE.Vector3();
        this.inventory = HOTBAR.slice();
        this.selectedSlot = 0;
    }

    getSelectedBlock() { return this.inventory[this.selectedSlot]; }

    cycleSlot(delta) {
        const n = this.inventory.length;
        this.selectedSlot = (this.selectedSlot + delta % n + n) % n;
    }

    isInMaterial(type) {
        const hw = PLAYER_WIDTH / 2;
        const x0 = Math.floor(this.position.x - hw);
        const x1 = Math.floor(this.position.x + hw);
        const y0 = Math.floor(this.position.y - PLAYER_HEIGHT + 0.1);
        const y1 = Math.floor(this.position.y + 0.1);
        const z0 = Math.floor(this.position.z - hw);
        const z1 = Math.floor(this.position.z + hw);

        for (let x = x0; x <= x1; x++) {
            for (let y = y0; y <= y1; y++) {
                for (let z = z0; z <= z1; z++) {
                    if (this.level.getTile(x, y, z) === type) return true;
                }
            }
        }
        return false;
    }

    // Float check for swimming: only water from SWIM_FLOAT_LINE above the feet up to just below
    // the eyes counts, so you float with your head out and dip back in on each bob.
    isBodyIn(liquid) {
        const hw = PLAYER_WIDTH / 2;
        const feet = this.position.y - PLAYER_HEIGHT;
        const x0 = Math.floor(this.position.x - hw), x1 = Math.floor(this.position.x + hw);
        const z0 = Math.floor(this.position.z - hw), z1 = Math.floor(this.position.z + hw);
        const y0 = Math.floor(feet + SWIM_FLOAT_LINE);
        const y1 = Math.max(y0, Math.floor(this.position.y - 0.4));
        for (let x = x0; x <= x1; x++)
            for (let y = y0; y <= y1; y++)
                for (let z = z0; z <= z1; z++)
                    if (this.level.getTile(x, y, z) === liquid) return true;
        return false;
    }

    // Height of the water's surface in your column (top of the highest water block from your
    // feet up to just above your head), or null if there's no water there
    // The visible surface of the water (or lava) you're in, or null
    waterSurfaceY(liquid = BLOCK.WATER) {
        const x = Math.floor(this.position.x), z = Math.floor(this.position.z);
        const y0 = Math.floor(this.position.y - PLAYER_HEIGHT), y1 = Math.floor(this.position.y) + 1;
        let top = null;
        for (let y = y0; y <= y1; y++) {
            if (this.level.getTile(x, y, z) === liquid) top = y;
            else if (top !== null) break;
        }
        return top === null ? null : top + 15 / 16;
    }


    update(dt, input) {
        const f = new THREE.Vector3(-Math.sin(this.rotation.y), 0, -Math.cos(this.rotation.y));
        const r = new THREE.Vector3(Math.cos(this.rotation.y), 0, -Math.sin(this.rotation.y));
        const m = new THREE.Vector3();

        if (input.forward) m.add(f);
        if (input.backward) m.sub(f);
        if (input.left) m.sub(r);
        if (input.right) m.add(r);
        if (m.lengthSq() > 0) m.normalize();
        this.moveDir.copy(m);

        const inWater = this.isInMaterial(BLOCK.WATER);
        const inLava = this.isInMaterial(BLOCK.LAVA);

        // Swimming state: starts when you touch water, ends only when you stand on something.
        // While it's on, the bob above the surface still uses swimming movement.
        if (inWater || inLava) this.swimming = true;
        else if (this.onGround) this.swimming = false;

        let landPhysics = false;
        if (inWater || inLava || (this.swimming && !this.onGround)) {
            // Minecraft water/lava movement, stepped at 20 ticks per second like the original.
            // Velocities are kept between ticks so you keep your momentum. Lava is the same
            // but much slower (Minecraft's 0.5 drag and 0.02 push).
            const liquid = inLava ? BLOCK.LAVA : BLOCK.WATER;
            const drag = inLava ? LAVA_DRAG : WATER_DRAG;
            const liquidAccel = inLava ? LAVA_ACCEL : SWIM_ACCEL;
            this.swimTickAccum += dt;
            while (this.swimTickAccum >= SWIM_TICK) {
                this.swimTickAccum -= SWIM_TICK;
                let vx = this.velocity.x * SWIM_TICK;
                let vy = this.velocity.y * SWIM_TICK;
                let vz = this.velocity.z * SWIM_TICK;
                const vyStart = vy;
                const floating = this.isBodyIn(liquid);

                if (floating) {
                    vx *= drag; vy *= drag; vz *= drag;
                    vy -= WATER_SINK;
                    if (input.jump) vy += SWIM_UP;
                } else {
                    // Bobbed above the surface: fall back in
                    vx *= SWIM_AIR_DRAG; vz *= SWIM_AIR_DRAG;
                    vy -= SWIM_AIR_GRAVITY;
                    vy *= 0.98;
                }
                const accel = floating ? liquidAccel : SWIM_AIR_ACCEL;
                vx += m.x * accel;
                vz += m.z * accel;

                // Bobbing at the water's surface while holding jump: buoyancy grows with how deep
                // your body is in the water (like a spring) against gravity, with light drag, and a
                // small swim kick at the bottom of each bob keeps it going
                const surface = this.waterSurfaceY(liquid);
                if (input.jump && surface !== null && this.position.y > surface - 0.5) {
                    const feet = this.position.y - PLAYER_HEIGHT;
                    const depth = Math.max(0, Math.min(surface - feet, 1.6));
                    const balanceDepth = PLAYER_HEIGHT - SWIM_BOB_HEIGHT;
                    vy = vyStart + SWIM_BUOYANCY * (depth - balanceDepth);
                    vy *= SWIM_BOB_DAMP;
                    // Kick when you stop sinking at the bottom of a bob
                    if (vyStart < 0 && vy >= 0) vy += SWIM_KICK * (0.75 + Math.random() * 0.5);
                }

                // Climbing out onto an edge: only while holding jump
                if (input.jump && this.blockedAhead() && this.canClimbOut()) vy = Math.max(vy, SWIM_CLIMB);

                this.velocity.set(vx / SWIM_TICK, vy / SWIM_TICK, vz / SWIM_TICK);
            }
        } else {
            this.velocity.x = m.x * PLAYER_SPEED;
            this.velocity.z = m.z * PLAYER_SPEED;
            if (input.jump && this.onGround) {
                this.velocity.y = JUMP_FORCE;
                this.onGround = false;
                this.swimTickAccum = 0; // the jump gets a full tick of upward movement, like Minecraft
            }
            landPhysics = true;
        }

        this.moveWithCollision(dt);
        this.clampToWorld();

        if (landPhysics) {
            // Minecraft gravity, stepped at 20 ticks per second after moving (like Minecraft's
            // tick: move, then add 0.08 fall speed and apply 0.98 air drag)
            this.swimTickAccum += dt;
            while (this.swimTickAccum >= SWIM_TICK - 1e-9) {
                this.swimTickAccum -= SWIM_TICK;
                let vy = this.velocity.y * SWIM_TICK;
                vy = (vy - MC_GRAVITY) * MC_AIR_DRAG;
                this.velocity.y = vy / SWIM_TICK;
            }
        }
    }

    clampToWorld() {
        const hw = PLAYER_WIDTH / 2;
        const min = hw + 0.001;
        const maxX = MAP_WIDTH - hw - 0.001;
        const maxZ = MAP_HEIGHT - hw - 0.001;
        if (this.position.x < min) { this.position.x = min; this.velocity.x = 0; }
        if (this.position.x > maxX) { this.position.x = maxX; this.velocity.x = 0; }
        if (this.position.z < min) { this.position.z = min; this.velocity.z = 0; }
        if (this.position.z > maxZ) { this.position.z = maxZ; this.velocity.z = 0; }
    }

    // True if you're pushing against a wall in the direction you're trying to move
    blockedAhead() {
        if (this.moveDir.lengthSq() === 0) return false;
        const hw = PLAYER_WIDTH / 2;
        const ox = this.position.x, oz = this.position.z;
        this.position.x += this.moveDir.x * 0.1;
        this.position.z += this.moveDir.z * 0.1;
        const blocked = this.collides(hw);
        this.position.x = ox; this.position.z = oz;
        return blocked;
    }

    // True if the space a little ahead and SWIM_CLIMB_CLEARANCE up is open, so the edge you're
    // swimming into is low enough to climb out onto (tall cliffs can't be climbed).
    canClimbOut() {
        if (this.moveDir.lengthSq() === 0) return false;
        const hw = PLAYER_WIDTH / 2;
        const ox = this.position.x, oy = this.position.y, oz = this.position.z;
        this.position.x += this.moveDir.x * 0.3;
        this.position.z += this.moveDir.z * 0.3;
        // In water, measure from the surface so how high you're bobbing doesn't matter: you can
        // climb onto an edge up to 1 block above the water, never higher
        const water = this.waterSurfaceY();
        const surface = water !== null ? water : this.waterSurfaceY(BLOCK.LAVA);
        if (surface !== null) this.position.y = surface + 1.1 + PLAYER_HEIGHT;
        else this.position.y += SWIM_CLIMB_CLEARANCE;
        const blocked = this.collides(hw);
        this.position.set(ox, oy, oz);
        return !blocked;
    }

    // Move by the velocity over dt. A big move (a slow frame, or falling fast) is split into
    // small steps so you can never pass through a block in one go.
    moveWithCollision(dt) {
        const far = Math.max(Math.abs(this.velocity.x), Math.abs(this.velocity.y), Math.abs(this.velocity.z)) * dt;
        const steps = Math.min(60, Math.max(1, Math.ceil(far / MAX_MOVE_STEP)));
        for (let i = 0; i < steps; i++) this.moveStep(dt / steps);
    }

    moveStep(dt) {
        const hw = PLAYER_WIDTH / 2;
        this.position.x += this.velocity.x * dt;
        if (this.collides(hw)) { this.position.x -= this.velocity.x * dt; this.velocity.x = 0; }
        this.position.y += this.velocity.y * dt;
        if (this.collides(hw)) {
            if (this.velocity.y < 0) {
                this.position.y = (Math.floor(this.position.y - PLAYER_HEIGHT + 0.001) + 1) + PLAYER_HEIGHT;
                this.onGround = true;
            } else {
                this.position.y = Math.floor(this.position.y + 0.1) - 0.101;
            }
            this.velocity.y = 0;
        } else {
            // Still standing if there's ground right under your feet (with tick-based gravity,
            // some frames have no downward movement to bump into it)
            this.onGround = false;
            if (this.velocity.y <= 0) {
                this.position.y -= 0.01;
                this.onGround = this.collides(hw);
                this.position.y += 0.01;
            }
        }
        this.position.z += this.velocity.z * dt;
        if (this.collides(hw)) { this.position.z -= this.velocity.z * dt; this.velocity.z = 0; }
    }

    collides(hw) {
        const x0 = Math.floor(this.position.x - hw), x1 = Math.floor(this.position.x + hw);
        const y0 = Math.floor(this.position.y - PLAYER_HEIGHT + 0.001), y1 = Math.floor(this.position.y + 0.1);
        const z0 = Math.floor(this.position.z - hw), z1 = Math.floor(this.position.z + hw);
        for (let x = x0; x <= x1; x++)
            for (let y = y0; y <= y1; y++)
                for (let z = z0; z <= z1; z++)
                    if (this.level.isSolidTile(x, y, z)) return true;
        return false;
    }

    getEyePosition() { return new THREE.Vector3(this.position.x, this.position.y, this.position.z); }

    getLookDirection() {
        return new THREE.Vector3(
            -Math.sin(this.rotation.y) * Math.cos(this.rotation.x),
            Math.sin(this.rotation.x),
            -Math.cos(this.rotation.y) * Math.cos(this.rotation.x)
        ).normalize();
    }
}

// ============================================================
// HUMAN MOB (Classic's "Zombie", using char.png)
// ============================================================

// One model part, like Classic's Cube.addBox: a box in skin pixels whose six faces are cut
// from the 64x32 skin exactly as Classic's Polygon maps them
// grow: make the box bigger on every side without changing its texture (used for the hat)
function buildModelBox(texU, texV, bx, by, bz, w, h, d, grow = 0) {
    const x0 = bx - grow, y0 = by - grow, z0 = bz - grow;
    const x1 = bx + w + grow, y1 = by + h + grow, z1 = bz + d + grow;
    const u0 = [x0, y0, z0], u1 = [x1, y0, z0], u2 = [x1, y1, z0], u3 = [x0, y1, z0];
    const l0 = [x0, y0, z1], l1 = [x1, y0, z1], l2 = [x1, y1, z1], l3 = [x0, y1, z1];
    const faces = [
        [[l1, u1, u2, l2], texU + d + w, texV + d, texU + d + w + d, texV + d + h],
        [[u0, l0, l3, u3], texU + 0, texV + d, texU + d, texV + d + h],
        [[l1, l0, u0, u1], texU + d, texV + 0, texU + d + w, texV + d],
        [[u2, u3, l3, l2], texU + d + w, texV + 0, texU + d + w + w, texV + d],
        [[u1, u0, u3, u2], texU + d, texV + d, texU + d + w, texV + d + h],
        [[l0, l1, l2, l3], texU + d + w + d, texV + d, texU + d + w + d + w, texV + d + h]
    ];
    const positions = [], uvs = [], indices = [], colors = [];
    // Flat per-face shade like block faces. The model is built with y pointing down, so the y0
    // face is the top. Order matches faces: +x, -x, top, bottom, -z, +z.
    const faceShade = [FACE_SHADE.eastWest, FACE_SHADE.eastWest, FACE_SHADE.top, FACE_SHADE.bottom,
        FACE_SHADE.northSouth, FACE_SHADE.northSouth];
    let fi = 0;
    for (const [corners, fu0, fv0, fu1, fv1] of faces) {
        const fs = shade(faceShade[fi++]);
        const base = positions.length / 3;
        // Classic Polygon: corner 0 -> (u1, v0), 1 -> (u0, v0), 2 -> (u0, v1), 3 -> (u1, v1)
        const cornerUV = [[fu1, fv0], [fu0, fv0], [fu0, fv1], [fu1, fv1]];
        for (let k = 0; k < 4; k++) {
            positions.push(...corners[k]);
            uvs.push(cornerUV[k][0] / 63.999, 1 - cornerUV[k][1] / 31.999);
            colors.push(fs, fs, fs);
        }
        indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
    return makeGeometry(positions, uvs, colors, indices);
}

// ZombieModel: the parts (skin offset, box, pivot), shared by every mob
// A skin texture: the skin's top 64x32 (the classic layout), with an all-solid hat area made
// see-through (old skins sometimes fill it, which would hide the face). Loads in the background.
function makeSkinTexture(src) {
    const canvas = document.createElement('canvas');
    canvas.width = 64; canvas.height = 32;
    const tex = new THREE.CanvasTexture(canvas);
    tex.magFilter = tex.minFilter = THREE.NearestFilter;
    tex.colorSpace = THREE.SRGBColorSpace;
    const img = new Image();
    img.onload = () => {
        const cx = canvas.getContext('2d');
        cx.clearRect(0, 0, 64, 32);
        cx.drawImage(img, 0, 0, 64, 32, 0, 0, 64, 32);
        const hat = cx.getImageData(32, 0, 32, 16);
        let seeThrough = false;
        for (let i = 3; i < hat.data.length; i += 4) if (hat.data[i] < 128) { seeThrough = true; break; }
        if (!seeThrough) cx.clearRect(32, 0, 32, 16);
        tex.needsUpdate = true;
    };
    img.src = src;
    return tex;
}
// A skin sent by the website or a server: a small PNG as a data: address
const isSkinData = s => typeof s === 'string' && s.startsWith('data:image/png;base64,') && s.length < 40000;

// The hat (the skin's second head layer): the head's box, 0.5 bigger, attached to the head
const HAT_PART = { tex: [32, 0], box: [-4, -8, -4, 8, 8, 8], grow: 0.5 };

const ZOMBIE_PARTS = {
    head: { tex: [0, 0], box: [-4, -8, -4, 8, 8, 8], pos: [0, 0, 0] },
    body: { tex: [16, 16], box: [-4, 0, -2, 8, 12, 4], pos: [0, 0, 0] },
    arm0: { tex: [40, 16], box: [-3, -2, -2, 4, 12, 4], pos: [-5, 2, 0] },
    arm1: { tex: [40, 16], box: [-1, -2, -2, 4, 12, 4], pos: [5, 2, 0] },
    leg0: { tex: [0, 16], box: [-2, 0, -2, 4, 12, 4], pos: [-2, 12, 0] },
    leg1: { tex: [0, 16], box: [-2, 0, -2, 4, 12, 4], pos: [2, 12, 0] }
};
const ZOMBIE_SIZE = 0.058333334; // skin pixels to blocks

class ZombieModel {
    constructor(material) {
        this.material = material;
        this.geometries = {};
        for (const name in ZOMBIE_PARTS) {
            const p = ZOMBIE_PARTS[name];
            this.geometries[name] = buildModelBox(p.tex[0], p.tex[1], ...p.box);
        }
        this.geometries.hat = buildModelBox(HAT_PART.tex[0], HAT_PART.tex[1], ...HAT_PART.box, HAT_PART.grow);
    }

    // Makes the scene objects for one mob. Each part is a pivot group placed at its setPos and
    // rotated z, then y, then x, like Classic's Cube.render
    create() {
        // Each mob gets its own copy of the material so it can be darkened on its own
        const material = this.material.clone();
        const root = new THREE.Group();          // world position
        const flip = new THREE.Group();          // Classic: scale(1, -1, 1) then scale(size)
        flip.scale.set(ZOMBIE_SIZE, -ZOMBIE_SIZE, ZOMBIE_SIZE);
        const body = new THREE.Group();          // bounce (y) and facing (y rotation)
        root.add(flip);
        flip.add(body);
        const parts = {};
        for (const name in ZOMBIE_PARTS) {
            const pivot = new THREE.Group();
            pivot.position.set(...ZOMBIE_PARTS[name].pos);
            pivot.rotation.order = 'ZYX';
            pivot.add(new THREE.Mesh(this.geometries[name], material));
            body.add(pivot);
            parts[name] = pivot;
        }
        parts.head.add(new THREE.Mesh(this.geometries.hat, material));   // turns with the head
        return { root, body, parts, material };
    }

    // ZombieModel.render's animation
    animate(parts, time) {
        parts.head.rotation.y = Math.sin(time * 0.83) * 1.0;
        parts.head.rotation.x = Math.sin(time) * 0.8;
        parts.arm0.rotation.x = Math.sin(time * 0.6662 + Math.PI) * 2.0;
        parts.arm0.rotation.z = (Math.sin(time * 0.2312) + 1.0) * 1.0;
        parts.arm1.rotation.x = Math.sin(time * 0.6662) * 2.0;
        parts.arm1.rotation.z = (Math.sin(time * 0.2812) - 1.0) * 1.0;
        parts.leg0.rotation.x = Math.sin(time * 0.6662) * 1.4;
        parts.leg1.rotation.x = Math.sin(time * 0.6662 + Math.PI) * 1.4;
    }
}

// Zombie: the mob itself. Position is the bottom-centre of its 0.6 x 1.8 box.
class Zombie {
    constructor(level, model, x, y, z) {
        this.level = level;
        this.removed = false;
        this.xd = 0; this.yd = 0; this.zd = 0;
        this.onGround = false;
        this.bbWidth = 0.6; this.bbHeight = 1.8;
        this.rotA = (Math.random() + 1.0) * 0.01;
        this.timeOffs = Math.random() * 1239813.0;
        this.rot = Math.random() * Math.PI * 2.0;
        this.speed = 1.0;
        // Classic Entity.setPos: the box is centred on the given point
        const w = this.bbWidth / 2, hh = this.bbHeight / 2;
        this.bb = [x - w, y - hh, z - w, x + w, y + hh, z + w];
        this.x = x; this.y = this.bb[1]; this.z = z;
        this.xo = this.x; this.yo = this.y; this.zo = this.z;
        this.view = model.create();
    }

    tick() {
        this.xo = this.x; this.yo = this.y; this.zo = this.z;
        if (this.y < -100) this.removed = true;

        this.rot += this.rotA;
        this.rotA *= 0.99;
        this.rotA += (Math.random() - Math.random()) * Math.random() * Math.random() * 0.08;
        const xa = Math.sin(this.rot);
        const za = Math.cos(this.rot);
        const inWater = this.isInLiquid(BLOCK.WATER);
        const inLava = !inWater && this.isInLiquid(BLOCK.LAVA);

        if (inWater || inLava) {
            // Minecraft mob swimming: paddle up most ticks, slow push, heavy drag, slow sink
            if (Math.random() < 0.8) this.yd += 0.04;
            const yo = this.y;
            this.moveRelative(xa, za, 0.02);
            this.move(this.xd, this.yd, this.zd);
            const drag = inWater ? 0.8 : 0.5;
            this.xd *= drag; this.yd *= drag; this.zd *= drag;
            this.yd -= 0.02;
            // Swam into a low edge: climb out
            if (this.horizontalCollision && this.isFree(this.xd, this.yd + 0.6 - this.y + yo, this.zd)) {
                this.yd = 0.3;
            }
            return;
        }

        if (this.onGround && Math.random() < 0.08) this.yd = 0.5;

        this.moveRelative(xa, za, this.onGround ? 0.1 : 0.02);
        this.yd -= 0.08;
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.91;
        this.yd *= 0.98;
        this.zd *= 0.91;
        if (this.onGround) {
            this.xd *= 0.7;
            this.zd *= 0.7;
        }
    }

    // Minecraft's liquid check: the box shrunk by 0.4 top and bottom touches the liquid
    isInLiquid(type) {
        const b = this.bb;
        for (let x = Math.floor(b[0]); x < Math.floor(b[3]) + 1; x++)
            for (let y = Math.floor(b[1] + 0.4); y < Math.floor(b[4] - 0.4) + 1; y++)
                for (let z = Math.floor(b[2]); z < Math.floor(b[5]) + 1; z++)
                    if (this.level.getTile(x, y, z) === type) return true;
        return false;
    }

    // True if the box moved by (xa, ya, za) wouldn't hit any solid block or liquid
    isFree(xa, ya, za) {
        const b = this.bb;
        const x0 = b[0] + xa, y0 = b[1] + ya, z0 = b[2] + za;
        const x1 = b[3] + xa, y1 = b[4] + ya, z1 = b[5] + za;
        if (this.cubesIn(x0, y0, z0, x1, y1, z1).some(c =>
            c[3] > x0 && c[0] < x1 && c[4] > y0 && c[1] < y1 && c[5] > z0 && c[2] < z1)) return false;
        for (let x = Math.floor(x0); x < Math.floor(x1) + 1; x++)
            for (let y = Math.floor(y0); y < Math.floor(y1) + 1; y++)
                for (let z = Math.floor(z0); z < Math.floor(z1) + 1; z++) {
                    const t = this.level.getTile(x, y, z);
                    if (t === BLOCK.WATER || t === BLOCK.LAVA) return false;
                }
        return true;
    }

    // Classic Entity.moveRelative (the mob's own yaw is 0, so the direction is used as-is)
    moveRelative(xa, za, speed) {
        let dist = xa * xa + za * za;
        if (dist < 0.01) return;
        dist = speed / Math.sqrt(dist);
        this.xd += xa * dist;
        this.zd += za * dist;
    }

    // Solid block boxes overlapping a region
    cubesIn(x0, y0, z0, x1, y1, z1) {
        const out = [];
        for (let x = Math.floor(x0); x < Math.floor(x1) + 1; x++)
            for (let y = Math.floor(y0); y < Math.floor(y1) + 1; y++)
                for (let z = Math.floor(z0); z < Math.floor(z1) + 1; z++)
                    if (this.level.isSolidTile(x, y, z)) out.push([x, y, z, x + 1, y + 1, z + 1]);
        return out;
    }

    // Classic Entity.move: slide the box one axis at a time (y, then x, then z), stopping at
    // solid blocks
    move(xa, ya, za) {
        const xaOrg = xa, yaOrg = ya, zaOrg = za;
        const b = this.bb;
        const cubes = this.cubesIn(
            Math.min(b[0], b[0] + xa), Math.min(b[1], b[1] + ya), Math.min(b[2], b[2] + za),
            Math.max(b[3], b[3] + xa), Math.max(b[4], b[4] + ya), Math.max(b[5], b[5] + za));

        for (const c of cubes) {
            if (b[3] <= c[0] || b[0] >= c[3] || b[5] <= c[2] || b[2] >= c[5]) continue;
            if (ya > 0 && b[4] <= c[1]) ya = Math.min(ya, c[1] - b[4]);
            if (ya < 0 && b[1] >= c[4]) ya = Math.max(ya, c[4] - b[1]);
        }
        b[1] += ya; b[4] += ya;

        for (const c of cubes) {
            if (b[4] <= c[1] || b[1] >= c[4] || b[5] <= c[2] || b[2] >= c[5]) continue;
            if (xa > 0 && b[3] <= c[0]) xa = Math.min(xa, c[0] - b[3]);
            if (xa < 0 && b[0] >= c[3]) xa = Math.max(xa, c[3] - b[0]);
        }
        b[0] += xa; b[3] += xa;

        for (const c of cubes) {
            if (b[4] <= c[1] || b[1] >= c[4] || b[3] <= c[0] || b[0] >= c[3]) continue;
            if (za > 0 && b[5] <= c[2]) za = Math.min(za, c[2] - b[5]);
            if (za < 0 && b[2] >= c[5]) za = Math.max(za, c[5] - b[2]);
        }
        b[2] += za; b[5] += za;

        this.onGround = yaOrg !== ya && yaOrg < 0;
        this.horizontalCollision = xaOrg !== xa || zaOrg !== za;
        if (xaOrg !== xa) this.xd = 0;
        if (yaOrg !== ya) this.yd = 0;
        if (zaOrg !== za) this.zd = 0;
        this.x = (b[0] + b[3]) / 2;
        this.y = b[1];
        this.z = (b[2] + b[5]) / 2;
    }

    // Places and animates the model. a: how far between the last tick and the next (0..1)
    updateView(model, a, nowSeconds) {
        const v = this.view;
        v.root.position.set(
            this.xo + (this.x - this.xo) * a,
            this.yo + (this.y - this.yo) * a,
            this.zo + (this.z - this.zo) * a);
        const time = nowSeconds * 10.0 * this.speed + this.timeOffs;
        v.body.position.y = -Math.abs(Math.sin(time * 0.6662)) * 5.0 - 23.0;
        v.body.rotation.y = this.rot + Math.PI;
        model.animate(v.parts, time);
    }
}

class BlockRaycaster {
    constructor(level) { this.level = level; }
    cast(origin, dir, maxDist) {
        let x = Math.floor(origin.x), y = Math.floor(origin.y), z = Math.floor(origin.z);
        const sx = dir.x > 0 ? 1 : -1, sy = dir.y > 0 ? 1 : -1, sz = dir.z > 0 ? 1 : -1;
        const tdx = dir.x !== 0 ? Math.abs(1 / dir.x) : Infinity;
        const tdy = dir.y !== 0 ? Math.abs(1 / dir.y) : Infinity;
        const tdz = dir.z !== 0 ? Math.abs(1 / dir.z) : Infinity;
        let tmaxx = dir.x !== 0 ? (dir.x > 0 ? x + 1 - origin.x : origin.x - x) * tdx : Infinity;
        let tmaxy = dir.y !== 0 ? (dir.y > 0 ? y + 1 - origin.y : origin.y - y) * tdy : Infinity;
        let tmaxz = dir.z !== 0 ? (dir.z > 0 ? z + 1 - origin.z : origin.z - z) * tdz : Infinity;
        let px = x, py = y, pz = z, dist = 0;
        while (dist < maxDist) {
            const t = this.level.getTile(x, y, z);
            // The bottom bedrock layer can't be selected (so it can't be built on either)
            const bottomBedrock = t === BLOCK.BEDROCK && y === 0;
            if (t !== BLOCK.AIR && t !== BLOCK.WATER && t !== BLOCK.LAVA && !bottomBedrock)
                return { hit: true, blockPos: { x, y, z }, prevPos: { x: px, y: py, z: pz } };
            px = x; py = y; pz = z;
            if (tmaxx < tmaxy) {
                if (tmaxx < tmaxz) { dist = tmaxx; x += sx; tmaxx += tdx; }
                else { dist = tmaxz; z += sz; tmaxz += tdz; }
            } else {
                if (tmaxy < tmaxz) { dist = tmaxy; y += sy; tmaxy += tdy; }
                else { dist = tmaxz; z += sz; tmaxz += tdz; }
            }
        }
        return { hit: false };
    }
}

class Game {
    constructor() {
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(SKY_COLOR);
        // Linear distance fog in air (hides the render distance edge), thick fog in liquids
        this.renderSetting = 0; // index into RENDER_DISTANCES (starts on Far)
        this.renderDistance = RENDER_DISTANCES[0].dist;
        this.airFog = new THREE.Fog(FOG_COLOR, RENDER_DISTANCES[0].fogStart, RENDER_DISTANCES[0].fogEnd);
        this.skyColor = new THREE.Color(SKY_COLOR);
        this.liquidFog = new THREE.FogExp2(0x050533, 0.15);
        this.scene.fog = this.airFog;

        this.camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.05, 2000);
        this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
        this.renderer.setSize(innerWidth, innerHeight);
        this.renderer.setPixelRatio(1);
        this.renderer.autoClear = false;
        document.body.appendChild(this.renderer.domElement);

        this.hudCanvas = document.createElement('canvas');
        this.hudCanvas.width = window.innerWidth;
        this.hudCanvas.height = window.innerHeight;
        Object.assign(this.hudCanvas.style, { position: 'absolute', top: '0', left: '0', pointerEvents: 'none', imageRendering: 'pixelated' });
        document.body.appendChild(this.hudCanvas);
        this.hudCtx = this.hudCanvas.getContext('2d');
        this.hudCtx.imageSmoothingEnabled = false;
        this.hudScale = 3;

        const fontImg = new Image();
        fontImg.src = './default.gif';
        fontImg.onload = () => { this.fontSheets = this.prepareFont(fontImg); };

        this.fpsFrames = 0; this.fpsTimeAccum = 0; this.displayFps = 0;
        this.chunksUpdatedCounter = 0; this.displayChunkUpdates = 0;

        // Pixel-art texture: no smoothing, sRGB colours
        const pixelTexture = url => {
            const t = new THREE.TextureLoader().load(url);
            t.magFilter = t.minFilter = THREE.NearestFilter;
            t.colorSpace = THREE.SRGBColorSpace;
            return t;
        };
        const tex = pixelTexture('./terrain.png');
        this.terrainTex = tex;

        // Solid blocks: cut-out (alphaTest) rather than see-through, front faces only, so they
        // render in the fast opaque pass. Saplings are flat crosses, so they draw both sides.
        this.solidMaterial = new THREE.MeshBasicMaterial({ map: tex, vertexColors: true, alphaTest: 0.1, side: THREE.FrontSide });
        this.plantMaterial = new THREE.MeshBasicMaterial({ map: tex, vertexColors: true, alphaTest: 0.1, side: THREE.DoubleSide });
        this.waterMaterial = new THREE.MeshBasicMaterial({
            map: tex, color: WATER_TINT, vertexColors: true, transparent: true, opacity: WATER_OPACITY, side: THREE.DoubleSide, depthWrite: false
        });
        this.lavaMaterial = new THREE.MeshBasicMaterial({ map: tex, vertexColors: true, side: THREE.DoubleSide });

        this.sections = new Map();       // "cx,cy,cz" -> { cx, cy, cz, group (null if empty) }
        this.dirtySections = new Set();  // built sections that need rebuilding after edits
        this.backgroundDirty = new Set(); // ...after big changes that aren't yours (rebuilt a little each frame)
        this.bulkChanges = false;         // true while applying such changes
        this.netChanges = [];             // block changes from a server, waiting: x, y, z, block, ...
        this.netChangesHead = 0;
        this.buildQueue = [];            // unbuilt sections near the player, nearest last
        this.columnTops = new Map();     // "cx,cz" -> highest non-air y in that chunk column
        this.queueStale = true;
        this.lastPlayerChunk = null;
        this.outerWorld = null;      // group holding the ocean/bedrock outside the map
        this.outerTextures = null;   // [waterTex, bedrockTex] once terrain.png has loaded
        this.buildMode = false;
        this.particles = new BlockParticles(this.scene, tex);

        // Mobs (G to spawn), drawn with char.png
        const charTex = makeSkinTexture('./char.png');
        this.mobMaterial = new THREE.MeshBasicMaterial({ map: charTex, alphaTest: 0.5, side: THREE.DoubleSide, vertexColors: true });
        this.zombieModel = new ZombieModel(this.mobMaterial);
        // The player's own model, only shown in third person (F5)
        this.thirdPerson = false;
        this.playerView = this.zombieModel.create();
        this.playerView.root.visible = false;
        // your walk animation state (see poseHumanoid)
        this.localAnim = { limbAmount: 0, limbPos: 0 };
        // multiplayer
        this.net = null;                    // the WebSocket while connected to a server
        this.netPending = null;             // a connection that's still joining
        this.remotePlayers = new Map();     // id -> another player's model, nametag and state
        this.playerName = 'Player' + Math.floor(100 + Math.random() * 900);
        this.signedIn = false;              // no accounts yet: Join Server.. asks you to sign in
        // Logged in on the website? Inside the website the page tells us (until then: no). A copy
        // of the game on its own, outside the website, has everything.
        this.loggedIn = window.parent === window;
        this.frozen = false; this.blind = false; this.blindText = '';   // set by servers (e.g. Hide and Seek)
        this.serverBuild = true; this.hideNametags = false;
        this.isGuest = false;
        this.autoJoin = null;               // a server to join from the page's address (?join)
        this.readJoinLink();
        // your skin, handed over by the website page the game is shown in
        this.mySkin = null;
        this.skinWaitUntil = performance.now() + 4000;
        window.addEventListener('message', e => {
            if (e.source !== window.parent || e.source === window) return;
            if (e.data && e.data.type === 'claudecraft-skin' && isSkinData(e.data.skin)) this.setMySkin(e.data.skin);
            if (e.data && e.data.type === 'claudecraft-account') {
                const user = typeof e.data.user === 'string' && /^[A-Za-z0-9_]{2,16}$/.test(e.data.user) ? e.data.user : null;
                // (a join link's name wins: that's who joined the server)
                if (!this.autoJoin && !this.net) {
                    this.loggedIn = !!user;
                    if (user) { this.playerName = user; this.signedIn = true; this.isGuest = false; }
                }
            }
        });
        if (window.parent !== window) window.parent.postMessage({ type: 'claudecraft-want-skin' }, '*');
        this.lastNetSend = 0;
        // chat (servers only)
        this.chatOpen = false;
        this.chatInput = '';
        this.chatLines = [];                // { text, color, time }
        this.scene.add(this.playerView.root);
        this.zombies = [];

        // Menu state: null (playing) or the open page: 'main', 'generate', 'load', 'delete', 'signin' or 'join'
        this.menu = null;
        this.statusMessage = null;   // full-screen message such as "Generating level.."
        this.loadingStage = null;    // step shown under it, e.g. "Raising.."
        this.loadingProgress = null; // 0..1 for the green bar, or null for no bar
        this.mouseX = 0; this.mouseY = 0;
        this.menuButtons = [];
        this.serverAddress = '';     // typed on the Join server page
        this.saveName = ''; this.saveDesc = '';   // the Save level page
        this.saveField = 'name';
        this.joinMessage = null;

        this.createClouds();
        // The starting level is generated once the game is running (see the end of the
        // constructor), so the loading screen can show while it builds
        this.level = null;
        this.player = null;

        this.blockPreview = new BlockPreview(tex);
        this.blockPreview.setType(HOTBAR[0]);

        const brkMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.45, depthWrite: false });
        this.breakHighlight = new THREE.Mesh(new THREE.BoxGeometry(1.002, 1.002, 1.002), brkMat);
        this.breakHighlight.visible = false;
        this.scene.add(this.breakHighlight);

        // thin dark outline along the 12 edges of the block you're looking at (like Minecraft)
        this.selectOutline = new THREE.LineSegments(
            new THREE.EdgesGeometry(new THREE.BoxGeometry(1.004, 1.004, 1.004)),
            new THREE.LineBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.45 }));
        this.selectOutline.visible = false;
        this.scene.add(this.selectOutline);

        this.ghostGeos = {};
        for (const id of HOTBAR.concat(EXTRA_BLOCKS)) this.ghostGeos[id] = id === BLOCK.SAPLING ? this.makePlantGhost(BLOCK_UVS[id]) : this.makeGhost(id);
        const gMat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.45, depthWrite: false, side: THREE.DoubleSide });
        this.placeHighlight = new THREE.Mesh(this.ghostGeos[BLOCK.DIRT], gMat);
        this.placeHighlight.visible = false;
        this.scene.add(this.placeHighlight);

        const texImg = new Image();
        texImg.src = './terrain.png';
        texImg.onload = () => {
            const createRepeatingTexture = (img, u, v) => {
                const canvas = document.createElement('canvas');
                canvas.width = 16; canvas.height = 16;
                canvas.getContext('2d').drawImage(img, u * 16, v * 16, 16, 16, 0, 0, 16, 16);
                const t = new THREE.CanvasTexture(canvas);
                t.magFilter = t.minFilter = THREE.NearestFilter;
                t.wrapS = t.wrapT = THREE.RepeatWrapping;
                t.colorSpace = THREE.SRGBColorSpace;
                return t;
            };
            const waterTex = createRepeatingTexture(texImg, WATER_UV[0], WATER_UV[1]);
            const bedrockTex = createRepeatingTexture(texImg, BEDROCK_UV[0], BEDROCK_UV[1]);
            this.outerTextures = [waterTex, bedrockTex];
            this.terrainImg = texImg; // used for the dirt background on the loading screen
            this.buildOuterWorld(waterTex, bedrockTex);
        };

        this.input = { forward: false, backward: false, left: false, right: false, jump: false };
        this.pointerLocked = false;
        this.lastTime = performance.now();
        this.tickAccumulator = 0;
        this.setupInput();
        this.loop = this.loop.bind(this);

        // Uncapped frames: a MessageChannel message runs the next frame as soon as this one
        // finishes, without waiting for the screen refresh like requestAnimationFrame does
        this.frameChannel = new MessageChannel();
        this.frameChannel.port1.onmessage = () => this.loop(performance.now());
        this.scheduleFrame();

        // Build the starting level behind the "Generating level.." screen
        // (a Small one when joining a server from a link, so it connects sooner; or a level from
        // the Levels page: ?level=address&title=Name)
        const levelLink = typeof location !== 'undefined' ? new URLSearchParams(location.search) : null;
        if (levelLink && levelLink.get('level') && !this.autoJoin) {
            this.loadSharedLevel(levelLink.get('level'), (levelLink.get('title') || 'level').replace(/[^\x20-\x7E]/g, '').slice(0, SAVE_NAME_MAX));
        } else {
            this.generateLevel(LEVEL_SIZES.find(sz => sz.label === (this.autoJoin ? 'Small' : 'Normal')), false);
        }
    }

    // Switch to a level: clears the old chunks and rebuilds everything that depends on it
    loadLevel(level) {
        for (const sec of this.sections.values()) this.disposeSection(sec);
        this.sections.clear();
        this.dirtySections.clear();
        this.buildQueue = [];
        this.columnTops.clear();
        this.queueStale = true;
        this.lastPlayerChunk = null;

        MAP_WIDTH = level.width;
        MAP_HEIGHT = level.height;
        MAP_DEPTH = level.depth;

        this.level = level;
        this.meshBuilder = new ChunkMeshBuilder(level, this.solidMaterial, this.waterMaterial, this.lavaMaterial, this.plantMaterial);
        level.addListener({
            tileChanged: (x, y, z) => this.queueChunkUpdate(x, y, z),
            lightColumnChanged: (x, z, y0, y1) => this.queueLightUpdate(x, z, y0, y1)
        });

        const slot = this.player ? this.player.selectedSlot : 0;
        this.player = new Player(level);
        this.player.selectedSlot = slot;
        // A saved level puts you back where you were, looking the same way
        if (level.savedPlayer) {
            const sp = level.savedPlayer;
            this.player.position.set(sp.x, sp.y, sp.z);
            this.player.rotation.x = sp.rotX;
            this.player.rotation.y = sp.rotY;
        }
        // Never start a level stuck inside blocks: move up until there's room
        while (this.player.collides(PLAYER_WIDTH / 2) && this.player.position.y < level.depth + PLAYER_HEIGHT) {
            this.player.position.y += 1;
        }
        this.raycaster = new BlockRaycaster(level);
        this.particles.setLevel(level);
        // Mobs belong to the old level
        for (const zb of this.zombies) this.scene.remove(zb.view.root);
        this.zombies = [];
        // Build the area right around the player straight away so you don't spawn in a void;
        // the rest streams in over the next frames
        this.updateChunks(Infinity, 48);
        if (this.blockPreview) this.blockPreview.setType(this.player.getSelectedBlock());
        if (this.outerTextures) this.buildOuterWorld(this.outerTextures[0], this.outerTextures[1]);
        if (this.clouds) this.clouds.position.set(MAP_WIDTH / 2, CLOUD_Y, MAP_HEIGHT / 2);
        // R brings you back here (Y changes it)
        const pp = this.player.position;
        this.spawnPoint = { x: pp.x, y: pp.y, z: pp.z, rotX: this.player.rotation.x, rotY: this.player.rotation.y };
    }

    // The usual nine blocks plus the extras this server gives you (keeping your choice if you can)
    applyExtraBlocks() {
        if (!this.player) return;
        const held = this.player.getSelectedBlock();
        this.player.inventory = HOTBAR.concat(this.net ? (this.extraBlocks || []) : []);
        const i = this.player.inventory.indexOf(held);
        this.player.selectedSlot = i >= 0 ? i : Math.min(this.player.selectedSlot, this.player.inventory.length - 1);
        if (this.blockPreview) this.blockPreview.setType(this.player.getSelectedBlock());
    }

    // ---- B: the block menu ----
    openBlockMenu() {
        if (!this.player || this.statusMessage || this.menu) return;
        this.openMenu('blocks');
        if (this.pointerLocked && document.exitPointerLock) document.exitPointerLock();     // free the mouse to click
    }

    // A grid of every block you can place, 9 to a row, centred in a dark panel
    layoutBlockMenu() {
        const gs = this.guiScale();
        const W = this.hudCanvas.width, H = this.hudCanvas.height;
        const blocks = this.player.inventory, cols = Math.min(9, blocks.length), rows = Math.ceil(blocks.length / 9);
        const slot = 22 * gs, padX = 8 * gs, top = 26 * gs, bottom = 10 * gs;
        const pw = cols * slot + padX * 2, ph = top + rows * slot + bottom;
        const px = Math.floor((W - pw) / 2), py = Math.floor((H - ph) / 2);
        this.blockPanel = { x: px, y: py, w: pw, h: ph };
        this.menuTitleY = py + 9 * gs;
        this.blockSlots = blocks.map((id, i) => ({ id, index: i, size: slot,
            x: px + padX + (i % 9) * slot, y: py + top + Math.floor(i / 9) * slot }));
        this.menuButtons = [];
        return gs;
    }

    renderBlockMenu() {
        const ctx = this.hudCtx, gs = this.layoutBlockMenu(), pnl = this.blockPanel;
        ctx.fillStyle = 'rgba(32, 32, 48, 0.75)';
        ctx.fillRect(pnl.x, pnl.y, pnl.w, pnl.h);
        this.drawTextCentered('Select block', Math.floor(this.hudCanvas.width / 2), this.menuTitleY, gs, 0xFFFFFF);
        for (const b of this.blockSlots) {
            const hover = this.mouseX >= b.x && this.mouseX < b.x + b.size && this.mouseY >= b.y && this.mouseY < b.y + b.size;
            if (hover) { ctx.fillStyle = 'rgba(255, 255, 255, 0.25)'; ctx.fillRect(b.x, b.y, b.size, b.size); }
            else if (b.index === this.player.selectedSlot) {           // the one you're holding
                ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)'; ctx.lineWidth = gs;
                ctx.strokeRect(b.x + gs / 2, b.y + gs / 2, b.size - gs, b.size - gs);
            }
            // hovered blocks are drawn a little bigger, like Classic
            this.drawBlockIcon(b.id, b.x + b.size / 2, b.y + b.size / 2, (hover ? 8 : 6.5) * gs);
        }
    }

    // A block as a little cube (top and two sides from terrain.png), or flat for plants.
    // w: half the cube's width, in screen pixels.
    drawBlockIcon(id, cx, cy, w) {
        const img = this.terrainTex && this.terrainTex.image;
        if (!img || !img.width) return;
        const ctx = this.hudCtx, ts = img.width / 16;
        ctx.save();
        ctx.imageSmoothingEnabled = false;
        if (id === BLOCK.SAPLING) {
            const [c, r] = faceUV(id, 0);
            ctx.drawImage(img, c * ts, r * ts, ts, ts, cx - w, cy - w, w * 2, w * 2);
            ctx.restore();
            return;
        }
        const h = w, H = w * 1.15, top = cy - (h + H) / 2;
        const T = [cx, top], R = [cx + w, top + h / 2], B = [cx, top + h], L = [cx - w, top + h / 2];
        const face = (uv, a, b, c, d, e, f, shade) => {
            ctx.setTransform(a / ts, b / ts, c / ts, d / ts, e, f);
            ctx.drawImage(img, uv[0] * ts, uv[1] * ts, ts, ts, 0, 0, ts, ts);
            if (shade) { ctx.fillStyle = `rgba(0, 0, 0, ${shade})`; ctx.fillRect(0, 0, ts, ts); }
        };
        face(faceUV(id, 1), T[0] - L[0], T[1] - L[1], B[0] - L[0], B[1] - L[1], L[0], L[1], 0);       // top
        face(faceUV(id, 0), B[0] - L[0], B[1] - L[1], 0, H, L[0], L[1], 0.2);                          // left side
        face(faceUV(id, 0), R[0] - B[0], R[1] - B[1], 0, H, B[0], B[1], 0.4);                          // right side
        ctx.restore();
    }

    // R: back to your spawn point on this map
    respawn() {
        if (!this.player || !this.spawnPoint || this.frozen || this.statusMessage) return;
        const sp = this.spawnPoint;
        this.player.position.set(sp.x, sp.y, sp.z);
        this.player.velocity.set(0, 0, 0);
        this.player.rotation.x = sp.rotX || 0;
        this.player.rotation.y = sp.rotY || 0;
        this.sendNet({ t: 'move', x: sp.x, y: sp.y, z: sp.z, rx: this.player.rotation.x, ry: this.player.rotation.y });
    }

    // Y: make where you are (and the way you're looking) your spawn point on this map
    setSpawnHere() {
        if (!this.player || this.statusMessage) return;
        const p = this.player.position;
        this.spawnPoint = { x: p.x, y: p.y, z: p.z, rotX: this.player.rotation.x, rotY: this.player.rotation.y };
        // on a server, kept (per level) only for as long as you're connected
        if (this.net && this.netLevelName) this.visitHomes[this.netLevelName] = this.spawnPoint;
        this.addChat('Spawn point set! Press R to come back here.', 0xFFFF55);
    }

    // Flat cloud layer from clouds.png, tiled so each texture pixel is CLOUD_BLOCKS_PER_PIXEL
    // blocks, centred on the level and big enough to reach the horizon
    createClouds() {
        const size = 6000;
        const tex = new THREE.TextureLoader().load('./clouds.png');
        tex.magFilter = tex.minFilter = THREE.NearestFilter;
        tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
        tex.colorSpace = THREE.SRGBColorSpace;
        const tileBlocks = 256 * CLOUD_BLOCKS_PER_PIXEL;
        tex.repeat.set(size / tileBlocks, size / tileBlocks);
        this.cloudTex = tex;
        const mat = new THREE.MeshBasicMaterial({
            // Fully opaque clouds: solid where the texture has cloud, clear in the gaps
            map: tex, alphaTest: 0.5, side: THREE.DoubleSide
        });
        this.clouds = new THREE.Mesh(new THREE.PlaneGeometry(size, size), mat);
        this.clouds.rotation.x = -Math.PI / 2;
        this.clouds.renderOrder = 2;
        this.scene.add(this.clouds);
    }

    // ---- Game menu ----

    openMenu(name) {
        this.menu = name;
        this.menuOpenedAt = performance.now();
        if (name === 'load') {
            // Slot names come from storage; show "-" until they arrive
            if (!this.slotNames) this.slotNames = new Array(LEVEL_SLOTS).fill(null);
            LevelStore.slotNames()
                .then(names => { this.slotNames = names; })
                .catch(err => console.error('Could not read saved levels:', err));
        }
        // Let go of all movement keys so you don't keep walking behind the menu
        for (const k in this.input) this.input[k] = false;
    }

    closeMenu() {
        this.menu = null;
    }

    lockPointer() {
        try {
            const r = this.renderer.domElement.requestPointerLock();
            if (r && r.catch) r.catch(() => { });
        } catch (err) { /* the browser may refuse right after Esc; clicking the game retries */ }
    }

    backToGame() {
        this.closeMenu();
        this.lockPointer();
    }

    // GUI scale: the version text's scale, shrunk if the window is too small for the tallest menu
    guiScale() {
        const w = this.hudCanvas.width, h = this.hudCanvas.height;
        return Math.max(1, Math.min(this.hudScale, Math.floor(w / 220), Math.floor(h / 200)));
    }

    // Lays out the open menu page as one block (title, then 200x20 Classic buttons) centred on
    // the screen. Item y values are relative to the top of the buttons.
    layoutMenu() {
        if (this.menu === 'blocks') return this.layoutBlockMenu();
        const gs = this.guiScale();
        const W = this.hudCanvas.width / gs, H = this.hudCanvas.height / gs;
        const TITLE_GAP = 20;              // title text plus the space under it
        let items = [];
        if (this.menu === 'main') {
            // single-player options are greyed out on a server
            const online = !!this.net;
            items = [
                { label: 'Generate new level...', enabled: !online, action: () => this.openMenu('generate') },
                // saving and loading need you to be logged in, and aren't for servers
                { label: 'Save level..', enabled: !online && this.loggedIn, action: () => this.openSavePage() },
                { label: 'Load level..', enabled: !online && this.loggedIn, action: () => this.openMenu('load') },
                { label: 'Back to game', action: () => this.backToGame() }
            ];
            // on a server, Disconnect goes above Back to game, which stays at the bottom as usual
            if (online) items.splice(items.length - 1, 0, { label: 'Disconnect', action: () => this.disconnectToNewLevel() });
            items = items.map((it, i) => ({ ...it, y: i * 32 }));
        } else if (this.menu === 'generate') {
            items = LEVEL_SIZES.map(size => ({ label: size.label, action: () => this.generateLevel(size) }));
            items.push({ label: 'Cancel', action: () => this.openMenu('main') });
            items = items.map((it, i) => ({ ...it, y: i * 32 }));
        } else if (this.menu === 'load') {
            // Classic level slots 24 apart, then Join Server.. and Cancel
            const names = this.slotNames || [];
            for (let i = 0; i < LEVEL_SLOTS; i++) {
                const name = names[i];
                // Filled slots are narrower to make room for their delete (X) button.
                // Filled slot: load it. Empty slot: pick a .dat file to put in it.
                items.push({ label: name || '-', y: i * 24, w: name ? 176 : 200,
                    action: () => { if (name) this.loadSlot(i); else this.importLevelFile(i); } });
                if (name) items.push({ label: 'X', y: i * 24, xOff: 180, w: 20,
                    action: () => { this.deleteSlot = i; this.openMenu('delete'); } });
            }
            const after = LEVEL_SLOTS * 24 + 6;
            items.push({ label: 'Cancel', y: after, action: () => this.openMenu('main') });
        } else if (this.menu === 'join') {
            // "Server address:" label at 0, the address box at 12, a message line at 36, then buttons
            items = [
                { label: 'Connect', y: 48, enabled: this.serverAddress.trim().length > 0, action: () => this.joinServer() },
                { label: 'Cancel', y: 72, action: () => this.openMenu('load') }
            ];
        } else if (this.menu === 'save') {
            // "Name:" label at 0, its box at 10, "Description:" at 36, its box at 46, message at 72
            items = [
                { label: 'Save', y: 86, enabled: this.saveName.trim().length > 0 && !this.saving, action: () => this.saveToLevels() },
                { label: 'Cancel', y: 110, action: () => this.openMenu('main') }
            ];
        } else if (this.menu === 'signin') {
            // red "not signed in" line at 0, then the choices
            items = [
                { label: 'Sign in', y: 20, action: () => {} },     // accounts come with the website
                { label: 'Play as Guest', y: 44, action: () => this.playAsGuest() },
                { label: 'Cancel', y: 76, action: () => this.openMenu('load') }
            ];
        } else if (this.menu === 'delete') {
            items = [
                { label: 'Delete', y: 0, action: () => this.deleteSavedLevel(this.deleteSlot) },
                { label: 'Cancel', y: 32, action: () => this.openMenu('load') }
            ];
        }
        // centre the whole block
        let height = 0;
        for (const it of items) height = Math.max(height, it.y + 20);
        const top = Math.max(0, Math.floor((H - TITLE_GAP - height) / 2));
        const bx = Math.floor(W / 2) - 100, by = top + TITLE_GAP;
        this.menuTitleY = top * gs;
        this.menuBodyY = by * gs;            // top of the buttons block, for text drawn in it
        if (this.menu === 'join') this.addressBox = { x: bx * gs, y: (by + 12) * gs, w: 200 * gs, h: 20 * gs };
        if (this.menu === 'save') {
            this.saveBoxes = { name: { x: bx * gs, y: (by + 10) * gs, w: 200 * gs, h: 20 * gs },
                desc: { x: bx * gs, y: (by + 46) * gs, w: 200 * gs, h: 20 * gs } };
        }
        this.menuButtons = items.map(it => ({
            enabled: true, ...it,
            x: (bx + (it.xOff || 0)) * gs, y: (by + it.y) * gs, w: (it.w || 200) * gs, h: 20 * gs
        }));
        return gs;
    }

    menuTitle() {
        if (this.menu === 'blocks') return 'Select block';
        if (this.menu === 'main') return 'Game menu';
        if (this.menu === 'generate') return 'Generate new level';
        if (this.menu === 'load') return 'Load level';
        if (this.menu === 'join') return 'Join server';
        if (this.menu === 'save') return 'Save level';
        if (this.menu === 'signin') return 'Join server';
        if (this.menu === 'delete') {
            const name = this.slotNames && this.slotNames[this.deleteSlot];
            return 'Delete ' + (name || 'level') + '?';
        }
        return '';
    }

    menuClick(x, y) {
        this.layoutMenu();
        if (this.menu === 'blocks') {
            // pick the block you clicked, and go straight back to the game
            const slot = this.blockSlots.find(b => x >= b.x && x < b.x + b.size && y >= b.y && y < b.y + b.size);
            if (slot) {
                this.player.selectedSlot = slot.index;
                this.blockPreview.setType(this.player.getSelectedBlock());
                this.backToGame();
            }
            return;
        }
        if (this.menu === 'save' && this.saveBoxes) {
            for (const key of ['name', 'desc']) {
                const b = this.saveBoxes[key];
                if (x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) { this.saveField = key; return; }
            }
        }
        for (const b of this.menuButtons) {
            if (b.enabled && x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) {
                b.action();
                return;
            }
        }
    }

    renderMenu() {
        if (this.menu === 'blocks') { this.renderBlockMenu(); return; }
        const ctx = this.hudCtx;
        const gs = this.layoutMenu();
        this.drawTextCentered(this.menuTitle(), Math.floor(this.hudCanvas.width / 2), this.menuTitleY, gs, 0xFFFFFF);
        for (const b of this.menuButtons) {
            const hover = b.enabled && this.mouseX >= b.x && this.mouseX < b.x + b.w &&
                this.mouseY >= b.y && this.mouseY < b.y + b.h;
            // Classic button: black outline and grey face (blue-grey when hovered).
            // Disabled: blue-grey outline, lighter grey face, grey text.
            ctx.fillStyle = b.enabled ? '#000000' : '#8080A0';
            ctx.fillRect(b.x - gs, b.y - gs, b.w + gs * 2, b.h + gs * 2);
            ctx.fillStyle = !b.enabled ? '#909090' : hover ? '#7070A0' : '#707070';
            ctx.fillRect(b.x, b.y, b.w, b.h);
            const textY = b.y + Math.floor((b.h - this.fontSheets.charH * gs) / 2);
            const color = !b.enabled ? 0xA0A0A0 : hover ? 0xFFFFA0 : 0xE0E0E0;
            this.drawTextCentered(b.label, b.x + b.w / 2, textY, gs, color);
        }
        if (this.menu === 'signin') {
            this.drawTextCentered("You aren't signed in", Math.floor(this.hudCanvas.width / 2), this.menuBodyY + 4 * gs, gs, 0xFF5555);
        }
        if (this.menu === 'join' && this.isGuest) {
            const last = this.menuButtons[this.menuButtons.length - 1];
            this.drawTextCentered('Playing as ' + this.playerName, Math.floor(this.hudCanvas.width / 2), last.y + last.h + 6 * gs, gs, 0xA0A0A0);
        }
        if (this.menu === 'save' && this.saveBoxes) {
            const cxm = Math.floor(this.hudCanvas.width / 2);
            for (const [key, label, value] of [['name', 'Name:', this.saveName], ['desc', 'Description:', this.saveDesc]]) {
                const ab = this.saveBoxes[key];
                const active = this.saveField === key;
                ctx.fillStyle = active ? '#FFFFFF' : '#A0A0A0';
                ctx.fillRect(ab.x - gs, ab.y - gs, ab.w + gs * 2, ab.h + gs * 2);
                ctx.fillStyle = '#000000';
                ctx.fillRect(ab.x, ab.y, ab.w, ab.h);
                const cursor = active && Math.floor(performance.now() / 300) % 2 === 0 ? '_' : '';
                let shown = value;
                const room = ab.w - 8 * gs - this.textWidth('_', gs);
                while (shown.length > 0 && this.textWidth(shown, gs) > room) shown = shown.slice(1);
                this.drawText(shown + cursor, ab.x + 4 * gs, ab.y + Math.floor((ab.h - this.fontSheets.charH * gs) / 2), gs, 0xE0E0E0);
                this.drawText(label, ab.x, ab.y - 10 * gs, gs, 0xA0A0A0);
            }
            if (this.saveMessage) this.drawTextCentered(this.saveMessage, cxm, this.saveBoxes.desc.y + 26 * gs, gs, this.saveMessageColor || 0xFF5555);
        }
        if (this.menu === 'join' && this.addressBox) {
            // text box: grey outline, black inside, the typed address and a blinking cursor
            const ab = this.addressBox;
            ctx.fillStyle = '#A0A0A0';
            ctx.fillRect(ab.x - gs, ab.y - gs, ab.w + gs * 2, ab.h + gs * 2);
            ctx.fillStyle = '#000000';
            ctx.fillRect(ab.x, ab.y, ab.w, ab.h);
            const cursor = Math.floor(performance.now() / 300) % 2 === 0 ? '_' : '';
            const textY = ab.y + Math.floor((ab.h - this.fontSheets.charH * gs) / 2);
            // too long for the box? show the end (where you're typing), like a text field scrolls
            let shown = this.serverAddress;
            const room = ab.w - 8 * gs - this.textWidth('_', gs);
            while (shown.length > 0 && this.textWidth(shown, gs) > room) shown = shown.slice(1);
            this.drawText(shown + cursor, ab.x + 4 * gs, textY, gs, 0xE0E0E0);
            this.drawTextCentered('Server address:', Math.floor(this.hudCanvas.width / 2), ab.y - 12 * gs, gs, 0xA0A0A0);
            if (this.joinMessage) this.drawTextCentered(this.joinMessage, Math.floor(this.hudCanvas.width / 2), ab.y + 24 * gs, gs, 0xFF5555);
            // a longer hint goes under the buttons, where there's room
            if (this.joinHint && this.joinMessage) {
                const last = this.menuButtons[this.menuButtons.length - 1];
                this.drawTextCentered(this.joinHint, Math.floor(this.hudCanvas.width / 2), last.y + last.h + (this.isGuest ? 18 : 6) * gs, gs, 0xA0A0A0);
            }
        }
    }

    // ---- Saving to the Levels page ----

    // Save level..: take the thumbnail now (what you're looking at), then ask for a name
    openSavePage() {
        this.saveThumb = null;
        this.thumbRequested = true;          // taken in the next frame (see the end of loop())
        this.saveField = 'name';
        this.saveMessage = null;
        this.saving = false;
        this.openMenu('save');
    }

    // A small picture of the world as it is on screen right now (like old Roblox thumbnails).
    // Called in the middle of a frame, straight after the world is drawn (without the selection
    // box and other in-world interface), before anything else.
    copyThumbnail() {
        try {
            const c = document.createElement('canvas');
            c.width = 320; c.height = 180;
            const src = this.renderer.domElement, sw = src.width, sh = src.height;
            const scale = Math.max(c.width / sw, c.height / sh);  // fill it, cropping the edges
            const w = c.width / scale, h = c.height / scale;
            c.getContext('2d').drawImage(src, (sw - w) / 2, (sh - h) / 2, w, h, 0, 0, c.width, c.height);
            return c.toDataURL('image/jpeg', 0.85);
        } catch (err) { console.error('Could not take a thumbnail:', err); return null; }
    }

    handleSaveKey(e) {
        if (e.code === 'Tab') { e.preventDefault(); this.saveField = this.saveField === 'name' ? 'desc' : 'name'; return; }
        if (e.code === 'Enter') { e.preventDefault(); if (this.saveName.trim() && !this.saving) this.saveToLevels(); return; }
        const key = this.saveField === 'name' ? 'saveName' : 'saveDesc', max = this.saveField === 'name' ? SAVE_NAME_MAX : SAVE_DESC_MAX;
        if (e.code === 'Backspace') { this[key] = this[key].slice(0, -1); }
        else if (!e.ctrlKey && !e.metaKey && e.key.length === 1 && e.key >= ' ' && e.key <= '~' && this[key].length < max) this[key] += e.key;
        else return;
        this.saveMessage = null;
        e.preventDefault();
    }

    // Save: on the website, send the level to the Levels page (through the website and the
    // server); if that can't happen, or the game isn't on the website, download it instead
    async saveToLevels() {
        const name = this.saveName.trim(), description = this.saveDesc.trim();
        if (!name || this.saving) return;
        this.saving = true;
        for (let i = 0; i < 20 && !this.saveThumb; i++) await new Promise(r => setTimeout(r, 50));   // (taken next frame)
        this.saveMessage = 'Saving..'; this.saveMessageColor = 0xE0E0E0;
        let blob;
        try { blob = await encodeLevel(this.level, this.player); }
        catch (err) { this.saving = false; this.saveMessage = 'Couldn\'t save the level'; this.saveMessageColor = 0xFF5555; return; }
        const download = () => {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = (name.replace(/[^A-Za-z0-9 _-]/g, '') || 'level') + '.dat';
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
        };
        if (window.parent === window) {                  // on its own: just a download
            download();
            this.saving = false;
            this.addChat('Level saved', 0xFFFF55);
            this.openMenu('main');
            return;
        }
        const bytes = new Uint8Array(await blob.arrayBuffer());
        let bin = '';
        for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
        const result = await new Promise(resolve => {
            const id = 'save-' + Date.now();
            const onReply = e => {
                if (e.source !== window.parent || !e.data || e.data.type !== 'claudecraft-publish-result' || e.data.id !== id) return;
                window.removeEventListener('message', onReply);
                resolve(e.data);
            };
            window.addEventListener('message', onReply);
            window.parent.postMessage({ type: 'claudecraft-publish', id, name, description, dat: btoa(bin), thumb: this.saveThumb }, '*');
            setTimeout(() => { window.removeEventListener('message', onReply); resolve({ ok: false, error: 'No server answered' }); }, 30000);
        });
        this.saving = false;
        if (result.ok) {
            this.addChat('Level saved to the Levels page: ' + name, 0xFFFF55);
            this.saveName = ''; this.saveDesc = '';
            this.openMenu('main');
        } else {
            // say what went wrong and stay here to try again (nothing is downloaded)
            const why = String(result.error || 'the Levels page isn\'t available').slice(0, 60);
            this.addChat('Couldn\'t save to the Levels page: ' + why, 0xFF5555);
            this.saveMessage = 'Couldn\'t save. Try again?'; this.saveMessageColor = 0xFF5555;
        }
    }

    // ---- Opening a level from the Levels page ----
    async loadSharedLevel(url, title) {
        this.statusMessage = 'Loading ' + title + '..';
        this.loadingStage = null;
        this.loadingProgress = 0;
        try {
            const res = await fetch(url);
            if (!res.ok) throw new Error('not found');
            // read it in pieces so the bar can fill up as it downloads
            const total = Number(res.headers.get('content-length')) || 0;
            const reader = res.body.getReader(), parts = [];
            let got = 0;
            for (;;) {
                const { done, value } = await reader.read();
                if (done) break;
                parts.push(value); got += value.length;
                if (total) this.loadingProgress = Math.min(0.9, got / total * 0.9);
            }
            let bytes = new Uint8Array(await new Blob(parts).arrayBuffer());
            // a .dat starts with gzip's 1f 8b; anything else is the older base64 text copy
            if (!(bytes[0] === 0x1f && bytes[1] === 0x8b)) bytes = Uint8Array.from(atob(new TextDecoder().decode(bytes).trim()), ch => ch.charCodeAt(0));
            this.loadingProgress = 0.95;
            const level = await decodeLevel(new Blob([bytes]));
            this.loadingProgress = 1;
            this.loadLevel(level);
        } catch (err) {
            console.error('Could not load that level:', err);
            this.statusMessage = null;
            this.addChat('Couldn\'t load that level', 0xFF5555);
            this.generateLevel(LEVEL_SIZES.find(sz => sz.label === 'Normal'), false);
            return;
        }
        this.statusMessage = null; this.loadingProgress = null;
    }

    // Join server page: typing the address
    handleAddressKey(e) {
        if (e.code === 'Enter') {
            e.preventDefault();
            if (this.serverAddress.trim()) this.joinServer();
            return;
        } else if (e.code === 'Backspace') {
            this.serverAddress = this.serverAddress.slice(0, -1);
        } else if (!e.ctrlKey && !e.metaKey && e.key.length === 1 && e.key >= ' ' && e.key <= '~' && this.serverAddress.length < SERVER_ADDRESS_MAX) {
            this.serverAddress += e.key;
        } else {
            return;
        }
        this.joinMessage = null;
        e.preventDefault();
    }


    // ---- New level / save / load ----

    // Generates in small pieces between frames so the loading screen can show progress
    // lockMouse: capture the mouse straight away (not possible when the game first opens,
    // since browsers only allow it after a click)
    generateLevel(size, lockMouse = true) {
        this.leaveServer();
        this.closeMenu();
        if (lockMouse) this.lockPointer();
        this.statusMessage = 'Generating level..';
        this.loadingStage = 'Raising..';
        this.loadingProgress = 0;
        const steps = new LevelGen(size.w, size.h, size.d).generateSteps();
        const finish = () => {
            this.statusMessage = null;
            this.loadingStage = null;
            this.loadingProgress = null;
        };
        const work = () => {
            const start = performance.now();
            let r;
            try {
                do {
                    r = steps.next();
                    if (!r.done) [this.loadingStage, this.loadingProgress] = r.value;
                } while (!r.done && performance.now() - start < 30);
            } catch (err) {
                console.error('Level generation failed:', err);
                finish();
                return;
            }
            if (!r.done) { setTimeout(work, 0); return; }
            setTimeout(() => {
                try {
                    this.loadLevel(new Level(size.w, size.h, size.d, r.value));
                } catch (err) {
                    console.error('Level generation failed:', err);
                }
                finish();
            }, 0);
        };
        setTimeout(work, 30);
    }

    // Save level..: download the current level as a .dat file
    downloadLevel() {
        const lv = this.level;
        this.statusMessage = 'Saving level..';
        encodeLevel(lv, this.player)
            .then(blob => {
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'level.dat';
                document.body.appendChild(a);
                a.click();
                a.remove();
                setTimeout(() => URL.revokeObjectURL(url), 1000);
                this.addChat('Level saved', 0xFFFF55);
            })
            .catch(err => { console.error('Could not save level:', err); this.addChat('Couldn\'t save the level', 0xFF5555); })
            .finally(() => { this.statusMessage = null; });
    }

    // Empty Load level slot: ask for a .dat file, check it's a level, and keep it in that slot
    // (named after the file) so it can be loaded any time
    importLevelFile(slot) {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.dat';
        input.onchange = async () => {
            const file = input.files && input.files[0];
            if (!file) return;
            this.statusMessage = 'Adding level..';
            try {
                const level = await decodeLevel(file); // throws if it isn't a level file
                const name = file.name.replace(/\.dat$/i, '').slice(0, LEVEL_NAME_MAX) || 'Level ' + (slot + 1);
                await LevelStore.put('data-' + slot, file);
                await LevelStore.put('meta-' + slot, { name, w: level.width, h: level.height, d: level.depth });
                if (!this.slotNames) this.slotNames = new Array(LEVEL_SLOTS).fill(null);
                this.slotNames[slot] = name;
            } catch (err) {
                console.error('Could not add level file:', err);
            }
            this.statusMessage = null;
        };
        input.click();
    }

    // Delete button: empty that slot and go back to the Load level page
    deleteSavedLevel(slot) {
        Promise.all([LevelStore.remove('data-' + slot), LevelStore.remove('meta-' + slot)])
            .then(() => { if (this.slotNames) this.slotNames[slot] = null; })
            .catch(err => console.error('Could not delete level:', err))
            .finally(() => this.openMenu('load'));
    }

    loadSlot(slot) {
        this.leaveServer();
        this.closeMenu();
        this.lockPointer();
        this.statusMessage = 'Loading level..';
        LevelStore.get('data-' + slot)
            .then(data => {
                if (!data) throw new Error('Slot ' + slot + ' is empty');
                return decodeLevel(data);
            })
            .then(level => this.loadLevel(level))
            .catch(err => console.error('Could not load level:', err))
            .finally(() => { this.statusMessage = null; });
    }

    buildOuterWorld(waterTex, bedrockTex) {
        if (this.outerWorld) {
            this.scene.remove(this.outerWorld);
            this.outerWorld.traverse(o => { if (o.geometry) o.geometry.dispose(); });
        }
        this.outerWorld = new THREE.Group();
        this.scene.add(this.outerWorld);
        const waterMat = new THREE.MeshBasicMaterial({
            map: waterTex, color: WATER_TINT, transparent: true, opacity: WATER_OPACITY, side: THREE.DoubleSide, depthWrite: false
        });
        const bedrockMat = new THREE.MeshBasicMaterial({ map: bedrockTex, side: THREE.FrontSide });
        const W = 4000, mapW = MAP_WIDTH, halfMap = mapW / 2, ext = W / 2;
        const wallMat = new THREE.MeshBasicMaterial({ map: bedrockTex, side: THREE.DoubleSide });
        // A flat plane with its texture repeated once per block
        const plane = (mat, pw, ph, x, y, z, rotX, rotY, order) => {
            const geo = new THREE.PlaneGeometry(pw, ph);
            const uvs = geo.attributes.uv;
            for (let i = 0; i < uvs.count; i++) { uvs.setX(i, uvs.getX(i) * pw); uvs.setY(i, uvs.getY(i) * ph); }
            const mesh = new THREE.Mesh(geo, mat);
            mesh.rotation.set(rotX, rotY, 0);
            mesh.position.set(x, y, z);
            if (order) mesh.renderOrder = order;
            this.outerWorld.add(mesh);
        };
        // ocean surface and sea floor all round the map (north, south, west, east strips)
        const strips = [[mapW + W, ext, halfMap, -ext / 2], [mapW + W, ext, halfMap, mapW + ext / 2],
            [ext, mapW, -ext / 2, halfMap], [ext, mapW, mapW + ext / 2, halfMap]];
        for (const [pw, ph, x, z] of strips) {
            plane(waterMat, pw, ph, x, SEA_LEVEL - 1 / 16, z, -Math.PI / 2, 0, 1);
            plane(bedrockMat, pw, ph, x, SEA_LEVEL - MAX_WATER_DEPTH, z, -Math.PI / 2, 0);   // deepest sea floor
        }
        // bedrock walls on the map's sides, up to the outer sea floor
        const wh = SEA_LEVEL - MAX_WATER_DEPTH;
        for (const [x, z, ry] of [[halfMap, 0, 0], [halfMap, mapW, Math.PI], [0, halfMap, Math.PI / 2], [mapW, halfMap, -Math.PI / 2]])
            plane(wallMat, mapW, wh, x, wh / 2, z, 0, ry);
    }

    prepareFont(img) {
        const charW = Math.floor(img.width / 16);
        const charH = Math.floor(img.height / 16);
        const canvas = document.createElement('canvas');
        canvas.width = img.width; canvas.height = img.height;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(img, 0, 0);
        const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const whiteCanvas = document.createElement('canvas');
        whiteCanvas.width = img.width; whiteCanvas.height = img.height;
        const whiteCtx = whiteCanvas.getContext('2d');
        whiteCtx.imageSmoothingEnabled = false;
        const whiteData = whiteCtx.createImageData(canvas.width, canvas.height);
        const shadowCanvas = document.createElement('canvas');
        shadowCanvas.width = img.width; shadowCanvas.height = img.height;
        const shadowCtx = shadowCanvas.getContext('2d');
        shadowCtx.imageSmoothingEnabled = false;
        const shadowData = shadowCtx.createImageData(canvas.width, canvas.height);
        for (let i = 0; i < data.data.length; i += 4) {
            const r = data.data[i], g = data.data[i + 1], b = data.data[i + 2], a = data.data[i + 3];
            const isCyan = (r < 50 && g > 200 && b > 200);
            const isText = (a > 128) && !isCyan && (r > 100 || g > 100 || b > 100);
            if (isText) {
                whiteData.data[i] = whiteData.data[i + 1] = whiteData.data[i + 2] = 255; whiteData.data[i + 3] = 255;
                shadowData.data[i] = shadowData.data[i + 1] = shadowData.data[i + 2] = 63; shadowData.data[i + 3] = 255;
            } else {
                whiteData.data[i + 3] = 0; shadowData.data[i + 3] = 0;
            }
        }
        whiteCtx.putImageData(whiteData, 0, 0);
        shadowCtx.putImageData(shadowData, 0, 0);
        const widths = new Array(256).fill(charW);
        const pixels = whiteData.data;
        for (let c = 0; c < 256; c++) {
            const cx = (c % 16) * charW, cy = Math.floor(c / 16) * charH;
            let maxX = -1;
            for (let py = 0; py < charH; py++)
                for (let px = 0; px < charW; px++)
                    if (pixels[((cy + py) * canvas.width + (cx + px)) * 4 + 3] > 0 && px > maxX) maxX = px;
            widths[c] = maxX >= 0 ? maxX + 2 : Math.floor(charW / 2);
            if (c === 32) widths[c] = 4;
        }
        return { white: whiteCanvas, shadow: shadowCanvas, charW, charH, widths };
    }

    // Font sheet tinted to a colour (cached). Used for coloured menu text and its shadow.
    tintedSheet(color) {
        const fs = this.fontSheets;
        if (!fs.tints) fs.tints = {};
        if (fs.tints[color]) return fs.tints[color];
        const c = document.createElement('canvas');
        c.width = fs.white.width; c.height = fs.white.height;
        const cx = c.getContext('2d');
        cx.drawImage(fs.white, 0, 0);
        cx.globalCompositeOperation = 'source-in';
        cx.fillStyle = '#' + color.toString(16).padStart(6, '0');
        cx.fillRect(0, 0, c.width, c.height);
        fs.tints[color] = c;
        return c;
    }

    // Repeating dirt background (Classic loading screen look): the dirt tile, scaled up by
    // the GUI scale and darkened. Returns null until terrain.png has loaded.
    dirtPattern(gs) {
        if (!this.terrainImg) return null;
        if (this.dirtPatternCache && this.dirtPatternCache.gs === gs) return this.dirtPatternCache.pattern;
        const size = 16 * gs * 2;
        const c = document.createElement('canvas');
        c.width = size; c.height = size;
        const cx = c.getContext('2d');
        cx.imageSmoothingEnabled = false;
        const [col, row] = BLOCK_UVS[BLOCK.DIRT];
        cx.drawImage(this.terrainImg, col * 16, row * 16, 16, 16, 0, 0, size, size);
        cx.fillStyle = 'rgba(0, 0, 0, 0.75)'; // darken to about a quarter brightness
        cx.fillRect(0, 0, size, size);
        const pattern = this.hudCtx.createPattern(c, 'repeat');
        this.dirtPatternCache = { gs, pattern };
        return pattern;
    }

    textWidth(text, scale) {
        if (!this.fontSheets) return 0;
        let wSum = 0;
        for (let i = 0; i < text.length; i++) wSum += this.fontSheets.widths[text.charCodeAt(i)];
        return wSum * scale;
    }

    drawTextCentered(text, cx, y, scale, color) {
        this.drawText(text, Math.floor(cx - this.textWidth(text, scale) / 2), y, scale, color);
    }

    // color is optional (defaults to white). The shadow is the colour at a quarter brightness,
    // like Minecraft.
    drawText(text, x, y, scale, color) {
        if (!this.fontSheets) return;
        let white = this.fontSheets.white, shadow = this.fontSheets.shadow;
        if (color != null && color !== 0xFFFFFF) {
            white = this.tintedSheet(color);
            shadow = this.tintedSheet((color & 0xFCFCFC) >> 2);
        }
        const s = scale == null ? this.hudScale : scale;
        this.blitText(this.hudCtx, shadow, text, x + s, y + s, s);   // shadow one pixel down-right
        this.blitText(this.hudCtx, white, text, x, y, s);
    }

    // Draws text from a font sheet at (x, y), each font pixel s screen pixels
    blitText(ctx, sheet, text, x, y, s) {
        const { charW, charH, widths } = this.fontSheets;
        let cursor = 0;
        for (let i = 0; i < text.length; i++) {
            const code = text.charCodeAt(i);
            ctx.drawImage(sheet, (code % 16) * charW, Math.floor(code / 16) * charH, charW, charH,
                Math.floor(x + cursor * s), Math.floor(y), charW * s, charH * s);
            cursor += widths[code];
        }
    }

    renderHUD() {
        const w = this.hudCanvas.width, h = this.hudCanvas.height;
        // Skip the redraw when nothing on the HUD changed (menus and loading screens animate,
        // so those always redraw)
        const hudKey = [w, h, !!this.fontSheets, this.displayFps, this.displayChunkUpdates].join('|');
        const nowT = performance.now();
        const chatShowing = this.chatOpen || this.chatLines.some(l => nowT - l.time < CHAT_SHOW_SECONDS * 1000);
        const animating = this.menu || this.statusMessage || chatShowing || this.chatWasShowing || this.blind || this.wasBlind;
        this.wasBlind = this.blind;
        this.chatWasShowing = chatShowing;      // one more redraw after the last message fades
        if (!animating && hudKey === this.lastHudKey) return;
        this.lastHudKey = animating ? null : hudKey;
        this.hudCtx.clearRect(0, 0, w, h);
        this.hudCtx.imageSmoothingEnabled = false;
        const cx = Math.floor(w / 2), cy = Math.floor(h / 2);
        if (this.statusMessage) {
            // Full-screen message while a level is generated or loaded, on tiled dirt
            this.hudCtx.fillStyle = this.dirtPattern(this.guiScale()) || '#000000';
            this.hudCtx.fillRect(0, 0, w, h);
            if (this.fontSheets) {
                // Classic loading screen: title, the current step, and a progress bar
                const gs = this.guiScale();
                this.drawTextCentered(this.statusMessage, cx, cy - (4 + 16) * gs, gs, 0xFFFFFF);
                if (this.loadingStage) this.drawTextCentered(this.loadingStage, cx, cy + (8 - 4) * gs, gs, 0xFFFFFF);
                if (this.loadingProgress != null) {
                    const bw = 100 * gs, bh = 2 * gs;
                    const bx = cx - bw / 2, by = cy + 16 * gs;
                    this.hudCtx.fillStyle = '#808080';
                    this.hudCtx.fillRect(bx, by, bw, bh);
                    this.hudCtx.fillStyle = '#80FF80';
                    this.hudCtx.fillRect(bx, by, Math.round(bw * Math.max(0, Math.min(1, this.loadingProgress))), bh);
                }
            }
            return;
        }
        if (this.menu === 'blocks') {
            // the block menu is just its panel, over the world
        } else if (this.menu) {
            // Classic menu shade: dark at the top fading to a blue-grey at the bottom
            const grad = this.hudCtx.createLinearGradient(0, 0, 0, h);
            grad.addColorStop(0, 'rgba(5, 5, 0, 0.38)');
            grad.addColorStop(1, 'rgba(48, 48, 96, 0.63)');
            this.hudCtx.fillStyle = grad;
            this.hudCtx.fillRect(0, 0, w, h);
        } else {
            const arm = 14, thick = 4;
            this.hudCtx.fillStyle = '#FFFFFF';
            this.hudCtx.fillRect(cx - arm, cy - Math.floor(thick / 2), arm * 2, thick);
            this.hudCtx.fillRect(cx - Math.floor(thick / 2), cy - arm, thick, arm * 2);
        }
        if (!this.fontSheets) return;
        const line1 = VERSION;
        const line2 = `${this.displayFps} fps, ${this.displayChunkUpdates} chunk updates`;
        const lineHeight = Math.floor(this.fontSheets.charH * this.hudScale + 4);
        this.drawText(line1, 4, 4);
        this.drawText(line2, 4, 4 + lineHeight);
        if (this.blind && !this.menu) {
            // the server has blinded you (the seeker while the others hide)
            this.hudCtx.fillStyle = '#000000';
            this.hudCtx.fillRect(0, 0, w, h);
            this.drawTextCentered(this.blindText, cx, cy - Math.floor(this.fontSheets.charH * this.hudScale / 2), this.hudScale, 0xFFFFFF);
        }
        if (!this.menu) this.renderChat();
        if (this.menu) this.renderMenu();
    }

    // Placement ghost box with the correct texture on each face (e.g. log rings on top)
    makeGhost(type) {
        const geo = new THREE.BoxGeometry(1.002, 1.002, 1.002);
        const a = geo.attributes.uv;
        const e = 0.0005;
        // BoxGeometry faces, 4 vertices each: +x, -x, +y, -y, +z, -z
        const faceNy = [0, 0, 1, -1, 0, 0];
        for (let f = 0; f < 6; f++) {
            const [u0, v0, u1, v1] = tileUV(...faceUV(type, faceNy[f]), e);
            for (let k = f * 4; k < f * 4 + 4; k++) {
                a.setXY(k, u0 + a.getX(k) * (u1 - u0), v0 + a.getY(k) * (v1 - v0));
            }
        }
        return geo;
    }

    makePlantGhost(uv) { return plantCrossGeometry(uv[0], uv[1], 0.0005, false); }

    // Nametag sprite, like Classic: white default.gif text with a dark drop shadow, no background
    // color: the text colour (white unless given, e.g. yellow for the server owner)
    makeNametag(text, color = 0xFFFFFF) {
        const fs = this.fontSheets, sc = 4;
        let tw = 0;
        for (let i = 0; i < text.length; i++) tw += fs.widths[text.charCodeAt(i)];
        tw -= 1;                                    // no gap after the last letter
        const pw = tw + 1, ph = fs.charH + 1;       // +1 pixel for the shadow
        const c = document.createElement('canvas');
        c.width = pw * sc; c.height = ph * sc;
        const cx = c.getContext('2d');
        cx.imageSmoothingEnabled = false;
        const white = color === 0xFFFFFF ? fs.white : this.tintedSheet(color);
        const shadow = color === 0xFFFFFF ? fs.shadow : this.tintedSheet((color & 0xFCFCFC) >> 2);
        this.blitText(cx, shadow, text, sc, sc, sc);   // shadow first, one pixel down-right
        this.blitText(cx, white, text, 0, 0, sc);
        const tex = new THREE.CanvasTexture(c);
        tex.magFilter = tex.minFilter = THREE.NearestFilter;
        tex.colorSpace = THREE.SRGBColorSpace;
        // a flat, one-sided plane (its front faces +z); updateNametag turns it to face you
        const tag = new THREE.Mesh(
            new THREE.PlaneGeometry(pw * NAMETAG_PIXEL, ph * NAMETAG_PIXEL),
            new THREE.MeshBasicMaterial({ map: tex, transparent: true, alphaTest: 0.05, depthWrite: false, fog: false, side: THREE.FrontSide }));
        tag.renderOrder = 3;
        tag.visible = false;
        return tag;
    }

    // Third person (F5): put the camera behind the player and show the player's model
    // Walk animation and pose for a player model (yours in third person, or another player's).
    // st holds its animation state: limbAmount (how strongly the limbs swing, eases toward the
    // walking speed), limbPos (how far through the swing), bodyYaw, and the last feet position.
    poseHumanoid(v, st, fx, fy, fz, headYaw, pitch, dt) {
        if (st.lastX !== undefined && dt > 0) {
            const dx = fx - st.lastX, dz = fz - st.lastZ;
            const perTick = Math.sqrt(dx * dx + dz * dz) / (dt * 20);       // blocks per tick
            const target = Math.min(1, perTick * 4);
            st.limbAmount += (target - st.limbAmount) * (1 - Math.pow(1 - LIMB_EASE, dt * 20));
            st.limbPos += st.limbAmount * dt * 20 * LIMB_SPEED;
        }
        st.lastX = fx; st.lastZ = fz;
        // the head leads; the body follows once the head is turned too far, and eases round
        // to face the view while walking
        const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));
        if (st.bodyYaw === undefined) st.bodyYaw = headYaw;
        if (dt > 0 && st.limbAmount > 0.1) st.bodyYaw += wrap(headYaw - st.bodyYaw) * (1 - Math.pow(1 - BODY_TURN_EASE, dt * 20));
        const diff = wrap(headYaw - st.bodyYaw);
        if (diff > HEAD_TURN_LIMIT) st.bodyYaw = headYaw - HEAD_TURN_LIMIT;
        if (diff < -HEAD_TURN_LIMIT) st.bodyYaw = headYaw + HEAD_TURN_LIMIT;

        v.root.position.set(fx, fy, fz);
        // the mobs' animation, scaled by how strongly it's walking, so it winds down when it stops
        const t = st.limbPos, amt = st.limbAmount;
        v.body.position.y = -Math.abs(Math.sin(t * 0.6662)) * 5.0 * amt - 23.0;
        v.body.rotation.y = st.bodyYaw;
        v.parts.arm0.rotation.x = Math.sin(t * 0.6662 + Math.PI) * 2.0 * amt;
        v.parts.arm0.rotation.z = (Math.sin(t * 0.2312) + 1.0) * amt;
        v.parts.arm1.rotation.x = Math.sin(t * 0.6662) * 2.0 * amt;
        v.parts.arm1.rotation.z = (Math.sin(t * 0.2812) - 1.0) * amt;
        v.parts.leg0.rotation.x = Math.sin(t * 0.6662) * 1.4 * amt;
        v.parts.leg1.rotation.x = Math.sin(t * 0.6662 + Math.PI) * 1.4 * amt;
        // the head follows the look exactly (turned relative to the body), no nodding or spinning
        v.parts.head.rotation.y = wrap(headYaw - st.bodyYaw);
        v.parts.head.rotation.x = -pitch;
        // shading like mobs: the light of the block at chest height
        const bx = Math.floor(fx), bz = Math.floor(fz), by = Math.floor(fy + 1.2);
        const sky = this.level.isLit(bx, by, bz) ? 1.0 : SHADOW_SHADE;
        const c = shade(sky * liquidDarkness(this.level, bx, by, bz));
        v.material.color.setRGB(c, c, c);
    }

    // Third person (F5): put the camera behind the player and show the player's model
    updateThirdPerson(eye, now) {
        const dt = this.lastAnimTime ? Math.min(0.25, (now - this.lastAnimTime) / 1000) : 0;
        this.lastAnimTime = now;
        // the animation runs in first person too, so it's right when you switch views
        const p = this.player.position;
        this.poseHumanoid(this.playerView, this.localAnim, p.x, p.y - PLAYER_HEIGHT, p.z, this.player.rotation.y, this.player.rotation.x, dt);
        this.playerView.root.visible = this.thirdPerson;
        if (!this.thirdPerson) return;
        // camera: back along the look direction, stopping short of any solid block
        const dir = this.player.getLookDirection();
        let dist = THIRD_PERSON_DISTANCE;
        for (let d = 0.1; d <= THIRD_PERSON_DISTANCE; d += 0.1) {
            const px = eye.x - dir.x * d, py = eye.y - dir.y * d, pz = eye.z - dir.z * d;
            if (this.level.isSolidTile(Math.floor(px), Math.floor(py), Math.floor(pz))) { dist = Math.max(0, d - 0.3); break; }
        }
        this.camera.position.set(eye.x - dir.x * dist, eye.y - dir.y * dist, eye.z - dir.z * dist);
    }

    // ---- Multiplayer ----

    // Join server page -> Connect: open a WebSocket to the server and say hello
    joinServer() {
        this.joinAddress = this.serverAddressToUrl(this.serverAddress);
        const addr = this.joinAddress;
        this.joinHint = null;
        // a secure (https) page can only open secure connections, except to this computer
        const securePage = typeof location !== 'undefined' && location.protocol === 'https:';
        const plain = /^ws:\/\//i.test(addr) && !/^ws:\/\/(localhost|127\.0\.0\.1|\[::1\])(:|\/|$)/i.test(addr);
        if (securePage && plain) {
            this.joinMessage = 'Use the https:// tunnel link';
            this.joinHint = 'Secure websites can\'t join plain IP addresses';
            return;
        }
        if (this.netPending) this.netPending.close();
        this.leaveServer();          // leave any server you're on before joining another
        let ws;
        try { ws = new WebSocket(addr); } catch (err) { this.joinMessage = 'That address isn\'t valid'; return; }
        this.joinMessage = 'Connecting..';
        this.netPending = ws;
        ws.binaryType = 'arraybuffer';
        ws.onopen = () => ws.send(JSON.stringify({ t: 'hello', name: this.playerName, skin: this.mySkin || undefined }));
        ws.onmessage = ev => this.onNetMessage(ws, ev.data);
        ws.onclose = () => this.onNetClose(ws);
        ws.onerror = () => { if (ws === this.netPending) this.joinMessage = 'Couldn\'t connect to the server'; };
    }

    // Sign-in page -> Play as Guest: carry on to the Join server page with a guest name
    playAsGuest() {
        this.playerAsGuestName();
        this.joinMessage = null;
        this.openMenu('join');
    }

    // A join link: ?join (the server this page came from) or ?join=address, plus &name=YourName
    readJoinLink() {
        if (typeof location === 'undefined' || !location.search) return;
        const q = new URLSearchParams(location.search);
        if (!q.has('join')) return;
        this.autoJoin = q.get('join') || location.origin;
        const name = q.get('name');
        // a join link carries your name only when you're logged in on the website
        this.loggedIn = !!(name && /^[A-Za-z0-9_]{2,16}$/.test(name));
        if (this.loggedIn) { this.playerName = name; this.signedIn = true; this.isGuest = false; }
        else this.playerAsGuestName();
        this.waitForSkin = q.has('skin');     // the website will send a skin: wait for it before joining
    }

    playerAsGuestName() {
        if (!this.isGuest) this.playerName = 'Guest' + Math.floor(100 + Math.random() * 900);
        this.isGuest = true;
    }

    // Your skin: shown on your own model, and sent to the server you're on
    setMySkin(dataUrl) {
        this.mySkin = dataUrl;
        this.playerView.material.map = makeSkinTexture(dataUrl);
        this.playerView.material.needsUpdate = true;
        this.sendNet({ t: 'skin', skin: dataUrl });
    }

    // ---- Chat ----

    openChat() {
        this.chatOpen = true;
        this.chatInput = '';
        for (const k in this.input) this.input[k] = false;   // stop walking while you type
    }

    closeChat() { this.chatOpen = false; this.chatInput = ''; }

    addChat(text, color) {
        this.chatLines.push({ text: text.slice(0, 120), color: typeof color === 'number' ? color : 0xFFFFFF, time: performance.now() });
        if (this.chatLines.length > CHAT_HISTORY) this.chatLines.shift();
    }

    // Typing on the chat line
    handleChatKey(e) {
        if ((e.ctrlKey || e.metaKey) && e.code === 'KeyV') return;   // let the paste happen
        e.preventDefault();
        if (e.code === 'Escape') { this.closeChat(); return; }
        if (e.code === 'Enter') {
            const text = this.chatInput.trim();
            if (text) this.sendNet({ t: 'chat', text });
            this.closeChat();
            return;
        }
        if (e.code === 'Backspace') { this.chatInput = this.chatInput.slice(0, -1); return; }
        if (!e.ctrlKey && !e.metaKey && e.key.length === 1 && e.key >= ' ' && e.key <= '~' && this.chatInput.length < CHAT_MAX) this.chatInput += e.key;
    }

    // Chat at the bottom left: recent messages (all recent ones while typing), and the chat line
    renderChat() {
        const ctx = this.hudCtx, s = this.hudScale, fs = this.fontSheets;
        const lineH = fs.charH * s + 2 * s;
        const h = this.hudCanvas.height;
        let y = h - 4 * s - lineH;
        if (this.chatOpen) {
            // the chat line: dark bar along the bottom with what you're typing and a blinking cursor
            ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
            ctx.fillRect(2 * s, y - s, this.hudCanvas.width - 4 * s, lineH);
            const cursor = Math.floor(performance.now() / 300) % 2 === 0 ? '_' : '';
            let shown = this.chatInput;
            const room = this.hudCanvas.width - 12 * s - this.textWidth('> _', s);
            while (shown.length > 0 && this.textWidth(shown, s) > room) shown = shown.slice(1);
            this.drawText('> ' + shown + cursor, 4 * s, y, s, 0xE0E0E0);
            y -= lineH + 2 * s;
        }
        const now = performance.now();
        const shown = this.chatOpen ? this.chatLines.slice(-CHAT_LINES_OPEN)
            : this.chatLines.filter(l => now - l.time < CHAT_SHOW_SECONDS * 1000).slice(-10);
        // long messages wrap onto more lines (newest message at the bottom)
        const maxW = Math.min(CHAT_WIDTH * s, this.hudCanvas.width - 12 * s);
        for (let i = shown.length - 1; i >= 0 && y > lineH * 3; i--) {
            const rows = this.wrapText(shown[i].text, maxW, s);
            for (let r = rows.length - 1; r >= 0 && y > lineH * 3; r--) {
                ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
                ctx.fillRect(2 * s, y - s, this.textWidth(rows[r], s) + 4 * s, lineH);
                this.drawText(rows[r], 4 * s, y, s, shown[i].color);
                y -= lineH;
            }
        }
    }

    // Split text into lines no wider than maxW (screen pixels), breaking between words; a single
    // word too long for a line is broken where it has to be
    wrapText(text, maxW, s) {
        const rows = [];
        let line = '';
        for (const word of String(text).split(' ')) {
            const tryLine = line ? line + ' ' + word : word;
            if (this.textWidth(tryLine, s) <= maxW) { line = tryLine; continue; }
            if (line) rows.push(line);
            line = word;
            while (this.textWidth(line, s) > maxW && line.length > 1) {     // a very long word
                let cut = line.length - 1;
                while (cut > 1 && this.textWidth(line.slice(0, cut), s) > maxW) cut--;
                rows.push(line.slice(0, cut));
                line = line.slice(cut);
            }
        }
        if (line || !rows.length) rows.push(line);
        return rows;
    }

    // Turns what was typed into a WebSocket address:
    //   192.168.1.20 / 73.2.5.18:25565 / localhost    -> ws://...  (port 25565 added if missing)
    //   https://name.trycloudflare.com or wss://...  -> wss://... (secure, standard port)
    //   name.trycloudflare.com                       -> wss://name.trycloudflare.com
    serverAddressToUrl(typed) {
        let addr = typed.trim().replace(/\/+$/, '');
        if (/^https?:\/\//i.test(addr)) addr = addr.replace(/^http/i, 'ws');           // https:// -> wss://
        else if (!/^wss?:\/\//i.test(addr)) {
            const host = addr.split('/')[0];
            addr = (/\.trycloudflare\.com$/i.test(host) ? 'wss://' : 'ws://') + addr;   // tunnels are secure
        }
        // plain ws:// addresses without a port use the game's default port
        if (/^ws:\/\//i.test(addr) && !/^ws:\/\/[^/]*:\d+/i.test(addr)) addr = addr.replace(/^(ws:\/\/[^/]*)/i, '$1:' + DEFAULT_PORT);
        return addr;
    }

    sendNet(msg) { if (this.net && this.net.readyState === 1) this.net.send(JSON.stringify(msg)); }

    onNetMessage(ws, data) {
        if (typeof data !== 'string') {
            // a level sent while you're on the server: you're going to another level (/goto)
            if (ws === this.net && this.changingLevel) {
                const spawn = this.changingLevel.spawn;
                this.loadingProgress = 0.7;
                decodeLevel(new Blob([data])).then(level => {
                    if (ws !== this.net) return;
                    level.savedPlayer = spawn;
                    this.loadingProgress = 1;
                    const respawn = this.changingLevel && this.changingLevel.respawn;
                    const name = this.changingLevel ? this.changingLevel.name : '';
                    this.loadLevel(level);
                    this.netLevelName = name;
                    // your Y spot on this level (this visit), or the level's spawn
                    const home = this.visitHomes && this.visitHomes[name];
                    if (home || respawn) this.spawnPoint = home || respawn;
                    this.applyExtraBlocks();
                }).catch(err => {
                    console.error('Bad level from server:', err);
                    this.addChat('That level couldn\'t be loaded', 0xFF5555);
                }).finally(() => { this.changingLevel = null; this.statusMessage = null; this.loadingStage = null; this.loadingProgress = null; });
                return;
            }
            // the level, as a .dat file
            if (ws !== this.netPending) return;
            if (!this.statusMessage) this.statusMessage = 'Loading level..';
            this.loadingProgress = 0.7;
            decodeLevel(new Blob([data])).then(level => {
                this.loadingProgress = 1;
                if (ws !== this.netPending) return;
                level.savedPlayer = this.netSpawn;
                // (other players may already have arrived while the level downloaded, so keep them)
                this.net = ws; this.netPending = null;
                this.loadLevel(level);
                if (this.netRespawn) this.spawnPoint = this.netRespawn;
                this.applyExtraBlocks();
                this.closeMenu();
            }).catch(err => {
                console.error('Bad level from server:', err);
                this.joinMessage = 'The server sent a bad level';
                ws.close();
            }).finally(() => { this.statusMessage = null; this.loadingStage = null; this.loadingProgress = null; });
            return;
        }
        let m;
        try { m = JSON.parse(data); } catch { return; }
        if (m.t === 'welcome') {
            this.netId = m.id; this.netSpawn = m.spawn; this.joinMessage = 'Downloading level..';
            this.netRespawn = m.respawn || null;      // the level's spawn point (R)
            this.netLevelName = String(m.level || '');
            this.visitHomes = {};                    // Y spots for this visit, per level
            // the loading screen: the server's name, its description under it, then the bar
            this.statusMessage = String(m.serverName || 'Loading level..').replace(/[^\x20-\x7E]/g, '').slice(0, 40);
            this.loadingStage = String(m.description || '').replace(/[^\x20-\x7E]/g, '').slice(0, 120) || null;
            this.loadingProgress = 0.2;
            // older servers don't send their features and can't do chat
            this.serverHasChat = Array.isArray(m.features) && m.features.includes('chat');
            // what this server allows (older servers don't say, so allow building)
            this.serverBuild = m.building !== false;
            this.serverLiquids = !!m.liquids;          // water and lava blocks (Anarchy)
            // the blocks beyond the usual nine this server lets you place (older servers: liquids only)
            this.extraBlocks = Array.isArray(m.extraBlocks) ? m.extraBlocks.filter(b => EXTRA_BLOCKS.includes(b))
                : this.serverLiquids ? LIQUID_BLOCKS.slice() : [];
            this.hideNametags = !!m.hideNametags;
            if (!this.serverHasChat) this.addChat(OLD_SERVER_WARNING, 0xFFFF55);
        }
        else if (m.t === 'players') m.list.forEach(p => this.addRemotePlayer(p));
        else if (m.t === 'join') this.addRemotePlayer(m);
        else if (m.t === 'leave') this.removeRemotePlayer(m.id);
        else if (m.t === 'move') {
            const r = this.remotePlayers.get(m.id);
            if (r) Object.assign(r.target, { x: m.x, y: m.y, z: m.z, rx: m.rx, ry: m.ry });
        } else if (m.t === 'set') {
            if (ws !== this.net || !this.level) return;
            // behind changes still waiting (keeps everything in order), or straight away
            if (this.netChanges.length) this.netChanges.push(m.x, m.y, m.z, m.b);
            else this.level.setTile(m.x, m.y, m.z, m.b, true);
        } else if (m.t === 'sets' && Array.isArray(m.list)) {
            // many block changes at once: x, y, z, block, x, y, z, block, ...
            if (ws !== this.net || !this.level) return;
            // waiting their turn: applied a couple of milliseconds' worth each frame (applyNetChanges)
            for (const v of m.list) this.netChanges.push(v);
        } else if (m.t === 'changeLevel') {
            // going to another level on this server: "Going to ..." until it arrives
            const name = String(m.name || 'level').replace(/[^\x20-\x7E]/g, '').slice(0, 40);
            this.changingLevel = { name, spawn: m.spawn, respawn: m.respawn || null };
            this.netChanges = []; this.netChangesHead = 0;          // (they were for the old level)
            this.clearRemotePlayers();          // (the players on the new level are sent next)
            this.statusMessage = 'Going to ' + name;
            this.loadingStage = null;
            this.loadingProgress = 0.3;
            if (this.pointerLocked) document.exitPointerLock();
        } else if (m.t === 'extraBlocks' && Array.isArray(m.list)) {
            // your rank changed: different extra blocks
            this.extraBlocks = m.list.filter(b => EXTRA_BLOCKS.includes(b));
            this.applyExtraBlocks();
        } else if (m.t === 'rank') {
            // someone's rank changed: their nametag gets the new colour
            const r = this.remotePlayers.get(m.id);
            if (r && Number.isInteger(m.tagColor)) {
                r.tagColor = m.tagColor;
                if (r.tag) { this.scene.remove(r.tag); r.tag.material.map.dispose(); r.tag.material.dispose(); r.tag.geometry.dispose(); r.tag = null; }
            }
        } else if (m.t === 'levelRules') {
            // the level you've gone to has its own rules (e.g. Hide and Seek: no building, no nametags)
            this.serverBuild = !!m.building;
            this.hideNametags = !!m.hideNametags;
            if (!this.frozen) this.blind = false;
        } else if (m.t === 'canBuild') {
            this.serverBuild = !!m.on;          // e.g. after agreeing to the rules
        } else if (m.t === 'teleport') {
            // the server moves you (e.g. back to spawn when a round starts)
            if (this.player && [m.x, m.y, m.z].every(Number.isFinite)) {
                this.player.position.set(m.x, m.y, m.z);
                this.player.velocity.set(0, 0, 0);
                if (Number.isFinite(m.rx)) this.player.rotation.x = m.rx;
                if (Number.isFinite(m.ry)) this.player.rotation.y = m.ry;
            } else if (Number.isFinite(m.x)) {
                this.netSpawn = { x: m.x, y: m.y, z: m.z, rotX: m.rx || 0, rotY: m.ry || 0 };
            }
        } else if (m.t === 'freeze') {
            // the server stops you moving, and can black out your screen with a message
            this.frozen = !!m.on;
            this.blind = !!(m.on && m.blind);
            this.blindText = String(m.text || '');
            if (this.frozen) for (const k in this.input) this.input[k] = false;
        } else if (m.t === 'skin') {
            const r = this.remotePlayers.get(m.id);
            if (r) { r.view.material.map = isSkinData(m.skin) ? makeSkinTexture(m.skin) : this.mobMaterial.map; r.view.material.needsUpdate = true; }
        } else if (m.t === 'chat') {
            this.addChat(String(m.text || ''), m.color);
        } else if (m.t === 'kick') {
            this.joinMessage = m.reason || 'Kicked from the server';
        }
    }

    onNetClose(ws) {
        if (ws === this.netPending) {
            this.netPending = null;
            if (this.joinMessage === 'Connecting..' || this.joinMessage === 'Downloading level..') {
                this.joinMessage = 'Couldn\'t connect to the server';
                this.joinHint = 'Is the server running? Check the address';
            }
        }
        if (ws === this.net) {
            this.net = null;
            this.changingLevel = null;
            this.netChanges = []; this.netChangesHead = 0;
            this.clearRemotePlayers();
            this.closeChat();
            this.resetServerRules();
            // dropped by the server: say so, and start a fresh single-player world
            this.addChat('Disconnected from the server', 0xFFFF55);
            if (this.pointerLocked) document.exitPointerLock();
            this.disconnectToNewLevel(false);
        }
    }

    // Leave the server and go to a new single-player world (the server's level isn't yours to
    // keep playing). lockMouse: capture the mouse again straight away (only after a click).
    disconnectToNewLevel(lockMouse = true) {
        this.leaveServer();
        this.generateLevel(LEVEL_SIZES.find(sz => sz.label === 'Normal'), lockMouse);
    }

    // Back to normal rules when you're not on a server
    resetServerRules() {
        this.serverLiquids = false;
        this.extraBlocks = [];
        if (this.player) { this.player.inventory = HOTBAR.slice(); this.player.selectedSlot = Math.min(this.player.selectedSlot, HOTBAR.length - 1); }
        this.frozen = false; this.blind = false; this.blindText = '';
        this.serverBuild = true; this.hideNametags = false;
    }

    // Leave the server (single player again). Called before generating or loading a level.
    leaveServer() {
        this.resetServerRules();
        const ws = this.net;
        this.net = null;
        if (ws) ws.close();
        this.clearRemotePlayers();
        this.closeChat();
    }

    addRemotePlayer(p) {
        if (p.id === this.netId || this.remotePlayers.has(p.id)) return;
        const view = this.zombieModel.create();
        this.scene.add(view.root);
        if (isSkinData(p.skin)) { view.material.map = makeSkinTexture(p.skin); view.material.needsUpdate = true; }
        const r = { id: p.id, name: String(p.name || 'Player'), owner: !!p.owner, view, tag: null,
            tagColor: Number.isInteger(p.tagColor) ? p.tagColor : p.owner ? OWNER_TAG_COLOR : 0xFFFFFF,   // their rank's colour
            pos: { x: p.x, y: p.y, z: p.z, rx: p.rx || 0, ry: p.ry || 0 },
            target: { x: p.x, y: p.y, z: p.z, rx: p.rx || 0, ry: p.ry || 0 },
            anim: { limbAmount: 0, limbPos: 0 } };
        this.remotePlayers.set(p.id, r);
    }

    removeRemotePlayer(id) {
        const r = this.remotePlayers.get(id);
        if (!r) return;
        this.scene.remove(r.view.root);
        if (r.tag) { this.scene.remove(r.tag); r.tag.material.map.dispose(); r.tag.material.dispose(); r.tag.geometry.dispose(); }
        this.remotePlayers.delete(id);
    }

    clearRemotePlayers() { for (const id of [...this.remotePlayers.keys()]) this.removeRemotePlayer(id); }

    // Each frame: send your position now and then, and move other players smoothly toward
    // where the server last said they were
    updateNetwork(now, dt) {
        // a join link: once the starting level is ready, connect (the Join server page shows progress)
        const skinReady = !this.waitForSkin || this.mySkin || now > this.skinWaitUntil;
        if (this.autoJoin && skinReady && !this.statusMessage && !this.net && !this.netPending && !this.loggedIn) {
            // guests can't join servers
            this.autoJoin = null;
            this.openMenu('join');
            this.joinMessage = 'Log in to join servers';
            this.joinHint = 'Log in on the Claudecraft website first';
        }
        if (this.autoJoin && skinReady && !this.statusMessage && !this.net && !this.netPending) {
            this.serverAddress = this.autoJoin.slice(0, SERVER_ADDRESS_MAX);
            this.autoJoin = null;
            this.joinMessage = null;
            this.openMenu('join');
            this.joinServer();
        }
        if (this.net && now - this.lastNetSend >= NET_SEND_MS) {
            this.lastNetSend = now;
            const p = this.player.position;
            this.sendNet({ t: 'move', x: p.x, y: p.y, z: p.z, rx: this.player.rotation.x, ry: this.player.rotation.y });
        }
        const follow = 1 - Math.pow(0.001, dt);       // closes most of the gap within about a second's tenth
        const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));
        for (const r of this.remotePlayers.values()) {
            const c = r.pos, tg = r.target;
            c.x += (tg.x - c.x) * follow; c.y += (tg.y - c.y) * follow; c.z += (tg.z - c.z) * follow;
            c.rx += (tg.rx - c.rx) * follow; c.ry += wrap(tg.ry - c.ry) * follow;
            this.poseHumanoid(r.view, r.anim, c.x, c.y - PLAYER_HEIGHT, c.z, c.ry, c.rx, dt);
            // name above the head, like Classic: always shown, turned to face you
            if (!r.tag && this.fontSheets) { r.tag = this.makeNametag(r.name, r.tagColor); this.scene.add(r.tag); }
            if (r.tag && this.hideNametags) { r.tag.visible = false; continue; }
            if (r.tag) {
                r.tag.position.set(c.x, c.y - PLAYER_HEIGHT + 2.3, c.z);
                r.tag.rotation.set(0, this.camera.rotation.y, 0);
                r.tag.visible = true;
            }
        }
    }

    // G: spawn a mob where the player is standing (Classic spawns it at the player's position)
    spawnZombie() {
        if (this.net) return;   // no mobs in multiplayer (they'd only exist on your screen)
        const p = this.player.position;
        const zb = new Zombie(this.level, this.zombieModel, p.x, p.y, p.z);
        this.zombies.push(zb);
        this.scene.add(zb.view.root);
    }

    // F: next render distance setting (fog and how far chunks are drawn)
    cycleRenderDistance() {
        this.renderSetting = (this.renderSetting + 1) % RENDER_DISTANCES.length;
        const rs = RENDER_DISTANCES[this.renderSetting];
        this.renderDistance = rs.dist;
        this.airFog.near = rs.fogStart;
        this.airFog.far = rs.fogEnd;
        // The closer the fog, the more the sky turns fog-coloured, so fogged terrain blends in
        this.skyColor.set(SKY_COLOR).lerp(new THREE.Color(FOG_COLOR), rs.skyFog);
        this.queueStale = true; // re-check which sections to draw, build or free
    }

    // ---- Chunk sections ----

    sectionKey(cx, cy, cz) { return cx + ',' + cy + ',' + cz; }

    // Highest non-air block in a 16x16 chunk column, so empty sky sections are never built
    chunkColumnTop(cx, cz) {
        const k = cx + ',' + cz;
        let top = this.columnTops.get(k);
        if (top !== undefined) return top;
        top = -1;
        const lv = this.level, blocks = lv.blocks, layer = lv.width * lv.height;
        for (let lx = 0; lx < CHUNK_SIZE; lx++) {
            const x = cx * CHUNK_SIZE + lx;
            if (x >= lv.width) break;
            for (let lz = 0; lz < CHUNK_SIZE; lz++) {
                const z = cz * CHUNK_SIZE + lz;
                if (z >= lv.height) break;
                const base = z * lv.width + x;
                for (let y = lv.depth - 1; y > top; y--) {
                    if (blocks[y * layer + base] !== BLOCK.AIR) { top = y; break; }
                }
            }
        }
        this.columnTops.set(k, top);
        return top;
    }

    // Horizontal distance from the player to the middle of a chunk column
    chunkDistance(cx, cz) {
        const dx = cx * CHUNK_SIZE + CHUNK_SIZE / 2 - this.player.position.x;
        const dz = cz * CHUNK_SIZE + CHUNK_SIZE / 2 - this.player.position.z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    // Apply block changes from a server, a couple of milliseconds' worth per frame
    applyNetChanges(budgetMs = NET_APPLY_MS) {
        const L = this.netChanges;
        if (!L.length) return;
        const start = performance.now();
        let h = this.netChangesHead;
        this.bulkChanges = true;               // rebuilt in the background (see updateChunks)
        try {
            while (h + 3 < L.length) {
                const x = L[h], y = L[h + 1], z = L[h + 2], b = L[h + 3];
                h += 4;
                if ([x, y, z, b].every(Number.isInteger) && b >= 0 && b <= 63 &&
                    x >= 0 && y >= 0 && z >= 0 && x < MAP_WIDTH && y < MAP_DEPTH && z < MAP_HEIGHT) this.level.setTile(x, y, z, b, true);
                if ((h & 3) === 0 && performance.now() - start > budgetMs) break;
            }
        } finally { this.bulkChanges = false; }
        if (h + 3 >= L.length) { this.netChanges = []; this.netChangesHead = 0; } else this.netChangesHead = h;
    }

    markSectionDirty(cx, cy, cz) {
        const key = this.sectionKey(cx, cy, cz);
        // Unbuilt sections are already in the build queue (or out of range), so only built
        // ones need marking
        if (this.sections.has(key)) (this.bulkChanges ? this.backgroundDirty : this.dirtySections).add(key);
    }

    queueChunkUpdate(x, y, z) {
        const lx = ((x % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const ly = ((y % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const lz = ((z % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const cx = Math.floor(x / CHUNK_SIZE), cy = Math.floor(y / CHUNK_SIZE), cz = Math.floor(z / CHUNK_SIZE);

        // A block placed above the old top of this column makes new sections non-empty
        const colKey = cx + ',' + cz;
        const top = this.columnTops.get(colKey);
        if (top !== undefined && y > top && this.level.getTile(x, y, z) !== BLOCK.AIR) {
            this.columnTops.set(colKey, y);
            this.queueStale = true;
        }

        // This section, plus neighbours that share the edited block's faces
        const xs = [cx], ys = [cy], zs = [cz];
        if (lx === 0) xs.push(cx - 1);
        if (lx === CHUNK_SIZE - 1) xs.push(cx + 1);
        if (ly === 0) ys.push(cy - 1);
        if (ly === CHUNK_SIZE - 1) ys.push(cy + 1);
        if (lz === 0) zs.push(cz - 1);
        if (lz === CHUNK_SIZE - 1) zs.push(cz + 1);
        for (const sx of xs) for (const sy of ys) for (const sz of zs) {
            if (sx === cx || sy === cy || sz === cz) {
                // only sections touching a face of the block (not diagonal-only ones)
                const diff = (sx !== cx) + (sy !== cy) + (sz !== cz);
                if (diff <= 1) this.markSectionDirty(sx, sy, sz);
            }
        }
    }

    // Shading on a column changed between y0 and y1: rebuild those sections in this column
    // and its four neighbours (their side faces use this column's light)
    queueLightUpdate(x, z, y0, y1) {
        const cy0 = Math.max(0, Math.floor(y0 / CHUNK_SIZE));
        const cy1 = Math.floor(y1 / CHUNK_SIZE);
        const cols = new Set();
        for (const [dx, dz] of [[0, 0], [-1, 0], [1, 0], [0, -1], [0, 1]]) {
            cols.add(Math.floor((x + dx) / CHUNK_SIZE) + ',' + Math.floor((z + dz) / CHUNK_SIZE));
        }
        for (const col of cols) {
            const [cx, cz] = col.split(',').map(Number);
            for (let cy = cy0; cy <= cy1; cy++) {
                const key = this.sectionKey(cx, cy, cz);
                if (this.sections.has(key)) (this.bulkChanges ? this.backgroundDirty : this.dirtySections).add(key);
            }
        }
    }

    disposeSection(sec) {
        if (!sec.group) return;
        this.scene.remove(sec.group);
        sec.group.traverse(o => { if (o.geometry) o.geometry.dispose(); });
    }

    buildSection(cx, cy, cz) {
        this.chunksUpdatedCounter++;
        const key = this.sectionKey(cx, cy, cz);
        const old = this.sections.get(key);
        if (old) this.disposeSection(old);
        const group = this.meshBuilder.buildChunkMesh(cx, cy, cz);
        if (group) {
            group.visible = this.chunkDistance(cx, cz) <= this.renderDistance;
            this.scene.add(group);
        }
        this.sections.set(key, { cx, cy, cz, group });
    }

    // Recomputes which unbuilt sections are in range (nearest last), hides sections outside
    // the render distance and frees ones far beyond it
    refreshChunkQueue() {
        for (const [key, sec] of this.sections) {
            const dist = this.chunkDistance(sec.cx, sec.cz);
            if (dist > this.renderDistance + UNLOAD_MARGIN) {
                this.disposeSection(sec);
                this.sections.delete(key);
                this.dirtySections.delete(key);
            } else if (sec.group) {
                sec.group.visible = dist <= this.renderDistance;
            }
        }

        const queue = [];
        const chunksX = Math.ceil(MAP_WIDTH / CHUNK_SIZE), chunksZ = Math.ceil(MAP_HEIGHT / CHUNK_SIZE);
        const pcx = Math.floor(this.player.position.x / CHUNK_SIZE);
        const pcz = Math.floor(this.player.position.z / CHUNK_SIZE);
        const rad = Math.ceil(this.renderDistance / CHUNK_SIZE) + 1;
        for (let cx = Math.max(0, pcx - rad); cx <= Math.min(chunksX - 1, pcx + rad); cx++) {
            for (let cz = Math.max(0, pcz - rad); cz <= Math.min(chunksZ - 1, pcz + rad); cz++) {
                const dist = this.chunkDistance(cx, cz);
                if (dist > this.renderDistance) continue;
                const topSection = Math.floor(this.chunkColumnTop(cx, cz) / CHUNK_SIZE);
                for (let cy = 0; cy <= topSection; cy++) {
                    if (!this.sections.has(this.sectionKey(cx, cy, cz))) queue.push({ cx, cy, cz, dist });
                }
            }
        }
        queue.sort((a, b) => b.dist - a.dist);
        this.buildQueue = queue;
        this.queueStale = false;
    }

    // Per-frame chunk work: rebuild edited sections first, then build new ones nearest-first
    // until the time budget runs out. maxDist limits building to nearby sections.
    updateChunks(budgetMs = CHUNK_BUILD_BUDGET_MS, maxDist = Infinity) {
        const start = performance.now();
        const pcx = Math.floor(this.player.position.x / CHUNK_SIZE);
        const pcz = Math.floor(this.player.position.z / CHUNK_SIZE);
        const pkey = pcx + ',' + pcz;
        // re-plan what to build when you move to another chunk; when it's only because something
        // grew taller (like rising lava), at most 4 times a second
        const now = performance.now();
        if (pkey !== this.lastPlayerChunk || (this.queueStale && now - (this.lastQueueRefresh || 0) > 250)) {
            this.lastPlayerChunk = pkey;
            this.lastQueueRefresh = now;
            this.refreshChunkQueue();
        }

        // Edits: always rebuild a couple straight away so block changes show instantly
        let rebuilt = 0;
        for (const key of this.dirtySections) {
            if (rebuilt >= 2 && performance.now() - start > budgetMs) break;
            this.dirtySections.delete(key);
            const sec = this.sections.get(key);
            if (sec) this.buildSection(sec.cx, sec.cy, sec.cz);
            rebuilt++;
        }

        // Big changes that aren't yours: a little each frame, nearest first
        const bgStart = performance.now();
        while (this.backgroundDirty.size && performance.now() - bgStart < Math.min(BACKGROUND_BUILD_MS, budgetMs)) {
            let best = null, bestD = Infinity;
            for (const key of this.backgroundDirty) {
                if (this.dirtySections.has(key)) { this.backgroundDirty.delete(key); continue; }   // (being rebuilt anyway)
                const sec = this.sections.get(key);
                if (!sec) { this.backgroundDirty.delete(key); continue; }
                const d = this.chunkDistance(sec.cx, sec.cz) + Math.abs(sec.cy * CHUNK_SIZE - this.player.position.y) * 0.5;
                if (d < bestD) { bestD = d; best = key; }
            }
            if (best === null) break;
            this.backgroundDirty.delete(best);
            const sec = this.sections.get(best);
            this.buildSection(sec.cx, sec.cy, sec.cz);
        }

        while (this.buildQueue.length && performance.now() - start < budgetMs) {
            const next = this.buildQueue[this.buildQueue.length - 1];
            if (next.dist > maxDist) break;
            this.buildQueue.pop();
            if (!this.sections.has(this.sectionKey(next.cx, next.cy, next.cz))) {
                this.buildSection(next.cx, next.cy, next.cz);
            }
        }
    }

    setupInput() {
        this.renderer.domElement.addEventListener('click', () => {
            if (!this.pointerLocked && !this.menu && !this.statusMessage) this.lockPointer();
        });
        document.addEventListener('pointerlockchange', () => {
            this.pointerLockChangedAt = performance.now();
            const wasLocked = this.pointerLocked;
            this.pointerLocked = document.pointerLockElement === this.renderer.domElement;
            // Some browsers send the release jump just before this event: if the camera moved in the
            // last moment before the mouse was released, undo that last movement
            if (wasLocked && !this.pointerLocked && this.lookBeforeMouse &&
                performance.now() - this.lookBeforeMouse.at < 50) {
                this.player.rotation.x = this.lookBeforeMouse.x;
                this.player.rotation.y = this.lookBeforeMouse.y;
            }
            // Losing the mouse (Esc) opens the game menu
            if (wasLocked && !this.pointerLocked) this.closeChat();
            if (wasLocked && !this.pointerLocked && !this.statusMessage && this.menu !== 'blocks') this.openMenu('main');
            if (this.pointerLocked) this.closeMenu();
        });
        document.addEventListener('mousemove', e => {
            this.mouseX = e.clientX; this.mouseY = e.clientY;
            // Only turn the camera while the mouse is really captured. Skip the jump browsers send
            // when the mouse is captured/released, and any movement too big to be real.
            if (!this.pointerLocked || document.pointerLockElement !== this.renderer.domElement || this.chatOpen) return;
            if (performance.now() - (this.pointerLockChangedAt || 0) < MOUSE_SETTLE_MS) return;
            if (Math.abs(e.movementX) > MOUSE_MAX_JUMP || Math.abs(e.movementY) > MOUSE_MAX_JUMP) return;
            // Remember the look direction before this movement, in case it was the release jump
            this.lookBeforeMouse = { x: this.player.rotation.x, y: this.player.rotation.y, at: performance.now() };
            this.player.rotation.y -= e.movementX * 0.002;
            this.player.rotation.x -= e.movementY * 0.002;
            this.player.rotation.x = Math.max(-1.57, Math.min(1.57, this.player.rotation.x));
        });
        document.addEventListener('mousedown', e => {
            if (!this.player) return;   // still generating the starting level
            if (this.menu && !this.pointerLocked) {
                if (e.button === 0) this.menuClick(e.clientX, e.clientY);
                return;
            }
            if (!this.pointerLocked || this.chatOpen) return;
            if (e.button === 2) this.buildMode = !this.buildMode;
            else if (e.button === 0) { if (this.buildMode) this.placeBlock(); else this.breakBlock(); }
        });
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('wheel', e => {
            if (!this.player) { e.preventDefault(); return; }   // still generating the starting level
            e.preventDefault();
            if (this.menu) return;
            const dir = e.deltaY > 0 ? 1 : -1;
            this.player.cycleSlot(dir);
            this.blockPreview.setType(this.player.getSelectedBlock());
        }, { passive: false });
        document.addEventListener('keydown', e => {
            // F5: third person (stop the browser from reloading the page)
            if (e.code === 'F5') {
                e.preventDefault();
                if (this.player && !this.menu) this.thirdPerson = !this.thirdPerson;
                return;
            }
            if (!this.player) return;   // still generating the starting level
            if (this.chatOpen) { this.handleChatKey(e); return; }
            if (e.code === 'KeyT' && this.net && !this.menu && !this.statusMessage) {
                e.preventDefault();      // so the T itself isn't typed
                if (this.serverHasChat) this.openChat();
                else this.addChat(OLD_SERVER_WARNING, 0xFFFF55);
                return;
            }
            if (this.menu === 'join' && e.code !== 'Escape') { this.handleAddressKey(e); return; }
            if (this.menu === 'save' && e.code !== 'Escape') { this.handleSaveKey(e); return; }
            if (this.menu === 'blocks') {
                // B or Esc closes the block menu
                if (e.code === 'KeyB' || (e.code === 'Escape' && performance.now() - this.menuOpenedAt > 300)) this.backToGame();
                return;
            }
            if (this.menu) {
                // Esc in a sub-menu goes back; in the main menu it returns to the game
                // (ignore the Esc press that just opened the menu)
                if (e.code === 'Escape' && performance.now() - this.menuOpenedAt > 300) {
                    if (this.menu === 'main') this.backToGame();
                    else if (this.menu === 'delete' || this.menu === 'join' || this.menu === 'signin') this.openMenu('load');
                    else if (this.menu === 'save') this.openMenu('main');
                    else this.openMenu('main');
                }
                return;
            }
            if (e.code === 'KeyF') this.cycleRenderDistance();
            if (e.code === 'KeyG') this.spawnZombie();
            if (e.code === 'KeyR') this.respawn();
            if (e.code === 'KeyB') this.openBlockMenu();
            if (e.code === 'KeyY') this.setSpawnHere();
            if (MOVE_KEYS[e.code]) this.input[MOVE_KEYS[e.code]] = true;
            // 1-9 for the usual blocks; 0 and - for water and lava where a server allows them
            const digit = e.code.match(/^Digit([0-9])$/) || (e.code === 'Minus' ? [null, '-'] : null);
            if (digit) {
                const slot = digit[1] === '0' ? 9 : digit[1] === '-' ? 10 : Number(digit[1]) - 1;
                if (slot < this.player.inventory.length) {
                    this.player.selectedSlot = slot;
                    this.blockPreview.setType(this.player.getSelectedBlock());
                }
            }
        });
        // Ctrl+V: paste into the server address box or the chat line
        document.addEventListener('paste', e => {
            const text = ((e.clipboardData && e.clipboardData.getData('text')) || '').replace(/[^\x20-\x7E]/g, '').trim();
            if (!text) return;
            if (this.menu === 'save') {
                const max = this.saveField === 'name' ? SAVE_NAME_MAX : SAVE_DESC_MAX;
                if (this.saveField === 'name') this.saveName = (this.saveName + text).slice(0, max);
                else this.saveDesc = (this.saveDesc + text).slice(0, max);
            } else if (this.menu === 'join') {
                this.serverAddress = (this.serverAddress + text).slice(0, SERVER_ADDRESS_MAX);
                this.joinMessage = null;
            } else if (this.chatOpen) {
                this.chatInput = (this.chatInput + text).slice(0, CHAT_MAX);
            } else return;
            e.preventDefault();
        });
        document.addEventListener('keyup', e => {
            if (MOVE_KEYS[e.code]) this.input[MOVE_KEYS[e.code]] = false;
        });
        window.addEventListener('resize', () => {
            this.camera.aspect = innerWidth / innerHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(innerWidth, innerHeight);
            this.hudCanvas.width = innerWidth;
            this.hudCanvas.height = innerHeight;
            this.hudCtx.imageSmoothingEnabled = false;
        });
    }

    breakBlock() {
        if (this.net && this.serverBuild === false) return;   // the server has building turned off
        const hit = this.raycaster.cast(this.player.getEyePosition(), this.player.getLookDirection(), REACH_DISTANCE);
        if (!hit.hit || hit.blockPos.y <= 0) return;
        const { x, y, z } = hit.blockPos;
        const type = this.level.getTile(x, y, z);
        if (type === BLOCK.AIR || type === BLOCK.WATER || type === BLOCK.LAVA || type === BLOCK.BEDROCK) return;
        this.particles.spawn(x, y, z, type);
        this.level.setTile(x, y, z, BLOCK.AIR);
        this.sendNet({ t: 'set', x, y, z, b: BLOCK.AIR });
    }

    // Is anyone (you, another player or a mob) in the way of a block at (x, y, z)?
    someoneInBlock(x, y, z) {
        const hw = PLAYER_WIDTH / 2;
        const overlaps = (px, eyeY, pz) => x + 1 > px - hw && x < px + hw && y + 1 > eyeY - PLAYER_HEIGHT && y < eyeY + 0.1 && z + 1 > pz - hw && z < pz + hw;
        const me = this.player.position;
        if (overlaps(me.x, me.y, me.z)) return true;
        for (const r of this.remotePlayers.values()) {
            // where they are on screen and where the server last said they are
            if (overlaps(r.pos.x, r.pos.y, r.pos.z) || overlaps(r.target.x, r.target.y, r.target.z)) return true;
        }
        for (const zb of this.zombies) {
            const b = zb.bb;
            if (x + 1 > b[0] && x < b[3] && y + 1 > b[1] && y < b[4] && z + 1 > b[2] && z < b[5]) return true;
        }
        return false;
    }

    placeBlock() {
        if (this.net && this.serverBuild === false) return;
        const hit = this.raycaster.cast(this.player.getEyePosition(), this.player.getLookDirection(), REACH_DISTANCE);
        if (!hit.hit) return;
        const { x, y, z } = hit.prevPos;
        if (x < 0 || y < 0 || z < 0 || x >= MAP_WIDTH || y >= MAP_DEPTH || z >= MAP_HEIGHT) return;
        if (y > BUILD_LIMIT_Y) return; // height limit
        const id = this.player.getSelectedBlock();
        if (id === BLOCK.BEDROCK) return;
        const liquid = id === BLOCK.WATER || id === BLOCK.LAVA;
        // only blocks you have: the usual nine, plus any extras the server gives you
        if (!this.player.inventory.includes(id)) return;
        // solid blocks never go inside anyone (saplings and liquids aren't solid)
        if (id !== BLOCK.SAPLING && !liquid && this.someoneInBlock(x, y, z)) return;
        this.level.setTile(x, y, z, id);
        this.sendNet({ t: 'set', x, y, z, b: id });
    }

    scheduleFrame() {
        if (UNCAPPED_FPS && !document.hidden) this.frameChannel.port2.postMessage(0);
        else requestAnimationFrame(() => this.loop(performance.now()));
    }

    loop(now) {
        this.scheduleFrame();
        let dtMs = now - this.lastTime;
        if (dtMs < 0) dtMs = 0;
        if (dtMs > 250) dtMs = 250;

        const dt = dtMs / 1000;
        this.lastTime = now;

        this.fpsFrames++;
        this.fpsTimeAccum += dtMs;
        if (this.fpsTimeAccum >= 500) {
            this.displayFps = Math.round((this.fpsFrames * 1000) / this.fpsTimeAccum);
            this.fpsFrames = 0;
            this.displayChunkUpdates = this.chunksUpdatedCounter;
            this.chunksUpdatedCounter = 0;
            this.fpsTimeAccum = 0;
        }

        // No level yet (the starting level is still generating): just draw the loading screen
        if (!this.level || !this.player) {
            this.renderer.setViewport(0, 0, innerWidth, innerHeight);
            this.renderer.clear();
            this.renderHUD();
            return;
        }

        if (this.net) this.applyNetChanges();
        this.tickAccumulator += dtMs;
        let ticksRun = 0;
        while (this.tickAccumulator >= MS_PER_TICK && ticksRun < 5) {
            // (on a server, the server runs flowing liquids and grass, and sends the changes)
            if (!this.net) {
                this.bulkChanges = true;           // flowing water etc.: rebuilt in the background
                try { this.level.tick(now); } finally { this.bulkChanges = false; }
            }
            for (const zb of this.zombies) zb.tick();
            this.tickAccumulator -= MS_PER_TICK;
            ticksRun++;
        }
        if (this.tickAccumulator > MS_PER_TICK * 5) this.tickAccumulator = 0;

        this.particles.update(dt, this.camera);

        // Mobs: drop removed ones, then place and animate the rest between ticks
        if (this.zombies.length) {
            this.zombies = this.zombies.filter(zb => {
                if (zb.removed) this.scene.remove(zb.view.root);
                return !zb.removed;
            });
            const a = Math.min(1, this.tickAccumulator / MS_PER_TICK);
            const nowSeconds = now / 1000;
            for (const zb of this.zombies) {
                zb.updateView(this.zombieModel, a, nowSeconds);
                // Non-smooth lighting: the mob takes the light of the one block at its chest -
                // sky shadow, water or lava - with no blending between blocks
                const bx = Math.floor(zb.x), bz = Math.floor(zb.z), by = Math.floor(zb.y + 1.2);
                const sky = this.level.isLit(bx, by, bz) ? 1.0 : SHADOW_SHADE;
                const v = shade(sky * liquidDarkness(this.level, bx, by, bz));
                zb.view.material.color.setRGB(v, v, v);
            }
        }
        this.updateNetwork(now, dt);

        // Clouds drift slowly across the sky
        if (this.cloudTex) {
            const tileBlocks = 256 * CLOUD_BLOCKS_PER_PIXEL;
            this.cloudTex.offset.x = ((now / 1000) * CLOUD_SPEED / tileBlocks) % 1;
        }

        this.updateChunks();

        this.player.update(dt, this.frozen ? {} : this.input);
        const eye = this.player.getEyePosition();
        this.camera.position.copy(eye);
        this.camera.rotation.order = 'YXZ';
        this.camera.rotation.y = this.player.rotation.y;
        this.camera.rotation.x = this.player.rotation.x;
        this.updateThirdPerson(eye, now);

        // Fog follows where the camera is (behind you in third person)
        const cam = this.camera.position;
        const eyeBlock = this.level.getTile(Math.floor(cam.x), Math.floor(cam.y), Math.floor(cam.z));
        if (eyeBlock === BLOCK.WATER) {
            this.scene.fog = this.liquidFog;
            this.liquidFog.color.setHex(0x050533);
            this.liquidFog.density = 0.15;
            this.scene.background.setHex(0x050533);
        } else if (eyeBlock === BLOCK.LAVA) {
            this.scene.fog = this.liquidFog;
            this.liquidFog.color.setHex(0xb82600);
            this.liquidFog.density = 2.0;
            this.scene.background.setHex(0xb82600);
        } else {
            this.scene.fog = this.airFog;
            this.scene.background.copy(this.skyColor);
        }

        this.breakHighlight.visible = false;
        this.placeHighlight.visible = false;
        this.selectOutline.visible = false;
        const hit = this.raycaster.cast(eye, this.player.getLookDirection(), REACH_DISTANCE);
        if (hit.hit) {
            this.selectOutline.visible = true;
            this.selectOutline.position.set(hit.blockPos.x + 0.5, hit.blockPos.y + 0.5, hit.blockPos.z + 0.5);
            const pulse = 0.3 + 0.3 * Math.abs(Math.sin(now * 0.002));
            if (!this.buildMode) {
                this.breakHighlight.visible = true;
                this.breakHighlight.position.set(hit.blockPos.x + 0.5, hit.blockPos.y + 0.5, hit.blockPos.z + 0.5);
                this.breakHighlight.material.opacity = pulse;
            } else {
                this.placeHighlight.visible = true;
                this.placeHighlight.position.set(hit.prevPos.x + 0.5, hit.prevPos.y + 0.5, hit.prevPos.z + 0.5);
                this.placeHighlight.material.opacity = pulse;
                this.placeHighlight.geometry = this.ghostGeos[this.player.getSelectedBlock()];
            }
        }

        // --- A level thumbnail asked for: draw just the world (no selection box, outline,
        // placement ghost or nametags), copy it, then put those back for the normal frame ---
        if (this.thumbRequested) {
            this.thumbRequested = false;
            const gui = [this.breakHighlight, this.placeHighlight, this.selectOutline, this.nametag,
                ...[...this.remotePlayers.values()].map(r => r.tag)].filter(Boolean);
            const shown = gui.map(o => o.visible);
            for (const o of gui) o.visible = false;
            this.renderer.setViewport(0, 0, innerWidth, innerHeight);
            this.renderer.clear();
            this.renderer.render(this.scene, this.camera);
            this.saveThumb = this.copyThumbnail();
            gui.forEach((o, i) => { o.visible = shown[i]; });
        }

        // --- Render Main View ---
        this.renderer.setViewport(0, 0, innerWidth, innerHeight);
        this.renderer.clear();
        this.renderer.render(this.scene, this.camera);

        // --- Render Block Preview Native UI Overlay ---
        this.blockPreview.setType(this.player.getSelectedBlock());
        this.renderer.clearDepth();
        const pSize = this.blockPreview.size;
        const pMargin = this.blockPreview.margin;
        this.renderer.setViewport(innerWidth - pSize - pMargin, innerHeight - pSize - pMargin, pSize, pSize);
        this.renderer.render(this.blockPreview.scene, this.blockPreview.camera);

        this.renderHUD();
    }
}

new Game();
