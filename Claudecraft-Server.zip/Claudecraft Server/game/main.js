// Claudecraft 0.32 (comments taken out to make it smaller; main.source.js has them)
const THREE = require('three');
const VERSION = "0.32";
const CLASSIC_0011A = typeof location !== 'undefined' && ['0.0.12a', '0.0.11a'].includes(new URLSearchParams(location.search).get('version'));
const SURVIVAL_024 = typeof location !== 'undefined' && new URLSearchParams(location.search).get('version') === '0.24_st';
const SANDBOX = typeof location !== 'undefined' && new URLSearchParams(location.search).get('version') === 'sandbox';
const CLASSIC_019 = typeof location !== 'undefined' && new URLSearchParams(location.search).get('version') === '0.0.19a';
const OLD_UI = CLASSIC_0011A || CLASSIC_019;
const TERRAIN_FILE = CLASSIC_0011A ? './terrain12.png' : SURVIVAL_024 ? './terrainsurvival.png' : CLASSIC_019 ? './terrain19.png' : './terrain30.png';
const TERRAIN_PATHS = CLASSIC_0011A || SURVIVAL_024 ? [TERRAIN_FILE]
    : CLASSIC_019 ? [TERRAIN_FILE, 'https://claudecraft.neocities.org/minecraft/terrain19.png']
    : [TERRAIN_FILE, './terrain1.png', './terrain.png',
    'https://claudecraft.neocities.org/minecraft/terrain30.png'];
const CHUNK_SIZE = 16;
let MAP_WIDTH = 256;
let MAP_HEIGHT = 256;
let MAP_DEPTH = 256;
const LEVEL_SIZES = [
    { label: 'Small', w: 128, h: 128, d: 128 },
    { label: 'Normal', w: 256, h: 256, d: 256 },
    { label: 'Huge', w: 512, h: 512, d: 512 }
];
const LEVEL_FILE_MAGIC = 0x4D435243;
const LEVEL_FILE_VERSION = 2;
const LEVEL_SLOTS = 5;
const SAVE_NAME_MAX = 32;
const SAVE_DESC_MAX = 100;
const SERVER_ADDRESS_MAX = 80;
const DEFAULT_PORT = 25565;
const OLD_SERVER_WARNING = 'This server is out of date: update and restart server.js to chat';
const CHAT_MAX = 64;
const CHAT_SHOW_SECONDS = 10;
const CHAT_WIDTH = 320;
const CHAT_HISTORY = 100;
const CHAT_LINES_OPEN = 20;
const NET_SEND_MS = 50;
const LEVEL_NAME_MAX = 24;
const slotKey = (kind, i) => (CLASSIC_0011A ? 'c12-' : '') + kind + '-' + i;
const C12_LEVEL_TAG = '[0.0.12a_03] ';
const LevelStore = {
    db: null,
    open() {
        if (this.db) return Promise.resolve(this.db);
        return new Promise((resolve, reject) => {
            const req = indexedDB.open('mc-recreation-levels', 1);
            req.onupgradeneeded = () => req.result.createObjectStore('levels');
            req.onsuccess = () => { this.db = req.result; resolve(this.db); };
            req.onerror = () => reject(req.error);
        });
    },
    async run(mode, action) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction('levels', mode);
            const req = action(tx.objectStore('levels'));
            tx.oncomplete = () => resolve(req.result === undefined ? null : req.result);
            tx.onerror = () => reject(tx.error);
        });
    },
    get(key) { return this.run('readonly', st => st.get(key)); },
    put(key, value) { return this.run('readwrite', st => st.put(value, key)); },
    remove(key) { return this.run('readwrite', st => st.delete(key)); },
    async slotNames() {
        const names = [];
        for (let i = 0; i < LEVEL_SLOTS; i++) {
            const meta = await this.get(slotKey('meta', i));
            names.push(meta ? meta.name : null);
        }
        return names;
    }
};
async function encodeLevel(level, player) {
    const header = new Int32Array([LEVEL_FILE_MAGIC, LEVEL_FILE_VERSION, level.width, level.height, level.depth]);
    const p = player
        ? [player.position.x, player.position.y, player.position.z, player.rotation.x, player.rotation.y]
        : [NaN, NaN, NaN, 0, 0];
    const playerData = new Float32Array(p);
    const blob = new Blob([header, playerData, level.blocks]);
    if (typeof CompressionStream !== 'undefined') {
        try {
            return await new Response(blob.stream().pipeThrough(new CompressionStream('gzip'))).blob();
        } catch (err) { console.warn('Compression failed, saving uncompressed', err); }
    }
    return blob;
}
const LVL_MAGIC = 1874;
let classicToBlockTable = null;
function classicToBlock() {
    if (classicToBlockTable) return classicToBlockTable;
    const B = BLOCK, m = new Uint8Array(256).fill(B.ROCK);
    const list = [B.AIR, B.ROCK, B.GRASS, B.DIRT, B.COBBLESTONE, B.PLANKS, B.SAPLING, B.BEDROCK, B.WATER, B.WATER,
        B.LAVA, B.LAVA, B.SAND, B.GRAVEL, B.GOLD_ORE, B.IRON_ORE, B.COAL_ORE, B.LOG, B.LEAVES, B.SPONGE, B.GLASS];
    list.forEach((b, i) => { m[i] = b; });
    for (let i = 0; i < 16; i++) m[21 + i] = B.CLOTH_RED + i;
    [B.DANDELION, B.ROSE, B.BROWN_MUSHROOM, B.RED_MUSHROOM, B.GOLD_BLOCK, B.IRON_BLOCK, B.DOUBLE_SLAB, B.SLAB,
        B.BRICK, B.TNT, B.BOOKSHELF, B.MOSSY_COBBLE, B.OBSIDIAN].forEach((b, i) => { m[37 + i] = b; });
    const cpe = [44, 39, 12, 0, 10, 33, 25, 3, 29, 28, 20, 42, 49, 36, 5, 1];
    cpe.forEach((c, i) => { m[50 + i] = m[c]; });
    return (classicToBlockTable = m);
}
function decodeLvl(buf) {
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    const u16 = o => dv.getUint16(o, true);
    if (buf.length < 18 || u16(0) !== LVL_MAGIC) return null;
    const w = u16(2), len = u16(4), h = u16(6);
    const n = w * len * h;
    if (!w || !len || !h || buf.length < 18 + n) throw new Error('This .lvl file is cut short');
    const blocks = new Uint8Array(n), src = buf.subarray(18, 18 + n), table = classicToBlock();
    for (let i = 0; i < n; i++) blocks[i] = table[src[i]];
    const level = new Level(w, len, h, blocks);
    const sx = u16(8), sz = u16(10), sy = u16(12), yaw = buf[14], pitch = buf[15];
    const p = pitch > 127 ? pitch - 256 : pitch;
    level.savedPlayer = { x: sx + 0.5, y: sy + PLAYER_HEIGHT + 0.01, z: sz + 0.5, rotX: -p / 256 * Math.PI * 2, rotY: -yaw / 256 * Math.PI * 2 };
    return level;
}
async function decodeLevel(blob) {
    let buf = new Uint8Array(await blob.arrayBuffer());
    if (buf[0] === 0x1f && buf[1] === 0x8b) {
        const ds = new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'));
        buf = new Uint8Array(await new Response(ds).arrayBuffer());
    }
    const lvl = decodeLvl(buf);
    if (lvl) return lvl;
    const header = new Int32Array(buf.buffer.slice(buf.byteOffset, buf.byteOffset + 20));
    const [magic, version, w, h, d] = header;
    if (magic !== LEVEL_FILE_MAGIC || (version !== 1 && version !== 2)) throw new Error('Not a level');
    const dataStart = version === 2 ? 40 : 20;
    if (buf.length !== dataStart + w * h * d) throw new Error('Level data is the wrong size');
    const level = new Level(w, h, d, buf.slice(dataStart));
    if (version === 2) {
        const p = new Float32Array(buf.buffer.slice(buf.byteOffset + 20, buf.byteOffset + 40));
        if (p.every(Number.isFinite)) level.savedPlayer = { x: p[0], y: p[1], z: p[2], rotX: p[3], rotY: p[4] };
    }
    return level;
}
const JUMP_FORCE = 8.4;
const SANDBOX_PHYS = { speed: 1, jump: 1, gravity: 1 };
const MC_GRAVITY = 0.08;
const CLASSIC_JUMP = 0.5;
const MC_AIR_DRAG = 0.98;
const PLAYER_HEIGHT = 1.62;
const PLAYER_WIDTH = 0.6;
const PLAYER_SPEED = 4.317;
const NOTCH_PHYSICS = CLASSIC_0011A || typeof location !== 'undefined';
const REACH_DISTANCE = SURVIVAL_024 ? 4 : 5;
const MAX_MOVE_STEP = 0.45;
const THIRD_PERSON_DISTANCE = 2.5;
const LIMB_SPEED = 0.8;
const OWNER_TAG_COLOR = 0xFFFF55;
const NAMETAG_PIXEL = 0.04;
const HEAD_TURN_LIMIT = 50 * Math.PI / 180;
const BODY_TURN_EASE = 0.25;
const LIMB_EASE = 0.4;
const MOUSE_MAX_JUMP = 400;
const MOUSE_SETTLE_MS = 150;
const SWIM_TICK = 1 / 20;
const SWIM_UP = 0.04;
const SWIM_ACCEL = 0.025;
const WATER_DRAG = 0.8;
const WATER_SINK = 0.02;
const SWIM_AIR_ACCEL = 0.02;
const SWIM_AIR_DRAG = 0.91;
const SWIM_AIR_GRAVITY = 0.08;
const SWIM_CLIMB = 0.3;
const SWIM_CLIMB_CLEARANCE = 2.2;
const LAVA_DRAG = 0.5;
const LAVA_ACCEL = 0.02;
const SWIM_BOB_HEIGHT = 1.15;
const SWIM_BUOYANCY = 0.06;
const SWIM_BOB_DAMP = 0.97;
const SWIM_KICK = 0.04;
const SWIM_FLOAT_LINE = 0.4;
const TICK_RATE = 20;
const MS_PER_TICK = 1000 / TICK_RATE;
const RENDER_DISTANCES = [
    { name: 'Far', dist: 512, fogStart: 64, fogEnd: 512, skyFog: 0.0 },
    { name: 'Normal', dist: 224, fogStart: 24, fogEnd: 224, skyFog: 1.0 },
    { name: 'Short', dist: 96, fogStart: 6, fogEnd: 96, skyFog: 1.0 },
    { name: 'Tiny', dist: 40, fogStart: 0, fogEnd: 40, skyFog: 1.0 }
];
if (typeof location !== 'undefined' && !new URLSearchParams(location.search).get('version') || SURVIVAL_024 || SANDBOX || CLASSIC_019) {
    RENDER_DISTANCES.forEach((rs, i) => {
        const end = 512 >> (i * 2), f = Math.pow(1 / (4 - i), 0.25);
        rs.fogStart = 0; rs.fogEnd = end; rs.dist = Math.max(end + 16, 32);
        rs.fogColor = new THREE.Color().setRGB((CLASSIC_019 ? 0.5 : 0.6) * (1 - f) + f, 0.8 * (1 - f) + f, 1 * (1 - f) + f, THREE.SRGBColorSpace).getHex();
        rs.skyFog = 1;
    });
}
const FOG_023 = !!RENDER_DISTANCES[0].fogColor;
if (THREE.ShaderChunk && THREE.ShaderChunk.fog_fragment)
    THREE.ShaderChunk.fog_fragment = THREE.ShaderChunk.fog_fragment.replace('smoothstep( fogNear, fogFar, vFogDepth )', 'clamp( ( vFogDepth - fogNear ) / ( fogFar - fogNear ), 0.0, 1.0 )');
const UNLOAD_MARGIN = 64;
const CHUNK_BUILD_BUDGET_MS = 4;
const FOG_COLOR = 0xEAF4FF;
const SKY_COLOR = CLASSIC_0011A || SURVIVAL_024 || CLASSIC_019 ? 0x80CCFF : 0x99CCFF;
const UNCAPPED_FPS = true;
const FRAME_LATE_MS = 1;
const HITCH_PAUSE_MS = 2000;
const BACKGROUND_BUILD_MS = 2;
const NET_APPLY_MS = 1.5;
function shade(v) { return Math.pow(v, 2.2); }
const FACE_SHADE = { top: 1.0, northSouth: 0.8, eastWest: 0.6, bottom: 0.5 };
let SHADOW_SHADE = 0.6;
const WATER_DARKEN = 0.65;
const LAVA_DARKEN = 0.55;
const CLOUD_HEIGHT_ABOVE_WATER = 34;
const CLOUD_BLOCKS_PER_PIXEL = 8;
const CLOUD_SPEED = 0.6;
const WATER_UV = [14, 0];
const LAVA_UV = [14, 1];
const BEDROCK_UV = [1, 1];
const SEA_LEVEL = 32;
const BUILD_LIMIT_Y = Math.floor(SEA_LEVEL + CLOUD_HEIGHT_ABOVE_WATER - PLAYER_HEIGHT) - 1;
const CLOUD_Y = BUILD_LIMIT_Y + 1 + PLAYER_HEIGHT;
const WATER_FRACTION = 0.30;
const MIN_LAKE_SIZE = 16;
const PLATEAU_FLAT_RADIUS = 2;
const PLATEAU_MIN_SIZE = 60;
const PLATEAU_MAX_SIZE = 3000;
const PLATEAU_EDGE_SPREAD = 3;
const PLATEAU_CHANCE = 0.25;
const GRAVEL_FLOOR_COVERAGE = 0.2;
const CLIFF_SMOOTHING = 4;
const TERRAIN_MAX = 5;
const BEACH_WIDTH = 4;
const MIN_ISLAND_SIZE = 12;
const BEACH_MAX_ABOVE_WATER = 1;
const MAX_WATER_DEPTH = 5;
const CLIFF_STEP = 3;
const CLIFF_LEVELS = [0.0, 0.4, 0.75];
const SMALL_CLIFF_STEP = 2;
const SMALL_CLIFF_LEVELS = [0.05, 0.5];
const CLIFF_SHORE_DIST = 5;
const BEACH_COVERAGE = 0.5;
const SHELF_WIDTH = 8;
const GRAVEL_MAX_HOLE = 30;
const BLOCK = {
    AIR: 0,
    ROCK: 1,
    GRASS: 2,
    DIRT: 3,
    COBBLESTONE: 4,
    PLANKS: 5,
    SAPLING: 6,
    WATER: 7,
    BEDROCK: 8,
    LAVA: 9,
    SAND: 10,
    GRAVEL: 11,
    LOG: 12,
    LEAVES: 13,
    COAL_ORE: 14,
    IRON_ORE: 15,
    GOLD_ORE: 16,
    BARRIER: 17,
    DANDELION: 18,
    ROSE: 19,
    BROWN_MUSHROOM: 20,
    RED_MUSHROOM: 21,
    SPONGE: 22, GLASS: 23,
    CLOTH_RED: 24, CLOTH_ORANGE: 25, CLOTH_YELLOW: 26, CLOTH_LIME: 27, CLOTH_GREEN: 28, CLOTH_AQUA_GREEN: 29, CLOTH_CYAN: 30, CLOTH_BLUE: 31,
    CLOTH_PURPLE: 32, CLOTH_INDIGO: 33, CLOTH_VIOLET: 34, CLOTH_MAGENTA: 35, CLOTH_PINK: 36, CLOTH_BLACK: 37, CLOTH_GRAY: 38, CLOTH_WHITE: 39,
    GOLD_BLOCK: 40,
    IRON_BLOCK: 41, DOUBLE_SLAB: 42, SLAB: 43, BRICK: 44, TNT: 45, BOOKSHELF: 46, MOSSY_COBBLE: 47, OBSIDIAN: 48
};
const CLOTH_BLOCKS = [BLOCK.CLOTH_RED, BLOCK.CLOTH_ORANGE, BLOCK.CLOTH_YELLOW, BLOCK.CLOTH_LIME, BLOCK.CLOTH_GREEN, BLOCK.CLOTH_AQUA_GREEN,
    BLOCK.CLOTH_CYAN, BLOCK.CLOTH_BLUE, BLOCK.CLOTH_PURPLE, BLOCK.CLOTH_INDIGO, BLOCK.CLOTH_VIOLET, BLOCK.CLOTH_MAGENTA, BLOCK.CLOTH_PINK,
    BLOCK.CLOTH_BLACK, BLOCK.CLOTH_GRAY, BLOCK.CLOTH_WHITE];
const BLOCK_UVS = {
    [BLOCK.ROCK]: [1, 0],
    [BLOCK.DIRT]: [2, 0],
    [BLOCK.COBBLESTONE]: [0, 1],
    [BLOCK.PLANKS]: [4, 0],
    [BLOCK.SAPLING]: [15, 0],
    [BLOCK.DANDELION]: [13, 0],
    [BLOCK.ROSE]: [12, 0],
    [BLOCK.BROWN_MUSHROOM]: [13, 1],
    [BLOCK.RED_MUSHROOM]: [12, 1],
    [BLOCK.SPONGE]: [0, 3],
    [BLOCK.GLASS]: [1, 3],
    [BLOCK.GOLD_BLOCK]: [8, 2],
    [BLOCK.IRON_BLOCK]: [7, 2],
    [BLOCK.DOUBLE_SLAB]: [5, 0], [BLOCK.SLAB]: [5, 0],
    [BLOCK.BRICK]: [7, 0], [BLOCK.TNT]: [8, 0], [BLOCK.BOOKSHELF]: [3, 2],
    [BLOCK.MOSSY_COBBLE]: [4, 2], [BLOCK.OBSIDIAN]: [5, 2],
    [BLOCK.WATER]: WATER_UV,
    [BLOCK.BEDROCK]: BEDROCK_UV,
    [BLOCK.LAVA]: LAVA_UV,
    [BLOCK.SAND]: [2, 1],
    [BLOCK.GRAVEL]: [3, 1],
    [BLOCK.LOG]: [4, 1],
    [BLOCK.LEAVES]: [6, 1],
    [BLOCK.GOLD_ORE]: [0, 2],
    [BLOCK.IRON_ORE]: [1, 2],
    [BLOCK.COAL_ORE]: [2, 2]
};
function liquidDarkness(level, x, y, z) {
    const t = level.getTile(x, y, z);
    if (t === BLOCK.LAVA) return LAVA_DARKEN;
    if (t === BLOCK.WATER) return WATER_DARKEN;
    return 1;
}
const LOG_TOP_UV = [5, 1];
for (let i = 0; i < 16; i++) BLOCK_UVS[BLOCK.CLOTH_RED + i] = [i, 4];
function faceUV(type, ny) {
    if (type === BLOCK.GOLD_BLOCK || type === BLOCK.IRON_BLOCK) { const [c, r] = BLOCK_UVS[type]; return ny === 1 ? [c, r - 1] : ny === -1 ? [c, r + 1] : [c, r]; }
    if (type === BLOCK.SLAB || type === BLOCK.DOUBLE_SLAB) return ny !== 0 ? [6, 0] : [5, 0];
    if (type === BLOCK.TNT) return ny === 1 ? [9, 0] : ny === -1 ? [10, 0] : [8, 0];
    if (type === BLOCK.BOOKSHELF) return ny !== 0 ? [4, 0] : [3, 2];
    if (type === BLOCK.GRASS) return ny === 1 ? [0, 0] : ny === -1 ? [2, 0] : [3, 0];
    if (type === BLOCK.LOG) return ny !== 0 ? LOG_TOP_UV : BLOCK_UVS[BLOCK.LOG];
    return BLOCK_UVS[type] || [2, 0];
}
const SETTING_KEYS = ['claudecraft-music', 'claudecraft-sound', 'claudecraft-invert', 'claudecraft-showfps',
    'claudecraft-bobbing', 'claudecraft-maxfps', 'claudecraft-render'];
function storeSetting(key, value) {
    try { localStorage.setItem(key, value); } catch {  }
    if (typeof window !== 'undefined' && window.parent !== window) window.parent.postMessage({ type: 'claudecraft-setting', key, value }, '*');
}
function loadImageAny(paths, onload) {
    const im = new Image();
    let i = 0;
    const go = src => { im.crossOrigin = /^https?:/.test(src) ? 'anonymous' : null; im.src = src; };
    im.onerror = () => { if (++i < paths.length) go(paths[i]); else console.warn('Couldn\'t find ' + paths[0]); };
    if (onload) im.onload = onload;
    go(paths[0]);
    return im;
}
const GUI_BUILT_IN = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAABqCAYAAAD5jB57AAA440lEQVR42u19S88kyXXdyYh8VFZ939fTPZ4RSXBMjGl4I/0JLwjYgDf2X/DCSxmCZcmEFob/gcC9AAk2CHAjQAsDMiGZEkDLetGmQRjwgOSYoEhRw+np7q/rke/0IvJEnryV9fWQnJHMQSUwmO7qqsyIG/dx7rk3IhMAI67X9frkXclHcZMUAL7xjW8AAL7zne8AAH70ox8BAD71qU/FP1+v6/XzcL3zzjv40pe+9JHdL6Vh/N7v/V78cLvd4ng8AgCyLENVVfDeo+/7xf+32y3ato3//vrrr+Pp06d4++238e6778bv8SrLEqfTCQDiv/F+vO7u7nB/fw8A+MxnPoMf//jH+OxnP4t33303jqdtW5Rlia7rAABt2yLLMmRZhrqu0fd9/J5edny87DgBnI2rrmsURbG4L+/3+c9/Hu+8885CNjqfZ8+eLT6z3+E9L41Px8Lv6LU2fq7jOI5488038d3vfnf1O/ztmrzsdWl8rxoH153P6PseeZ4jz3OcTie89dZbeP/996Nu2HUoigIAok6qzOz43nnnnY/U4FKdxG/91m999aEvFwVQ10CaAd2KLH/5l3/5CxRQ3/f4yle+8tVyC5yOP8GApns7B3zxi7/xBRXCl7/85a86BwzD8ru87L8N/fx354Bf//UvfkEX4ctf/vLF+eq9Ll1f/OIXv/D06VMMw4DNZoPf+Z3fuXi/3U2Qw6V7cnwPzdc5oNwCh/1ludnxffvb38anPvUpeO/P7sf1/LAy4HzX5Ge/e0lH9N//7a9+8Qvvvvsu8jxH13Vn67G2BkUB9MNybXV8H3VESgmpmqYBAPzCp4GbTYBv94cRd7sEGBMUeYa6aYFkBMYEz/YDHt8uYd5ut8P3v/99AMBmswEAvP3ZAnXbXBzAMI4o0hTDMOLFqcfNJkHdA9vUIU3Ts++//blzaOnh0GMAxiSMT+59rIEiSzAAcM7heDxiEMl+/u0EwzjCJfMc99WIIkuQiTOMsuA1LsdRVdXZ/doe8C6M4WYz/90lSbxfuSlxfzjBuzDu+/t7PHr0CFmWxfke2xHbLDzPJw79G0vNuD+MKDYJCg8UeYan9w1uNgkOh8OZR/+FzyDe6+waE2Spw77pUXig7oHCJfAuQT8O0aOrAnM9hjGM3yXz/NfWGgDKIkfdtKgn6xyGIUaDv//3g9yHcUQ/zGvgExfGMM7jKTclTtUJZVHiVJ8+FsjmmGswhNM4AOBuFyaLZAxKnowYxhEDBvy9O38m3GDhRYQ9AFC3TRSMCikOIEmQpjkwAjeFC88tM7w49dFodUHuD8vf1z2CcQAL44geZ1L0wiOGeefcAj5xMYd+iDLIJgUBgtItjGN6FudKxSm34c/HOszzblvCJUmQ6RjuSUPk/U7VCftjUCjnwvzTNF3Ah22WIPMeN+UOVXcegu52CbLJwOqmnY2mKOC9R57nUbF5L5+4MyeDZETb9+iHMa4DkjEax5nCDziTIed/U+6iXuyrEW0fvuOSJI6xKIq4DhzfmXGMYbwvTn0Ytxjr88MJmfdomvpjy2kcI8h2u53x3TTY+8MYPQIVO3MeRZouhJZ5H5VTFS/NZuFxQc48y5jgVJ+CkifzItNQ9X7DgBjR6FUKLws8fQYA+yqMvW5HFFkOjAnKsoyK572Hc8txtNOzON/CXxZc2yN6QOYmp2P47U3hUBZ58GrTWI+i2IxSvN58LUTKly9foizLxXP4vbbvsT8dFlFN5+uSBGVRRgOnATrnkCTJQo7Hpp8jwvT7HgOObXhW1wR5dE0PjEl0FMMwLO6j4+MYiizHo43H/nSIjoQOZ1+NKPIMRZ4tHItd56pDNA7vwrq8fpdj3/RRjvsqrM++CQbN9f9YDEQToMx7OD8J3c8Tp2IfuwHOLVeJ39cJe+9nDDomeHHq0fZLZQYA75JVyEKDjJ4lE6FOY1Ej5QL347BYgJtNgvuqQZa6VQ8YjT8Z8ezlDAHcNMa6n70yF+bYjgtFresawzDAuckBJCPuT1MEHYL3tLDmZhM86zCO0TB3u91qovrs5TTGSUb7asRNeQOMszete6Cpa3i4qNAkUWjIzoX5Zj4YxjBKdBgTbLMEHi4YVzKix4Cb3Q7FtEaEzYfDAa+99hqcC/MoN2U0rrptkOYeRZ6h7ZeI4WYToofKU9c1yL7ENkviWsT5NW2AkD7oqCIdjtU59/EZyOwZe3STJr9+W5xDFo+znKJu2iggZTR0AjebhEBohkSTAHziUBRzvlHk2QJyKGSL+YYa0qQ422zOIyjAIstR+DCvYRgWHpoKTdjDnOrpfROjmUaRZy9HPN6lyFyIiLVkuM65CDnqHmjbGaZs83M4uq+CTOh4iiywOjaC3GwSPL5NUBZ5hLg3mwT70x73x2GxLj0G9BhQuJDj0Ond3t6eQaF26NEOs8Fxvu3YLxxW29VAMsInDk3TIMsy7HY7PH/+PM73VJ1mBzAGI/jR0waZD3BrzfHZdeV1qk+4P4zwbgmZiyxf6KjOe3Z4w8dvINFqxyQaApVfw6lGgmcvJYn0PtKvUb+Zn/jgIfbVuMglqm5YGNnT++bihNU4MCZohyQa1zCOwTtNzyuL8syY9/v9IoIQTnZNj7oPnvWmcPCJi1i97SevvQ3hfgBQbkoURYHnz5/HJJ3zLfycy9VNi6E/z43UA9Z9cDrH4xFN0yxyG3VCquB1DxRyD46REfZulyBNU5RliR/84AerOUPmgnO5KVyUQyQXkoD9+dx0Cplt2+JwOETPz2cyapXlBsM44vFtcDrbAjEHYX5CZZ/1xEVInnmPu10Yf5FnUU+evqzPjEvTAUbyj81AlJ3wicO+nqW5TUPYvtkEjMnJ9hgwjCM+9aRYeFKyT46JbjJGOHGqTwuMvK9CyM+8j0a2LSTJM9QgF6LtgQEDCg88OzSr+c0as2FZnX3TYxhHVFOC/uLUx8S07QNWzyaF30xQsvDAfvLOAWo45HmOYZicyZg8XNNNxkUSe1dmUXZ938daAe2k7pcelJGJ0CdEhDEa3fsve9xsbxa1mLXrWM9eWr1yNkUj/axu2qjQu90uev6YKw4j6j5EkwhPmzaSFMwptsX8zDRN0U+RPZAk0zjGAPVOdYPHNz5GW0Y8j9mgF9FkxbF8ZAZCSHRsR/STsDmQAcPMkrRNTLiolKeJRbi9vY0eBgg8OEMg4QS9wLGd4QLGJOYxJAbuj/sFfcz7tZMCki4ltPKJQ7kpowKehfJ+PSJlbkTmPB7f3MwJf7KOZftxnKNoMqLrOmy3W3Rdh6dPn8K5KdeYnh8T7KE/83r3x310HvenFh4Om80GZVliGAZ471HXczK6Bms1r7rN/EQ0AI9vE9STczidTnHezs3R/GZ7g089vonwqu2X3niNlKDjo6FoJN+kiAZ77AaJZi7mE0jGyGJFUmV6ZsjjTE6RJHjZ9DNc9rNjrrsuzsUymx8rxLrNhJHCgGeHbmJI8rOEK/NhUYjh2ZZCS97dLOlYZTq2WYIsCb/f1wNOdbOgPzUaHA6HpRdMZnaN0OLFqcfzw2kBIbhITEwZyjWkV12AlPvTPnqqyLcb8RR5FnKpMXhLdhyUZYk33nhjXuBJJttiOWdlkbLEI3MT/TnJumkanE4n5Pn83dfvcvjE4enz4BhUGeg999WINPc4dgOGSSmdd3DO4e7uLuY1wxBIg301Yn/cY386xHX0blx4Y8o2/h04gzLOBW++r4dITgxjgNtvPNpG+Pz4dk66a0Efamg0vjMY7+Y6i86dzyPN/bEbSFmWcG7G+PsqUGeKpZWu5QIxUazrDrvdDn3fx8lqxVeTKQrm2Adq96ZwcHAY+sBE1X3wWCpAtp9oETNzHgMI/WaoQkPmd5kodl2Hvu/j/wfDLlH5g5Gny3wHsxd3SSjKNU2Dvu9R1/Ui2ayHoChZ4mO0DJHXo+4DhDn2A7LE42aTB1ZJPGrTNPDeB0jZtEgzj7vboBBrykB2aJslaCcmr25aDMOA+/v7BTZv23GR/2Teo+37M3jqkmQxe65fWZYxog9D0BebwxDehjwu/O7xbbKg5RViAUCe55EVUx0LBAtQ5gXutm6Z005sZd3j4zeQJDmnIZEsKVnSitHKxwSv36XBspOZliXEYtJqPXE/DvjxB2OEbd6FxW+7AbeZx/EYPL723pxVYydPv01dzGNsIsvvUyFibuQCnKHH9whJuYeLv+3a/oyZWyzEmFzk8YupIPjsEKjtoUekc4sJi5N1otHRGHmf/X4fafJT3UQMH/ObcaWjIHF447Xtom5lC60LetRg+AiLpvUqXHKmfGfwalLU2nwe0MUK+WNp/guwrsiz+L2MEDMZFwXhuu6i0T8EDz+yOsgwzFbJmsKLai6ecWDZhPmHCYKRTaFntpVWtoFoEe+NJzPFGbn4CXuSbiWsUsjB39Az9WPwYBp+dVH5fZtXqMcPHHpQaEKhfhBmbhLTa7uZ71+0tEw5g2VVHt/4mOAr+2Qr/qSqqXxFUcywSNs2knEmT5IZsjD36schtF7kxRlNblmsIs/O4MwZU5gsi6VFUaBt20Uu5+FwauoIebkObTdE4mPNmM+e2fdxfMeJ1XxR9YvfWqNnPWxb4MxAP7YcpG7aQM9NRkDYoYpW+LAYZCgoxDRNcXt7iydPnswFoDE5UygWyaiMFOqllpQsy/D666+fVXAV15fGM5IE2FdjjHx5nuPm5uacQu3DgrJAxraLSCWPgek6narVPiY1NvXI/RhYPhpn5n2UlSpnWeRohzFGuNWu2nG5HqylvLYt0Rh6s26b0KEwFR2V3bk/TPAvLc6iieZXa+zZnHu4pXOJtZUEN9vJGSXLYqpGDYWubP3BCpwLKEZqIaY3r8eAzHsca6z2fn1sdRBCFXp2fXg/DrGlYa0X63g8LjB5PcwTVHbjpnCo22au3AILlks9YNd1cbEX+YWEXGXWCh9yi7LI8agMyStzmrVKdebm6Hiqm1gsuyl3kRBwcIt2EY0cbLEvtwgV7oWAXTSUF1UXah790ji7tg+s3DRf9dCz8o2L9agnpvFUn+LnmlT7JImGoXO+2yWoOkSWy9YTHBy2Qmc/1GhqDb3wQD8ky36xqYG0HfuF3kSa1kQkdZD3hzEycwDw7NBFYojXi6rD63f53x6LZT3NQgjjnIA9e2n4/mQ88wTOLZPzwofmwcCKDAtvcmzHWEG3ldG6rmM+cre9CTBwnJve1Gh0weqmDXlKJlV800vU9iGJz3zg2zPnIyvHfiLmWEMfjIYLRsXjvpbTEXjv/uUyAibzvG4zH9slotfOfYzGvB9zuDUljNFoKvLRM7NT2CcORZ6hl1YdTYZJi7d9gJPa63V/GNEOYyBPtP1jU672OmlO006Gn/kwjrpfQqtA3c9G+ezQxfXtum7ZQTAmKNIUd7vAcN6U2TJCT5X9ug+sa920H1uingAYv/SlL+E73/nOxYKSXiwSsdP2/v4en/70pyPf/u677+Ltt9/G06dP8frrr6PrOqRpijzPcTwekaZp/Cz0L7kIA2wIH4YBf/VXf4XPfvazuL+/x93dHfI8j8/mn/lbvR8V7fb2NjQSnk5o2xY//OEP8eabb6KqKjx+/Bht2z5YYAotJEPMg5gndF0H51yc7+FwiOyO/o7f19b9oihwOp0WY6VM7P34+dqYOEdWzCkzFmubpsG3v/1tvPXWW6jrOq6vlRMAPHnyBB988EG8p85FndX3vvc9vPXWWwCAN998E++9997qtgS9eD+ul47/3Xffxec+9zns9/tV/eNY9f9tG4qWa/L+0z/9U/z+7//+Wnn2p7rizE6nU9yppjvYmEuwusudhPToZVniW9/61rK57tkzHA4HtG2L0+l0tmtN739pFxp38NEInz59uthJx3HZDlO7E/C99947e0bf97i/v4/Usb2n5gB2FyQb9vb7/dn47C43UraWrdF72p2aer+yLCOVfGnHX5Zli7HY++V5jufPn+N4POL58+eRlt5ut+j7Pn7X7mB87733ztaH43vx4gXu7+/x/e9//6xd3XYt8N91PTluzufFixd4/vz5qv7ZRN4/wFb5j4HJSnA9tOF6fTKvjzaC/P8+0Ot1vf4urjRN099t2/afD8OAuq6R+AQ/PH0Pn7v7h/g/730rhsc8z5EkySI0MhRWVRWhB6+/+LO/xL/8F//qd7uPiZ++Xtfrb8VAiO3+03/+7fhh0zTI86/PpMI44u7uDu+//z6KosCzZ8/w5MkTVFUVE2TiS+LrP/gvf3iV7vX6ZBhI24eI8LU/+CMwkhRFETfIaBsKo0aSJGjb9oyN+qf/7J8gTdOz1pXrdb1+bg1kk28iI/TbX/qPP5Nm/8qv/evxf37jm1fJXq9PxOUA4H//zTfPeO+f9nr8+DGAj2fzyvW6Xn8nBgKcV29/2uvly5cxb7le1+sTYyAf9WXPtLpe1+vn1kA+quhxva7XJ9JAPqr8g5etiVyv6/VzbSBJknxkSu29R1VVq23l1+t6/VwayDiO8fDln/Vi1+uTJ0+u0r1enwwDYRfrR9EWwshhO2Wv1/X6uTWQtm3hnPtImSd75ur1ul4/twZSFAWGYbjCout1vdYMhDv59PSQn+XSE8Wv1/X6RESQrusWBzv/rPDqSvVer0+MgXzwwQdI0zS2ifwsF08FvOYg1+sTYyBlWWK/338kEGuz2aDv+2uryfX65BiIcw7b7fYjeUPP26/9IwzDsHps6PW6Xj9vVwqESrpzDv/m3/0Kfu03fnWkoXjv4/E0PFvp0skRWZbhrZt/gHEco8Fdr+v1iTAQtqZ/83/8L2y3Wzx79gybzSZ+XlUVnjx5guPxeHZOkx4x4/1/xzAM192E1+uTZSB/8Wd/iT/86n+NkQBAfMc2I0ZRFEiS5KwlZRxHbDYb1HWNR48e4cWLFzidTtcIcr0+EdffxrlY13Byva4Gcr2u1ycWYv3iL/4igPm08iRJYh7BM1SZZ/R9H19Of+nSs1d5Pm2apguWTE9C4XmraZrGJJ//RgJhGIYHt/HykGY9LXwcxzgX/scjLXlfzokkhI7VHoGZJMnZiyfPPE6SwHsfczEdi8oDwCLPe2huSZJEuQzDsLinysnKQ+dKuNw0zdmzeH+7Lpe+89DFuXddF8ek8td5WF3RZ/G7KsNLsuF91o4rXbvv2v3GcYxrxvl/61vfmlksTo5f1oXTga6xWFZ4VAAKO8uyKJhxHKORRStN07ig/Nz+mROwBqRGzOOIdMJFUZwptBq7GhHfVqv31HmM44i6rheKyrHQuLUGNI5jlJd+n89QOfOenIPOT5VXnRD/z+IslZOyUEPqui5+RxVJHR6fu6a0ur4qZ3Uk6sw4b8pN10TvyXOHu66LzsnqH3VPn2kdjzU8fsYjqLquW9x3zanTwWoNzwP492+88caq9xiGYcFY2fOxOGH1VGpoGo3UiKy3s4OmMqmCcXL2nC69n3pv3pOC4WfWWz7kMemVuGiqEPwzHUDXdfHESY2wbdueRTGOgQaq39c/Z1m2KudLa0SjUHJFlX5N1lb51MhU7hqpqHQ0PMpVZcp5qxNRo1Dl5/yoLzo3HZf+VtfcOhs65DWjvBSBdDyU8fvvv38eQTgoVTarvPpgKpD1qlROKpR6l7VLDUDrLZwoD6jjPS0EVO+j46BguRBqpLpw/I33PhqGHrnPOXCROA7nXPTOvI/1ahY2qDGroVjDJ1y0Y9UoqHKljHhPVU7d66MQmuPQ6EAFsUhA568OQp2JemNrlPpcdaQaFVSuGs0I2dTwFd1wvOM4LpwS72efx/vleb5wbG3bLpzI2eHVDDOqEFZ5eGVZhizLLi6iwhW9l4ULaZou8g+rZDpgxZFak2EoX8PS/Le1BVIownvp3/k7m9+ocljPpt/R51loaSOV3pfjoMNQRdC58CTMNWXnd6kwCqUuwUh1Lmuwa8341SDX8k0auzpLe1FHbLuTylKfy2cyr9T7KlpQA7XQkK+C0GhoZZhaC1f8qMJYm5iGdFViKio/12SY4d8+g4OnQFRxdMKq9EVRnIVFfS8GPYLeT8fIl+7YBbXexzm3aN/X92VohFLvyeiqEMXmb1YRrSOg89G14W/UWK1y6L3scy/hcD1C1sI6/l3Ho+tCpKH5lTovhcz8j05YX46j+aZ1tuoUrL4yeug6WgepeqByUuNaW4fUKrxlsSiANRbLWptlMihkfcvUmje9xGLRaPI8X2Wx1ICzLIte/tJ8lMXS9hn1RCpoem+NDvo6Mw33a2yJKtSrWCwrRxuVmHAqi2XzEf27jvPDsFga2VWx9P72BT76bwpjLINn8xZFIhZ263qtJej2+ZRbnucL8sHmaXpfO8c1wmQ1gmiItRHDKrTmKnbwNs9QBVfsqOFzs9lEBVcltsmpZar4Hb441NKeHCeVSxWQmJUhmx7Q5hmWyXoVHXtpb79CN47bei3OT8fFHIfGa+dCpbQ0pxqTGrXCJV37tXziEpFCh2ZJFH2O5kDq4Cy003yVjkrhq+qKOhKFhVVVLQxRWSnV3bXoQ9mu5YGptZhLSq+ToWdd45HXchfF85aN0OSWGJBtLfw7/69C4rPoOagganQKCyiMNa5cF4DCVQehePuhWoGFmXZR1diapomGooZuIwkjKMetc1GjtcZLeeZ5HqOJGgRP79cIxmfY18hZB0odeAiyrbFImvMpQ2khN5VblXYtwip8JdzWXJSUvBod/673t++R1PmfRRD+kIPSL+vCKE7nBinLNdvwtUYLqtenQlj2RIXDyXIM2htmhahQTRVyLeFXuKTCs0kkF4GGx/Fp5CO8svfQcWktRJ3IWkLOZ2tuYNlEjbCElpvNJsJXW+/hZzaya65mWb+u6+K8LWW+lkMpRFcH1rZtvA+jojVERgTNfzleKrk6V8qqqqpYClADsvmMMleWODqDWDoZNQgmgvoQTopWz0WxLIUuukIyQi6+X8QmqTbBtBc9gdYmLEW5Jgh6mIcKnPoWVfXIqjQcq1UwnbetHWiSqJ9ZfK3QTKOsfkfhlXo+dRpcE6u8dARqRAp7LD63NYK1joY15kcNV8eiBAbfVEZdsBDekirWCVoCh8/iASSW6VNnYxkxdXzW0aYPYelLeQA9LNkiQi6bnGmoVyhABkNxq7JAD10PFbyoqJdglHp2VU5r1PZ5tqClMJQ5yxo9rCyQNQ5bM6KcWBzUau6lWoOtEagHXMtTFH5wztYL81m23kQZ6POVOODY7dgs/aulBN4/z3N0XXeWPGvUVl1RZbcJuIXDawygOjLqnur8GcRa44s5+bVil7VuDeFrPTZMnPg9TYoUrthiXpZlqKpq4c01+VPD4EJYD2HDZtM0i6ho524TXLtJzAp/LTew/VVKRbK1QudtcfQlWl2hAJ3MpRqUXYe1PiRVPM0PFE7ZirVtRVFHqv1Xtt+KcG+NFDoejwtCwkYufbW1/puFy/r+TI1cSp5oEq/IRo3vLILY4slaP9QabXYpYV0r72tfjIUga3nIMAw4HA6LCa0JRsOm/VyN3H6ukO5S053l8C3dzH9bY5Z00bQbQBks9fyUPRNrPss2SzICMmprTqbVb0JgVTD7PnmusbZ+MNJYyKvMkkUIVuHWCAtlBJVyJ5GiLSLay8b11ZxvLedkPqoRUKONwmxN2LVdZ7PZnDGQCYDxl37pl17ZuakRYq2/RsOXpRGppIqV1atZr73mDTUx04lbtmTt9zZc21aNtUTTtlesVX1VHqr4asTa9qAGaf+ui8/mQy0wro1BMbNl4tYgo6VNNfche6j3sEm3xfB27TUaqSxsJ8IajFZIttYtbus0l6LYWs6m0UTXVfNjnSsN75vf/OYyB7EUKZNcQgLb10OhslyvvVlUQE0O1YtYL6oFLmWc1Cvps+kh1oqQmltoVFSFsUU4y5Gr8ds6gyaAmn9pYyOfxXGtYV1VAqXOtUXH0rdK72oUsN+3zKEyeJY6ZqKsCmehpSqhzVE1smoHgRq/JSks1avw28rJwmbrTJWB5Norvb+WHytxslbkXkSQ636Q636Q636QB/aDXCvp10r6tZK+Xkm/brm9XtfrobLCVQTX63pdvlIA+MpXvrJasV5r33gVLrX0oO3NX2tHfgj72lD6YYqJl7DtQwXJtXrHpcIhx2Rbs9e2y+ozbZL9quvD4v5LbRJ2Q5WuA4t2duPXWtuPvYelwHlP3Tz3qjW2RUe9l9W5hw4sXGMo12SjOy91zpeur3/96/jN3/zNmcX6+te/vvpF5aFZnHqVMnLiFJi2axO/LooxE6bWHMIWhrQY+FDCr7i173tst9tYpV3rtdL5acKsi2IJBdtyk6Zp5PKbplnkEZyDEhxaWbfMIWXw0OJZ2vt0OsV8YA3fK91ue8Q4B7sZa805aE1EHQ3vyXxTiRKSGrZEoPkAGyfJmK4l4Za6tXmeKr/qrrY1PeTMySSeTid0XYf33ntv2WrCiesedCrjpYY+CkJpWVK/2timSdFagYeTUuOgt9LeGh5SZxdPjSPLsgVTs9/vFwuvDZjaImHvSYWr6zoe/EAl01YJVsBPp1M0fDWsuq5jRdrWjjgOpaNJaFCOLJxp/5TtYqCM6AjYwbt2gLilNjWZ5vyskmlLSZIkKMsyHrLAzgTWYrgJjUm8FlL5bHWEPHSCTsoyoNQpPdjBIhJlBnUbrdLLl5y/Po/1J9XRVK2Tg7CFFOu9tChHBVLGiTc/nU6x01dpU1tl1YWgca31N+kJHnZ7JRVdN2mxHd5CPmVrtOagEIEsFhkObbugt+M8aQTapmO9nnbj2r/roqs8qqpaVH3twQm65982LVLp+DsWLG2LjUIaNVo1MB0D7601EMsEMarYrmC7F36tmEud4Tpwnmxd1y3WCsuyLIvGybqc6otl8GikrONxzpR57H6wuJUe2EYSiy8ZGqmUa9i+LMszo9JWdqWB2bD2qrYVbXdgSFZ+2/ZzqZe0m/41CmrLA5/HyOG9R1EUqKpq0cqhY7Et53yWylEPd7B1E3tfKuZms1n0uqknJ3Q7HA6L9hLbaNk0zWJPOuVxaU86I5H23dktALbdSE8zUfqXa0gFp+HYKj1lRp1RmalHV6/P/GiNkredENbhUubH4zF+p2maOEbqQspBqOfSRbVQy4ZreyzOWljWDfIWs1M5FfZwcQmH7OkV/PeyLM+qzJor6YtJ19pXjscj2rbFZrO5qFiMVofD4ewAh0t70hkFNc9R77eWS9jaA5VF91IrzKrrOiqVRjfrJKyRrtVptKNWe7i0yNv3/aKZkp0MepoK507d0DXWjm7WLfI8XzQiqi5aKLm2J127JBjlbVSiQ6iqarW1R53s2iEcqSY4inE1PNKiiIV1D4dddPXY6lWyLIvCs8ex0HjyPI9KqezEdrtdTbI0v2GhUXG3Rj1tYtNXNGghiaGcGJ6KrkqqLRqX9qTzove3lXR+Zr2l9bpq3Ao/X7Un3RIRNM48z3E8Hlcr1zQa26CqsM6+d1L/XZ+rrT1agOVnbOlXWKgNndpzR0+/dg6W7j9SiKdysV28tuXJblyzjjRdC7FN05wd0MbQaSu0DzWWKRTT/hwb3r33uLm5iUaoSTvHo57b7lYjzFg7DICLxN9qpFSczv8zKvFFpNZ5PPRyUovRbZJMw9JkdK1tfw2XE2MTjqqjopJZ2SikJb7WKr6yeLqHxCrb2ppSR7Rl3xIPvJdtz9F7cXx61JRtu39VJZ3v12S+y2jA/EINQnWLa0rHunrai03UGLItTtRefZtI64LY7ZG6JZcLpYLkhOipCS2ojIRJ2qjIvIctyoQebdueMTAKd+ypJ5bBUxpRac8Puyd97VhNjdCW3dLoS49vcxTvPcqyXFDny3ey+AXMtZGqKIrI6qgxbLdbVFW1aMXRPdrq0dUr88/ahLnWimKbJZUEUmjGz5UsIRNHB/aqPenee2y327M96dxnolvDlRWjPOjIlKqPibs+jFZHhbTNbfbgA+28VXrV7nFXz8HvUBlpBBruOWD1bOpV9agezQ30IAGFALpX2T6Lno7PIIzi4tgOYS4I2TFtAuS46UQueSXF6mpIqsiqUHqomjKI6oi4Dm3bRkhblmU0RtvmzflpAdE269k96W3bLvKih5oO1cFQxoSzZD71MyUfvPc4HA5nxwTZ5NvWqRhtyao+tCddmStLHJGUWUAsDoaHIGgipsrGQXCx6NmrqlpECrsnXdu9i6KIiZMqqmLOSxVzhkvWC9Yw+5ogqCwPFTgVIiklbfek07D12FCtFymso/GdTqczkkH3pFhIpvNRupgRUVvEudGHntrCSa4tDYdGpFFHi3mX9qSvQS+lUdfYR907Tv3o+x5lWaKqqqjMug3bboGw3dTUKxqXVvi32+0Cor1qT7rtluYz4vaLS1haC2uaWDJ5pUEURRGTUd2XoJ5XJ0/IpIujhviq1gql8nQRKYhLp4lQMJvNJuY0qlC28qxKrpVxxf56SIDmVXQeCicsq0JIqXs6mqaJjJp1Hsrra12Iv9N91nqiiUI4TYjXuhG0vnRpT7oeY0oopHBO770WNSgf7v7jmmi9yTJf6nTsEanaraERxxqWMnIqK7uhjU71dDotDUS9qVZklQVRXlxfsUYsa/eha1JK6EQB8s/aYm7DelEUOBwOC+yrlKJOnlz42p50DfPH4zEqieZLl/p3mNi+imnSBbAtHlQ+eu6iKJCmaYQrHMtut1s9xX7tXOPj8Xh2XKgdv0ZmrrHmaJpc69FFPGpV6W/NzzS66u8Jze1zScJc2pN+f38fHajdfq2owjKmqhealFN+uoORVX9LkijjpunCGcTS/vm15jU7aFr6WuPXGtfOQds9J9p6oArR9z2ePXsWQ/Clzfpr792wPWSXjvN/6H0nmtDzGZZuZi5EZslujSX9rPUKlYG+a4TypgEREurzNAISajESatVf200I8VRBNF8ja6iGqSeg2Mhp+51s3rKGIh7ak86xkhYfxzF6b92hyEil62WZVjpTGjhhJMdEB6QJu1LPNzc3ZzA9tXTbpY5TTeSUX1/jkG0zIC1fTyrXe9rTFZn47na7xSJo4mo9oz2FRPdy24Y51gQITaxH08qvemmFMgp9FH5qhy+jq1bcH9r0pV5Qdzpq4Y7vn1d573a7aBhKdSssUY+rJ4koha/4XV+lwLVbe5+KnY9W3lUWlLets+iaMLqv1dl0qzX1g9FCzxlQ2EQyRV+NQOeupAdlZzddLXqx1qxee63IF9vtntvtNpbr+X16VE2iGPL0fev6ohVOLs/zRS+N3VGo/UF8GxA9rlKhSlfbc6PoORUKrB0RpJGPEM5WdenRtTqs2zdZDLRt4zZ/UupcC6r2ADslMxgFLIVrIZ7tkqXC8nnb7XZRLNTT19fa6S8d6UNlW3upDskS2w5CA9CT9q2ctBnSbjewLwvSNiHmgNRDm6fZmpbtR4wG8ud//uf467/+64UXt4cNcJHUYD7UhpNJAMfj8azTdXFA14TJmZ9oRLNHblp24/7+flFDuHR2lT2Vr2maCEX0GBqt0q41V6r3VuytZ0vp9ljnXKQtdb+7PpMGyELlJXp4rT1HtytrkU67d7WXicai+Zs1BH1TFZ2b1pO0B0+di33dW1mWCxhnD2/TArQahX1hEZ2M7fO6xEhq7ke56Wn9r9rrvoBYirvyPMd2u12tMtPbrFn12uYkxcOMKJrE6VlTvOd+v18UBHVjzSXqV+sGCgvs+UuMJqSptX2GrJqyN8pyKVOlr4NYa7BkT1iSJHGvBrsJOBbdh0FjtVS0lat6TZUNPbR9y9Za8q7zWntFgcJn3p+MpbasqEzZY8fnKbxVFk9hqVLclL89hodRPibMkyMj/FUZruWR2t9FKGzfS3OpnhPb53Hdk369rtflssJVBNfrer0CYv3hn4wYR4CRKkmArguhxbv583PcB1gYx8+8A4Yx/HkYlvdOEmAcw3cZ6YYh/H1959f8G97jVZf3gJ5cM47zM4YRSP18P/03js87oO3On5f6ebxNF+Kv98s58Pt6XyA818nceW+OwyXhO3EODuiHczmsXVwHlWHXz+vHsfD3xcSIN+00Xw+07fL3zs2f8R79EGTgEqDt53sm0/OydL6Hrpv+n/fu+/kz6opLljIMcP38M8ouTYG+C1joUkpBHcyzMP62m+awom8c59f+6Gv4D7/+j2ea94/++GsXlHPEMIzIMo+27eH92rGRCYZB36PNLYw9iiINAhhGFEWKYRjP7pNlLihc08E5vjdkQJY582qGAX0/oCjS+L0ggDH+nWPh9x892qCuuzi+JAHy3KNpeozjPL+iSOO4xzHMgWNc+/MwjKjrDlnmkGUem002tep06Hu+/25AlvnJ4QzougHeJ0hTfya3NHXo+wF13SNN3WJ+5wse5hsUxOHlywZF4ZFlHl03LNaB4xjHMO88D+tIo2yaPsrZOVai3eI+Vnm4fvwu7xlYvRRVNcs7yxz6fozj0LViHrDd5jidWlRVh80mPXsmfzvvHXdo2+X4ssxFvVk2q6bw3qGqWljeQ4020L4e+32Nuu7xgx/83yXECklRf7YQWeajQlBJkgQoCh8X4XBoFgq42YRB7Xb5tJBJFLreh9+n4qtxdF2PppkNKXjAMd7TGij/XxRp/D4AfPDBEVXVoao6NE0/KXYf71dVwSi7bpgMBlFhw+IO2GzS6L2CMaTwPkFZZsjzFLtpgZ8/r+L8nAsKdzg06LowN+8TmU8wsLbtF4qw2aRR+XfbDNttFg2Jiqfzb5oe2y07FWaZcQ2cS5BlwTD4fVWULHPT3Fko9NFRzM2Uw2QQQca3t8Vk+AmOxwZV1UV9OR5btG2Pw6GJBs/ncNx0IjTC06mNclbdoGEHMmcev+qp6kzbDkgSRJlRJqfTuXFQRzgvyjdNg6zMnnRy8XOUCKzGuScZBtKtI7puQFV32JbzIjZNjzwPDMb+0MG7edF5Px3sDHOCJy/LDM71USBcrDz3cC5BVXWLyMJ/p/cJ45u9e55bOnKcwnVQ4LLM4rxCxPPRmANLErxVEJqLUSLcf9p7X3VxvF3XI0kYbca4UEGeyz3pWeajY7Kn+o0jcDi26Lo+Kjq9q0ZBlWuWOXgfvC3/894hTYMHnXc9LveGcx7jiKh8Weai4ofINywMlffZbvM4BkYmNVBdWxo+nQG9foDEwRntDw385Oi8dzFanE5tjFb6fd43z/1kaMFIg0NyOJ3a+BxG83EE6rqbxp/heGyjEdKhmT3ps8JuNuEHVMhhGKO18zPn/BQaM5Rltgh/c4hMcLPLo/IRAzMU0/DGESjLFJtNhq4bxIjGhQeb6yUuhlwaBZU9KORswCr8YWDVPolKlmVByXh/jl3/3vcjvE+wLTMcjk0M4YRB4blDzHdoUOH+84IqnDkvTrnoaSljjmO7zRcGRMgS6jAjuq7HixeVRD2/mHfYF9HG6MVINo5YOD8qGp1L3/tF9Keizm02Q4SKdC66JhoJxhELBQ9Qbgl1GGWpM7xmeXvpKg7GERwEolOmY+d4vE+iQQTIPVf8vXdomh739/Or3u7vO6RpMO7FnvS2JR5MoiGod+/7YF2Wb26aPnrX82JaCNcUPMNuCPcuhmiG0bruFoYTPF+Cuu4xDJC283mCt7f6nvQ0epKm6ZGmHmnqcDyyUJYsFm0YRtzf12i7HtsyW/wbFzCEXIckcXhxX0W8GgwrGDujgAq+LDM0TR8NPSjT0liWuURQWlXYEDHy6NEpK0aF42SshLRz1XqMOV9os/GL5zLCWiwe0EPIkXa7fBGJi8Kj70dst1n8vG179P0Y9YXQcjcpuOYTs8KOUTf2hwabIpXoN0OoYRgXjsJ2L2je1rZhreu6x2YzrzEdWJqGPx8Osx7MuWSycLI0qBAUZE86uxC44MHTzAxAUXgURUi+woCcvILsvKrJZJHRh4Og8NRjEJYcTx02UxJP4QT2IsHdXREFZxVsEh+22wxFnuJ4asT7zJ7FuXAvYnDvHR49SlHX/fS9IOzjqUW5CQtXlhnadsa8hDnMG7ioa+9JZ/gOxuriWIdhxOkUFuvRo40ks37h/S2UCfs+0pivzd217iwfCwqfLiBPnnsUucfLfbOIyCyO0VOH6ITFfDknOht9Ftefzw0J+xChHj1+KTCcMHaZA2ERQcPvQ/QOjiBZMIrMhwiRb2/zRX41EwGITpz3DeNz0z4hJ0hljE7urFmRXi4sYL3wSqHFpIvwIOQffYQYVkHUEyZJ8Ehdp3vSxwin6OUev5ahKAKODKHTR+9SVV2ELE3Tmz3pIdw+f14tvI5i1HHso1efaeWZcSKDxBAfEugex2Mbk346Bmuka2weDcDmbwrdmOdQhiFJJgQNC8vn7Q8d8szjeGxRlhk2m3T6rV8oZWABueB9jABUvD2APE8XMJZOjDCq78coZ4VB1qiOx2YiKXxMckmA0OAZVWgElJ3KhYbJ3NK5JDJ51JXQeTAsnJI6yLD+p2iIgbZ2KDcpjpM+BVnOvwnyD/ldUaQ4nVoMw3jmcFLWDIjxGLItTqQl8t+VKpx7cEKopKJwgfI80KBKpyYJMXc6QbDAeCRJgru7DbxLcJoYpqrqFhAkhPzwrJtdjrYdUJZDZIXUgMoynZQnCMkydfPcgmIy4QyRJ1vQwKosa3S3Gg9pZiqneiYyf8E7uwmOuonatnvSk2mOffxt1wVYwf8TAtPI+L2q6rDb5SjLLFLdHPujuw32E9NE2Mg1PZ062fyVnlHRpGYZcfS5thcqSeacrCiY883QjNFO87809dgUHqeJtVMiwbJrSeLgvcPd3SY6TOre/csa3ruYb1A3A9vp49rSoXEMx6PZk06MT6ur6pD8ZJlfUGQUbtdxoz9ZpWAApCEpUNKuDKEcjGJ2Jm/qhTlgPk9hXEiCQ+7jnMPzF3NuYCleCqeu+6iQS4o5mRRsWEAFcvnqNRlh6NnLMhh8OnnI00Qlz/fIFvWApdLPWF0NSRWZ8GWun7iY73QdWSEXHRNZrKbpI6R99GiDrhtwPDaLfCfLHI6nJkbYMLeZyCARQwXinOo6GBxJA0bptVoYk/txnGFUXffROex2eTTivh9jtGRt5/mLKt5TnS51Qo1GCYaX+wo7ocadGxf0v9LRtqZC6JplZk96ULBww8OR5zglU5vwEEPPTMV1KHIf85WuG/D06XFibdJYV1BMGejPZOKpc6TeYX9oALgzzKlh0F5t20clXvL1iAq6Jojb2+JMWXWB6SG7LlCKhH/EuiwZkaIkNUhmhyQGE1JGBSrkfl9PzFOySCLpbOgs1nIQKg6NaIYlbZQnnQbzwkq8b5IET980PTabFHXdoa5DfkaShOujdZbl+yPH6Ikpx7C5qT1jzxRRMJFmZCiKFE3TY7fLcTy2sa41Fx8Rc4SgF5DG0zE+J8/9xLaNE9wMKOjutliQGTonHZM6UhpT+D5Qlvmr9qTz1GtMP5oXqyjSBbbb7XJst1lUcDUO4k3iS2CM3PQMCUZUVR8HPQwP95Fw8bQwObduj2eVYrvAu22G01QTmAt4aSQOKDj+N9OqScy9KHgSCLOSzTkGjScoxzKRDUoznFXoT1WH3TZDlnm8fFnHedH4Qj2ji56P9yEDyKQ4TT1ub9PFOuQ5D0wYo5xsUS4YNA+J62IeoCwSoR6hDCNpXXfYbvPp+S46G9K/p6rDtkyikWut4maX41S1Cwa174cJJcyRIyh4P8lhXNSuuB62EE0dIS2sjix8hsVvxxE4Htu1PenJIonquiEuNMP9TEkuhXs8tosahrITVBhCJy4OPZz3DtvtXEthUkac+/z5acK+Y1xoVSydbPAow6JARXjHqvj9y3ryMKMUHM9hEJPKw6FdQDzmajZqzZRouvCwbFtJ0zDnpu2x22ZIUxfhCuVwN9HWwzAuSBIm7ZRn3wfYFOBr4Pstmxgi0xwVCXnatjOV6mUrESvxp6qdxmn3pLtFwZe5Rpq6GE0AIBNd8N7h8WulOKBxEbF//P4BWeaiPOdaVRKZ1Vm5l84yTefi526bRQTECMPoQTgX9DGJqICMW9OMqJsO6VTkPNuTTiGzwkj8q6zQLPy50k0r1wVSXK0enNVRwjbek4LVaND3A370Ny9RbrLoaRQa6X1pFKT8NIlThVU6j1COi2E9TpBFL5Xp8Yxuplcqy2yiLm0BLMFul8VepM0mJKMK5bh4zK2YWN/scvST0WlOxQhICtq5bGq/qGPBcQRQTH1XwzAn4FQQzddI3TPhZp6mzB7rHkH5k8XaMj8KznNuVzoIJcy2GnVqocUoyHK7Deu22+YYxjFGT3Uw2y0LyX4RFefmxwTPX1RxLOztYo0GAF57bTPV3Pro8OlwN5sUj1/boKr7cxZLe1k0mqwVagZZNG06YwRh7w+xOZvkxhGxlYVdl3N12C+8cIAPHo/uNgsMzmQrMFLJxKAsKV16muBd/NRfRErVxYScibhGThtmmRgHQ0Kkm6k4gSJMJsVLF5w+PenhMBu/Fk1n6IJFr9tul+NwaNC2odBYTMU0OoL7SXloVM4lMRmnApGp6bphUeUndGaRlM6h7cKmJt7HJsbssFBsr3kbG0v5jKADsyzCvAKVSoPSlhcSDC/uq4t1NtLVWjUPKGSY9KmfolCgmqn8wSH5ybHNyIh5rOaMh2MbGT2zJx3SEjICcNEDM5Einz3XEcL+4Ud3BV7c14v2D3L1mkTRI1NwVIrTiUfOu4hPD4cmQgJVek1kuy7kRewFu7nJ43OIS/PcT1XW7qxDlcoevP4YWbY5z3HSEeqnBsph0VfkpM+McIywlBDn9jaPC6tYV2GLpc7JcNEANN9i9ElTF6MAHZayOVxLJvuklDm/m5s8Pu/2pohUO+dcVe0i8SaZYcdEo6Zs5mLsuOiXmzsatJY25xzH4wy/rZxYqwrGNhdcCb8UZpG2LsssOg12fCy7FdxZ4ZORNcBMaVb8b3/yx/jud787b+vsOmSX9qRXFQrzuoCHLva08HDpxZ50OYbGpynK7Xay9had7Fd/1Z70D8YRfdfB/YR70tumQZbnSLMMTg5KjnvS0xT9hTOI4570NEUzbQHVPel918FzT7r3OLx8iWTasqpbU/W0jb7rsPlp96RnWZSnT1MM05xX96TnOZJJI4ZpG/AMWVf2pOcZ2sbsSc9zjOb40whhp7Xw3qPclmib9uxgiXhCTtvCf9g96W2LVE6Gt7J55Z70PMcwbZP+Cfekz4lbURTwux0aOc91sSddjuJ51Z70ftqTzgOUu7bFqHvSp0OLo3CHAfuXp59qTzqSJArgw+5JT7MMzXTEDvdy912HhHvSpxNXuNl/sSd9Mp7OHHTGMSbck348Is0yFNP5WMNHtSd9evde3JNeVdEoRzkwbXVPupwmuNiTnmVhjeye9HuzJ70oouNwzgUHYfak65GzXD/dk87974s96VmGQY4Sbac96bnZk97UNRLnonF96D3pk5NWosDK+bon/Xpdr5/g+n8+vjU7M2RyLQAAAABJRU5ErkJggg==';
const ICONS_BUILT_IN = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFgAAAAbCAYAAAD4WUj2AAACwElEQVR42u2YMXLaQBSG/9/DFXIBl2lyAkHGlWfce9wx0MIdwDdIgZNODF3wpHHhGdx4HK0vYIqUoUsKd7nApmAlr5bVagVLbCm8Gc08nn49oQ/p7S+AcCHVZuYvAhVmrkcMyFgdq+dV+7yVaIWCG0URAEAIkcsBMAXRbrdhy0kyBTpVx8ZC5PJ+hT7qF5ZYn5x6btwR1npOM5utNd0u9bxIYx7PkHBtIYSAlBIpCFskSYIpiamjT08I9Dz6kFwDvb0Fzs5guWBmcDWNDbKczSROToD7+80+CqapMSEfOcm94UevNCxwt9JY4FbRHKGBMfeozz36rDzqq5IeIQBTCFE4HgCQJJMkcT7WfYC9gj49IdD37AMAFwDnFrgX2hiwacw47na5ssA91saATbOPO3gDcgo3E1jg6FAAwAY5hVuljwnQhLstZBOuL+QN++MKjwXPatH0c0RR5OwVqz7xjn0A4KujRxXNT+UUdtWEWORkiL5xoD6vHSy7APPRK4FKR21nzY/RJtCrhzEGH8eFX6xs//tLcp+AQ8xg+ev3HyzuHnUYZs2qiaIIykNLy2cU1GoVQRa55XIJABnAxd1jVivSuF5OUqAuTSMAe44H3Nx8y3IFcKOu5wVuI+dEdLimI/nf7mB++fzJukPV6dI0PY5wiAPgOkdr0BnttDpffb+ka8YWzeqtzvUwrlT33b9XHzzojGQgHyk9fPZOmjr64FbIH8uAw0KYEykxzF+YDZ4GqLZ/m4acwRITiWzTYU8cr7STGv/n/A8Br+EOyWzTIQ+ZBzkktDv54CJ84T49S/n0LFOoPF9kkGmApAaaB8AV4sO7wkWDnrUD4Mpwy2Zwg+cwA/nglxms4nwh5fUpdXdBm3tI5/SgM3oVAKmPr4UPVjMXAKDBNRc0s0YPm7b192uUD74+ZbEPti1ow8aPYPwFPTAXvHJ9QCYAAAAASUVORK5CYII=';
const GUI_PATHS = ['./gui/gui.png', './gui.png', './Gui/gui.png', '../gui/gui.png', GUI_BUILT_IN];
const ICONS_PATHS = ['./gui/icons.png', './icons.png', './Gui/icons.png', '../gui/icons.png', ICONS_BUILT_IN];
const RAIN_PATHS = ['./rain.png', '../rain.png'];
const SANDBOX_SHADE_DEFAULT_KEY = [FACE_SHADE.top, FACE_SHADE.northSouth, FACE_SHADE.eastWest, FACE_SHADE.bottom, SHADOW_SHADE].join();
const SANDBOX_DEFAULTS = () => ({
    terrain: { width: 256, length: 256, seaLevel: 32, hills: 1, flat: false, caves: 1, ores: 1, lakes: 1, lavaPools: 1,
        trees: 1, flowers: 1, mushrooms: 1, beaches: true, bottom: 'lava', seed: '' },
    render: { viewDistance: 512, fog: true, fov: 70,
        fogColor: '#' + new THREE.Color(RENDER_DISTANCES[0].fogColor != null ? RENDER_DISTANCES[0].fogColor : SKY_COLOR).getHexString(),
        skyColor: '#' + new THREE.Color(SKY_COLOR).getHexString(), clouds: true, cloudHeight: Math.round(CLOUD_Y * 10) / 10, cloudSpeed: CLOUD_SPEED,
        shadeTop: FACE_SHADE.top, shadeNS: FACE_SHADE.northSouth, shadeEW: FACE_SHADE.eastWest, shadeBottom: FACE_SHADE.bottom,
        shadow: SHADOW_SHADE, rain: false },
    player: { speed: 1, jump: 1, gravity: 1 }
});
const Sandbox = {
    s: SANDBOX_DEFAULTS(),
    load() {
        let saved = null;
        try { saved = JSON.parse(localStorage.getItem('claudecraft-sandbox') || 'null'); } catch { saved = null; }
        const d = SANDBOX_DEFAULTS();
        if (saved && typeof saved === 'object') for (const g of Object.keys(d)) Object.assign(d[g], saved[g] || {});
        this.s = d;
    },
    save() { try { localStorage.setItem('claudecraft-sandbox', JSON.stringify(this.s)); } catch {  } },
    reset(group) { this.s[group] = SANDBOX_DEFAULTS()[group]; this.save(); }
};
if (SANDBOX) Sandbox.load();
function sandboxSeed(text) {
    const t = String(text || '').trim();
    if (!t) return undefined;
    if (/^-?\d+$/.test(t)) return parseInt(t, 10);
    let h = 0; for (let i = 0; i < t.length; i++) h = (Math.imul(31, h) + t.charCodeAt(i)) | 0;
    return h;
}
const SANDBOX_FIELDS = {
    terrain: [
        ['width', 'Level width', 'range', 64, 512, 16], ['length', 'Level length', 'range', 64, 512, 16],
        ['seaLevel', 'Sea level', 'range', 4, 60, 1], ['hills', 'Hill height', 'mult', 0, 3, 0.1], ['flat', 'Flat world', 'check'],
        ['caves', 'Caves', 'mult', 0, 5, 0.1], ['ores', 'Ore veins', 'mult', 0, 5, 0.1], ['lakes', 'Lakes', 'mult', 0, 10, 0.5],
        ['lavaPools', 'Lava pools', 'mult', 0, 10, 0.5], ['trees', 'Trees', 'mult', 0, 10, 0.5], ['flowers', 'Flowers', 'mult', 0, 10, 0.5],
        ['mushrooms', 'Mushrooms', 'mult', 0, 10, 0.5], ['beaches', 'Sand and gravel', 'check'],
        ['bottom', 'Bottom layer', 'select', [['lava', 'Lava (like 0.30)'], ['bedrock', 'Bedrock'], ['stone', 'Stone']]],
        ['seed', 'Seed', 'text', 'blank: random']
    ],
    render: [
        ['viewDistance', 'View distance', 'range', 16, 1024, 16], ['fog', 'Fog', 'check'], ['fov', 'Field of view', 'range', 30, 110, 1],
        ['fogColor', 'Fog colour', 'color'], ['skyColor', 'Sky colour', 'color'],
        ['clouds', 'Clouds', 'check'], ['cloudHeight', 'Cloud height', 'range', 0, 200, 0.5], ['cloudSpeed', 'Cloud speed', 'range', 0, 10, 0.1],
        ['shadeTop', 'Tops of blocks', 'shade'], ['shadeNS', 'North and south sides', 'shade'], ['shadeEW', 'East and west sides', 'shade'],
        ['shadeBottom', 'Bottoms of blocks', 'shade'], ['shadow', 'Shadows', 'shade'], ['rain', 'Rain (P)', 'check']
    ],
    player: [
        ['speed', 'Walking speed', 'mult', 0.25, 5, 0.25], ['jump', 'Jump strength', 'mult', 0.5, 3, 0.1], ['gravity', 'Gravity', 'mult', 0, 3, 0.1]
    ]
};
const SANDBOX_TABS = [['terrain', 'Terrain'], ['render', 'Rendering'], ['player', 'Player']];
const SANDBOX_NOTES = {
    terrain: 'These are used when you press Generate new level (below) or use Generate new level... in the Esc menu.',
    render: 'These change straight away. The brightness settings redraw the world when you let go.',
    player: 'These change straight away, in single player only.'
};
function buildSandboxPanel(game) {
    const css = document.createElement('style');
    css.textContent = `
.sbx { position: fixed; left: 50%; top: 50%; transform: translate(-50%, -50%); z-index: 50; width: min(560px, calc(100vw - 24px));
  max-height: calc(100vh - 24px); display: flex; flex-direction: column; box-sizing: border-box;
  background: rgba(0, 0, 0, 0.82); border: 2px solid #000; outline: 2px solid #555; color: #e0e0e0;
  font: 13px Arial, Helvetica, sans-serif; text-shadow: 1px 1px 0 #3f3f3f; }
.sbx[hidden] { display: none; }
.sbx h2 { margin: 10px 0 6px; font-size: 16px; text-align: center; color: #fff; }
.sbx .tabs { display: flex; gap: 4px; justify-content: center; padding: 0 10px 8px; }
.sbx .body { overflow-y: auto; padding: 4px 14px 6px; }
.sbx .note { margin: 2px 0 10px; color: #a0a0a0; font-size: 12px; text-align: center; }
.sbx .row { display: grid; grid-template-columns: 11em 1fr 4.5em; align-items: center; gap: 8px; min-height: 26px; }
.sbx .row label { color: #e0e0e0; }
.sbx .row .val { text-align: right; font-variant-numeric: tabular-nums; color: #ffffa0; }
.sbx input[type=range] { width: 100%; accent-color: #8b8bff; }
.sbx input[type=text], .sbx select { background: #000; color: #e0e0e0; border: 1px solid #a0a0a0; padding: 3px 5px; font: inherit; }
.sbx input[type=color] { width: 48px; height: 22px; padding: 0; border: 1px solid #a0a0a0; background: #000; }
.sbx input[type=checkbox] { width: 16px; height: 16px; accent-color: #8b8bff; justify-self: start; }
.sbx .foot { display: flex; gap: 6px; justify-content: center; flex-wrap: wrap; padding: 10px; border-top: 1px solid #333; }
.sbx button { min-width: 96px; height: 26px; padding: 0 12px; font: 13px Arial, Helvetica, sans-serif; color: #e0e0e0; cursor: pointer;
  text-shadow: 1px 1px 0 #3f3f3f; background: #6e6e6e; border: 2px solid #000;
  box-shadow: inset 2px 2px 0 #a8a8a8, inset -2px -2px 0 #484848; }
.sbx button:hover { color: #ffffa0; background: #7e86b8; box-shadow: inset 2px 2px 0 #b8c0e8, inset -2px -2px 0 #4a5070; }
.sbx button.on { color: #ffffa0; background: #555; box-shadow: inset 2px 2px 0 #333, inset -2px -2px 0 #777; }
.sbx button.go { background: #4f7f3f; box-shadow: inset 2px 2px 0 #7fb06f, inset -2px -2px 0 #2f4f27; }
@media (max-width: 480px) { .sbx .row { grid-template-columns: 8.5em 1fr 3.5em; } }`;
    document.head.append(css);
    const el = document.createElement('div'); el.className = 'sbx'; el.hidden = true;
    el.innerHTML = '<h2>Sandbox settings</h2><div class="tabs"></div><div class="body"></div><div class="foot"></div>';
    document.body.append(el);
    for (const ev of ['mousedown', 'click', 'wheel']) el.addEventListener(ev, e => e.stopPropagation());
    const tabsEl = el.querySelector('.tabs'), body = el.querySelector('.body'), foot = el.querySelector('.foot');
    let tab = 'terrain';
    const fmt = (kind, v) => kind === 'mult' ? '×' + (+v).toFixed(2).replace(/\.?0+$/, '') : kind === 'shade' ? Math.round(v * 100) + '%' : String(v);
    const draw = () => {
        tabsEl.innerHTML = '';
        for (const [id, name] of SANDBOX_TABS) {
            const b = document.createElement('button'); b.textContent = name; if (id === tab) b.className = 'on';
            b.onclick = () => { tab = id; draw(); }; tabsEl.append(b);
        }
        const S = Sandbox.s[tab];
        body.innerHTML = '';
        const note = document.createElement('p'); note.className = 'note'; note.textContent = SANDBOX_NOTES[tab]; body.append(note);
        for (const [key, name, kind, a, b2, step] of SANDBOX_FIELDS[tab]) {
            const row = document.createElement('div'); row.className = 'row';
            const id = 'sbx-' + tab + '-' + key;
            const label = document.createElement('label'); label.textContent = name; label.htmlFor = id;
            const val = document.createElement('span'); val.className = 'val';
            let input;
            const commit = v => { S[key] = v; Sandbox.save(); };
            if (kind === 'check') {
                input = document.createElement('input'); input.type = 'checkbox'; input.checked = !!S[key];
                input.onchange = () => commit(input.checked);
            } else if (kind === 'select') {
                input = document.createElement('select');
                for (const [v, t] of a) { const o = document.createElement('option'); o.value = v; o.textContent = t; input.append(o); }
                input.value = S[key]; input.onchange = () => commit(input.value);
            } else if (kind === 'text') {
                input = document.createElement('input'); input.type = 'text'; input.value = S[key]; input.placeholder = a; input.maxLength = 40;
                input.oninput = () => commit(input.value);
            } else if (kind === 'color') {
                input = document.createElement('input'); input.type = 'color'; input.value = S[key];
                input.oninput = () => { commit(input.value); val.textContent = input.value; };
                val.textContent = S[key];
            } else {
                const [lo, hi, st] = kind === 'shade' ? [0, 1, 0.05] : [a, b2, step];
                input = document.createElement('input'); input.type = 'range'; input.min = lo; input.max = hi; input.step = st; input.value = S[key];
                val.textContent = fmt(kind, S[key]);
                input.oninput = () => { val.textContent = fmt(kind, input.value); if (kind !== 'shade') commit(+input.value); };
                input.onchange = () => commit(+input.value);
            }
            input.id = id;
            row.append(label, input, val); body.append(row);
        }
        foot.innerHTML = '';
        const btn = (text, fn, cls) => { const b = document.createElement('button'); b.textContent = text; if (cls) b.className = cls; b.onclick = fn; foot.append(b); };
        if (tab === 'terrain') btn('Generate new level', () => { el.hidden = true; game.generateLevel(null, true, { sandboxSize: true }); }, 'go');
        btn('Reset ' + SANDBOX_TABS.find(t => t[0] === tab)[1].toLowerCase(), () => { Sandbox.reset(tab); draw(); });
        btn('Done', () => game.closeSandbox());
    };
    return { el, refresh: draw };
}
function isPlant(type) {
    return type === BLOCK.SAPLING || type === BLOCK.DANDELION || type === BLOCK.ROSE || type === BLOCK.BROWN_MUSHROOM || type === BLOCK.RED_MUSHROOM;
}
function isSeeThrough(type) {
    return type === BLOCK.AIR || type === BLOCK.WATER || type === BLOCK.LAVA ||
        isPlant(type) || type === BLOCK.LEAVES || type === BLOCK.BARRIER || type === BLOCK.GLASS || type === BLOCK.SLAB;
}
function tileUV(col, row, e) {
    return [col / 16 + e, 1 - (row + 1) / 16 + e, (col + 1) / 16 - e, 1 - row / 16 - e];
}
function makeGeometry(positions, uvs, colors, indices, darks) {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    if (colors) geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    if (darks && darks.length) geo.setAttribute('aDark', new THREE.Float32BufferAttribute(darks, 1));
    geo.setIndex(indices);
    return geo;
}
const srgb = (r, g, b) => new THREE.Color().setRGB(r, g, b, THREE.SRGBColorSpace);
const C12 = {
    litAmb: { value: srgb(1, 1, 1) }, darkAmb: { value: srgb(0.6, 0.6, 0.6) },
    darkFogColor: { value: srgb(14 / 255, 11 / 255, 10 / 255) }, darkFogDensity: { value: 0.01 },
    fogNear: { value: 0 }, fogFar: { value: 0 }
};
function classic012Shader(mat) {
    mat.onBeforeCompile = sh => {
        sh.uniforms.uLitAmb = C12.litAmb; sh.uniforms.uDarkAmb = C12.darkAmb;
        sh.uniforms.uDarkFogColor = C12.darkFogColor; sh.uniforms.uDarkFogDensity = C12.darkFogDensity;
        sh.uniforms.uFogNear = C12.fogNear; sh.uniforms.uFogFar = C12.fogFar;
        sh.vertexShader = 'attribute float aDark;\nvarying float vDark;\nvarying vec3 vC12View;\n' + sh.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\n    vDark = aDark;')
            .replace('#include <fog_vertex>', '#include <fog_vertex>\n    vC12View = mvPosition.xyz;');
        sh.fragmentShader = 'uniform vec3 uLitAmb;\nuniform vec3 uDarkAmb;\nuniform vec3 uDarkFogColor;\nuniform float uDarkFogDensity;\nuniform float uFogNear;\nuniform float uFogFar;\nvarying float vDark;\nvarying vec3 vC12View;\n' + sh.fragmentShader
            .replace('#include <color_fragment>', '#include <color_fragment>\n    diffuseColor.rgb *= mix(uLitAmb, uDarkAmb, vDark);')
            .replace('#include <fog_fragment>', `#ifdef USE_FOG
    float c12Density = mix(fogDensity, uDarkFogDensity, vDark);
    vec3 c12Color = mix(fogColor, uDarkFogColor, vDark);
    float c12Dist = length(vC12View);
    float c12Fog = 1.0 - exp(-c12Density * c12Dist);
    if (uFogFar > 0.0) c12Fog = max(c12Fog, smoothstep(uFogNear, uFogFar, c12Dist));
    gl_FragColor.rgb = mix(gl_FragColor.rgb, c12Color, c12Fog);
#endif`);
    };
    mat.customProgramCacheKey = () => 'classic012';
    mat.needsUpdate = true;
}
function plantCrossGeometry(col, row, e, withColors) {
    const d = 0.353553;
    const positions = [-d, -0.5, -d, d, -0.5, d, d, 0.5, d, -d, 0.5, -d, d, -0.5, -d, -d, -0.5, d, -d, 0.5, d, d, 0.5, -d];
    const [u0, v0, u1, v1] = tileUV(col, row, e);
    const uvs = [u0, v0, u1, v0, u1, v1, u0, v1, u0, v0, u1, v0, u1, v1, u0, v1];
    return makeGeometry(positions, uvs, withColors ? new Array(24).fill(1) : null, [0, 1, 2, 0, 2, 3, 4, 5, 6, 4, 6, 7]);
}
const LIQUID_INSET = 0.01;
const BLOCK_FACES = [
    { n: [0, 1, 0], c: [[0, 1, 0], [0, 1, 1], [1, 1, 1], [1, 1, 0]] },
    { n: [0, -1, 0], c: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]] },
    { n: [0, 0, 1], c: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]] },
    { n: [0, 0, -1], c: [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]] },
    { n: [1, 0, 0], c: [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]] },
    { n: [-1, 0, 0], c: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]] }
];
const MOVE_KEYS = { KeyW: 'forward', KeyS: 'backward', KeyA: 'left', KeyD: 'right', Space: 'jump' };
const SELECTABLE_BLOCKS = [BLOCK.ROCK, BLOCK.COBBLESTONE, BLOCK.BRICK, BLOCK.DIRT, BLOCK.PLANKS, BLOCK.LOG, BLOCK.LEAVES, BLOCK.GLASS,
    BLOCK.SLAB, BLOCK.MOSSY_COBBLE, BLOCK.SAPLING, BLOCK.DANDELION, BLOCK.ROSE, BLOCK.BROWN_MUSHROOM, BLOCK.RED_MUSHROOM,
    BLOCK.SAND, BLOCK.GRAVEL, BLOCK.SPONGE, ...CLOTH_BLOCKS, BLOCK.COAL_ORE, BLOCK.IRON_ORE, BLOCK.GOLD_ORE,
    BLOCK.IRON_BLOCK, BLOCK.GOLD_BLOCK, BLOCK.BOOKSHELF, BLOCK.TNT, BLOCK.OBSIDIAN];
const HOTBAR = SELECTABLE_BLOCKS.slice(0, 9);
if (CLASSIC_0011A) HOTBAR.splice(0, HOTBAR.length, BLOCK.ROCK, BLOCK.DIRT, BLOCK.COBBLESTONE, BLOCK.PLANKS, BLOCK.SAPLING);
if (CLASSIC_019) HOTBAR.splice(0, HOTBAR.length, BLOCK.ROCK, BLOCK.DIRT, BLOCK.COBBLESTONE, BLOCK.PLANKS, BLOCK.SAPLING,
    BLOCK.LOG, BLOCK.LEAVES, BLOCK.SAND, BLOCK.GRAVEL, BLOCK.SPONGE, BLOCK.GLASS);
const LIQUID_BLOCKS = [BLOCK.WATER, BLOCK.LAVA];
const EXTRA_BLOCKS = [BLOCK.WATER, BLOCK.LAVA, BLOCK.COAL_ORE, BLOCK.IRON_ORE, BLOCK.GOLD_ORE];
let seedState = BigInt(Date.now()) ^ BigInt(Math.floor(Math.random() * 0xFFFFFFFF));
function getUniqueSeed() {
    seedState = (seedState * 0x5DEECE66Dn + 0xBn) & ((1n << 48n) - 1n);
    return Number(seedState);
}
class JavaRandom {
    constructor(seed) {
        this.setSeed(seed === undefined ? getUniqueSeed() : seed);
    }
    setSeed(seed) {
        this.seed = (BigInt(seed) ^ 0x5DEECE66Dn) & ((1n << 48n) - 1n);
    }
    next(bits) {
        this.seed = (this.seed * 0x5DEECE66Dn + 0xBn) & ((1n << 48n) - 1n);
        return Number(this.seed >> (48n - BigInt(bits)));
    }
    nextInt(bound) {
        if (bound === undefined) return this.next(32) | 0;
        if ((bound & -bound) === bound) {
            return Number((BigInt(bound) * BigInt(this.next(31))) >> 31n);
        }
        let bits, val;
        do {
            bits = this.next(31);
            val = bits % bound;
        } while (bits - val + (bound - 1) < 0);
        return val;
    }
    nextFloat() {
        return this.next(24) / 16777216;
    }
}
class FastRandom {
    constructor(seed = (Math.random() * 0xFFFFFFFF) >>> 0) {
        this.s = (seed >>> 0) || 0x9E3779B9;
    }
    nextU32() {
        let x = this.s;
        x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
        this.s = x >>> 0;
        return this.s;
    }
    nextInt(bound) { return this.nextU32() % bound; }
    nextFloat() { return this.nextU32() / 4294967296; }
}
class NoiseMap {
    constructor(levels) {
        this.random = new JavaRandom();
        this.seed = this.random.nextInt();
        this.levels = 0;
        this.fuzz = 16;
        this.levels = levels;
    }
    read(width, height) {
        const random = new JavaRandom();
        const tmp = new Int32Array(width * height);
        const level = this.levels;
        let step = width >> level;
        for (let y = 0; y < height; y += step) {
            for (let x = 0; x < width; x += step) {
                tmp[x + y * width] = (random.nextInt(256) - 128) * this.fuzz;
            }
        }
        for (step = width >> level; step > 1; step = Math.trunc(step / 2)) {
            const val = 256 * (step << level);
            const ss = Math.trunc(step / 2);
            for (let y = 0; y < height; y += step) {
                for (let x = 0; x < width; x += step) {
                    const ul = tmp[(x + 0) % width + ((y + 0) % height) * width];
                    const ur = tmp[(x + step) % width + ((y + 0) % height) * width];
                    const dl = tmp[(x + 0) % width + ((y + step) % height) * width];
                    const dr = tmp[(x + step) % width + ((y + step) % height) * width];
                    const m = Math.trunc((ul + dl + ur + dr) / 4) + random.nextInt(val * 2) - val;
                    tmp[x + ss + (y + ss) * width] = m;
                }
            }
            for (let y = 0; y < height; y += step) {
                for (let x = 0; x < width; x += step) {
                    const c = tmp[x + y * width];
                    const r = tmp[(x + step) % width + y * width];
                    const d = tmp[x + ((y + step) % height) * width];
                    const mu = tmp[((x + ss) & (width - 1)) + (((y + ss - step) & (height - 1)) * width)];
                    const ml = tmp[((x + ss - step) & (width - 1)) + (((y + ss) & (height - 1)) * width)];
                    const m = tmp[(x + ss) % width + ((y + ss) % height) * width];
                    const u = Math.trunc((c + r + m + mu) / 4) + random.nextInt(val * 2) - val;
                    const l = Math.trunc((c + d + m + ml) / 4) + random.nextInt(val * 2) - val;
                    tmp[x + ss + y * width] = u;
                    tmp[x + (y + ss) * width] = l;
                }
            }
        }
        const result = new Int32Array(width * height);
        for (let y = 0; y < height; ++y) {
            for (let x = 0; x < width; ++x) {
                result[x + y * width] = Math.trunc(tmp[(x % width) + (y % height) * width] / 512) + 128;
            }
        }
        return result;
    }
}
function boxBlur(src, w, h, r) {
    const sw = w + 1;
    const sat = new Float64Array(sw * (h + 1));
    for (let z = 0; z < h; z++)
        for (let x = 0; x < w; x++)
            sat[(x + 1) + (z + 1) * sw] = src[x + z * w] + sat[x + (z + 1) * sw] + sat[(x + 1) + z * sw] - sat[x + z * sw];
    const out = new Float32Array(w * h);
    for (let z = 0; z < h; z++) {
        for (let x = 0; x < w; x++) {
            const x0 = Math.max(0, x - r), x1 = Math.min(w - 1, x + r);
            const z0 = Math.max(0, z - r), z1 = Math.min(h - 1, z + r);
            const sum = sat[(x1 + 1) + (z1 + 1) * sw] - sat[x0 + (z1 + 1) * sw]
                - sat[(x1 + 1) + z0 * sw] + sat[x0 + z0 * sw];
            out[x + z * w] = sum / ((x1 - x0 + 1) * (z1 - z0 + 1));
        }
    }
    return out;
}
function renormalize(arr) {
    let min = Infinity, max = -Infinity;
    for (let i = 0; i < arr.length; i++) { if (arr[i] < min) min = arr[i]; if (arr[i] > max) max = arr[i]; }
    const span = (max - min) || 1;
    const out = new Float32Array(arr.length);
    for (let i = 0; i < arr.length; i++) out[i] = ((arr[i] - min) / span) * 2 - 1;
    return out;
}
function normalizedNoise(levels, w, h) {
    const raw = new NoiseMap(levels).read(w, h);
    let min = Infinity, max = -Infinity;
    for (let i = 0; i < raw.length; i++) {
        if (raw[i] < min) min = raw[i];
        if (raw[i] > max) max = raw[i];
    }
    const span = (max - min) || 1;
    const out = new Float32Array(raw.length);
    for (let i = 0; i < raw.length; i++) out[i] = ((raw[i] - min) / span) * 2 - 1;
    return out;
}
const idiv = (a, b) => (a / b) | 0;
class NoiseMap0011a {
    constructor(levels) { this.fuzz = 16; this.levels = levels; }
    read(width, height) {
        const random = new JavaRandom(), tmp = new Int32Array(width * height), level = this.levels;
        let step = width >> level;
        for (let y = 0; y < height; y += step) for (let x = 0; x < width; x += step) tmp[x + y * width] = (random.nextInt(256) - 128) * this.fuzz;
        for (step = width >> level; step > 1; step = idiv(step, 2)) {
            const val = 256 * (step << level), ss = idiv(step, 2);
            for (let y = 0; y < height; y += step) for (let x = 0; x < width; x += step) {
                const ul = tmp[(x + 0) % width + (y + 0) % height * width], ur = tmp[(x + step) % width + (y + 0) % height * width];
                const dl = tmp[(x + 0) % width + (y + step) % height * width], dr = tmp[(x + step) % width + (y + step) % height * width];
                tmp[x + ss + (y + ss) * width] = idiv(ul + dl + ur + dr, 4) + random.nextInt(val * 2) - val;
            }
            for (let y = 0; y < height; y += step) for (let x = 0; x < width; x += step) {
                const c = tmp[x + y * width], r = tmp[(x + step) % width + y * width], d = tmp[x + (y + step) % width * width];
                const mu = tmp[((x + ss) & (width - 1)) + ((y + ss - step) & (height - 1)) * width];
                const ml = tmp[((x + ss - step) & (width - 1)) + ((y + ss) & (height - 1)) * width];
                const m = tmp[(x + ss) % width + (y + ss) % height * width];
                const u = idiv(c + r + m + mu, 4) + random.nextInt(val * 2) - val;
                const l = idiv(c + d + m + ml, 4) + random.nextInt(val * 2) - val;
                tmp[x + ss + y * width] = u;
                tmp[x + (y + ss) * width] = l;
            }
        }
        const result = new Int32Array(width * height);
        for (let y = 0; y < height; ++y) for (let x = 0; x < width; ++x) result[x + y * width] = idiv(tmp[x % width + y % height * width], 512) + 128;
        return result;
    }
}
class NoiseMap012 {
    constructor(random, levels, fuzz) { this.random = random; this.levels = levels; this.fuzz = fuzz; this.scale = 16; }
    read(w, h) {
        const r = this.random, a = new Int32Array(w * h), lv = this.levels, f = this.fuzz, s = this.scale;
        let step = w >> lv;
        for (let y = 0; y < h; y += step) for (let x = 0; x < w; x += step) {
            a[x + y * w] = (r.nextInt(256) - 128) * s;
            if (!f) continue;
            if (x === 0 || y === 0) { a[x + y * w] = 0; continue; }
            a[x + y * w] = (r.nextInt(192) - 64) * s;
        }
        for (step = w >> lv; step > 1; step = idiv(step, 2)) {
            const val = 256 * (step << lv), half = idiv(step, 2);
            for (let y = 0; y < h; y += step) for (let x = 0; x < w; x += step) {
                const ul = a[x % w + y % h * w], ur = a[(x + step) % w + y % h * w], dl = a[x % w + (y + step) % h * w], dr = a[(x + step) % w + (y + step) % h * w];
                a[x + half + (y + half) * w] = idiv(ul + dl + ur + dr, 4) + r.nextInt(val * 2) - val;
                if (!f || (x !== 0 && y !== 0)) continue;
                a[x + y * w] = 0;
            }
            for (let y = 0; y < h; y += step) for (let x = 0; x < w; x += step) {
                const c = a[x + y * w], rr = a[(x + step) % w + y * w], d = a[x + (y + step) % w * w];
                const mu = a[((x + half) & (w - 1)) + ((y + half - step) & (h - 1)) * w];
                const ml = a[((x + half - step) & (w - 1)) + ((y + half) & (h - 1)) * w];
                const m = a[(x + half) % w + (y + half) % h * w];
                const u = idiv(rr + c + m + mu, 4) + r.nextInt(val * 2) - val;
                const l = idiv(c + d + m + ml, 4) + r.nextInt(val * 2) - val;
                a[x + half + y * w] = u; a[x + (y + half) * w] = l;
            }
        }
        const out = new Int32Array(w * h);
        for (let y = 0; y < h; ++y) for (let x = 0; x < w; ++x) out[x + y * w] = idiv(a[x % w + y % h * w], 512) + 128;
        return out;
    }
}
class LevelGen012 {
    constructor(width, height, depth) { this.w = width; this.h = height; this.d = depth; this.random = new JavaRandom(); this.levelRandom = new JavaRandom(); }
    *generateSteps() {
        const w = this.w, h = this.h, d = this.d, r = this.random, blocks = new Uint8Array(w * h * d);
        yield ['Raising..', 0];
        const m1 = new NoiseMap012(r, 1, true).read(w, h), m2 = new NoiseMap012(r, 0, true).read(w, h);
        const m3 = new NoiseMap012(r, 2, false).read(w, h), m4 = new NoiseMap012(r, 4, false).read(w, h);
        const m5 = new NoiseMap012(r, 1, true).read(w, h);
        const sea = idiv(d, 2), tops = new Int16Array(w * h);
        for (let x = 0; x < w; ++x) {
            for (let z = 0; z < h; ++z) {
                const i0 = x + z * w;
                const a1 = m1[i0]; let a2 = m2[i0];
                if (m3[i0] < 128) a2 = a1;
                let top = Math.max(a1, a2);
                top = idiv(top - 128, 8) + sea - 1;
                let rock = idiv(idiv(m5[i0] - 128, 6) + sea + top, 2);
                if (m4[i0] < 92) top = idiv(top, 2) << 1;
                else if (m4[i0] < 160) top = idiv(top, 4) << 2;
                if (top < sea - 2) top = idiv(top - sea, 2) + sea;
                if (rock > top - 2) rock = top - 2;
                tops[i0] = top;
                for (let y = 0; y < d; ++y) {
                    let id = 0;
                    if (y === top && y >= sea) id = BLOCK.GRASS;
                    if (y < top) id = BLOCK.DIRT;
                    if (y <= rock) id = BLOCK.ROCK;
                    blocks[(y * h + z) * w + x] = id;
                }
            }
            if ((x & 15) === 0) yield ['Raising..', x / w];
        }
        yield ['Carving..', 0];
        const count = idiv(idiv(w * h * d, 256), 64);
        for (let i = 0; i < count; ++i) {
            let x = r.nextFloat() * w, y = r.nextFloat() * d, z = r.nextFloat() * h;
            const length = Math.trunc(r.nextFloat() + r.nextFloat() * 150);
            let dir1 = r.nextFloat() * Math.PI * 2, dira1 = 0, dir2 = r.nextFloat() * Math.PI * 2, dira2 = 0;
            for (let l = 0; l < length; ++l) {
                x += Math.sin(dir1) * Math.cos(dir2); z += Math.cos(dir1) * Math.cos(dir2); y += Math.sin(dir2);
                dir1 += dira1 * 0.2; dira1 *= 0.9; dira1 += r.nextFloat() - r.nextFloat();
                dir2 += dira2 * 0.5; dir2 *= 0.5; dira2 *= 0.9; dira2 += r.nextFloat() - r.nextFloat();
                const size = Math.sin(l * Math.PI / length) * 2.5 + 1;
                for (let xx = Math.trunc(x - size); xx <= Math.trunc(x + size); ++xx)
                    for (let yy = Math.trunc(y - size); yy <= Math.trunc(y + size); ++yy)
                        for (let zz = Math.trunc(z - size); zz <= Math.trunc(z + size); ++zz) {
                            const xd = xx - x, yd = yy - y, zd = zz - z;
                            if (!(xd * xd + yd * yd * 2 + zd * zd < size * size) || xx < 1 || yy < 1 || zz < 1 || xx >= w - 1 || yy >= d - 1 || zz >= h - 1) continue;
                            const ii = (yy * h + zz) * w + xx;
                            if (blocks[ii] === BLOCK.ROCK) blocks[ii] = 0;
                        }
            }
            if ((i & 15) === 0) yield ['Carving..', i / count];
        }
        yield ['Watering..', 0];
        for (let x = 0; x < w; ++x) { this.flood(blocks, x, sea - 1, 0, BLOCK.WATER); this.flood(blocks, x, sea - 1, h - 1, BLOCK.WATER); }
        for (let z = 0; z < h; ++z) { this.flood(blocks, 0, sea - 1, z, BLOCK.WATER); this.flood(blocks, w - 1, sea - 1, z, BLOCK.WATER); }
        for (let x = 0; x < w; ++x) for (let z = 0; z < h; ++z) {
            const top = tops[x + z * w];
            if (top < sea && top > 0 && blocks[(top * h + z) * w + x] === 0) this.flood(blocks, x, top, z, r.nextInt(2) === 0 ? BLOCK.WATER : BLOCK.LAVA);
        }
        yield ['Melting..', 0];
        const lr = this.levelRandom;
        for (let i = 0; i < 400; ++i) {
            const x = lr.nextInt(w), y = lr.nextInt(idiv(d, 2)), z = lr.nextInt(h);
            if (blocks[(y * h + z) * w + x] !== 0) continue;
            this.flood(blocks, x, y, z, BLOCK.LAVA);
        }
        for (let y = 0; y < d; y++) for (let z = 0; z < h; z++) for (let x = 0; x < w; x++) {
            const i = (y * h + z) * w + x;
            if (blocks[i] !== BLOCK.LAVA) continue;
            const water = (a, b, c) => a >= 0 && b >= 0 && c >= 0 && a < w && b < d && c < h && blocks[(b * h + c) * w + a] === BLOCK.WATER;
            if (water(x - 1, y, z) || water(x + 1, y, z) || water(x, y - 1, z) || water(x, y + 1, z) || water(x, y, z - 1) || water(x, y, z + 1)) blocks[i] = BLOCK.ROCK;
        }
        return blocks;
    }
    flood(b, x, y, z, id) {
        const w = this.w, h = this.h, stack = [[x, y, z]];
        while (stack.length) {
            const [cx, cy, cz] = stack.pop();
            if (cx < 0 || cz < 0 || cy < 0 || cx >= w || cz >= h || cy >= this.d) continue;
            const i = (cy * h + cz) * w + cx;
            if (b[i] !== 0) continue;
            b[i] = id;
            stack.push([cx + 1, cy, cz], [cx - 1, cy, cz], [cx, cy, cz + 1], [cx, cy, cz - 1], [cx, cy - 1, cz]);
        }
    }
}
class LevelGen0011a {
    constructor(width, height, depth) { this.width = width; this.height = height; this.depth = depth; this.random = new JavaRandom(); }
    *generateSteps() {
        const w = this.width, h = this.height, d = this.depth;
        yield ['Raising..', 0];
        const heightmap1 = new NoiseMap0011a(0).read(w, h), heightmap2 = new NoiseMap0011a(0).read(w, h);
        const cf = new NoiseMap0011a(1).read(w, h), rockMap = new NoiseMap0011a(1).read(w, h);
        const blocks = new Uint8Array(w * h * d);
        yield ['Soiling..', 0];
        for (let x = 0; x < w; ++x) {
            for (let y = 0; y < d; ++y) for (let z = 0; z < h; ++z) {
                const dh1 = heightmap1[x + z * w]; let dh2 = heightmap2[x + z * w];
                const cfh = cf[x + z * w];
                if (cfh < 128) dh2 = dh1;
                let dh = dh1; if (dh2 > dh1) dh = dh2;
                dh = idiv(dh, 8) + idiv(d, 3);
                let rh = idiv(rockMap[x + z * w], 8) + idiv(d, 3);
                if (rh > dh - 2) rh = dh - 2;
                const i = (y * h + z) * w + x;
                let id = 0;
                if (y === dh) id = BLOCK.GRASS;
                if (y < dh) id = BLOCK.DIRT;
                if (y <= rh) id = BLOCK.ROCK;
                blocks[i] = id;
            }
            if ((x & 15) === 0) yield ['Soiling..', x / w];
        }
        const count = idiv(idiv(w * h * d, 256), 64), random = this.random;
        for (let i = 0; i < count; ++i) {
            let x = random.nextFloat() * w, y = random.nextFloat() * d, z = random.nextFloat() * h;
            const length = Math.trunc(random.nextFloat() + random.nextFloat() * 150);
            let dir1 = random.nextFloat() * Math.PI * 2, dira1 = 0, dir2 = random.nextFloat() * Math.PI * 2, dira2 = 0;
            for (let l = 0; l < length; ++l) {
                x = x + Math.sin(dir1) * Math.cos(dir2);
                z = z + Math.cos(dir1) * Math.cos(dir2);
                y = y + Math.sin(dir2);
                dir1 += dira1 * 0.2; dira1 *= 0.9; dira1 += random.nextFloat() - random.nextFloat();
                dir2 += dira2 * 0.5; dir2 *= 0.5; dira2 *= 0.9; dira2 += random.nextFloat() - random.nextFloat();
                const size = Math.sin(l * Math.PI / length) * 2.5 + 1;
                for (let xx = Math.trunc(x - size); xx <= Math.trunc(x + size); ++xx)
                    for (let yy = Math.trunc(y - size); yy <= Math.trunc(y + size); ++yy)
                        for (let zz = Math.trunc(z - size); zz <= Math.trunc(z + size); ++zz) {
                            const xd = xx - x, yd = yy - y, zd = zz - z, dd = xd * xd + yd * yd * 2 + zd * zd;
                            if (dd < size * size && xx >= 1 && yy >= 1 && zz >= 1 && xx < w - 1 && yy < d - 1 && zz < h - 1) {
                                const ii = (yy * h + zz) * w + xx;
                                if (blocks[ii] === BLOCK.ROCK) blocks[ii] = 0;
                            }
                        }
            }
            if ((i & 15) === 0) yield ['Carving..', i / count];
        }
        yield ['Carving..', 1];
        return blocks;
    }
}
const C024 = { AIR: 0, STONE: 1, GRASS: 2, DIRT: 3, BEDROCK: 7, WATER: 8, STILL_WATER: 9, LAVA: 10, STILL_LAVA: 11,
    SAND: 12, GRAVEL: 13, GOLD_ORE: 14, IRON_ORE: 15, COAL_ORE: 16, LOG: 17, LEAVES: 18, DANDELION: 37, ROSE: 38,
    BROWN_MUSHROOM: 39, RED_MUSHROOM: 40 };
class ImprovedNoise024 {
    constructor(random) {
        const p = this.p = new Int32Array(512);
        for (let i = 0; i < 256; i++) p[i] = i;
        for (let i = 0; i < 256; i++) {
            const j = random.nextInt(256 - i) + i, t = p[i];
            p[i] = p[j]; p[j] = t; p[i + 256] = p[i];
        }
    }
    static fade(t) { return t * t * t * (t * (t * 6 - 15) + 10); }
    static lerp(t, a, b) { return a + t * (b - a); }
    static grad(h, x, y, z) {
        h &= 15;
        const u = h < 8 ? x : y, v = h < 4 ? y : (h === 12 || h === 14 ? x : z);
        return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
    }
    compute(x0, y0) {
        const p = this.p, F = ImprovedNoise024.fade, L = ImprovedNoise024.lerp, G = ImprovedNoise024.grad;
        let x = x0, y = y0, z = 0;
        let X = Math.floor(x) & 255, Y = Math.floor(y) & 255; const Z = 0;
        x -= Math.floor(x); y -= Math.floor(y);
        const u = F(x), v = F(y), w = F(z);
        let A = p[X] + Y; const AA = p[A] + Z, AB = p[A + 1] + Z;
        X = p[X + 1] + Y; const BA = p[X] + Z, BB = p[X + 1] + Z;
        return L(w, L(v, L(u, G(p[AA], x, y, z), G(p[BA], x - 1, y, z)), L(u, G(p[AB], x, y - 1, z), G(p[BB], x - 1, y - 1, z))),
            L(v, L(u, G(p[AA + 1], x, y, z - 1), G(p[BA + 1], x - 1, y, z - 1)), L(u, G(p[AB + 1], x, y - 1, z - 1), G(p[BB + 1], x - 1, y - 1, z - 1))));
    }
}
class PerlinNoise024 {
    constructor(random, octaves) { this.n = []; for (let i = 0; i < octaves; i++) this.n.push(new ImprovedNoise024(random)); }
    compute(x, y) { let r = 0, s = 1; for (const n of this.n) { r += n.compute(x / s, y / s) * s; s *= 2; } return r; }
}
class Distort024 {
    constructor(a, b) { this.a = a; this.b = b; }
    compute(x, y) { return this.a.compute(x + this.b.compute(x, y), y); }
}
class LevelGen024 {
    constructor(width, height, seed, T = null) {
        this.T = T || {};
        this.w = width; this.h = height; this.d = 64; this.water = T ? Math.max(4, Math.min(60, T.seaLevel | 0)) : 32;
        this.random = new JavaRandom(seed); this.treeRandom = new JavaRandom(seed == null ? undefined : seed + 1);
    }
    idx(x, y, z) { return (y * this.h + z) * this.w + x; }
    *generateSteps() {
        const w = this.w, h = this.h, d = this.d, r = this.random, f = this.f = new Uint8Array(w * h * d);
        const nf = () => r.nextFloat(), P = (n) => new PerlinNoise024(r, n);
        yield ['Raising..', 0];
        const heights = new Int32Array(w * h);
        {
            const a = new Distort024(P(8), P(8)), b = new Distort024(P(8), P(8)), c = P(6);
            for (let x = 0; x < w; ++x) {
                for (let z = 0; z < h; ++z) {
                    const low = a.compute(x * 1.3, z * 1.3) / 6 - 4;
                    let high = b.compute(x * 1.3, z * 1.3) / 5 + 10 - 4;
                    if (c.compute(x, z) / 8 > 0) high = low;
                    let hh = Math.max(low, high) / 2;
                    if (hh < 0) hh *= 0.8;
                    if (this.T.hills != null) hh *= this.T.hills;
                    if (this.T.flat) hh = 0;
                    heights[x + z * w] = Math.trunc(hh);
                }
                if ((x & 15) === 0) yield ['Raising..', x / w];
            }
        }
        yield ['Eroding..', 0];
        {
            const a = new Distort024(P(8), P(8)), b = new Distort024(P(8), P(8));
            for (let x = 0; x < w; ++x) {
                for (let z = 0; z < h; ++z) {
                    const e = a.compute(x << 1, z << 1) / 8, s = b.compute(x << 1, z << 1) > 0 ? 1 : 0;
                    if (!(e > 2)) continue;
                    const i = x + z * w;
                    heights[i] = Math.trunc((heights[i] - s) / 2) * 2 + s;
                }
                if ((x & 15) === 0) yield ['Eroding..', x / w];
            }
        }
        yield ['Soiling..', 0];
        {
            const n = P(8);
            for (let x = 0; x < w; ++x) {
                for (let z = 0; z < h; ++z) {
                    const off = this.T.flat ? -4 : Math.trunc(n.compute(x, z) / 24) - 4, i = x + z * w;
                    const dirtTop = heights[i] + this.water, rockTop = dirtTop + off;
                    heights[i] = Math.max(dirtTop, rockTop);
                    if (heights[i] > d - 2) heights[i] = d - 2;
                    if (heights[i] < 1) heights[i] = 1;
                    for (let y = 0; y < d; ++y) {
                        let t = 0;
                        if (y <= dirtTop) t = C024.DIRT;
                        if (y <= rockTop) t = C024.STONE;
                        if (y === 0) t = SURVIVAL_024 ? C024.BEDROCK : this.T.bottom === 'bedrock' ? C024.BEDROCK : this.T.bottom === 'stone' ? C024.STONE : C024.LAVA;
                        f[this.idx(x, y, z)] = t;
                    }
                }
                if ((x & 15) === 0) yield ['Soiling..', x / w];
            }
        }
        yield ['Carving..', 0];
        {
            const count = Math.floor(((w * h * d / 256 / 64 | 0) << 1) * (this.T.caves ?? 1));
            for (let i = 0; i < count; ++i) {
                let x = nf() * w, y = nf() * d, z = nf() * h;
                const len = Math.trunc((nf() + nf()) * 200);
                let dir1 = nf() * Math.PI * 2, dd1 = 0, dir2 = nf() * Math.PI * 2, dd2 = 0;
                const size = nf() * nf();
                for (let l = 0; l < len; ++l) {
                    x += Math.sin(dir1) * Math.cos(dir2); z += Math.cos(dir1) * Math.cos(dir2); y += Math.sin(dir2);
                    dir1 += dd1 * 0.2; dd1 *= 0.9; dd1 += nf() - nf();
                    dir2 += dd2 * 0.5; dir2 *= 0.5; dd2 *= 0.75; dd2 += nf() - nf();
                    if (nf() < 0.25) continue;
                    const cx = x + (nf() * 4 - 2) * 0.2, cy = y + (nf() * 4 - 2) * 0.2, cz = z + (nf() * 4 - 2) * 0.2;
                    let rad = (d - cy) / d;
                    rad = 1.2 + (rad * 3.5 + 1) * size;
                    rad = Math.sin(l * Math.PI / len) * rad;
                    this.carve(cx, cy, cz, rad, C024.STONE, 0, 2);
                }
                if ((i & 15) === 0) yield ['Carving..', i / count / 4];
            }
            this.ore(C024.COAL_ORE, 90); yield ['Carving..', 0.5];
            this.ore(C024.IRON_ORE, 70); yield ['Carving..', 0.75];
            this.ore(C024.GOLD_ORE, 50); yield ['Carving..', 1];
        }
        yield ['Watering..', 0];
        {
            const sea = this.water - 1;
            for (let x = 0; x < w; ++x) { this.flood(x, sea, 0, C024.STILL_WATER); this.flood(x, sea, h - 1, C024.STILL_WATER); }
            for (let z = 0; z < h; ++z) { this.flood(0, sea, z, C024.STILL_WATER); this.flood(w - 1, sea, z, C024.STILL_WATER); }
            const n = Math.floor((w * h / 8000 | 0) * (this.T.lakes ?? 1));
            for (let i = 0; i < n; ++i) {
                const x = r.nextInt(w), y = this.water - 1 - r.nextInt(2), z = r.nextInt(h);
                if (f[this.idx(x, y, z)] !== 0) continue;
                this.flood(x, y, z, C024.STILL_WATER);
            }
        }
        yield ['Melting..', 0];
        {
            const n = Math.floor((w * h * d / 20000 | 0) * (this.T.lavaPools ?? 1));
            for (let i = 0; i < n; ++i) {
                const x = r.nextInt(w), y = Math.trunc(nf() * nf() * (this.water - 3)), z = r.nextInt(h);
                if (f[this.idx(x, y, z)] !== 0) continue;
                this.flood(x, y, z, C024.STILL_LAVA);
            }
        }
        yield ['Growing..', 0];
        {
            const sandN = P(8), gravelN = P(8);
            for (let x = 0; x < w; ++x) {
                for (let z = 0; z < h; ++z) {
                    const beaches = this.T.beaches ?? true;
                    const sand = beaches && sandN.compute(x, z) > 8, gravel = beaches && gravelN.compute(x, z) > 12;
                    const y = heights[x + z * w], i = this.idx(x, y, z), above = f[this.idx(x, y + 1, z)];
                    if ((above === C024.WATER || above === C024.STILL_WATER) && y <= this.water - 1 && gravel) f[i] = C024.GRAVEL;
                    if (above !== 0) continue;
                    f[i] = (y <= this.water - 1 && sand) ? C024.SAND : C024.GRASS;
                }
            }
        }
        yield ['Planting..', 0];
        {
            const n = Math.floor((w * h / 3000 | 0) * (this.T.flowers ?? 1));
            for (let i = 0; i < n; ++i) {
                const type = r.nextInt(2), x0 = r.nextInt(w), z0 = r.nextInt(h);
                for (let j = 0; j < 10; ++j) {
                    let x = x0, z = z0;
                    for (let k = 0; k < 5; ++k) {
                        if ((type >= 2 && r.nextInt(4) !== 0) || (x += r.nextInt(6) - r.nextInt(6)) < 0 || (z += r.nextInt(6) - r.nextInt(6)) < 0 || x >= w || z >= h) continue;
                        const y = heights[x + z * w] + 1;
                        if (f[this.idx(x, y, z)] !== 0) continue;
                        if (f[this.idx(x, y - 1, z)] !== C024.GRASS) continue;
                        f[this.idx(x, y, z)] = type === 0 ? C024.DANDELION : C024.ROSE;
                    }
                }
            }
            const m = Math.floor((w * h * d / 2000 | 0) * (this.T.mushrooms ?? 1));
            for (let i = 0; i < m; ++i) {
                const type = r.nextInt(2), x0 = r.nextInt(w), y0 = r.nextInt(d), z0 = r.nextInt(h);
                for (let j = 0; j < 20; ++j) {
                    let x = x0, y = y0, z = z0;
                    for (let k = 0; k < 5; ++k) {
                        if ((type >= 2 && r.nextInt(4) !== 0) || (x += r.nextInt(6) - r.nextInt(6)) < 0 || (z += r.nextInt(6) - r.nextInt(6)) < 0
                            || (y += r.nextInt(2) - r.nextInt(2)) < 1 || x >= w || z >= h || y >= heights[x + z * w] - 1 || f[this.idx(x, y, z)] !== 0) continue;
                        if (f[this.idx(x, y - 1, z)] !== C024.STONE) continue;
                        f[this.idx(x, y, z)] = type === 0 ? C024.BROWN_MUSHROOM : C024.RED_MUSHROOM;
                    }
                }
                if ((i & 63) === 0) yield ['Planting..', 0.5 * i / m];
            }
            const t = Math.floor((w * h / 4000 | 0) * (this.T.trees ?? 1));
            for (let i = 0; i < t; ++i) {
                const x0 = r.nextInt(w), z0 = r.nextInt(h);
                for (let j = 0; j < 20; ++j) {
                    let x = x0, z = z0;
                    for (let k = 0; k < 20; ++k) {
                        if ((x += r.nextInt(6) - r.nextInt(6)) < 0 || (z += r.nextInt(6) - r.nextInt(6)) < 0 || x >= w || z >= h) continue;
                        const y = heights[x + z * w] + 1;
                        if (r.nextInt(4) !== 0) continue;
                        this.maybeGrowTree(x, y, z);
                    }
                }
            }
            yield ['Planting..', 1];
        }
        return this.toGameBlocks();
    }
    carve(cx, cy, cz, rad, from, to, ySquash) {
        const f = this.f;
        for (let x = Math.trunc(cx - rad); x <= Math.trunc(cx + rad); ++x)
            for (let y = Math.trunc(cy - rad); y <= Math.trunc(cy + rad); ++y)
                for (let z = Math.trunc(cz - rad); z <= Math.trunc(cz + rad); ++z) {
                    const dx = x - cx, dy = y - cy, dz = z - cz;
                    if (!(dx * dx + dy * dy * ySquash + dz * dz < rad * rad) || x < 1 || y < 1 || z < 1 || x >= this.w - 1 || y >= this.d - 1 || z >= this.h - 1) continue;
                    const i = this.idx(x, y, z);
                    if (f[i] !== from) continue;
                    f[i] = to;
                }
    }
    ore(type, density) {
        const r = this.random, nf = () => r.nextFloat();
        const count = Math.floor(((this.w * this.h * this.d / 256 / 64 | 0) * density / 100 | 0) * (this.T.ores ?? 1));
        for (let i = 0; i < count; ++i) {
            let x = nf() * this.w, y = nf() * this.d, z = nf() * this.h;
            const len = Math.trunc((nf() + nf()) * 75 * density / 100);
            let dir1 = nf() * Math.PI * 2, dd1 = 0, dir2 = nf() * Math.PI * 2, dd2 = 0;
            for (let l = 0; l < len; ++l) {
                x += Math.sin(dir1) * Math.cos(dir2); z += Math.cos(dir1) * Math.cos(dir2); y += Math.sin(dir2);
                dir1 += dd1 * 0.2; dd1 *= 0.9; dd1 += nf() - nf();
                dir2 += dd2 * 0.5; dir2 *= 0.5; dd2 *= 0.9; dd2 += nf() - nf();
                const rad = Math.sin(l * Math.PI / len) * density / 100 + 1;
                this.carve(x, y, z, rad, C024.STONE, type, 2);
            }
        }
    }
    flood(x0, y0, z0, type) {
        const f = this.f, w = this.w, h = this.h, layer = w * h, lava = type === C024.LAVA || type === C024.STILL_LAVA;
        const stack = [this.idx(x0, y0, z0)];
        while (stack.length) {
            const i = stack.pop();
            if (f[i] !== 0) continue;
            f[i] = type;
            const x = i % w, z = (i / w | 0) % h, y = i / layer | 0;
            if (x > 0 && f[i - 1] === 0) stack.push(i - 1);
            if (x < w - 1 && f[i + 1] === 0) stack.push(i + 1);
            if (z > 0 && f[i - w] === 0) stack.push(i - w);
            if (z < h - 1 && f[i + w] === 0) stack.push(i + w);
            if (y > 0) {
                const below = f[i - layer];
                if (lava && (below === C024.WATER || below === C024.STILL_WATER)) f[i - layer] = C024.STONE;
                else if (below === 0) stack.push(i - layer);
            }
        }
    }
    maybeGrowTree(x, y, z) {
        const f = this.f, r = this.treeRandom, th = r.nextInt(3) + 4;
        let ok = true;
        for (let yy = y; yy <= y + 1 + th; ++yy) {
            let rr = 1;
            if (yy === y) rr = 0;
            if (yy >= y + 1 + th - 2) rr = 2;
            for (let xx = x - rr; xx <= x + rr && ok; ++xx)
                for (let zz = z - rr; zz <= z + rr && ok; ++zz) {
                    if (xx >= 0 && yy >= 0 && zz >= 0 && xx < this.w && yy < this.d && zz < this.h) { if (f[this.idx(xx, yy, zz)] !== 0) ok = false; }
                    else ok = false;
                }
        }
        if (!ok) return false;
        if (f[this.idx(x, y - 1, z)] !== C024.GRASS || y >= this.d - th - 1) return false;
        f[this.idx(x, y - 1, z)] = C024.DIRT;
        for (let yy = y - 3 + th; yy <= y + th; ++yy) {
            const dy = yy - (y + th), rr = 1 - Math.trunc(dy / 2);
            for (let xx = x - rr; xx <= x + rr; ++xx)
                for (let zz = z - rr; zz <= z + rr; ++zz) {
                    if (Math.abs(xx - x) === rr && Math.abs(zz - z) === rr && (r.nextInt(2) === 0 || dy === 0)) continue;
                    f[this.idx(xx, yy, zz)] = C024.LEAVES;
                }
        }
        for (let i = 0; i < th; ++i) f[this.idx(x, y + i, z)] = C024.LOG;
        return true;
    }
    toGameBlocks() {
        const map = new Uint8Array(256);
        const pairs = [[C024.STONE, BLOCK.ROCK], [C024.GRASS, BLOCK.GRASS], [C024.DIRT, BLOCK.DIRT], [C024.BEDROCK, BLOCK.BEDROCK],
            [C024.WATER, BLOCK.WATER], [C024.STILL_WATER, BLOCK.WATER], [C024.LAVA, BLOCK.LAVA], [C024.STILL_LAVA, BLOCK.LAVA],
            [C024.SAND, BLOCK.SAND], [C024.GRAVEL, BLOCK.GRAVEL], [C024.GOLD_ORE, BLOCK.GOLD_ORE], [C024.IRON_ORE, BLOCK.IRON_ORE],
            [C024.COAL_ORE, BLOCK.COAL_ORE], [C024.LOG, BLOCK.LOG], [C024.LEAVES, BLOCK.LEAVES], [C024.DANDELION, BLOCK.DANDELION],
            [C024.ROSE, BLOCK.ROSE], [C024.BROWN_MUSHROOM, BLOCK.BROWN_MUSHROOM], [C024.RED_MUSHROOM, BLOCK.RED_MUSHROOM]];
        for (const [c, g] of pairs) map[c] = g;
        const f = this.f, out = new Uint8Array(f.length);
        for (let i = 0; i < f.length; i++) out[i] = map[f[i]];
        return out;
    }
}
class LevelGen023 extends LevelGen024 {
    *generateSteps() {
        const w = this.w, h = this.h, d = this.d, r = this.random, f = this.f = new Uint8Array(w * h * d);
        const nf = () => r.nextFloat(), P = (n) => new PerlinNoise024(r, n);
        yield ['Raising..', 0];
        const heights = new Int32Array(w * h);
        {
            const a = new Distort024(P(8), P(8)), b = new Distort024(P(8), P(8)), c = P(8);
            for (let x = 0; x < w; ++x) {
                for (let z = 0; z < h; ++z) {
                    const low = a.compute(x * 1.3, z * 1.3) / 8 - 8;
                    let high = b.compute(x * 1.3, z * 1.3) / 6 + 6;
                    if (c.compute(x, z) / 8 > 0) high = low;
                    let hh = Math.max(low, high) / 2;
                    if (hh < 0) hh *= this.v18 ? 0.5 : 0.8;
                    heights[x + z * w] = Math.trunc(hh);
                }
                if ((x & 15) === 0) yield ['Raising..', x / w];
            }
        }
        yield ['Eroding..', 0];
        {
            const a = new Distort024(P(8), P(8)), b = new Distort024(P(8), P(8));
            for (let x = 0; x < w; ++x) {
                for (let z = 0; z < h; ++z) {
                    const e = a.compute(x << 1, z << 1) / 8, s = b.compute(x << 1, z << 1) > 0 ? 1 : 0;
                    if (!(e > 2)) continue;
                    const i = x + z * w;
                    heights[i] = Math.trunc((heights[i] - s) / 2) * 2 + s;
                }
                if ((x & 15) === 0) yield ['Eroding..', x / w];
            }
        }
        yield ['Soiling..', 0];
        {
            const n = P(8);
            for (let x = 0; x < w; ++x) {
                for (let z = 0; z < h; ++z) {
                    const off = Math.trunc(n.compute(x, z) / 24) - 4, i = x + z * w;
                    const dirtTop = heights[i] + d / 2, rockTop = dirtTop + off;
                    heights[i] = Math.max(dirtTop, rockTop);
                    for (let y = 0; y < d; ++y) {
                        let t = 0;
                        if (y <= dirtTop) t = C024.DIRT;
                        if (y <= rockTop) t = C024.STONE;
                        f[this.idx(x, y, z)] = t;
                    }
                }
                if ((x & 15) === 0) yield ['Soiling..', x / w];
            }
        }
        yield ['Carving..', 0];
        {
            const count = w * h * d / 256 / 64 | 0;
            for (let i = 0; i < count; ++i) {
                let x = nf() * w, y = nf() * d, z = nf() * h;
                const len = Math.trunc((nf() + nf()) * 75);
                let dir1 = nf() * Math.PI * 2, dd1 = 0, dir2 = nf() * Math.PI * 2, dd2 = 0;
                for (let l = 0; l < len; ++l) {
                    x += Math.sin(dir1) * Math.cos(dir2); z += Math.cos(dir1) * Math.cos(dir2); y += Math.sin(dir2);
                    dir1 += dd1 * 0.2; dd1 *= 0.9; dd1 += nf() - nf();
                    dir2 += dd2 * 0.5; dir2 *= 0.5; dd2 *= 0.9; dd2 += nf() - nf();
                    const rad = Math.sin(l * Math.PI / len) * 2.5 + 1;
                    if (this.v18) { this.carve(x, y, z, rad, C024.STONE, 0, 2); continue; }
                    if (nf() < 0.3) continue;
                    const cx = x + nf() * 4 - 2, cy = y + nf() * 4 - 2, cz = z + nf() * 4 - 2;
                    this.carve(cx, cy, cz, rad, C024.STONE, 0, 2);
                }
                if ((i & 15) === 0) yield ['Carving..', i / count / 4];
            }
            this.ore(C024.COAL_ORE, 90); yield ['Carving..', 0.5];
            this.ore(C024.IRON_ORE, 70); yield ['Carving..', 0.75];
            this.ore(C024.GOLD_ORE, 50); yield ['Carving..', 1];
        }
        yield ['Watering..', 0];
        {
            for (let x = 0; x < w; ++x) { this.flood(x, d / 2 - 1, 0, C024.STILL_WATER); this.flood(x, d / 2 - 1, h - 1, C024.STILL_WATER); }
            for (let z = 0; z < h; ++z) { this.flood(0, d / 2 - 1, z, C024.STILL_WATER); this.flood(w - 1, d / 2 - 1, z, C024.STILL_WATER); }
            const n = w * h / 200 | 0;
            for (let i = 0; i < n; ++i) {
                const x = r.nextInt(w), y = d / 2 - 1 - r.nextInt(3), z = r.nextInt(h);
                if (f[this.idx(x, y, z)] !== 0) continue;
                this.flood(x, y, z, C024.STILL_WATER);
                if (i % 100 === 0) yield ['Watering..', i / n];
            }
        }
        yield ['Melting..', 0];
        {
            const n = w * h * d / 10000 | 0;
            for (let i = 0; i < n; ++i) {
                const x = r.nextInt(w), y = r.nextInt(d / 2 - 4), z = r.nextInt(h);
                if (f[this.idx(x, y, z)] !== 0) continue;
                this.flood(x, y, z, C024.STILL_LAVA);
            }
        }
        yield ['Growing..', 0];
        {
            const sandN = P(8), gravelN = P(8);
            for (let x = 0; x < w; ++x) {
                for (let z = 0; z < h; ++z) {
                    const sand = sandN.compute(x, z) > 8, gravel = gravelN.compute(x, z) > 12;
                    const y = heights[x + z * w], i = this.idx(x, y, z), above = f[this.idx(x, y + 1, z)];
                    if ((above === C024.WATER || above === C024.STILL_WATER) && y <= d / 2 - 1 && gravel) f[i] = C024.GRAVEL;
                    if (above !== 0) continue;
                    f[i] = (y <= d / 2 - 1 && sand) ? C024.SAND : C024.GRASS;
                }
            }
        }
        yield ['Planting..', 0];
        {
            const t = w * h / 4000 | 0;
            for (let i = 0; i < t; ++i) {
                const x0 = r.nextInt(w), z0 = r.nextInt(h);
                for (let j = 0; j < 20; ++j) {
                    let x = x0, z = z0;
                    for (let k = 0; k < 20; ++k) {
                        if ((x += r.nextInt(6) - r.nextInt(6)) < 0 || (z += r.nextInt(6) - r.nextInt(6)) < 0 || x >= w || z >= h) continue;
                        this.plantTree(x, heights[x + z * w] + 1, z);
                    }
                }
                if ((i & 7) === 0) yield ['Planting..', i / t];
            }
        }
        return this.toGameBlocks();
    }
    plantTree(x, y, z) {
        const f = this.f, r = this.random, th = r.nextInt(3) + 4;
        let ok = true;
        for (let yy = y; yy <= y + 1 + th; ++yy) {
            const rr = yy >= y + 1 + th - 2 ? 2 : 1;
            for (let xx = x - rr; xx <= x + rr && ok; ++xx)
                for (let zz = z - rr; zz <= z + rr && ok; ++zz) {
                    if (xx >= 0 && yy >= 0 && zz >= 0 && xx < this.w && yy < this.d && zz < this.h) { if (f[this.idx(xx, yy, zz)] !== 0) ok = false; }
                    else ok = false;
                }
        }
        if (!ok) return;
        if (f[this.idx(x, y - 1, z)] !== C024.GRASS || y >= this.d - th - 1) return;
        f[this.idx(x, y - 1, z)] = C024.DIRT;
        for (let yy = y - 3 + th; yy <= y + th; ++yy) {
            const dy = yy - (y + th), rr = 1 - Math.trunc(dy / 2);
            for (let xx = x - rr; xx <= x + rr; ++xx)
                for (let zz = z - rr; zz <= z + rr; ++zz) {
                    if (Math.abs(xx - x) === rr && Math.abs(zz - z) === rr && (r.nextInt(2) === 0 || dy === 0)) continue;
                    f[this.idx(xx, yy, zz)] = C024.LEAVES;
                }
        }
        for (let i = 0; i < th; ++i) f[this.idx(x, y + i, z)] = C024.LOG;
    }
}
class LevelGen019 extends LevelGen023 {
    constructor(width, height, seed) { super(width, height, seed); this.v18 = true; }
}
function generateNow(gen) {
    const it = gen.generateSteps();
    for (;;) { const r = it.next(); if (r.done) return r.value; }
}
class LevelGen {
    constructor(width, height, depth) {
        this.width = width;
        this.height = height;
        this.depth = depth;
        this.random = new JavaRandom();
    }
    generateMap() {
        const steps = this.generateSteps();
        let r = steps.next();
        while (!r.done) r = steps.next();
        return r.value;
    }
    *generateSteps() {
        const w = this.width, h = this.height, d = this.depth;
        const n = w * h;
        const WATER_TOP = SEA_LEVEL - 1;
        const lv = (size) => Math.max(0, Math.min(6, Math.round(Math.log2(w / size))));
        const heightmap1 = new NoiseMap(lv(128)).read(w, h);
        const heightmap2 = new NoiseMap(lv(128)).read(w, h);
        const cf = new NoiseMap(lv(64)).read(w, h);
        const lakeN = normalizedNoise(lv(32), w, h);
        const roughN = normalizedNoise(lv(32), w, h);
        const cliffN = renormalize(boxBlur(normalizedNoise(lv(64), w, h), w, h, CLIFF_SMOOTHING));
        const smallCliffN = renormalize(boxBlur(normalizedNoise(lv(32), w, h), w, h, 3));
        const floorGravelN = normalizedNoise(lv(32), w, h);
        const seaFloorN = renormalize(boxBlur(normalizedNoise(lv(32), w, h), w, h, 2));
        const seaDetailN = normalizedNoise(lv(16), w, h);
        const dirtN = normalizedNoise(lv(16), w, h);
        const beachMaskN = normalizedNoise(lv(64), w, h);
        yield ['Raising..', 0];
        const combined = new Float32Array(n);
        for (let i = 0; i < n; i++) {
            const dh1 = heightmap1[i];
            let dh2 = heightmap2[i];
            if (cf[i] < 128) dh2 = dh1;
            combined[i] = Math.max(dh1, dh2);
        }
        const sortedC = Float32Array.from(combined).sort();
        const lo = sortedC[Math.floor(n * 0.02)], hi = sortedC[Math.floor(n * 0.98)];
        const span = (hi - lo) || 1;
        const raw = new Float32Array(n);
        for (let z = 0; z < h; z++) {
            for (let x = 0; x < w; x++) {
                const i = x + z * w;
                let v = ((combined[i] - lo) / span) * 2 - 1;
                v += lakeN[i] * 0.45;
                v += roughN[i] * 0.12;
                raw[i] = v;
            }
        }
        const sorted = Float32Array.from(raw).sort();
        const threshold = sorted[Math.floor(n * WATER_FRACTION)];
        const peak = sorted[Math.floor(n * 0.995)];
        const step = Math.max(1e-6, (peak - threshold) / TERRAIN_MAX);
        const terrace = new Int32Array(n);
        const land = new Uint8Array(n);
        for (let i = 0; i < n; i++) {
            terrace[i] = Math.floor((raw[i] - threshold) / step);
            land[i] = terrace[i] >= 0 ? 1 : 0;
        }
        yield ['Eroding..', 0];
        const ocean = new Uint8Array(n);
        for (let i = 0; i < n; i++) ocean[i] = land[i] ? 0 : 1;
        const queue = new Int32Array(n);
        const neighbours4 = (i) => {
            const x = i % w, z = (i / w) | 0;
            return [
                x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1,
                z > 0 ? i - w : -1, z < h - 1 ? i + w : -1
            ];
        };
        const growPatch = (start, mark, list, ok) => {
            let ph = 0, pt = 0;
            mark[start] = 1; list[pt++] = start;
            while (ph < pt) {
                const i = list[ph++];
                for (const j of neighbours4(i)) if (j >= 0 && !mark[j] && ok(j, i)) { mark[j] = 1; list[pt++] = j; }
            }
            return pt;
        };
        const visited = new Uint8Array(n);
        const patch = new Int32Array(n);
        const removeSmallPatches = (mask, other, minSize) => {
            visited.fill(0);
            for (let start = 0; start < n; start++) {
                if (!mask[start] || visited[start]) continue;
                const pt = growPatch(start, visited, patch, j => mask[j]);
                if (pt < minSize) {
                    for (let k = 0; k < pt; k++) { mask[patch[k]] = 0; other[patch[k]] = 1; }
                }
            }
        };
        removeSmallPatches(ocean, land, MIN_LAKE_SIZE);
        removeSmallPatches(land, ocean, MIN_ISLAND_SIZE);
        const bfs = (isSource) => {
            const dist = new Int32Array(n).fill(-1);
            let bh = 0, bt = 0;
            for (let i = 0; i < n; i++) {
                if (isSource(i)) { dist[i] = 0; queue[bt++] = i; }
            }
            while (bh < bt) {
                const i = queue[bh++];
                const x = i % w, z = (i / w) | 0;
                for (let dz = -1; dz <= 1; dz++) {
                    for (let dx = -1; dx <= 1; dx++) {
                        if (dx === 0 && dz === 0) continue;
                        const nx = x + dx, nz = z + dz;
                        if (nx < 0 || nz < 0 || nx >= w || nz >= h) continue;
                        const j = nx + nz * w;
                        if (dist[j] < 0) { dist[j] = dist[i] + 1; queue[bt++] = j; }
                    }
                }
            }
            return dist;
        };
        const distToOcean = bfs(i => ocean[i] === 1);
        const distToLand = bfs(i => land[i] === 1);
        const heights = new Int32Array(n);
        for (let i = 0; i < n; i++) {
            if (ocean[i]) {
                const dl = distToLand[i] < 0 ? 30 : distToLand[i];
                const base = 1 + Math.min(dl, 12) / 12 * (MAX_WATER_DEPTH - 2.5);
                let depth = Math.round(base + seaFloorN[i] * 1.6 + seaDetailN[i] * 0.6);
                depth = Math.max(1, Math.min(depth, MAX_WATER_DEPTH));
                heights[i] = WATER_TOP - depth;
            } else {
                let hh = WATER_TOP + Math.max(0, terrace[i]);
                const dist = distToOcean[i] < 0 ? 50 : distToOcean[i];
                if (dist >= CLIFF_SHORE_DIST) {
                    for (const t of CLIFF_LEVELS) if (cliffN[i] > t) hh += CLIFF_STEP;
                    for (const t of SMALL_CLIFF_LEVELS) if (smallCliffN[i] > t) hh += SMALL_CLIFF_STEP;
                }
                heights[i] = Math.min(hh, d - 3);
            }
        }
        for (let pass = 0; pass < 2; pass++) {
            const src = Int32Array.from(heights);
            for (let z = 0; z < h; z++) {
                for (let x = 0; x < w; x++) {
                    const i = x + z * w;
                    let mn = Infinity, mx = -Infinity, cnt = 0;
                    const check = (nx, nz) => {
                        if (nx < 0 || nz < 0 || nx >= w || nz >= h) return;
                        const j = nx + nz * w;
                        if (ocean[j] !== ocean[i]) return;
                        const v = src[j];
                        if (v < mn) mn = v;
                        if (v > mx) mx = v;
                        cnt++;
                    };
                    check(x - 1, z); check(x + 1, z); check(x, z - 1); check(x, z + 1);
                    if (cnt < 2) continue;
                    if (src[i] > mx) heights[i] = mx;
                    else if (src[i] < mn) heights[i] = mn;
                }
            }
        }
        yield ['Watering..', 0];
        const sortedB = Float32Array.from(beachMaskN).sort();
        const beachCutoff = sortedB[Math.floor(n * (1 - BEACH_COVERAGE))];
        const isBeach = new Uint8Array(n);
        for (let i = 0; i < n; i++) {
            if (ocean[i]) continue;
            const hh = heights[i];
            if (beachMaskN[i] >= beachCutoff && distToOcean[i] <= BEACH_WIDTH &&
                hh >= WATER_TOP && hh <= WATER_TOP + BEACH_MAX_ABOVE_WATER) {
                isBeach[i] = 1;
            }
        }
        {
            const beachTop = WATER_TOP + BEACH_MAX_ABOVE_WATER;
            let bh = 0, bt = 0;
            for (let i = 0; i < n; i++) if (isBeach[i]) queue[bt++] = i;
            while (bh < bt) {
                const i = queue[bh++];
                for (const j of neighbours4(i)) {
                    if (j < 0 || ocean[j] || isBeach[j]) continue;
                    if (heights[j] > beachTop || distToOcean[j] > BEACH_WIDTH + 6) continue;
                    isBeach[j] = 1;
                    queue[bt++] = j;
                }
            }
        }
        for (let pass = 0; pass < 8; pass++) {
            let changed = 0;
            for (let i = 0; i < n; i++) {
                if (ocean[i] || isBeach[i]) continue;
                const nb = neighbours4(i);
                const sandy = (j) => j >= 0 && (isBeach[j] || ocean[j]);
                let sandN = 0, beachN4 = 0;
                for (const j of nb) {
                    if (sandy(j)) sandN++;
                    if (j >= 0 && isBeach[j]) beachN4++;
                }
                const sandwiched = (sandy(nb[0]) && sandy(nb[1])) || (sandy(nb[2]) && sandy(nb[3]));
                if (beachN4 >= 1 && (sandN >= 3 || sandwiched) && (beachN4 >= 2 || sandwiched)) {
                    isBeach[i] = 1;
                    if (heights[i] > WATER_TOP + BEACH_MAX_ABOVE_WATER) heights[i] = WATER_TOP + BEACH_MAX_ABOVE_WATER;
                    changed++;
                }
            }
            if (!changed) break;
        }
        const shelfDist = new Int32Array(n).fill(-1);
        {
            let sh = 0, st = 0;
            for (let i = 0; i < n; i++) if (isBeach[i]) { shelfDist[i] = 0; queue[st++] = i; }
            while (sh < st) {
                const i = queue[sh++];
                if (shelfDist[i] >= SHELF_WIDTH) continue;
                for (const j of neighbours4(i)) {
                    if (j >= 0 && ocean[j] && shelfDist[j] < 0) {
                        shelfDist[j] = shelfDist[i] + 1;
                        queue[st++] = j;
                    }
                }
            }
        }
        const isShelf = new Uint8Array(n);
        for (let i = 0; i < n; i++) {
            if (!ocean[i] || shelfDist[i] <= 0) continue;
            const shelfH = WATER_TOP - 1 - Math.floor((shelfDist[i] - 1) / 2);
            if (shelfH > heights[i]) heights[i] = shelfH;
            isShelf[i] = 1;
        }
        yield ['Soiling..', 0];
        const fill = new Int32Array(n).fill(-1);
        const buckets = [];
        for (let k = 0; k < d; k++) buckets.push([]);
        for (let i = 0; i < n; i++) {
            if (ocean[i]) { fill[i] = WATER_TOP; buckets[WATER_TOP].push(i); }
        }
        for (let lvl = 0; lvl < d; lvl++) {
            const bucket = buckets[lvl];
            while (bucket.length) {
                const i = bucket.pop();
                for (const j of neighbours4(i)) {
                    if (j < 0 || fill[j] >= 0) continue;
                    fill[j] = Math.max(heights[j], lvl);
                    buckets[fill[j]].push(j);
                }
            }
        }
        const isGravel = new Uint8Array(n);
        const holeSeen = new Uint8Array(n);
        const holeCols = new Int32Array(n);
        for (let start = 0; start < n; start++) {
            if (ocean[start] || holeSeen[start] || fill[start] <= heights[start]) continue;
            let hh2 = 0, ht = 0;
            holeSeen[start] = 1; holeCols[ht++] = start;
            let minH = heights[start];
            while (hh2 < ht) {
                const i = holeCols[hh2++];
                if (heights[i] < minH) minH = heights[i];
                for (const j of neighbours4(i)) {
                    if (j >= 0 && !ocean[j] && !holeSeen[j] && fill[j] > heights[j]) {
                        holeSeen[j] = 1; holeCols[ht++] = j;
                    }
                }
            }
            if (ht > GRAVEL_MAX_HOLE) continue;
            for (let k = 0; k < ht; k++) {
                const i = holeCols[k];
                if (heights[i] === minH && !isBeach[i]) isGravel[i] = 1;
            }
        }
        const sortedFG = Float32Array.from(floorGravelN).sort();
        const floorGravelCut = sortedFG[Math.floor(n * (1 - GRAVEL_FLOOR_COVERAGE))];
        const surface = new Uint8Array(n);
        for (let i = 0; i < n; i++) {
            if (ocean[i]) {
                if (isShelf[i]) surface[i] = BLOCK.SAND;
                else surface[i] = floorGravelN[i] > floorGravelCut ? BLOCK.GRAVEL : BLOCK.DIRT;
            }
            else if (isBeach[i]) surface[i] = BLOCK.SAND;
            else if (isGravel[i]) surface[i] = BLOCK.GRAVEL;
            else surface[i] = BLOCK.GRASS;
        }
        const PR = PLATEAU_FLAT_RADIUS;
        const flatArea = new Uint8Array(n);
        for (let z = PR; z < h - PR; z++) {
            for (let x = PR; x < w - PR; x++) {
                const i = x + z * w;
                if (ocean[i]) continue;
                const hh = heights[i];
                let flat = true;
                for (let dz = -PR; dz <= PR && flat; dz++) {
                    for (let dx = -PR; dx <= PR; dx++) {
                        const j = i + dx + dz * w;
                        if (ocean[j] || heights[j] !== hh) { flat = false; break; }
                    }
                }
                if (!flat) continue;
                for (let dz = -PR; dz <= PR; dz++)
                    for (let dx = -PR; dx <= PR; dx++) flatArea[i + dx + dz * w] = 1;
            }
        }
        {
            const seen = new Uint8Array(n);
            const cols = new Int32Array(n);
            for (let start = 0; start < n; start++) {
                if (!flatArea[start] || seen[start]) continue;
                const hh = heights[start];
                let ct = growPatch(start, seen, cols, j => flatArea[j] && heights[j] === hh);
                if (ct < PLATEAU_MIN_SIZE || ct > PLATEAU_MAX_SIZE) continue;
                if (this.random.nextFloat() >= PLATEAU_CHANCE) continue;
                const dist = new Map();
                for (let k = 0; k < ct; k++) dist.set(cols[k], 0);
                let gh = 0;
                while (gh < ct) {
                    const i = cols[gh++];
                    const di = dist.get(i);
                    if (di >= PLATEAU_EDGE_SPREAD) continue;
                    for (const j of neighbours4(i)) {
                        if (j >= 0 && !ocean[j] && !dist.has(j) && heights[j] === hh) {
                            dist.set(j, di + 1);
                            cols[ct++] = j;
                        }
                    }
                }
                for (let k = 0; k < ct; k++) surface[cols[k]] = BLOCK.GRAVEL;
            }
        }
        {
            const seen = new Uint8Array(n);
            const patchCols = new Int32Array(n);
            for (let start = 0; start < n; start++) {
                if (surface[start] !== BLOCK.GRAVEL || seen[start]) continue;
                const wet = ocean[start];
                let onCliff = false;
                const pt = growPatch(start, seen, patchCols, (j, i) => {
                    if (surface[j] === BLOCK.GRAVEL && ocean[j] === wet) return true;
                    if (heights[j] < heights[i] && (wet || !ocean[j])) onCliff = true;
                    return false;
                });
                if (!onCliff) continue;
                for (let k = 0; k < pt; k++) surface[patchCols[k]] = wet ? BLOCK.DIRT : BLOCK.GRASS;
            }
        }
        const blocks = new Uint8Array(w * h * d);
        for (let x = 0; x < w; ++x) {
            if ((x & 7) === 0) yield ['Soiling..', x / w];
            for (let z = 0; z < h; ++z) {
                const col = x + z * w;
                const dh = heights[col];
                const surf = surface[col];
                const dirtDepth = 2 + Math.floor((dirtN[col] + 1) * 1.5);
                const rh = Math.max(1, dh - dirtDepth);
                const subDepth = surf === BLOCK.SAND ? (ocean[col] ? 2 : 3) : 0;
                for (let y = 0; y < d; ++y) {
                    const i = (y * h + z) * w + x;
                    let id = BLOCK.AIR;
                    if (y === 0) {
                        id = BLOCK.BEDROCK;
                    } else if (y < dh) {
                        if (y <= rh) id = BLOCK.ROCK;
                        else if (y >= dh - subDepth) id = surf;
                        else id = BLOCK.DIRT;
                    } else if (y === dh) {
                        id = surf;
                    } else if (y < SEA_LEVEL) {
                        id = BLOCK.WATER;
                    }
                    blocks[i] = id;
                }
            }
        }
        const count = Math.trunc(Math.trunc(w * h * d / 256) / 64);
        for (let i = 0; i < count; ++i) {
            if ((i & 15) === 0) yield ['Carving..', i / count];
            let x = this.random.nextFloat() * w;
            let y = this.random.nextFloat() * d;
            let z = this.random.nextFloat() * h;
            const length = Math.trunc(this.random.nextFloat() + this.random.nextFloat() * 150.0);
            let dir1 = this.random.nextFloat() * Math.PI * 2.0, dira1 = 0.0;
            let dir2 = this.random.nextFloat() * Math.PI * 2.0, dira2 = 0.0;
            for (let l = 0; l < length; ++l) {
                x += Math.sin(dir1) * Math.cos(dir2);
                z += Math.cos(dir1) * Math.cos(dir2);
                y += Math.sin(dir2);
                dir1 += dira1 * 0.2;
                dira1 = dira1 * 0.9 + (this.random.nextFloat() - this.random.nextFloat());
                dir2 = (dir2 + dira2 * 0.5) * 0.5;
                dira2 = dira2 * 0.9 + (this.random.nextFloat() - this.random.nextFloat());
                const size = Math.sin(l * Math.PI / length) * 2.5 + 1.0;
                for (let xx = Math.trunc(x - size); xx <= Math.trunc(x + size); ++xx) {
                    for (let yy = Math.trunc(y - size); yy <= Math.trunc(y + size); ++yy) {
                        for (let zz = Math.trunc(z - size); zz <= Math.trunc(z + size); ++zz) {
                            const xd = xx - x, yd = yy - y, zd = zz - z;
                            if (xd * xd + yd * yd * 2.0 + zd * zd < size * size &&
                                xx >= 1 && yy >= 1 && zz >= 1 &&
                                xx < w - 1 && yy < d - 1 && zz < h - 1) {
                                const ii = (yy * h + zz) * w + xx;
                                if (blocks[ii] === BLOCK.ROCK) blocks[ii] = BLOCK.AIR;
                            }
                        }
                    }
                }
            }
        }
        const ores = [
            [BLOCK.COAL_ORE, 90, SEA_LEVEL + 20],
            [BLOCK.IRON_ORE, 70, SEA_LEVEL + 20],
            [BLOCK.GOLD_ORE, 50, SEA_LEVEL + 20]
        ];
        for (const [ore, abundance, maxY] of ores) {
            yield ['Carving..', 1];
            this.placeOreVeins(blocks, ore, abundance, maxY);
        }
        const meltTries = Math.floor(w * h * d / 20000);
        for (let i = 0; i < meltTries; i++) {
            const x = this.random.nextInt(w);
            const y = Math.trunc(this.random.nextFloat() * this.random.nextFloat() * (SEA_LEVEL - 3));
            const z = this.random.nextInt(h);
            if (blocks[(y * h + z) * w + x] === BLOCK.AIR) this.floodDown(blocks, x, y, z, BLOCK.LAVA);
            if (i % 100 === 0) yield ['Melting..', i / meltTries];
        }
        yield ['Melting..', 1];
        yield ['Planting..', 0];
        this.plantTrees(blocks);
        yield ['Planting..', 1];
        return blocks;
    }
    floodDown(blocks, x, y, z, id) {
        const w = this.width, h = this.height, d = this.depth;
        const stack = [(y * h + z) * w + x];
        while (stack.length) {
            const i = stack.pop();
            if (blocks[i] !== BLOCK.AIR) continue;
            blocks[i] = id;
            const xx = i % w, zz = Math.floor(i / w) % h, yy = Math.floor(i / (w * h));
            if (xx > 0) stack.push(i - 1);
            if (xx < w - 1) stack.push(i + 1);
            if (zz > 0) stack.push(i - w);
            if (zz < h - 1) stack.push(i + w);
            if (yy > 0) stack.push(i - w * h);
        }
    }
    placeOreVeins(blocks, ore, abundance, maxY) {
        const w = this.width, h = this.height, d = this.depth;
        const rockLayers = Math.min(d, maxY);
        const count = Math.trunc(w * h * rockLayers / 256 / 64 * abundance / 100);
        for (let i = 0; i < count; i++) {
            let x = this.random.nextFloat() * w;
            let y = this.random.nextFloat() * rockLayers;
            let z = this.random.nextFloat() * h;
            const length = Math.trunc((this.random.nextFloat() + this.random.nextFloat()) * 75 * abundance / 100);
            let dir1 = this.random.nextFloat() * Math.PI * 2, dira1 = 0;
            let dir2 = this.random.nextFloat() * Math.PI * 2, dira2 = 0;
            for (let l = 0; l < length; l++) {
                x += Math.sin(dir1) * Math.cos(dir2);
                z += Math.cos(dir1) * Math.cos(dir2);
                y += Math.sin(dir2);
                dir1 += dira1 * 0.2;
                dira1 = dira1 * 0.9 + (this.random.nextFloat() - this.random.nextFloat());
                dir2 = (dir2 + dira2 * 0.5) * 0.5;
                dira2 = dira2 * 0.9 + (this.random.nextFloat() - this.random.nextFloat());
                const size = Math.sin(l * Math.PI / length) * abundance / 100 + 1;
                for (let xx = Math.trunc(x - size); xx <= Math.trunc(x + size); xx++) {
                    for (let yy = Math.trunc(y - size); yy <= Math.trunc(y + size); yy++) {
                        for (let zz = Math.trunc(z - size); zz <= Math.trunc(z + size); zz++) {
                            const xd = xx - x, yd = yy - y, zd = zz - z;
                            if (xd * xd + yd * yd * 2 + zd * zd >= size * size) continue;
                            if (xx < 1 || yy < 1 || zz < 1 || xx >= w - 1 || yy >= d - 1 || zz >= h - 1) continue;
                            const ii = (yy * h + zz) * w + xx;
                            if (blocks[ii] === BLOCK.ROCK) blocks[ii] = ore;
                        }
                    }
                }
            }
        }
    }
    plantTrees(blocks) {
        const w = this.width, h = this.height, d = this.depth;
        const idx = (x, y, z) => (y * h + z) * w + x;
        const groves = Math.trunc(w * h / 4000);
        for (let g = 0; g < groves; g++) {
            const gx = this.random.nextInt(w);
            const gz = this.random.nextInt(h);
            for (let j = 0; j < 20; j++) {
                let x = gx, z = gz;
                for (let k = 0; k < 20; k++) {
                    x += this.random.nextInt(6) - this.random.nextInt(6);
                    z += this.random.nextInt(6) - this.random.nextInt(6);
                    if (x < 2 || z < 2 || x >= w - 2 || z >= h - 2) continue;
                    if (this.random.nextFloat() >= 0.25) continue;
                    let y = d - 1;
                    while (y > 0 && blocks[idx(x, y, z)] === BLOCK.AIR) y--;
                    if (blocks[idx(x, y, z)] !== BLOCK.GRASS) continue;
                    const height = this.random.nextInt(2) + 4;
                    this.growTree(blocks, x, y + 1, z, height);
                }
            }
        }
    }
    growTree(blocks, x, y, z, height) {
        const w = this.width, h = this.height, d = this.depth;
        const idx = (xx, yy, zz) => (yy * h + zz) * w + xx;
        const top = y + height;
        if (top >= d || x < 1 || z < 1 || x >= w - 1 || z >= h - 1) return false;
        for (let yy = y; yy <= top; yy++) {
            const r = yy >= top - 2 ? 1 : 0;
            for (let xx = x - r; xx <= x + r; xx++)
                for (let zz = z - r; zz <= z + r; zz++)
                    if (blocks[idx(xx, yy, zz)] !== BLOCK.AIR) return false;
        }
        blocks[idx(x, y - 1, z)] = BLOCK.DIRT;
        for (let yy = top - 2; yy <= top - 1; yy++)
            for (let xx = x - 1; xx <= x + 1; xx++)
                for (let zz = z - 1; zz <= z + 1; zz++)
                    blocks[idx(xx, yy, zz)] = BLOCK.LEAVES;
        blocks[idx(x, top, z)] = BLOCK.LEAVES;
        blocks[idx(x - 1, top, z)] = BLOCK.LEAVES;
        blocks[idx(x + 1, top, z)] = BLOCK.LEAVES;
        blocks[idx(x, top, z - 1)] = BLOCK.LEAVES;
        blocks[idx(x, top, z + 1)] = BLOCK.LEAVES;
        for (let yy = y; yy < y + height; yy++) blocks[idx(x, yy, z)] = BLOCK.LOG;
        return true;
    }
}
class Level {
    constructor(w, h, d, blocks) {
        this.width = w; this.height = h; this.depth = d;
        this.lightDepths = new Int32Array(w * h);
        this.levelListeners = [];
        this.activeLiquids = new Map();
        this.flow = CLASSIC_0011A ? new Uint8Array(this.width * this.height * this.depth) : null;
        this.classicTickCount = 0;
        this.liquidQueues = { 500: [], 1000: [] };
        this.liquidHeads = { 500: 0, 1000: 0 };
        this.random = new FastRandom();
        if (blocks) {
            this.blocks = blocks;
        } else {
            console.log('Running LevelGen...');
            this.blocks = new LevelGen(w, h, d).generateMap();
            console.log('LevelGen done.');
        }
        this.calcLightDepths(0, 0, w, h);
    }
    calcLightDepths(x0, z0, x1, z1) {
        for (let x = x0; x < x0 + x1; ++x) {
            for (let z = z0; z < z0 + z1; ++z) {
                const oldDepth = this.lightDepths[x + z * this.width];
                let y = this.depth - 1;
                while (y > 0 && !this.isLightBlocker(x, y, z)) y--;
                this.lightDepths[x + z * this.width] = y;
                if (oldDepth !== y) {
                    const yl0 = oldDepth < y ? oldDepth : y;
                    const yl1 = oldDepth > y ? oldDepth : y;
                    for (let i = 0; i < this.levelListeners.length; i++) {
                        if (this.levelListeners[i].lightColumnChanged)
                            this.levelListeners[i].lightColumnChanged(x, z, yl0, yl1);
                    }
                }
            }
        }
    }
    hasAdjacentAir(x, y, z) {
        if (this.getTile(x - 1, y, z) === BLOCK.AIR) return true;
        if (this.getTile(x + 1, y, z) === BLOCK.AIR) return true;
        if (this.getTile(x, y - 1, z) === BLOCK.AIR) return true;
        if (this.getTile(x, y, z - 1) === BLOCK.AIR) return true;
        if (this.getTile(x, y, z + 1) === BLOCK.AIR) return true;
        return false;
    }
    enqueueLiquid(x, y, z, type, now) {
        if (CLASSIC_0011A) return;
        const other = type === BLOCK.WATER ? BLOCK.LAVA : BLOCK.WATER;
        const touchesOther = [[-1, 0, 0], [1, 0, 0], [0, -1, 0], [0, 1, 0], [0, 0, -1], [0, 0, 1]]
            .some(([dx, dy, dz]) => this.getTile(x + dx, y + dy, z + dz) === other);
        if (!this.hasAdjacentAir(x, y, z) && !touchesOther) return;
        const idx = (y * this.height + z) * this.width + x;
        if (this.activeLiquids.has(idx)) return;
        const delay = (type === BLOCK.WATER) ? 500 : 1000;
        this.activeLiquids.set(idx, now + delay);
        this.liquidQueues[delay].push(idx, now + delay);
    }
    addListener(l) { this.levelListeners.push(l); }
    isLightBlocker(x, y, z) {
        const type = this.getTile(x, y, z);
        return type !== BLOCK.AIR && !isPlant(type) && type !== BLOCK.WATER && type !== BLOCK.LEAVES && type !== BLOCK.BARRIER && type !== BLOCK.GLASS;
    }
    setTile(x, y, z, type, force = false) {
        if (x < 0 || y < 0 || z < 0 || x >= this.width || y >= this.depth || z >= this.height) return false;
        if (y === 0 && !force && !CLASSIC_0011A) return false;
        const index = (y * this.height + z) * this.width + x;
        if (this.blocks[index] === type) return false;
        this.blocks[index] = type;
        this.calcLightDepths(x, z, 1, 1);
        const now = performance.now();
        if (type === BLOCK.WATER || type === BLOCK.LAVA) {
            this.enqueueLiquid(x, y, z, type, now);
        }
        const neighbors = [
            [x - 1, y, z], [x + 1, y, z],
            [x, y - 1, z], [x, y + 1, z],
            [x, y, z - 1], [x, y, z + 1]
        ];
        for (const [nx, ny, nz] of neighbors) {
            if (nx >= 0 && ny >= 0 && nz >= 0 && nx < this.width && ny < this.depth && nz < this.height) {
                const nt = this.blocks[(ny * this.height + nz) * this.width + nx];
                if (nt === BLOCK.WATER || nt === BLOCK.LAVA) {
                    this.enqueueLiquid(nx, ny, nz, nt, now);
                }
            }
        }
        for (let i = 0; i < this.levelListeners.length; i++) {
            if (this.levelListeners[i].tileChanged) this.levelListeners[i].tileChanged(x, y, z);
        }
        if ((type === BLOCK.SAND || type === BLOCK.GRAVEL) && !CLASSIC_0011A && this.fallsInto(this.getTile(x, y - 1, z))) {
            let ny = y - 1;
            while (ny > 0 && this.fallsInto(this.getTile(x, ny - 1, z))) ny--;
            this.setTile(x, y, z, BLOCK.AIR);
            this.setTile(x, ny, z, type);
            return true;
        }
        if (!CLASSIC_0011A && (type === BLOCK.AIR || this.fallsInto(type))) {
            const above = this.getTile(x, y + 1, z);
            if (above === BLOCK.SAND || above === BLOCK.GRAVEL) this.setTile(x, y + 1, z, above);
        }
        if (type === BLOCK.SLAB && this.getTile(x, y - 1, z) === BLOCK.SLAB) {
            this.setTile(x, y, z, BLOCK.AIR);
            this.setTile(x, y - 1, z, BLOCK.DOUBLE_SLAB);
            return true;
        }
        if (type === BLOCK.SPONGE) {
            for (let dx = -2; dx <= 2; dx++) for (let dy = -2; dy <= 2; dy++) for (let dz = -2; dz <= 2; dz++)
                if (this.getTile(x + dx, y + dy, z + dz) === BLOCK.WATER) this.setTile(x + dx, y + dy, z + dz, BLOCK.AIR);
        }
        if (this.flow) {
            if (type !== BLOCK.WATER && type !== BLOCK.LAVA) this.flow[index] = 0;
            this.classicNeighbours(x, y, z);
        }
        return true;
    }
    isLiquid(t) { return t === BLOCK.WATER || t === BLOCK.LAVA; }
    flowAt(x, y, z) { return this.flow[(y * this.height + z) * this.width + x]; }
    setClassicLiquid(x, y, z, type, flowing) {
        if (x < 0 || y < 0 || z < 0 || x >= this.width || y >= this.depth || z >= this.height) return false;
        const i = (y * this.height + z) * this.width + x, f = flowing ? 1 : 0;
        if (this.blocks[i] === type && this.flow[i] === f) return false;
        this.flow[i] = f;
        if (this.blocks[i] !== type) this.setTile(x, y, z, type);
        else this.classicNeighbours(x, y, z);
        return true;
    }
    classicNeighbours(x, y, z) {
        const t = this.getTile(x, y, z), flowing = this.isLiquid(t) && this.flowAt(x, y, z) === 1;
        for (const [dx, dy, dz] of [[-1, 0, 0], [1, 0, 0], [0, -1, 0], [0, 1, 0], [0, 0, -1], [0, 0, 1]])
            this.classicNeighbourChanged(x + dx, y + dy, z + dz, t, flowing);
    }
    classicNeighbourChanged(x, y, z, changed, changedFlowing) {
        if (x < 0 || y < 0 || z < 0 || x >= this.width || y >= this.depth || z >= this.height) return;
        const t = this.getTile(x, y, z);
        if (!this.isLiquid(t)) return;
        if (!this.flowAt(x, y, z)) {
            const air = (a, b, c) => this.getTile(a, b, c) === BLOCK.AIR;
            if (air(x - 1, y, z) || air(x + 1, y, z) || air(x, y, z - 1) || air(x, y, z + 1) || air(x, y - 1, z)) this.setClassicLiquid(x, y, z, t, true);
        }
        if (changedFlowing && ((t === BLOCK.WATER && changed === BLOCK.LAVA) || (t === BLOCK.LAVA && changed === BLOCK.WATER)))
            this.setTile(x, y, z, BLOCK.ROCK);
    }
    classicFlow(x, y, z, depth, type) {
        const water = type === BLOCK.WATER, reach = water ? 8 : 2;
        let changed = false, cy = y;
        while (this.getTile(x, cy - 1, z) === BLOCK.AIR && cy - 1 >= 0) { cy--; if (this.setClassicLiquid(x, cy, z, type, true)) changed = true; }
        if (water || !changed) {
            for (const [dx, dz] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
                const nx = x + dx, nz = z + dz;
                if (this.getTile(nx, cy, nz) === BLOCK.AIR && nx >= 0 && nz >= 0 && nx < this.width && nz < this.height) {
                    const placed = this.setClassicLiquid(nx, cy, nz, type, true);
                    if (placed && depth < reach) changed = this.classicFlow(nx, cy, nz, depth + 1, type) || changed;
                }
            }
        }
        if (!changed) this.setClassicLiquid(x, cy, z, type, false);
        return changed;
    }
    classicLiquidTicks() {
        this.classicTickCount += this.width * this.height * this.depth;
        const n = Math.floor(this.classicTickCount / 200);
        this.classicTickCount -= n * 200;
        for (let k = 0; k < n; k++) {
            const x = (Math.random() * this.width) | 0, y = (Math.random() * this.depth) | 0, z = (Math.random() * this.height) | 0;
            const i = (y * this.height + z) * this.width + x, t = this.blocks[i];
            if ((t === BLOCK.WATER || t === BLOCK.LAVA) && this.flow[i]) this.classicFlow(x, y, z, 0, t);
        }
    }
    fallsInto(t) { return t === BLOCK.AIR || t === BLOCK.WATER || t === BLOCK.LAVA; }
    nearSponge(x, y, z) {
        for (let dx = -2; dx <= 2; dx++) for (let dy = -2; dy <= 2; dy++) for (let dz = -2; dz <= 2; dz++)
            if (this.getTile(x + dx, y + dy, z + dz) === BLOCK.SPONGE) return true;
        return false;
    }
    isLit(x, y, z) {
        if (x < 0 || y < 0 || z < 0 || x >= this.width || y >= this.depth || z >= this.height) return true;
        return y >= this.lightDepths[x + z * this.width];
    }
    getTile(x, y, z) {
        if (x < 0 || y < 0 || z < 0 || x >= this.width || y >= this.depth || z >= this.height) return BLOCK.AIR;
        return this.blocks[(y * this.height + z) * this.width + x];
    }
    isSolidTile(x, y, z) {
        if (x < 0 || z < 0 || x >= this.width || z >= this.height) return true;
        if (y < 0) return true;
        const type = this.getTile(x, y, z);
        return type !== BLOCK.AIR && !isPlant(type) && type !== BLOCK.WATER && type !== BLOCK.LAVA;
    }
    isUnderwater(x, y, z) {
        for (let cy = y + 1; cy < this.depth; ++cy) {
            const t = this.getTile(x, cy, z);
            if (t === BLOCK.WATER) return true;
            if (t !== BLOCK.AIR && !isPlant(t)) return false;
        }
        return false;
    }
    tick(now, random = true) {
        if (this.flow) this.classicLiquidTicks();
        const toProcess = [];
        for (const delay of [500, 1000]) {
            const q = this.liquidQueues[delay];
            let h = this.liquidHeads[delay];
            while (h < q.length && q[h + 1] <= now) { if (this.activeLiquids.get(q[h]) === q[h + 1]) toProcess.push(q[h]); h += 2; }
            if (h > 4096 && h * 2 > q.length) { q.splice(0, h); h = 0; }
            this.liquidHeads[delay] = h;
        }
        for (const idx of toProcess) {
            this.activeLiquids.delete(idx);
            const x = idx % this.width;
            const z = Math.trunc(idx / this.width) % this.height;
            const y = Math.trunc(idx / (this.width * this.height));
            const type = this.blocks[idx];
            if (type !== BLOCK.WATER && type !== BLOCK.LAVA) continue;
            const other = type === BLOCK.WATER ? BLOCK.LAVA : BLOCK.WATER;
            const checkAndSpread = (nx, ny, nz) => {
                if (nx < 0 || ny < 0 || nz < 0 || nx >= this.width || ny >= this.depth || nz >= this.height) return;
                if (this.liquidBlocked && this.liquidBlocked(nx, ny, nz)) return;
                if (type === BLOCK.WATER && this.nearSponge(nx, ny, nz)) return;
                const nb = this.blocks[(ny * this.height + nz) * this.width + nx];
                if (nb === BLOCK.AIR) this.setTile(nx, ny, nz, type);
                else if (nb === other) this.setTile(nx, ny, nz, BLOCK.ROCK);
            };
            if (y + 1 < this.depth && this.blocks[((y + 1) * this.height + z) * this.width + x] === other) this.setTile(x, y + 1, z, BLOCK.ROCK);
            checkAndSpread(x, y - 1, z);
            checkAndSpread(x - 1, y, z);
            checkAndSpread(x + 1, y, z);
            checkAndSpread(x, y, z - 1);
            checkAndSpread(x, y, z + 1);
        }
        const numTicks = random ? 14000 : 0;
        for (let i = 0; i < numTicks; i++) {
            const x = this.random.nextInt(this.width);
            const z = this.random.nextInt(this.height);
            const y = this.random.nextInt(this.depth);
            const type = this.getTile(x, y, z);
            if (type === BLOCK.DIRT) {
                if (this.isLit(x, y, z) && !this.isUnderwater(x, y, z)) {
                    this.setTile(x, y, z, BLOCK.GRASS);
                }
            } else if (type === BLOCK.GRASS) {
                if (!this.isLit(x, y, z) || this.isUnderwater(x, y, z)) {
                    this.setTile(x, y, z, BLOCK.DIRT);
                }
            }
        }
    }
}
class ChunkMeshBuilder {
    constructor(level, solidMaterial, waterMaterial, lavaMaterial, plantMaterial, glassMaterial) {
        this.level = level;
        this.glassMaterial = glassMaterial || solidMaterial;
        this.solidMaterial = solidMaterial;
        this.plantMaterial = plantMaterial || solidMaterial;
        this.waterMaterial = waterMaterial;
        this.lavaMaterial = lavaMaterial;
    }
    buildChunkMesh(cx, cy, cz) {
        const y0 = cy * CHUNK_SIZE, y1 = Math.min(this.level.depth, y0 + CHUNK_SIZE);
        const buffer = () => ({ p: [], u: [], c: [], i: [], k: CLASSIC_0011A ? [] : null, used: false });
        const solid = buffer(), water = buffer(), lava = buffer(), plant = buffer(), glass = buffer();
        for (let lx = 0; lx < CHUNK_SIZE; lx++) {
            for (let y = y0; y < y1; y++) {
                for (let lz = 0; lz < CHUNK_SIZE; lz++) {
                    const wx = cx * CHUNK_SIZE + lx, wz = cz * CHUNK_SIZE + lz;
                    const type = this.level.getTile(wx, y, wz);
                    if (type === BLOCK.AIR || type === BLOCK.BARRIER) continue;
                    if (isPlant(type)) this.addPlantFaces(plant, type, wx, y, wz);
                    else if (type === BLOCK.WATER) this.addLiquidFaces(water, type, wx, y, wz);
                    else if (type === BLOCK.LAVA) this.addLiquidFaces(lava, type, wx, y, wz);
                    else {
                        const b = CLASSIC_019 && type === BLOCK.GLASS ? glass : solid;
                        b.used = true;
                        for (const f of BLOCK_FACES) this.addFace(b, type, wx, y, wz, f);
                    }
                }
            }
        }
        const parts = [[plant, this.plantMaterial], [solid, this.solidMaterial], [lava, this.lavaMaterial], [water, this.waterMaterial], [glass, this.glassMaterial]];
        if (!parts.some(([b]) => b.used)) return null;
        const group = new THREE.Group();
        for (const [b, material] of parts) {
            if (!b.used) continue;
            const mesh = new THREE.Mesh(makeGeometry(b.p, b.u, b.c, b.i, b.k), material);
            if (b === water || b === glass || (CLASSIC_0011A && b === lava)) mesh.renderOrder = 1;
            group.add(mesh);
        }
        group.matrixAutoUpdate = false;
        group.updateMatrix();
        for (const child of group.children) {
            child.matrixAutoUpdate = false;
            child.updateMatrix();
        }
        return group;
    }
    pushQuad(b, f, x, y, yTop, z, col, row, light, halfSide = false, dark = 0) {
        const idx = b.p.length / 3;
        if (b.k) b.k.push(dark, dark, dark, dark);
        for (const [ox, oy, oz] of f.c) b.p.push(x + ox, oy ? yTop : y, z + oz);
        let [u0, v0, u1, v1] = tileUV(col, row, 0.0005);
        if (halfSide) v1 = (v0 + v1) / 2;
        if (f.n[1] === 1) b.u.push(u0, v1, u0, v0, u1, v0, u1, v1);
        else b.u.push(u0, v0, u1, v0, u1, v1, u0, v1);
        const lc = shade(light);
        for (let k = 0; k < 4; k++) b.c.push(lc, lc, lc);
        b.i.push(idx, idx + 1, idx + 2, idx, idx + 2, idx + 3);
    }
    liquidTop(x, y, z) {
        const above = this.level.getTile(x, y + 1, z);
        return above === BLOCK.WATER || above === BLOCK.LAVA || this.level.isSolidTile(x, y + 1, z) ? 1 : 15 / 16;
    }
    addLiquidFaces(b, type, wx, y, wz) {
        b.used = true;
        const [col, row] = BLOCK_UVS[type];
        if (CLASSIC_0011A) {
            for (const f of BLOCK_FACES) {
                const [nx, ny, nz] = f.n;
                const nb = this.level.getTile(wx + nx, y + ny, wz + nz);
                if (nb === type || (this.level.isSolidTile(wx + nx, y + ny, wz + nz) && !(isSeeThrough(nb) && !(nb === BLOCK.SLAB && ny === 1)))) continue;
                this.pushQuad(b, f, wx, y - 0.1, y + 0.9, wz, col, row, ny === 1 ? FACE_SHADE.top : FACE_SHADE.northSouth);
            }
            return;
        }
        const top = y + this.liquidTop(wx, y, wz);
        for (const f of BLOCK_FACES) {
            const [nx, ny, nz] = f.n, x2 = wx + nx, y2 = y + ny, z2 = wz + nz;
            const nb = this.level.getTile(x2, y2, z2);
            let y0 = y, inset = 0;
            if ((nb === BLOCK.WATER || nb === BLOCK.LAVA) && (nb === type || type === BLOCK.WATER)) {
                if (ny !== 0) continue;
                const nTop = y + this.liquidTop(x2, y2, z2);
                if (nTop >= top - 1e-6) continue;
                y0 = nTop;
            } else if (this.level.isSolidTile(x2, y2, z2)) {
                if (!isSeeThrough(nb) || (nb === BLOCK.SLAB && ny === 1)) continue;
                inset = LIQUID_INSET;
            } else if (ny === -1 && y2 < 0) continue;
            let light = ny === 1 ? FACE_SHADE.top : ny === -1 ? FACE_SHADE.bottom : nz !== 0 ? FACE_SHADE.northSouth : FACE_SHADE.eastWest;
            if (type === BLOCK.WATER) light *= this.level.isLit(wx, y + 1, wz) ? 1.0 : SHADOW_SHADE;
            this.pushLiquidQuad(b, f, wx, y, y0, top, wz, col, row, light, inset);
        }
    }
    pushLiquidQuad(b, f, wx, y, y0, y1, wz, col, row, light, inset) {
        const idx = b.p.length / 3, [nx, ny, nz] = f.n;
        if (b.k) b.k.push(0, 0, 0, 0);
        for (const [ox, oy, oz] of f.c) b.p.push(wx + ox - nx * inset, (oy ? y1 : y0) - ny * inset, wz + oz - nz * inset);
        const [u0, v0, u1, v1] = tileUV(col, row, 0.0005);
        if (ny === 1) b.u.push(u0, v1, u0, v0, u1, v0, u1, v1);
        else if (ny === -1) b.u.push(u0, v0, u1, v0, u1, v1, u0, v1);
        else {
            const vb = v0 + (v1 - v0) * (y0 - y), vt = v0 + (v1 - v0) * (y1 - y);
            b.u.push(u0, vb, u1, vb, u1, vt, u0, vt);
        }
        const lc = shade(light);
        for (let k = 0; k < 4; k++) b.c.push(lc, lc, lc);
        b.i.push(idx, idx + 1, idx + 2, idx, idx + 2, idx + 3);
    }
    addPlantFaces(b, type, wx, y, wz) {
        b.used = true;
        const idx = b.p.length / 3;
        const d = 0.353553;
        const x0 = wx + 0.5 - d, x1 = wx + 0.5 + d;
        const z0 = wz + 0.5 - d, z1 = wz + 0.5 + d;
        b.p.push(x0, y, z0, x1, y, z1, x1, y + 1, z1, x0, y + 1, z0,
            x1, y, z0, x0, y, z1, x0, y + 1, z1, x1, y + 1, z0);
        const [u0, v0, u1, v1] = tileUV(...BLOCK_UVS[type], 0.5 / 256);
        b.u.push(u0, v0, u1, v0, u1, v1, u0, v1, u0, v0, u1, v0, u1, v1, u0, v1);
        const plantLit = this.level.isLit(wx, CLASSIC_0011A ? y : y + 1, wz);
        const sky = plantLit || CLASSIC_0011A ? 1.0 : SHADOW_SHADE;
        const lc = shade(sky);
        for (let i = 0; i < 8; i++) b.c.push(lc, lc, lc);
        if (b.k) for (let i = 0; i < 8; i++) b.k.push(plantLit ? 0 : 1);
        b.i.push(idx, idx + 1, idx + 2, idx, idx + 2, idx + 3, idx + 4, idx + 5, idx + 6, idx + 4, idx + 6, idx + 7);
    }
    addFace(b, type, wx, y, wz, f) {
        const [nx, ny, nz] = f.n;
        const nb = this.level.getTile(wx + nx, y + ny, wz + nz), slab = type === BLOCK.SLAB;
        if (!(slab && ny === 1) && (!isSeeThrough(nb) || (type === BLOCK.GLASS && nb === BLOCK.GLASS))) return;
        if (y + ny < 0 && !CLASSIC_0011A) return;
        const [col, row] = faceUV(type, ny);
        const faceMult = ny === 1 ? FACE_SHADE.top : ny === -1 ? FACE_SHADE.bottom
            : nz !== 0 ? FACE_SHADE.northSouth : FACE_SHADE.eastWest;
        const lit = this.level.isLit(wx + nx, y + ny, wz + nz), sky = lit || CLASSIC_0011A ? 1.0 : SHADOW_SHADE;
        const light = faceMult * sky * (CLASSIC_0011A ? 1 : liquidDarkness(this.level, wx + nx, y + ny, wz + nz));
        this.pushQuad(b, f, wx, y, slab ? y + 0.5 : y + 1, wz, col, row, light, slab && ny === 0, lit ? 0 : 1);
    }
}
class BlockParticles {
    constructor(scene, texture) {
        this.scene = scene;
        this.texture = texture;
        this.particles = [];
        this.level = null;
        this.material = new THREE.MeshBasicMaterial({
            map: texture, transparent: false, depthWrite: true, alphaTest: 0.1, side: THREE.DoubleSide
        });
    }
    static uvForBlock(type) {
        return faceUV(type, 0);
    }
    spawnOne(px, py, pz, type, power, scale, vel) {
        if (type === BLOCK.AIR || type === BLOCK.WATER || type === BLOCK.LAVA) return;
        const [tc, tr] = BlockParticles.uvForBlock(type), tile = 1 / 16, eps = 0.5 / 256;
        const uMin = tc * tile + eps, vMin = 1 - (tr + 1) * tile + eps, tileW = tile - 2 * eps, tileH = tile - 2 * eps;
        let xd = (Math.random() * 2 - 1) * 0.4, yd = (Math.random() * 2 - 1) * 0.4, zd = (Math.random() * 2 - 1) * 0.4;
        const speed = (Math.random() + Math.random() + 1) * 0.15, dd = Math.hypot(xd, yd, zd) || 1;
        xd = xd / dd * speed * 0.4 * power; yd = (yd / dd * speed * 0.4 + 0.1 - 0.1) * power + 0.1; zd = zd / dd * speed * 0.4 * power;
        if (vel) { xd = vel[0] + (Math.random() * 2 - 1) * 0.4 * 0.15; yd = vel[1] + 0.1; zd = vel[2] + (Math.random() * 2 - 1) * 0.4 * 0.15; }
        const size = (Math.random() * 0.5 + 0.5) * 0.2 * scale, q = Math.floor(Math.random() * 4), r = Math.floor(Math.random() * 4);
        const geo = new THREE.PlaneGeometry(size, size), uvs = geo.attributes.uv;
        const u0 = uMin + tileW * q / 4, v0 = vMin + tileH * r / 4, du = tileW / 4, dv = tileH / 4;
        uvs.setXY(0, u0, v0 + dv); uvs.setXY(1, u0 + du, v0 + dv); uvs.setXY(2, u0, v0); uvs.setXY(3, u0 + du, v0); uvs.needsUpdate = true;
        const mesh = new THREE.Mesh(geo, this.material); mesh.position.set(px, py, pz);
        this.particles.push({ mesh, vx: xd * 20, vy: yd * 20, vz: zd * 20, life: 4 / (Math.random() * 0.9 + 0.1) / 20,
            onGround: false, rotSpeed: 0, classic: true, gravity: 0, drag: 0, maxFall: Infinity });
        this.scene.add(mesh);
    }
    spawn(x, y, z, type, count) {
        if (type === BLOCK.AIR || type === BLOCK.WATER || type === BLOCK.LAVA || type === BLOCK.BEDROCK) return;
        const [tc, tr] = BlockParticles.uvForBlock(type);
        const tile = 1 / 16;
        const eps = 0.5 / 256;
        const uMin = tc * tile + eps, uMax = (tc + 1) * tile - eps;
        const vMin = 1 - (tr + 1) * tile + eps, vMax = 1 - tr * tile - eps;
        const tileW = uMax - uMin, tileH = vMax - vMin;
        if ((CLASSIC_0011A || SURVIVAL_024) && count == null) {
            const SD = 4;
            for (let xx = 0; xx < SD; xx++) for (let yy = 0; yy < SD; yy++) for (let zz = 0; zz < SD; zz++) {
                const px = x + (xx + 0.5) / SD, py = y + (yy + 0.5) / SD, pz = z + (zz + 0.5) / SD;
                let xd = px - x - 0.5 + (Math.random() * 2 - 1) * 0.4, yd = py - y - 0.5 + (Math.random() * 2 - 1) * 0.4, zd = pz - z - 0.5 + (Math.random() * 2 - 1) * 0.4;
                const speed = (Math.random() + Math.random() + 1) * 0.15, dd = Math.hypot(xd, yd, zd) || 1;
                xd = xd / dd * speed * 0.4; yd = yd / dd * speed * 0.4 + 0.1; zd = zd / dd * speed * 0.4;
                const size = (Math.random() * 0.5 + 0.5) * 0.2, q = Math.floor(Math.random() * 4), r = Math.floor(Math.random() * 4);
                const geo = new THREE.PlaneGeometry(size, size), uvs = geo.attributes.uv;
                const u0 = uMin + tileW * q / 4, v0 = vMin + tileH * r / 4, du = tileW / 4, dv = tileH / 4;
                uvs.setXY(0, u0, v0 + dv); uvs.setXY(1, u0 + du, v0 + dv); uvs.setXY(2, u0, v0); uvs.setXY(3, u0 + du, v0); uvs.needsUpdate = true;
                const mesh = new THREE.Mesh(geo, this.material); mesh.position.set(px, py, pz);
                this.particles.push({ mesh, vx: xd * 20, vy: yd * 20, vz: zd * 20, life: 4 / (Math.random() * 0.9 + 0.1) / 20,
                    onGround: false, rotSpeed: 0, classic: true, gravity: 0, drag: 0, maxFall: Infinity });
                this.scene.add(mesh);
            }
            return;
        }
        const n = count == null ? (12 + Math.floor(Math.random() * 9)) : count;
        for (let i = 0; i < n; i++) {
            const frac = 0.20 + Math.random() * 0.20;
            const sU = tileW * frac, sV = tileH * frac;
            const su = uMin + Math.random() * (tileW - sU);
            const sv = vMin + Math.random() * (tileH - sV);
            const geo = new THREE.PlaneGeometry(0.12 + Math.random() * 0.08, 0.12 + Math.random() * 0.08);
            const uvs = geo.attributes.uv;
            uvs.setXY(0, su, sv + sV); uvs.setXY(1, su + sU, sv + sV);
            uvs.setXY(2, su, sv); uvs.setXY(3, su + sU, sv);
            uvs.needsUpdate = true;
            const mesh = new THREE.Mesh(geo, this.material);
            mesh.position.set(x + 0.2 + Math.random() * 0.6, y + 0.2 + Math.random() * 0.6, z + 0.2 + Math.random() * 0.6);
            const light = type === BLOCK.LEAVES;
            const burst = light ? 3.5 : 4.0;
            this.particles.push({
                mesh,
                vx: (Math.random() - 0.5) * burst,
                vy: light ? 1.2 + Math.random() * 1.6 : 1.0 + Math.random() * 2.0,
                vz: (Math.random() - 0.5) * burst,
                life: light ? 2.0 + Math.random() * 1.0 : 1.0 + Math.random() * 0.5,
                onGround: false,
                rotSpeed: (Math.random() - 0.5) * (light ? 4 : 8),
                gravity: light ? 2.5 : 14,
                drag: light ? 1.8 : 0,
                maxFall: light ? 0.9 : Infinity
            });
            this.scene.add(mesh);
        }
    }
    update(dt, camera) {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.life -= dt;
            if (p.life <= 0) {
                this.scene.remove(p.mesh);
                p.mesh.geometry.dispose();
                this.particles.splice(i, 1);
                continue;
            }
            if (p.classic) {
                p.vy -= 0.04 * 400 * dt;
                const keep = Math.pow(0.98, dt * 20); p.vx *= keep; p.vy *= keep; p.vz *= keep;
                if (p.onGround) { const g = Math.pow(0.7, dt * 20); p.vx *= g; p.vz *= g; }
            } else if (!p.onGround) {
                p.vy -= p.gravity * dt;
                if (p.drag > 0) {
                    const keep = Math.max(0, 1 - p.drag * dt);
                    p.vx *= keep; p.vz *= keep;
                    if (p.vy > 0) p.vy *= keep;
                }
                if (p.vy < -p.maxFall) p.vy = -p.maxFall;
            }
            const nextX = p.mesh.position.x + p.vx * dt;
            const nextY = p.mesh.position.y + p.vy * dt;
            const nextZ = p.mesh.position.z + p.vz * dt;
            const bx = Math.floor(nextX), by = Math.floor(nextY - 0.05), bz = Math.floor(nextZ);
            const top = this.level && this.level.getTile(bx, by, bz) === BLOCK.SLAB ? by + 0.5 : by + 1;
            if (this.level && this.level.isSolidTile(bx, by, bz) && nextY - 0.05 < top) {
                p.mesh.position.y = top + 0.02;
                p.vy = 0; p.onGround = true;
                p.mesh.position.x = nextX; p.mesh.position.z = nextZ;
                if (!p.classic) { p.vx *= Math.max(0, 1 - 10 * dt); p.vz *= Math.max(0, 1 - 10 * dt); }
            } else {
                p.onGround = false;
                p.mesh.position.set(nextX, nextY, nextZ);
            }
            if (camera) p.mesh.quaternion.copy(camera.quaternion);
            p.mesh.rotation.z += p.rotSpeed * dt;
        }
    }
    setLevel(level) { this.level = level; }
}
const PREVIEW_UV_EPS = 0.5 / 256;
class BlockPreview {
    constructor(texture) {
        this.scene = new THREE.Scene();
        const frustumSize = 1.6;
        this.camera = new THREE.OrthographicCamera(
            -frustumSize / 2, frustumSize / 2,
            frustumSize / 2, -frustumSize / 2,
            0.1, 100
        );
        const dist = 10;
        this.camera.position.set(dist, dist, dist);
        this.camera.lookAt(0, 0, 0);
        this.texture = texture;
        this.mesh = null;
        this.currentType = -1;
        this.size = 112;
        this.margin = 20;
    }
    faceUVs(geo, faceIndex, col, row, eps = PREVIEW_UV_EPS) {
        const [u0, v0, u1, v1] = tileUV(col, row, eps);
        const base = faceIndex * 4;
        const uv = geo.attributes.uv;
        uv.setXY(base + 0, u0, v1); uv.setXY(base + 1, u1, v1);
        uv.setXY(base + 2, u0, v0); uv.setXY(base + 3, u1, v0);
    }
    buildMesh(type) {
        if (this.mesh) {
            this.scene.remove(this.mesh);
            this.mesh.geometry.dispose();
            this.mesh.material.dispose();
            this.mesh = null;
        }
        if (type === BLOCK.AIR) { this.currentType = type; return; }
        if (type === BLOCK.AIR) return;
        if (isPlant(type)) {
            const geo = plantCrossGeometry(...BLOCK_UVS[type], PREVIEW_UV_EPS, true);
            const mat = new THREE.MeshBasicMaterial({
                map: this.texture, vertexColors: true, transparent: true, alphaTest: 0.1, side: THREE.DoubleSide
            });
            this.mesh = new THREE.Mesh(geo, mat);
        } else {
            const geo = new THREE.BoxGeometry(1, 1, 1);
            const faceNy = [0, 0, 1, -1, 0, 0];
            const faceShade = OLD_UI ? [0.6, 0.6, 1, 1, 0.8, 0.8] : [FACE_SHADE.eastWest, FACE_SHADE.eastWest, FACE_SHADE.top,
                FACE_SHADE.bottom, FACE_SHADE.northSouth, FACE_SHADE.northSouth];
            const cols = [];
            for (let f = 0; f < 6; f++) {
                this.faceUVs(geo, f, ...faceUV(type, faceNy[f]), OLD_UI ? 0.01 / 256 : PREVIEW_UV_EPS);
                const sl = shade(faceShade[f]);
                for (let v = 0; v < 4; v++) cols.push(sl, sl, sl);
            }
            geo.attributes.uv.needsUpdate = true;
            geo.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
            const mat = new THREE.MeshBasicMaterial({
                map: this.texture, vertexColors: true, transparent: true, alphaTest: 0.1,
                side: type === BLOCK.LEAVES ? THREE.DoubleSide : THREE.FrontSide
            });
            this.mesh = new THREE.Mesh(geo, mat);
        }
        this.mesh.rotation.set(0, 0, 0);
        this.scene.add(this.mesh);
        this.currentType = type;
    }
    setType(type) {
        if (type !== this.currentType) {
            this.buildMesh(type);
        }
    }
}
class Player {
    constructor(level) {
        this.level = level;
        let sx = Math.floor(MAP_WIDTH / 2);
        let sz = Math.floor(MAP_HEIGHT / 2);
        let sy = MAP_DEPTH;
        let found = false;
        for (let r = 0; r < MAP_WIDTH / 2 && !found; r++) {
            for (let dx = -r; dx <= r && !found; dx++) {
                for (let dz = -r; dz <= r && !found; dz++) {
                    if (Math.abs(dx) !== r && Math.abs(dz) !== r) continue;
                    const tx = sx + dx;
                    const tz = sz + dz;
                    if (tx < 0 || tx >= MAP_WIDTH || tz < 0 || tz >= MAP_HEIGHT) continue;
                    for (let y = MAP_DEPTH - 1; y > 0; y--) {
                        const t = level.getTile(tx, y, tz);
                        if (t !== BLOCK.AIR) {
                            if (t === BLOCK.GRASS || t === BLOCK.DIRT || t === BLOCK.ROCK ||
                                t === BLOCK.SAND || t === BLOCK.GRAVEL) {
                                sx = tx;
                                sz = tz;
                                sy = y + 1 + PLAYER_HEIGHT + 0.01;
                                found = true;
                            }
                            break;
                        }
                    }
                }
            }
        }
        if (!found) sy = MAP_DEPTH - 1 + PLAYER_HEIGHT;
        this.position = new THREE.Vector3(sx + 0.5, sy, sz + 0.5);
        this.velocity = new THREE.Vector3();
        this.rotation = { x: 0, y: 0 };
        this.onGround = false;
        this.swimming = false;
        this.swimTickAccum = 0;
        this.moveDir = new THREE.Vector3();
        this.inventory = HOTBAR.slice();
        this.selectedSlot = 0;
        if (SURVIVAL_024) Survival024.prototype.setupPlayer(this);
    }
    getSelectedBlock() { return this.inventory[this.selectedSlot]; }
    cycleSlot(delta) {
        const n = this.inventory.length;
        this.selectedSlot = (this.selectedSlot + delta % n + n) % n;
    }
    isInMaterial(type) {
        const hw = PLAYER_WIDTH / 2;
        const x0 = Math.floor(this.position.x - hw);
        const x1 = Math.floor(this.position.x + hw);
        const y0 = Math.floor(this.position.y - PLAYER_HEIGHT + (CLASSIC_0011A ? 0 : 0.1));
        const y1 = Math.floor(this.position.y + (CLASSIC_0011A ? 0.18 : 0.1));
        const z0 = Math.floor(this.position.z - hw);
        const z1 = Math.floor(this.position.z + hw);
        for (let x = x0; x <= x1; x++) {
            for (let y = y0; y <= y1; y++) {
                for (let z = z0; z <= z1; z++) {
                    if (this.level.getTile(x, y, z) === type) return true;
                }
            }
        }
        return false;
    }
    isBodyIn(liquid) {
        const hw = PLAYER_WIDTH / 2;
        const feet = this.position.y - PLAYER_HEIGHT;
        const x0 = Math.floor(this.position.x - hw), x1 = Math.floor(this.position.x + hw);
        const z0 = Math.floor(this.position.z - hw), z1 = Math.floor(this.position.z + hw);
        const y0 = Math.floor(feet + SWIM_FLOAT_LINE);
        const y1 = Math.max(y0, Math.floor(this.position.y - 0.4));
        for (let x = x0; x <= x1; x++)
            for (let y = y0; y <= y1; y++)
                for (let z = z0; z <= z1; z++)
                    if (this.level.getTile(x, y, z) === liquid) return true;
        return false;
    }
    waterSurfaceY(liquid = BLOCK.WATER) {
        const x = Math.floor(this.position.x), z = Math.floor(this.position.z);
        const y0 = Math.floor(this.position.y - PLAYER_HEIGHT), y1 = Math.floor(this.position.y) + 1;
        let top = null;
        for (let y = y0; y <= y1; y++) {
            if (this.level.getTile(x, y, z) === liquid) top = y;
            else if (top !== null) break;
        }
        return top === null ? null : top + 15 / 16;
    }
    update(dt, input) {
        const f = new THREE.Vector3(-Math.sin(this.rotation.y), 0, -Math.cos(this.rotation.y));
        const r = new THREE.Vector3(Math.cos(this.rotation.y), 0, -Math.sin(this.rotation.y));
        const m = new THREE.Vector3();
        if (input.forward) m.add(f);
        if (input.backward) m.sub(f);
        if (input.left) m.sub(r);
        if (input.right) m.add(r);
        if (m.lengthSq() > 0) m.normalize();
        this.moveDir.copy(m);
        const inWater = this.isInMaterial(BLOCK.WATER);
        const inLava = this.isInMaterial(BLOCK.LAVA);
        if (inWater || inLava) this.swimming = true;
        else if (this.onGround) this.swimming = false;
        let landPhysics = false;
        if (NOTCH_PHYSICS && (inWater || inLava)) {
            const k = inLava ? 0.5 : CLASSIC_0011A ? 0.7 : 0.8;
            this.swimTickAccum += dt;
            while (this.swimTickAccum >= SWIM_TICK) {
                this.swimTickAccum -= SWIM_TICK;
                let vx = this.velocity.x * SWIM_TICK * k, vy = this.velocity.y * SWIM_TICK * k, vz = this.velocity.z * SWIM_TICK * k;
                vy -= 0.02;
                if (input.jump) vy += CLASSIC_0011A && !inLava ? 0.06 : 0.04;
                vx += this.moveDir.x * 0.02; vz += this.moveDir.z * 0.02;
                if (!CLASSIC_0011A && this.blockedAhead() && this.freeUp030()) vy = 0.3;
                this.velocity.set(vx / SWIM_TICK, vy / SWIM_TICK, vz / SWIM_TICK);
            }
            this.swimming = false;
        } else if (!NOTCH_PHYSICS && (inWater || inLava || (this.swimming && !this.onGround))) {
            const liquid = inLava ? BLOCK.LAVA : BLOCK.WATER;
            const drag = inLava ? LAVA_DRAG : WATER_DRAG;
            const liquidAccel = inLava ? LAVA_ACCEL : SWIM_ACCEL;
            this.swimTickAccum += dt;
            while (this.swimTickAccum >= SWIM_TICK) {
                this.swimTickAccum -= SWIM_TICK;
                let vx = this.velocity.x * SWIM_TICK;
                let vy = this.velocity.y * SWIM_TICK;
                let vz = this.velocity.z * SWIM_TICK;
                const vyStart = vy;
                const floating = this.isBodyIn(liquid);
                if (floating) {
                    vx *= drag; vy *= drag; vz *= drag;
                    vy -= WATER_SINK;
                    if (input.jump) vy += SWIM_UP;
                } else {
                    vx *= SWIM_AIR_DRAG; vz *= SWIM_AIR_DRAG;
                    vy -= SWIM_AIR_GRAVITY;
                    vy *= 0.98;
                }
                const accel = floating ? liquidAccel : SWIM_AIR_ACCEL;
                vx += m.x * accel;
                vz += m.z * accel;
                const surface = this.waterSurfaceY(liquid);
                if (input.jump && surface !== null && this.position.y > surface - 0.5) {
                    const feet = this.position.y - PLAYER_HEIGHT;
                    const depth = Math.max(0, Math.min(surface - feet, 1.6));
                    const balanceDepth = PLAYER_HEIGHT - SWIM_BOB_HEIGHT;
                    vy = vyStart + SWIM_BUOYANCY * (depth - balanceDepth);
                    vy *= SWIM_BOB_DAMP;
                    if (vyStart < 0 && vy >= 0) vy += SWIM_KICK * (0.75 + Math.random() * 0.5);
                }
                if (input.jump && this.blockedAhead() && this.canClimbOut()) vy = Math.max(vy, SWIM_CLIMB);
                this.velocity.set(vx / SWIM_TICK, vy / SWIM_TICK, vz / SWIM_TICK);
            }
        } else {
            if (!NOTCH_PHYSICS) { this.velocity.x = m.x * PLAYER_SPEED; this.velocity.z = m.z * PLAYER_SPEED; }
            if (this.knockX || this.knockZ) {
                this.velocity.x += this.knockX; this.velocity.z += this.knockZ;
                const keep = Math.pow(this.onGround ? 0.91 * 0.6 : 0.91, dt * 20);
                this.knockX *= keep; this.knockZ *= keep;
                if (Math.abs(this.knockX) + Math.abs(this.knockZ) < 0.05) this.knockX = this.knockZ = 0;
            }
            if (input.jump && this.onGround) {
                this.velocity.y = CLASSIC_0011A ? CLASSIC_JUMP / SWIM_TICK : JUMP_FORCE * SANDBOX_PHYS.jump;
                this.onGround = false;
                this.swimTickAccum = 0;
            }
            landPhysics = true;
        }
        this.moveWithCollision(dt);
        this.clampToWorld();
        if (landPhysics) {
            this.swimTickAccum += dt;
            while (this.swimTickAccum >= SWIM_TICK - 1e-9) {
                this.swimTickAccum -= SWIM_TICK;
                let vy = this.velocity.y * SWIM_TICK;
                if (!NOTCH_PHYSICS) vy = (vy - MC_GRAVITY) * MC_AIR_DRAG;
                else {
                    vy = vy * MC_AIR_DRAG - MC_GRAVITY * SANDBOX_PHYS.gravity;
                    let vx = this.velocity.x * SWIM_TICK * 0.91, vz = this.velocity.z * SWIM_TICK * 0.91;
                    if (this.onGround) { vx *= 0.6; vz *= 0.6; }
                    const sp = (this.onGround ? 0.1 : 0.02) * SANDBOX_PHYS.speed;
                    vx += this.moveDir.x * sp; vz += this.moveDir.z * sp;
                    this.velocity.x = vx / SWIM_TICK; this.velocity.z = vz / SWIM_TICK;
                }
                this.velocity.y = vy / SWIM_TICK;
            }
        }
    }
    clampToWorld() {
        const hw = PLAYER_WIDTH / 2;
        const min = hw + 0.001;
        const maxX = MAP_WIDTH - hw - 0.001;
        const maxZ = MAP_HEIGHT - hw - 0.001;
        if (this.position.x < min) { this.position.x = min; this.velocity.x = 0; }
        if (this.position.x > maxX) { this.position.x = maxX; this.velocity.x = 0; }
        if (this.position.z < min) { this.position.z = min; this.velocity.z = 0; }
        if (this.position.z > maxZ) { this.position.z = maxZ; this.velocity.z = 0; }
    }
    blockedAhead() {
        if (this.moveDir.lengthSq() === 0) return false;
        const hw = PLAYER_WIDTH / 2;
        const ox = this.position.x, oz = this.position.z;
        this.position.x += this.moveDir.x * 0.1;
        this.position.z += this.moveDir.z * 0.1;
        const blocked = this.collides(hw);
        this.position.x = ox; this.position.z = oz;
        return blocked;
    }
    freeUp030() {
        if (this.moveDir.lengthSq() === 0) return false;
        const ox = this.position.x, oy = this.position.y, oz = this.position.z;
        this.position.x += this.moveDir.x * 0.1; this.position.z += this.moveDir.z * 0.1; this.position.y += 0.6;
        const blocked = this.collides(PLAYER_WIDTH / 2);
        this.position.set(ox, oy, oz);
        return !blocked;
    }
    canClimbOut() {
        if (this.moveDir.lengthSq() === 0) return false;
        const hw = PLAYER_WIDTH / 2;
        const ox = this.position.x, oy = this.position.y, oz = this.position.z;
        this.position.x += this.moveDir.x * 0.3;
        this.position.z += this.moveDir.z * 0.3;
        const water = this.waterSurfaceY();
        const surface = water !== null ? water : this.waterSurfaceY(BLOCK.LAVA);
        if (surface !== null) this.position.y = surface + 1.1 + PLAYER_HEIGHT;
        else this.position.y += SWIM_CLIMB_CLEARANCE;
        const blocked = this.collides(hw);
        this.position.set(ox, oy, oz);
        return !blocked;
    }
    moveWithCollision(dt) {
        const far = Math.max(Math.abs(this.velocity.x), Math.abs(this.velocity.y), Math.abs(this.velocity.z)) * dt;
        const steps = Math.min(60, Math.max(1, Math.ceil(far / MAX_MOVE_STEP)));
        for (let i = 0; i < steps; i++) this.moveStep(dt / steps);
    }
    moveStep(dt) {
        const hw = PLAYER_WIDTH / 2;
        this.inside = null;
        if (this.collides(hw)) this.inside = this.overlapped(hw);
        this.position.x += this.velocity.x * dt;
        if (this.collides(hw) && !this.stepUp(hw)) { this.position.x -= this.velocity.x * dt; this.velocity.x = 0; }
        this.position.y += this.velocity.y * dt;
        if (this.collides(hw)) {
            if (this.velocity.y < 0) {
                this.position.y = this.groundTop(hw) + PLAYER_HEIGHT;
                this.onGround = true;
            } else {
                this.position.y = Math.floor(this.position.y + 0.1) - 0.101;
            }
            this.velocity.y = 0;
        } else {
            this.onGround = false;
            if (this.velocity.y <= 0) {
                this.position.y -= 0.01;
                this.onGround = this.collides(hw);
                this.position.y += 0.01;
            }
        }
        this.position.z += this.velocity.z * dt;
        if (this.collides(hw) && !this.stepUp(hw)) { this.position.z -= this.velocity.z * dt; this.velocity.z = 0; }
        this.inside = null;
    }
    stepUp(hw) {
        if (!this.onGround || CLASSIC_0011A) return false;
        this.position.y += 0.5;
        if (this.collides(hw)) { this.position.y -= 0.5; return false; }
        const before = this.position.y - 0.5;
        this.position.y = this.groundTop(hw) + PLAYER_HEIGHT;
        if (this.collides(hw)) { this.position.y += 0.001; if (this.collides(hw)) { this.position.y -= 0.501; return false; } }
        this.ySlide = (this.ySlide || 0) + (this.position.y - before);
        return true;
    }
    collides(hw) {
        const x0 = Math.floor(this.position.x - hw), x1 = Math.floor(this.position.x + hw);
        const y0 = Math.floor(this.position.y - PLAYER_HEIGHT + 0.001), y1 = Math.floor(this.position.y + 0.1);
        const z0 = Math.floor(this.position.z - hw), z1 = Math.floor(this.position.z + hw);
        const feet = this.position.y - PLAYER_HEIGHT;
        for (let x = x0; x <= x1; x++)
            for (let y = y0; y <= y1; y++)
                for (let z = z0; z <= z1; z++)
                    if (this.level.isSolidTile(x, y, z) && !(this.level.getTile(x, y, z) === BLOCK.SLAB && feet >= y + 0.5 - 0.001) &&
                        !(this.inside && this.inside.has(x + ',' + y + ',' + z))) return true;
        return false;
    }
    overlapped(hw) {
        const out = new Set();
        const x0 = Math.floor(this.position.x - hw), x1 = Math.floor(this.position.x + hw);
        const y0 = Math.floor(this.position.y - PLAYER_HEIGHT + 0.001), y1 = Math.floor(this.position.y + 0.1);
        const z0 = Math.floor(this.position.z - hw), z1 = Math.floor(this.position.z + hw);
        for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++)
            if (this.level.isSolidTile(x, y, z)) out.add(x + ',' + y + ',' + z);
        return out;
    }
    groundTop(hw) {
        const feet = this.position.y - PLAYER_HEIGHT;
        const x0 = Math.floor(this.position.x - hw), x1 = Math.floor(this.position.x + hw);
        const z0 = Math.floor(this.position.z - hw), z1 = Math.floor(this.position.z + hw);
        let top = Math.floor(feet + 0.001) + 1;
        let best = -Infinity;
        for (let x = x0; x <= x1; x++) for (let z = z0; z <= z1; z++) for (let y = Math.floor(feet + 0.001); y >= Math.floor(feet) - 1; y--) {
            if (!this.level.isSolidTile(x, y, z)) continue;
            const t = this.level.getTile(x, y, z) === BLOCK.SLAB ? y + 0.5 : y + 1;
            if (t <= feet + 0.6) best = Math.max(best, t);
        }
        if (best > -Infinity) top = best;
        return top;
    }
    getEyePosition() { return new THREE.Vector3(this.position.x, this.position.y, this.position.z); }
    getLookDirection() {
        return new THREE.Vector3(
            -Math.sin(this.rotation.y) * Math.cos(this.rotation.x),
            Math.sin(this.rotation.x),
            -Math.cos(this.rotation.y) * Math.cos(this.rotation.x)
        ).normalize();
    }
}
function buildModelBox(texU, texV, bx, by, bz, w, h, d, grow = 0) {
    const x0 = bx - grow, y0 = by - grow, z0 = bz - grow;
    const x1 = bx + w + grow, y1 = by + h + grow, z1 = bz + d + grow;
    const u0 = [x0, y0, z0], u1 = [x1, y0, z0], u2 = [x1, y1, z0], u3 = [x0, y1, z0];
    const l0 = [x0, y0, z1], l1 = [x1, y0, z1], l2 = [x1, y1, z1], l3 = [x0, y1, z1];
    const faces = [
        [[l1, u1, u2, l2], texU + d + w, texV + d, texU + d + w + d, texV + d + h],
        [[u0, l0, l3, u3], texU + 0, texV + d, texU + d, texV + d + h],
        [[l1, l0, u0, u1], texU + d, texV + 0, texU + d + w, texV + d],
        [[u2, u3, l3, l2], texU + d + w, texV + 0, texU + d + w + w, texV + d],
        [[u1, u0, u3, u2], texU + d, texV + d, texU + d + w, texV + d + h],
        [[l0, l1, l2, l3], texU + d + w + d, texV + d, texU + d + w + d + w, texV + d + h]
    ];
    const positions = [], uvs = [], indices = [], colors = [];
    const faceShade = [FACE_SHADE.eastWest, FACE_SHADE.eastWest, FACE_SHADE.top, FACE_SHADE.bottom,
        FACE_SHADE.northSouth, FACE_SHADE.northSouth];
    let fi = 0;
    for (const [corners, fu0, fv0, fu1, fv1] of faces) {
        const fs = shade(faceShade[fi++]);
        const base = positions.length / 3;
        const cornerUV = [[fu1, fv0], [fu0, fv0], [fu0, fv1], [fu1, fv1]];
        for (let k = 0; k < 4; k++) {
            positions.push(...corners[k]);
            uvs.push(cornerUV[k][0] / 63.999, 1 - cornerUV[k][1] / 31.999);
            colors.push(fs, fs, fs);
        }
        indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
    return makeGeometry(positions, uvs, colors, indices);
}
function makeSkinTexture(src) {
    const canvas = document.createElement('canvas');
    canvas.width = 64; canvas.height = 32;
    const tex = new THREE.CanvasTexture(canvas);
    tex.magFilter = tex.minFilter = THREE.NearestFilter;
    tex.colorSpace = THREE.SRGBColorSpace;
    const img = new Image();
    img.onload = () => {
        const cx = canvas.getContext('2d');
        cx.clearRect(0, 0, 64, 32);
        cx.drawImage(img, 0, 0, 64, 32, 0, 0, 64, 32);
        const hat = cx.getImageData(32, 0, 32, 16);
        let seeThrough = false;
        for (let i = 3; i < hat.data.length; i += 4) if (hat.data[i] < 128) { seeThrough = true; break; }
        if (!seeThrough) cx.clearRect(32, 0, 32, 16);
        tex.needsUpdate = true;
    };
    img.src = src;
    return tex;
}
const isSkinData = s => typeof s === 'string' && s.startsWith('data:image/png;base64,') && s.length < 40000;
const HAT_PART = { tex: [32, 0], box: [-4, -8, -4, 8, 8, 8], grow: 0.5 };
const ZOMBIE_PARTS = {
    head: { tex: [0, 0], box: [-4, -8, -4, 8, 8, 8], pos: [0, 0, 0] },
    body: { tex: [16, 16], box: [-4, 0, -2, 8, 12, 4], pos: [0, 0, 0] },
    arm0: { tex: [40, 16], box: [-3, -2, -2, 4, 12, 4], pos: [-5, 2, 0] },
    arm1: { tex: [40, 16], box: [-1, -2, -2, 4, 12, 4], pos: [5, 2, 0] },
    leg0: { tex: [0, 16], box: [-2, 0, -2, 4, 12, 4], pos: [-2, 12, 0] },
    leg1: { tex: [0, 16], box: [-2, 0, -2, 4, 12, 4], pos: [2, 12, 0] }
};
const ZOMBIE_SIZE = 0.058333334;
class ZombieModel {
    constructor(material) {
        this.material = material;
        this.geometries = {};
        for (const name in ZOMBIE_PARTS) {
            const p = ZOMBIE_PARTS[name];
            this.geometries[name] = buildModelBox(p.tex[0], p.tex[1], ...p.box);
        }
        this.geometries.hat = buildModelBox(HAT_PART.tex[0], HAT_PART.tex[1], ...HAT_PART.box, HAT_PART.grow);
    }
    create() {
        const material = this.material.clone();
        const root = new THREE.Group();
        const flip = new THREE.Group();
        flip.scale.set(ZOMBIE_SIZE, -ZOMBIE_SIZE, ZOMBIE_SIZE);
        const body = new THREE.Group();
        root.add(flip);
        flip.add(body);
        const parts = {};
        for (const name in ZOMBIE_PARTS) {
            const pivot = new THREE.Group();
            pivot.position.set(...ZOMBIE_PARTS[name].pos);
            pivot.rotation.order = 'ZYX';
            pivot.add(new THREE.Mesh(this.geometries[name], material));
            body.add(pivot);
            parts[name] = pivot;
        }
        parts.head.add(new THREE.Mesh(this.geometries.hat, material));
        return { root, body, parts, material };
    }
    animate(parts, time) {
        parts.head.rotation.y = Math.sin(time * 0.83) * 1.0;
        parts.head.rotation.x = Math.sin(time) * 0.8;
        parts.arm0.rotation.x = Math.sin(time * 0.6662 + Math.PI) * 2.0;
        parts.arm0.rotation.z = (Math.sin(time * 0.2312) + 1.0) * 1.0;
        parts.arm1.rotation.x = Math.sin(time * 0.6662) * 2.0;
        parts.arm1.rotation.z = (Math.sin(time * 0.2812) - 1.0) * 1.0;
        parts.leg0.rotation.x = Math.sin(time * 0.6662) * 1.4;
        parts.leg1.rotation.x = Math.sin(time * 0.6662 + Math.PI) * 1.4;
    }
}
class Zombie {
    constructor(level, model, x, y, z) {
        this.level = level;
        this.removed = false;
        this.xd = 0; this.yd = 0; this.zd = 0;
        this.onGround = false;
        this.bbWidth = 0.6; this.bbHeight = 1.8;
        this.rotA = (Math.random() + 1.0) * 0.01;
        this.timeOffs = Math.random() * 1239813.0;
        this.rot = Math.random() * Math.PI * 2.0;
        this.speed = 1.0;
        const w = this.bbWidth / 2, hh = this.bbHeight / 2;
        this.bb = [x - w, y - hh, z - w, x + w, y + hh, z + w];
        this.x = x; this.y = this.bb[1]; this.z = z;
        this.xo = this.x; this.yo = this.y; this.zo = this.z;
        this.view = model.create();
    }
    tick() {
        this.xo = this.x; this.yo = this.y; this.zo = this.z;
        if (this.y < -100) this.removed = true;
        this.rot += this.rotA;
        this.rotA *= 0.99;
        this.rotA += (Math.random() - Math.random()) * Math.random() * Math.random() * 0.08;
        const xa = Math.sin(this.rot);
        const za = Math.cos(this.rot);
        const inWater = this.isInLiquid(BLOCK.WATER);
        const inLava = !inWater && this.isInLiquid(BLOCK.LAVA);
        if (inWater || inLava) {
            if (Math.random() < 0.8) this.yd += 0.04;
            const yo = this.y;
            this.moveRelative(xa, za, 0.02);
            this.move(this.xd, this.yd, this.zd);
            const drag = inWater ? 0.8 : 0.5;
            this.xd *= drag; this.yd *= drag; this.zd *= drag;
            this.yd -= 0.02;
            if (this.horizontalCollision && this.isFree(this.xd, this.yd + 0.6 - this.y + yo, this.zd)) {
                this.yd = 0.3;
            }
            return;
        }
        if (this.onGround && Math.random() < 0.08) this.yd = 0.5;
        this.moveRelative(xa, za, this.onGround ? 0.1 : 0.02);
        this.yd -= 0.08;
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.91;
        this.yd *= 0.98;
        this.zd *= 0.91;
        if (this.onGround) {
            this.xd *= 0.7;
            this.zd *= 0.7;
        }
    }
    isInLiquid(type) {
        const b = this.bb;
        for (let x = Math.floor(b[0]); x < Math.floor(b[3]) + 1; x++)
            for (let y = Math.floor(b[1] + 0.4); y < Math.floor(b[4] - 0.4) + 1; y++)
                for (let z = Math.floor(b[2]); z < Math.floor(b[5]) + 1; z++)
                    if (this.level.getTile(x, y, z) === type) return true;
        return false;
    }
    isFree(xa, ya, za) {
        const b = this.bb;
        const x0 = b[0] + xa, y0 = b[1] + ya, z0 = b[2] + za;
        const x1 = b[3] + xa, y1 = b[4] + ya, z1 = b[5] + za;
        if (this.cubesIn(x0, y0, z0, x1, y1, z1).some(c =>
            c[3] > x0 && c[0] < x1 && c[4] > y0 && c[1] < y1 && c[5] > z0 && c[2] < z1)) return false;
        for (let x = Math.floor(x0); x < Math.floor(x1) + 1; x++)
            for (let y = Math.floor(y0); y < Math.floor(y1) + 1; y++)
                for (let z = Math.floor(z0); z < Math.floor(z1) + 1; z++) {
                    const t = this.level.getTile(x, y, z);
                    if (t === BLOCK.WATER || t === BLOCK.LAVA) return false;
                }
        return true;
    }
    moveRelative(xa, za, speed) {
        let dist = xa * xa + za * za;
        if (dist < 0.01) return;
        dist = speed / Math.sqrt(dist);
        this.xd += xa * dist;
        this.zd += za * dist;
    }
    cubesIn(x0, y0, z0, x1, y1, z1) {
        const out = [];
        for (let x = Math.floor(x0); x < Math.floor(x1) + 1; x++)
            for (let y = Math.floor(y0); y < Math.floor(y1) + 1; y++)
                for (let z = Math.floor(z0); z < Math.floor(z1) + 1; z++)
                    if (this.level.isSolidTile(x, y, z)) out.push([x, y, z, x + 1, y + 1, z + 1]);
        return out;
    }
    move(xa, ya, za) {
        const xaOrg = xa, yaOrg = ya, zaOrg = za;
        const b = this.bb;
        const cubes = this.cubesIn(
            Math.min(b[0], b[0] + xa), Math.min(b[1], b[1] + ya), Math.min(b[2], b[2] + za),
            Math.max(b[3], b[3] + xa), Math.max(b[4], b[4] + ya), Math.max(b[5], b[5] + za));
        for (const c of cubes) {
            if (b[3] <= c[0] || b[0] >= c[3] || b[5] <= c[2] || b[2] >= c[5]) continue;
            if (ya > 0 && b[4] <= c[1]) ya = Math.min(ya, c[1] - b[4]);
            if (ya < 0 && b[1] >= c[4]) ya = Math.max(ya, c[4] - b[1]);
        }
        b[1] += ya; b[4] += ya;
        for (const c of cubes) {
            if (b[4] <= c[1] || b[1] >= c[4] || b[5] <= c[2] || b[2] >= c[5]) continue;
            if (xa > 0 && b[3] <= c[0]) xa = Math.min(xa, c[0] - b[3]);
            if (xa < 0 && b[0] >= c[3]) xa = Math.max(xa, c[3] - b[0]);
        }
        b[0] += xa; b[3] += xa;
        for (const c of cubes) {
            if (b[4] <= c[1] || b[1] >= c[4] || b[3] <= c[0] || b[0] >= c[3]) continue;
            if (za > 0 && b[5] <= c[2]) za = Math.min(za, c[2] - b[5]);
            if (za < 0 && b[2] >= c[5]) za = Math.max(za, c[5] - b[2]);
        }
        b[2] += za; b[5] += za;
        this.onGround = yaOrg !== ya && yaOrg < 0;
        this.horizontalCollision = xaOrg !== xa || zaOrg !== za;
        if (xaOrg !== xa) this.xd = 0;
        if (yaOrg !== ya) this.yd = 0;
        if (zaOrg !== za) this.zd = 0;
        this.x = (b[0] + b[3]) / 2;
        this.y = b[1];
        this.z = (b[2] + b[5]) / 2;
    }
    updateView(model, a, nowSeconds) {
        const v = this.view;
        v.root.position.set(
            this.xo + (this.x - this.xo) * a,
            this.yo + (this.y - this.yo) * a,
            this.zo + (this.z - this.zo) * a);
        const time = nowSeconds * 10.0 * this.speed + this.timeOffs;
        v.body.position.y = -Math.abs(Math.sin(time * 0.6662)) * 5.0 - 23.0;
        v.body.rotation.y = this.rot + Math.PI;
        model.animate(v.parts, time);
    }
}
function rayBox(o, d, x0, y0, z0, x1, y1, z1) {
    let tn = -Infinity, tf = Infinity, axis = -1, sign = 0;
    const lo = [x0, y0, z0], hi = [x1, y1, z1], oo = [o.x, o.y, o.z], dd = [d.x, d.y, d.z];
    for (let i = 0; i < 3; i++) {
        if (dd[i] === 0) { if (oo[i] < lo[i] || oo[i] > hi[i]) return null; continue; }
        let a = (lo[i] - oo[i]) / dd[i], b = (hi[i] - oo[i]) / dd[i], s = -1;
        if (a > b) { const tmp = a; a = b; b = tmp; s = 1; }
        if (a > tn) { tn = a; axis = i; sign = s; }
        tf = Math.min(tf, b);
        if (tn > tf || tf < 0) return null;
    }
    return { t: Math.max(0, tn), axis, sign };
}
class BlockRaycaster {
    constructor(level) { this.level = level; }
    cast(origin, dir, maxDist) {
        let x = Math.floor(origin.x), y = Math.floor(origin.y), z = Math.floor(origin.z);
        const sx = dir.x > 0 ? 1 : -1, sy = dir.y > 0 ? 1 : -1, sz = dir.z > 0 ? 1 : -1;
        const tdx = dir.x !== 0 ? Math.abs(1 / dir.x) : Infinity;
        const tdy = dir.y !== 0 ? Math.abs(1 / dir.y) : Infinity;
        const tdz = dir.z !== 0 ? Math.abs(1 / dir.z) : Infinity;
        let tmaxx = dir.x !== 0 ? (dir.x > 0 ? x + 1 - origin.x : origin.x - x) * tdx : Infinity;
        let tmaxy = dir.y !== 0 ? (dir.y > 0 ? y + 1 - origin.y : origin.y - y) * tdy : Infinity;
        let tmaxz = dir.z !== 0 ? (dir.z > 0 ? z + 1 - origin.z : origin.z - z) * tdz : Infinity;
        let px = x, py = y, pz = z, dist = 0;
        while (dist < maxDist) {
            const t = this.level.getTile(x, y, z);
            const bottomBedrock = t === BLOCK.BEDROCK && y === 0;
            if (t === BLOCK.SLAB) {
                const f = rayBox(origin, dir, x, y, z, x + 1, y + 0.5, z + 1);
                if (f && f.t <= maxDist) return { hit: true, blockPos: { x, y, z }, prevPos: f.axis === 1 && f.sign > 0 ? { x, y: y + 1, z } : { x: px, y: py, z: pz } };
            } else if (t !== BLOCK.AIR && t !== BLOCK.WATER && t !== BLOCK.LAVA && t !== BLOCK.BARRIER && !bottomBedrock)
                return { hit: true, blockPos: { x, y, z }, prevPos: { x: px, y: py, z: pz } };
            px = x; py = y; pz = z;
            if (tmaxx < tmaxy) {
                if (tmaxx < tmaxz) { dist = tmaxx; x += sx; tmaxx += tdx; }
                else { dist = tmaxz; z += sz; tmaxz += tdz; }
            } else {
                if (tmaxy < tmaxz) { dist = tmaxy; y += sy; tmaxy += tdy; }
                else { dist = tmaxz; z += sz; tmaxz += tdz; }
            }
        }
        return { hit: false };
    }
}
const MUSIC_FIRST_DELAY = [60, 120];
const MUSIC_GAP = [180, 420];
const MUSIC_VOLUME = 0.26;
const arpSong = ({ chords, pattern, step, perChord, melodies, plan, padV = 0.02, bassV = 0.32, arpV = 0.16, melV = 0.3, end }) => {
    const out = []; let b0 = 0;
    for (const part of plan) for (let c = 0; c < chords.length; c++) {
        const ch = chords[c];
        out.push({ beat: b0, m: ch[0], v: bassV });
        for (let i = 0; i * step < perChord - 1e-6; i++) out.push({ beat: b0 + i * step, m: ch[pattern[i % pattern.length]], v: arpV + (i % (pattern.length) === 0 ? 0.03 : 0) });
        out.push({ beat: b0, pad: ch.slice(1, 4), len: perChord + 0.2, v: padV });
        if (part !== null) { const [k, up] = Array.isArray(part) ? part : [part, 0];
            for (const [b, m] of melodies[k][c] || []) out.push({ beat: b0 + b, m: m + up, v: up ? melV * 0.85 : melV }); }
        b0 += perChord;
    }
    end.forEach((m, i) => out.push({ beat: b0 + i * 0.12, m, v: i ? 0.2 : 0.3 }));
    return out;
};
const SONGS = [
    { name: 'Morning Glass', bpm: 72, build: () => arpSong({
        chords: [[38, 62, 66, 69, 74], [37, 61, 64, 69, 73], [35, 62, 66, 69, 71], [43, 59, 62, 66, 67],
                 [43, 59, 62, 67, 71], [43, 58, 62, 67, 70], [42, 62, 66, 69, 74], [45, 62, 64, 69, 71]],
        pattern: [1, 2, 3, 4, 3, 2, 1, 2], step: 0.5, perChord: 4,
        melodies: [
            [[[0, 78], [1.5, 76], [2, 74]], [[0, 76], [1, 73], [2, 69]], [[0, 71], [1, 74], [2, 78]], [[0, 79], [2, 78]],
             [[0, 79], [1, 81], [2, 83]], [[0, 82], [2, 79]], [[0, 78], [1, 76], [2, 74]], [[0, 76], [2, 73]]],
            [[[0, 81], [1, 78], [2, 76], [3, 78]], [[0, 76], [2, 73]], [[0, 74], [1, 76], [2, 78], [3, 81]], [[0, 83], [2, 79]],
             [[0, 79], [2, 83]], [[0, 82], [1, 79], [2, 77]], [[0, 78], [2, 81]], [[0, 76], [1, 78], [2, 81]]]],
        plan: [null, 0, 1, [0, 12], 1, null], end: [38, 62, 66, 69, 74, 78] }) },
    { name: 'Quiet Fields', bpm: 76, build: () => arpSong({
        chords: [[45, 57, 64, 69, 73], [44, 56, 64, 68, 71], [42, 57, 61, 64, 69], [38, 57, 61, 66, 69],
                 [45, 57, 64, 69, 73], [40, 56, 64, 68, 71], [38, 57, 62, 66, 69], [38, 57, 62, 65, 69]],
        pattern: [1, 2, 3, 4, 2, 3], step: 0.5, perChord: 3, arpV: 0.15,
        melodies: [
            [[[0, 76], [1.5, 78]], [[0, 80], [2, 76]], [[0, 73], [1.5, 76]], [[0, 78], [2, 81]],
             [[0, 80], [1, 78], [1.5, 76]], [[0, 76], [2, 80]], [[0, 81], [1.5, 78]], [[0, 77], [2, 76]]],
            [[[0, 85], [1, 83], [2, 81]], [[0, 80], [2, 83]], [[0, 81], [1.5, 78]], [[0, 76], [1.5, 78], [2.5, 81]],
             [[0, 83], [1.5, 85]], [[0, 83], [2, 80]], [[0, 78], [1, 81], [2, 83]], [[0, 81], [2, 77]]]],
        plan: [null, 0, 0, 1, [0, 12], 1, null], end: [45, 57, 64, 69, 73, 76] }) },
    { name: 'Lantern', bpm: 88, level: 1.4, build: () => arpSong({
        chords: [[43, 67, 71, 74, 79], [42, 66, 69, 74, 78], [40, 67, 71, 74, 76], [36, 64, 67, 71, 76],
                 [47, 67, 71, 74, 79], [45, 64, 67, 72, 76], [38, 66, 69, 72, 74], [43, 67, 71, 74, 79]],
        pattern: [1, 2, 3, 4, 3, 2], step: 0.5, perChord: 6, arpV: 0.13, bassV: 0.28, melV: 0.26,
        melodies: [
            [[[0, 83], [3, 81], [4.5, 79]], [[0, 81], [3, 78]], [[0, 79], [1.5, 81], [3, 83]], [[0, 84], [3, 83]],
             [[0, 83], [3, 86]], [[0, 84], [1.5, 83], [3, 81]], [[0, 78], [3, 81]], [[0, 79]]],
            [[[0, 86], [3, 83], [4.5, 84]], [[0, 86], [3, 81]], [[0, 83], [3, 86]], [[0, 88], [3, 84]],
             [[0, 86], [1.5, 88], [3, 91]], [[0, 88], [3, 84]], [[0, 86], [1.5, 84], [3, 81]], [[0, 83]]]],
        plan: [null, 0, 1, 0, null], end: [43, 67, 71, 74, 79, 83] }) },
];
class MusicPlayer {
    constructor() {
        let off = false; try { off = localStorage.getItem('claudecraft-music') === 'off'; } catch {  }
        this.enabled = !off;
        this.ctx = null; this.song = null; this.nextAt = 0; this.last = -1;
    }
    unlock() {
        if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
        const AC = typeof window !== 'undefined' && (window.AudioContext || window.webkitAudioContext);
        if (!AC) return;
        try { this.ctx = new AC(); } catch { return; }
        this.setupOutput(this.ctx);
        this.nextAt = this.ctx.currentTime + MUSIC_FIRST_DELAY[0] + Math.random() * (MUSIC_FIRST_DELAY[1] - MUSIC_FIRST_DELAY[0]);
        this.loadCalm();
    }
    loadCalm() {
        this.calm = [];
        for (const i of [1, 2, 3]) {
            const name = 'calm' + i + '.ogg';
            fetchSound(this.ctx, name)
                .then(buf => { this.calm.push({ buf, duration: buf.duration }); })
                .catch(() => soundElement(name).then(el => { this.calm.push({ el, duration: el.duration }); })
                    .catch(() => console.warn('Claudecraft: the music ' + name + ' could not be loaded from ' + soundUrls(name).join(' or '))));
        }
    }
    setupOutput(ctx) {
        this.ctx = ctx;
        this.out = ctx.createGain(); this.out.gain.value = MUSIC_VOLUME; this.out.connect(ctx.destination);
        RecordAudio.tap(ctx, this.out);
        const len = Math.floor(ctx.sampleRate * 2.4), ir = ctx.createBuffer(2, len, ctx.sampleRate);
        for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.2); }
        this.reverb = ctx.createConvolver(); this.reverb.buffer = ir;
        const wet = ctx.createGain(); wet.gain.value = 0.26; this.reverb.connect(wet); wet.connect(this.out);
    }
    setEnabled(on) {
        this.enabled = on;
        storeSetting('claudecraft-music', on ? 'on' : 'off');
        if (!on) this.stop();
        else if (this.ctx) this.nextAt = this.ctx.currentTime + 2;
    }
    stop() {
        if (!this.song || !this.ctx) return;
        const g = this.song.gain.gain, t = this.ctx.currentTime;
        g.cancelScheduledValues(t); g.setValueAtTime(g.value, t); g.linearRampToValueAtTime(0, t + 1.5);
        const old = this.song.gain, src = this.song.src, el = this.song.el;
        if (el) el.pause();
        setTimeout(() => { old.disconnect(); if (src) try { src.stop(); } catch {  } }, 2000);
        this.song = null;
    }
    update() {
        const ctx = this.ctx;
        if (!ctx || !this.enabled || ctx.state !== 'running') return;
        const now = ctx.currentTime;
        if (!this.song) {
            if (now < this.nextAt) return;
            if (this.calm && this.calm.length) {
                let k; do { k = Math.floor(Math.random() * this.calm.length); } while (k === this.lastCalm && this.calm.length > 1);
                this.lastCalm = k;
                const c = this.calm[k], gain = ctx.createGain(), start = now + 0.5;
                gain.gain.value = 0.5 / MUSIC_VOLUME; gain.connect(this.out);
                if (c.buf) {
                    const src = ctx.createBufferSource(); src.buffer = c.buf; src.connect(gain); src.start(start);
                    this.song = { gain, src, notes: [], i: 0, spb: 1, start, end: start + c.duration };
                } else {
                    const el = c.el; el.currentTime = 0; el.volume = 0.5; el.play().then(() => RecordAudio.element(el)).catch(() => {  });
                    this.song = { gain, el, notes: [], i: 0, spb: 1, start, end: start + (Number.isFinite(c.duration) ? c.duration : 240) };
                }
                return;
            }
            let k; do { k = Math.floor(Math.random() * SONGS.length); } while (k === this.last && SONGS.length > 1);
            this.last = k;
            const s = SONGS[k], gain = ctx.createGain(); gain.gain.value = s.level || 1;
            gain.connect(this.out); gain.connect(this.reverb);
            const notes = s.build().sort((a, b) => a.beat - b.beat);
            const spb = 60 / s.bpm, start = now + 0.5;
            this.song = { gain, notes, i: 0, spb, start, end: start + (notes[notes.length - 1].beat + 8) * spb };
        }
        const sg = this.song;
        if (sg.i < sg.notes.length) {
            const due = sg.start + sg.notes[sg.i].beat * sg.spb;
            if (due < now - 0.25) { const late = now + 0.1 - due; sg.start += late; sg.end += late; }
        }
        while (sg.i < sg.notes.length && sg.start + sg.notes[sg.i].beat * sg.spb < now + 2) {
            const n = sg.notes[sg.i++], t = Math.max(now, sg.start + n.beat * sg.spb);
            if (n.pad) this.pad(t, n.pad, n.len * sg.spb, n.v, sg.gain); else this.piano(t, n.m, n.v, sg.gain);
        }
        if (now > sg.end) {
            sg.gain.disconnect(); this.song = null;
            this.nextAt = now + MUSIC_GAP[0] + Math.random() * (MUSIC_GAP[1] - MUSIC_GAP[0]);
        }
    }
    piano(t, m, v, dest) {
        const ctx = this.ctx, f = 440 * Math.pow(2, (m - 69) / 12), decay = Math.max(2.2, Math.min(6, 3.8 + (60 - m) * 0.06));
        const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 6000 + v * 8000; lp.Q.value = 0.3;
        let last = lp;
        if (ctx.createStereoPanner) { const pan = ctx.createStereoPanner(); pan.pan.value = Math.max(-0.45, Math.min(0.45, (m - 64) / 40)); lp.connect(pan); last = pan; }
        last.connect(dest);
        [[1, 1, 1], [2, 0.6, 0.75], [3, 0.32, 0.55], [4, 0.2, 0.42], [5, 0.11, 0.33], [6, 0.07, 0.27], [7, 0.035, 0.22]].forEach(([h, a, keep]) => {
            const fh = f * h * (1 + 0.0004 * h * h); if (fh > 16000) return;
            const o = ctx.createOscillator(), g = ctx.createGain(), d = decay * keep;
            o.frequency.value = fh;
            g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v * a, t + 0.004);
            g.gain.exponentialRampToValueAtTime(v * a * 0.4, t + 0.25 * keep + 0.05); g.gain.exponentialRampToValueAtTime(0.0005, t + d);
            o.connect(g); g.connect(lp); o.start(t); o.stop(t + d + 0.05);
        });
        if (!this.tap || this.tap.sampleRate !== ctx.sampleRate) {
            const n = Math.floor(ctx.sampleRate * 0.03); this.tap = ctx.createBuffer(1, n, ctx.sampleRate);
            const d = this.tap.getChannelData(0); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 4);
        }
        const src = ctx.createBufferSource(), tg = ctx.createGain(), hp = ctx.createBiquadFilter();
        src.buffer = this.tap; hp.type = 'bandpass'; hp.frequency.value = Math.min(5000, f * 4); hp.Q.value = 1.2;
        tg.gain.value = v * 0.06; src.connect(hp); hp.connect(tg); tg.connect(lp); src.start(t);
    }
    pad(t, notes, len, v, dest) {
        const ctx = this.ctx, g = ctx.createGain(), lp = ctx.createBiquadFilter();
        lp.type = 'lowpass'; lp.frequency.value = 900; lp.connect(dest); g.connect(lp);
        g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v, t + Math.min(2, len / 3)); g.gain.setValueAtTime(v, t + len * 0.7); g.gain.linearRampToValueAtTime(0, t + len + 1.5);
        for (const m of notes) for (const det of [-7, 7]) {
            const o = ctx.createOscillator(); o.type = 'triangle'; o.frequency.value = 440 * Math.pow(2, (m - 69) / 12); o.detune.value = det;
            o.connect(g); o.start(t); o.stop(t + len + 1.6);
        }
    }
}
const HARDNESS_024 = { [BLOCK.ROCK]: 1, [BLOCK.GRASS]: 0.6, [BLOCK.DIRT]: 0.5, [BLOCK.COBBLESTONE]: 2, [BLOCK.PLANKS]: 2,
    [BLOCK.SAPLING]: 0, [BLOCK.SAND]: 0.5, [BLOCK.GRAVEL]: 0.6, [BLOCK.GOLD_ORE]: 3, [BLOCK.IRON_ORE]: 3, [BLOCK.COAL_ORE]: 3,
    [BLOCK.LOG]: 2.5, [BLOCK.LEAVES]: 0.2, [BLOCK.DANDELION]: 0, [BLOCK.ROSE]: 0, [BLOCK.BROWN_MUSHROOM]: 0, [BLOCK.RED_MUSHROOM]: 0 };
const hardTicks024 = type => Math.trunc((HARDNESS_024[type] ?? 1) * 20);
function drops024(type) {
    if (type === BLOCK.GRASS) return [BLOCK.DIRT, 1];
    if (type === BLOCK.LOG) return [BLOCK.PLANKS, 3 + Math.floor(Math.random() * 3)];
    if (type === BLOCK.LEAVES) return [BLOCK.SAPLING, Math.floor(Math.random() * 6) === 0 ? 1 : 0];
    return [type, 1];
}
const UNBREAKABLE_024 = new Set([BLOCK.AIR, BLOCK.WATER, BLOCK.LAVA, BLOCK.BEDROCK, BLOCK.BARRIER]);
function moveBox024(level, bb, xd, yd, zd) {
    const oxd = xd, oyd = yd, ozd = zd;
    const x0 = Math.floor(Math.min(bb[0], bb[0] + xd)), x1 = Math.floor(Math.max(bb[3], bb[3] + xd));
    const y0 = Math.floor(Math.min(bb[1], bb[1] + yd)), y1 = Math.floor(Math.max(bb[4], bb[4] + yd));
    const z0 = Math.floor(Math.min(bb[2], bb[2] + zd)), z1 = Math.floor(Math.max(bb[5], bb[5] + zd));
    const cubes = [];
    for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) {
        const out = x < 0 || z < 0 || x >= level.width || z >= level.height || y < 0;
        if (out || level.isSolidTile(x, y, z)) cubes.push([x, y, z]);
    }
    for (const [x, y, z] of cubes) {
        if (bb[3] <= x || bb[0] >= x + 1 || bb[5] <= z || bb[2] >= z + 1) continue;
        if (yd > 0 && bb[4] <= y) yd = Math.min(yd, y - bb[4]);
        if (yd < 0 && bb[1] >= y + 1) yd = Math.max(yd, y + 1 - bb[1]);
    }
    bb[1] += yd; bb[4] += yd;
    for (const [x, y, z] of cubes) {
        if (bb[4] <= y || bb[1] >= y + 1 || bb[5] <= z || bb[2] >= z + 1) continue;
        if (xd > 0 && bb[3] <= x) xd = Math.min(xd, x - bb[3]);
        if (xd < 0 && bb[0] >= x + 1) xd = Math.max(xd, x + 1 - bb[0]);
    }
    bb[0] += xd; bb[3] += xd;
    for (const [x, y, z] of cubes) {
        if (bb[4] <= y || bb[1] >= y + 1 || bb[3] <= x || bb[0] >= x + 1) continue;
        if (zd > 0 && bb[5] <= z) zd = Math.min(zd, z - bb[5]);
        if (zd < 0 && bb[2] >= z + 1) zd = Math.max(zd, z + 1 - bb[2]);
    }
    bb[2] += zd; bb[5] += zd;
    return { xd, yd, zd, onGround: oyd !== yd && oyd < 0, hitX: oxd !== xd, hitZ: ozd !== zd };
}
const HUMANOID_024 = {
    head: { tex: [0, 0], box: [-4, -8, -4, 8, 8, 8], pos: [0, 0, 0] },
    hat: { tex: [32, 0], box: [-4, -8, -4, 8, 8, 8], pos: [0, 0, 0], grow: 0.5 },
    body: { tex: [16, 16], box: [-4, 0, -2, 8, 12, 4], pos: [0, 0, 0] },
    arm0: { tex: [40, 16], box: [-3, -2, -2, 4, 12, 4], pos: [-5, 2, 0] },
    arm1: { tex: [40, 16], box: [-1, -2, -2, 4, 12, 4], pos: [5, 2, 0], mirror: true },
    leg0: { tex: [0, 16], box: [-2, 0, -2, 4, 12, 4], pos: [-2, 12, 0] },
    leg1: { tex: [0, 16], box: [-2, 0, -2, 4, 12, 4], pos: [2, 12, 0], mirror: true }
};
const SKELETON_024 = { ...HUMANOID_024,
    arm0: { tex: [40, 16], box: [-1, -2, -1, 2, 12, 2], pos: [-5, 2, 0] },
    arm1: { tex: [40, 16], box: [-1, -2, -1, 2, 12, 2], pos: [5, 2, 0], mirror: true },
    leg0: { tex: [0, 16], box: [-1, 0, -1, 2, 12, 2], pos: [-2, 12, 0] },
    leg1: { tex: [0, 16], box: [-1, 0, -1, 2, 12, 2], pos: [2, 12, 0], mirror: true } };
const CREEPER_024 = {
    head: { tex: [0, 0], box: [-4, -8, -4, 8, 8, 8], pos: [0, 0, 0] },
    body: { tex: [16, 16], box: [-4, 0, -2, 8, 12, 4], pos: [0, 0, 0] },
    leg0: { tex: [0, 16], box: [-2, 0, -2, 4, 6, 4], pos: [-2, 12, 4] },
    leg1: { tex: [0, 16], box: [-2, 0, -2, 4, 6, 4], pos: [2, 12, 4] },
    leg2: { tex: [0, 16], box: [-2, 0, -2, 4, 6, 4], pos: [-2, 12, -4] },
    leg3: { tex: [0, 16], box: [-2, 0, -2, 4, 6, 4], pos: [2, 12, -4] } };
const PIG_024 = {
    head: { tex: [0, 0], box: [-4, -4, -8, 8, 8, 8], pos: [0, 12, -6] },
    body: { tex: [28, 8], box: [-5, -10, -7, 10, 16, 8], pos: [0, 11, 2] },
    leg0: { tex: [0, 16], box: [-2, 0, -2, 4, 6, 4], pos: [-3, 18, 7] },
    leg1: { tex: [0, 16], box: [-2, 0, -2, 4, 6, 4], pos: [3, 18, 7] },
    leg2: { tex: [0, 16], box: [-2, 0, -2, 4, 6, 4], pos: [-3, 18, -5] },
    leg3: { tex: [0, 16], box: [-2, 0, -2, 4, 6, 4], pos: [3, 18, -5] } };
const ARMOUR_024 = { head: HUMANOID_024.head, body: HUMANOID_024.body, arm0: HUMANOID_024.arm0, arm1: HUMANOID_024.arm1 };
const MOBS_024 = {
    zombie: { parts: HUMANOID_024, tex: 'zombie', w: 0.6, h: 1.8, eye: 1.62, look: 30, score: 100, attack: true },
    skeleton: { parts: SKELETON_024, tex: 'skeleton', w: 0.6, h: 1.8, eye: 1.62, look: 30, score: 100, attack: true },
    creeper: { parts: CREEPER_024, tex: 'creeper', w: 0.6, h: 1.8, eye: 1.62, look: 45, score: 250, attack: true, explodes: true },
    pig: { parts: PIG_024, tex: 'pig', w: 1.4, h: 1.2, eye: 1.72, look: 0, score: 10, attack: false }
};
function partGeo024(p, grow = 0) {
    const geo = buildModelBox(p.tex[0], p.tex[1], ...p.box, grow);
    if (p.mirror) {
        geo.applyMatrix4(new THREE.Matrix4().makeScale(-1, 1, 1)).applyMatrix4(new THREE.Matrix4().makeTranslation(2 * p.box[0] + p.box[3], 0, 0));
    }
    return geo;
}
const rad024 = d => d * Math.PI / 180;
class Mob024 {
    constructor(sv, kind, x, feet, z) {
        this.sv = sv; this.kind = kind; this.def = MOBS_024[kind];
        this.w = this.def.w; this.h = this.def.h;
        this.x = x; this.feet = feet; this.z = z; this.xo = x; this.feeto = feet; this.zo = z;
        this.xd = 0; this.yd = 0; this.zd = 0; this.onGround = false; this.hitX = false; this.hitZ = false;
        this.yRot = Math.random() * 360; this.xRot = 0; this.yRotO = this.yRot; this.xRotO = 0; this.yBodyRot = this.yRot; this.yBodyRotO = this.yRot;
        this.health = 20; this.lastHealth = 20; this.invulnerableTime = 0; this.hurtTime = 0; this.hurtDuration = 10; this.hurtDir = 0;
        this.deathTime = 0; this.attackTime = 0; this.airSupply = 300; this.fallDistance = 0; this.tickCount = 0;
        this.animStep = 0; this.animStepO = 0; this.run = 0; this.oRun = 0; this.removed = false;
        this.ai = { xxa: 0, yya: 0, turn: 0, jumping: false, cooldown: 0, look: this.def.look };
        this.id = sv.mobSeq = (sv.mobSeq || 0) + 1;
        this.helmet = (kind === 'zombie' || kind === 'skeleton') && Math.random() < 0.2;
        this.armour = (kind === 'zombie' || kind === 'skeleton') && Math.random() < 0.2;
        this.mesh = null;
    }
    get y() { return this.feet + this.def.eye; }
    get bb() { const hw = this.w / 2; return [this.x - hw, this.feet, this.z - hw, this.x + hw, this.feet + this.h, this.z + hw]; }
    tick() {
        const lv = this.sv.game.level;
        this.xo = this.x; this.feeto = this.feet; this.zo = this.z;
        this.oTilt = 0;
        if (this.attackTime > 0) this.attackTime--;
        if (this.hurtTime > 0) this.hurtTime--;
        if (this.invulnerableTime > 0) this.invulnerableTime--;
        if (this.health <= 0 && ++this.deathTime > 20) {
            if (this.def.explodes) this.sv.explode(this, this.x, this.y, this.z, 4);
            if (this.kind === 'skeleton' && this.sv.arrowsOn) this.sv.skeletonBurst(this);
            this.removed = true;
            return;
        }
        if (lv.getTile(Math.floor(this.x), Math.floor(this.y + 0.12), Math.floor(this.z)) === BLOCK.WATER) {
            if (this.airSupply > 0) this.airSupply--; else this.hurt(null, 2);
        } else this.airSupply = 300;
        const inWater = this.bodyIn(BLOCK.WATER), inLava = this.bodyIn(BLOCK.LAVA);
        if (inWater) this.fallDistance = 0;
        if (inLava) this.hurt(null, 10);
        this.animStepO = this.animStep; this.yBodyRotO = this.yBodyRot; this.yRotO = this.yRot; this.xRotO = this.xRot;
        this.tickCount++;
        this.aiStep(inWater, inLava);
        const dx = this.x - this.xo, dz = this.z - this.zo, dist = Math.hypot(dx, dz);
        let body = this.yBodyRot, step = 0, runTo = 0;
        this.oRun = this.run;
        if (dist > 0.05) { runTo = 1; step = dist * 3; body = Math.atan2(dz, dx) * 180 / Math.PI - 90; }
        if (!this.onGround) runTo = 0;
        this.run += (runTo - this.run) * 0.3;
        let diff = body - this.yBodyRot; while (diff < -180) diff += 360; while (diff >= 180) diff -= 360;
        this.yBodyRot += diff * 0.3;
        let head = this.yRot - this.yBodyRot; while (head < -180) head += 360; while (head >= 180) head -= 360;
        if (head < -75) this.yBodyRot += head + 75; if (head > 75) this.yBodyRot += head - 75;
        this.animStep += step;
    }
    bodyIn(type) {
        const lv = this.sv.game.level, bb = this.bb;
        for (let x = Math.floor(bb[0] + 0.001); x <= Math.floor(bb[3] - 0.001); x++)
            for (let y = Math.floor(bb[1] + 0.4); y <= Math.floor(bb[4] - 0.4); y++)
                for (let z = Math.floor(bb[2] + 0.001); z <= Math.floor(bb[5] - 0.001); z++) if (lv.getTile(x, y, z) === type) return true;
        return false;
    }
    aiStep(inWater, inLava) {
        const ai = this.ai, r = Math.random, sv = this.sv;
        if (ai.cooldown > 0) ai.cooldown--;
        if (this.health <= 0) { ai.jumping = false; ai.xxa = 0; ai.yya = 0; ai.turn = 0; }
        else {
            if (r() < 0.07) { ai.xxa = r() - 0.5; ai.yya = r(); }
            if (r() < 0.04) ai.turn = (r() - 0.5) * 60;
            this.yRot += ai.turn; this.xRot = ai.look;
            ai.jumping = r() < 0.01;
            if (inWater || inLava) ai.jumping = r() < 0.8;
            const target = sv.nearestPlayer(this.x, this.y, this.z);
            if (this.def.attack && target) this.attackAI(target);
            if (this.kind === 'skeleton' && target) {
                const p = target;
                if (p && p.health > 0 && Math.random() < 1 / 30) {
                    const dx = p.position.x - this.x, dz = p.position.z - this.z, d = Math.hypot(dx, dz);
                    if (d < 16 && d > 1.5 && !sv.blocked(this.x, this.y, this.z, p.position.x, p.position.y, p.position.z)) {
                        this.yRot = Math.atan2(dz, dx) * 180 / Math.PI - 90; this.attackTime = 5;
                        sv.skeletonShoot(this, p);
                    }
                }
            }
        }
        if (ai.jumping) { if (inWater || inLava) this.yd += 0.04; else if (this.onGround) this.yd = 0.42; }
        ai.xxa *= 0.98; ai.yya *= 0.98; ai.turn *= 0.9;
        this.travel(ai.xxa, ai.yya, inWater, inLava);
    }
    attackAI(p) {
        if (!p || p.health == null) return;
        const tx = p.position.x, ty = p.position.y, tz = p.position.z;
        const dx = tx - this.x, dz = tz - this.z, flat = Math.hypot(dx, dz);
        if (!(flat < 8)) return;
        const dy = ty - this.y;
        this.yRot = Math.atan2(dz, dx) * 180 / Math.PI - 90;
        this.xRot = -Math.atan2(dy, flat) * 180 / Math.PI;
        if (Math.hypot(dx, dy, dz) < 2 && this.ai.cooldown === 0) {
            if (this.sv.blocked(this.x, this.y, this.z, tx, ty, tz)) return;
            this.attackTime = 5;
            this.ai.cooldown = Math.floor(Math.random() * 20) + 10;
            this.sv.hurtTarget(p, this, Math.floor(Math.random() * 4) + Math.floor(Math.random() * 4) + 1);
            if (this.def.explodes) this.hurt(p, 4);
        }
    }
    moveRelative(xa, za, speed) {
        let d = xa * xa + za * za;
        if (d < 0.01) return;
        d = speed / Math.sqrt(d); xa *= d; za *= d;
        const s = Math.sin(rad024(this.yRot)), c = Math.cos(rad024(this.yRot));
        this.xd += xa * c - za * s; this.zd += za * c + xa * s;
    }
    move(xd, yd, zd) {
        const bb = this.bb, m = moveBox024(this.sv.game.level, bb, xd, yd, zd);
        this.x = (bb[0] + bb[3]) / 2; this.feet = bb[1]; this.z = (bb[2] + bb[5]) / 2;
        this.hitX = m.hitX; this.hitZ = m.hitZ;
        if (m.hitX) this.xd = 0; if (m.hitZ) this.zd = 0; if (m.yd !== yd) this.yd = 0;
        this.onGround = m.onGround;
        if (this.onGround) { if (this.fallDistance > 0) { const d = Math.ceil(this.fallDistance - 3); if (d > 0) this.hurt(null, d); this.fallDistance = 0; } }
        else if (m.yd < 0) this.fallDistance -= m.yd;
        if (this.feet < -20) this.removed = true;
    }
    free(xd, yd, zd) {
        const bb = this.bb; bb[0] += xd; bb[3] += xd; bb[1] += yd; bb[4] += yd; bb[2] += zd; bb[5] += zd;
        const lv = this.sv.game.level;
        for (let x = Math.floor(bb[0]); x <= Math.floor(bb[3]); x++) for (let y = Math.floor(bb[1]); y <= Math.floor(bb[4]); y++)
            for (let z = Math.floor(bb[2]); z <= Math.floor(bb[5]); z++) if (lv.isSolidTile(x, y, z) || lv.getTile(x, y, z) === BLOCK.WATER || lv.getTile(x, y, z) === BLOCK.LAVA) return false;
        return true;
    }
    travel(xa, za, inWater, inLava) {
        if (inWater || inLava) {
            const y0 = this.feet, k = inWater ? 0.8 : 0.5;
            this.moveRelative(xa, za, 0.02); this.move(this.xd, this.yd, this.zd);
            this.xd *= k; this.yd *= k; this.zd *= k; this.yd -= 0.02;
            if ((this.hitX || this.hitZ) && this.free(this.xd, this.yd + 0.6 - this.feet + y0, this.zd)) this.yd = 0.3;
            return;
        }
        this.moveRelative(xa, za, this.onGround ? 0.1 : 0.02);
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.91; this.yd *= 0.98; this.zd *= 0.91; this.yd -= 0.08;
        if (this.onGround) { this.xd *= 0.6; this.zd *= 0.6; }
    }
    hurt(src, damage) {
        if (this.health <= 0) return;
        if (this.invulnerableTime > 15) {
            if (this.lastHealth - damage >= this.health) return;
            this.health = this.lastHealth - damage;
        } else {
            this.lastHealth = this.health; this.invulnerableTime = 30; this.health -= damage; this.hurtDuration = 10; this.hurtTime = 10;
        }
        this.hurtDir = 0;
        const s = src && (src.position ? { x: src.position.x, z: src.position.z } : src);
        if (s) {
            const dx = s.x - this.x, dz = s.z - this.z, d = Math.hypot(dx, dz) || 1;
            this.hurtDir = Math.atan2(dz, dx) * 180 / Math.PI - this.yRot;
            this.xd /= 2; this.yd /= 2; this.zd /= 2;
            this.xd -= dx / d * 0.4; this.yd = Math.min(this.yd + 0.4, 0.4); this.zd -= dz / d * 0.4;
        } else this.hurtDir = Math.floor(Math.random() * 2) * 180;
        if (this.health <= 0) {
            if (this.kind === 'pig') {
                const n = Math.floor(Math.random() + Math.random() + 1);
                for (let i = 0; i < n; i++) this.sv.addSharedItem(this.x, this.feet + 0.5, this.z, BLOCK.BROWN_MUSHROOM);
            }
            const killer = src && src.owner ? src.owner : src;
            if (killer && killer.score != null) killer.score += this.def.score;
            else if (killer && killer.remoteId) this.sv.game.sendNet({ t: 'score', target: killer.remoteId, add: this.def.score });
        }
    }
    makeMesh() {
        const sv = this.sv, root = new THREE.Group(), hurtG = new THREE.Group(), flip = new THREE.Group(), lift = new THREE.Group(), turn = new THREE.Group(), mirror = new THREE.Group(), px = new THREE.Group();
        flip.scale.set(1, -1, 1); mirror.scale.set(-1, 1, 1); px.scale.setScalar(1 / 16);
        root.add(hurtG); hurtG.add(flip); flip.add(lift); lift.add(turn); turn.add(mirror); mirror.add(px);
        this.mat = sv.mobMaterial(this.def.tex);
        this.parts = {};
        for (const [name, p] of Object.entries(this.def.parts)) {
            const g = new THREE.Group(); g.position.set(...p.pos); g.rotation.order = 'ZYX';
            g.add(new THREE.Mesh(sv.partGeo(this.kind, name, p, p.grow || 0), this.mat));
            if ((name === 'head' && this.helmet) || ((name === 'body' || name === 'arm0' || name === 'arm1') && this.armour))
                g.add(new THREE.Mesh(sv.partGeo('armour', name, ARMOUR_024[name], 1), sv.armourMat));
            px.add(g); this.parts[name] = g;
        }
        this.mesh = root; this.hurtG = hurtG; this.lift = lift; this.turn = turn;
        sv.game.scene.add(root);
    }
    dropMesh() { if (this.mesh) { this.sv.game.scene.remove(this.mesh); this.mat.dispose(); this.mesh = null; } }
    frame(a) {
        if (!this.mesh) this.makeMesh();
        const L = (o, n) => o + (n - o) * a, wrap = (o, n) => { while (o - n < -180) o += 360; while (o - n >= 180) o -= 360; return o; };
        const body = L(wrap(this.yBodyRotO, this.yBodyRot), this.yBodyRot), yRot = L(wrap(this.yRotO, this.yRot), this.yRot);
        const xRot = L(wrap(this.xRotO, this.xRot), this.xRot), run = L(this.oRun, this.run), t = L(this.animStepO, this.animStep);
        this.mesh.position.set(L(this.xo, this.x), L(this.feeto, this.feet) + this.def.eye - 1.62, L(this.zo, this.z));
        let tip = this.hurtTime - a;
        if (tip > 0 || this.health <= 0) {
            tip = tip < 0 ? 0 : Math.sin(Math.pow(tip / this.hurtDuration, 4) * Math.PI) * 14;
            if (this.health <= 0) { const d = (this.deathTime + a) / 20; tip = Math.min(90, tip + d * d * 800); }
            const Y = new THREE.Vector3(0, 1, 0), Z = new THREE.Vector3(0, 0, 1), f5 = rad024(180 - body);
            this.hurtG.quaternion.setFromAxisAngle(Y, f5).multiply(new THREE.Quaternion().setFromAxisAngle(Y, -rad024(this.hurtDir)))
                .multiply(new THREE.Quaternion().setFromAxisAngle(Z, -rad024(tip))).multiply(new THREE.Quaternion().setFromAxisAngle(Y, rad024(this.hurtDir)))
                .multiply(new THREE.Quaternion().setFromAxisAngle(Y, -f5));
        } else this.hurtG.quaternion.identity();
        this.lift.position.y = (-Math.abs(Math.cos(t * 0.6662)) * 5 * run - 23) / 16;
        this.turn.rotation.y = rad024(180 - body);
        const P = this.parts, head = rad024(yRot - body), pitch = rad024(xRot), bob = this.tickCount + a;
        P.head.rotation.set(pitch, head, 0); if (P.hat) P.hat.rotation.set(pitch, head, 0);
        if (this.kind === 'pig' || this.kind === 'creeper') {
            if (this.kind === 'pig') P.body.rotation.x = Math.PI / 2;
            const c = Math.cos(t * 0.6662) * 1.4 * run, c2 = Math.cos(t * 0.6662 + Math.PI) * 1.4 * run;
            P.leg0.rotation.x = c; P.leg1.rotation.x = c2; P.leg2.rotation.x = c2; P.leg3.rotation.x = c;
        } else {
            P.arm0.rotation.set(Math.cos(t * 0.6662 + Math.PI) * 2 * run, 0, (Math.cos(t * 0.2312) + 1) * run);
            P.arm1.rotation.set(Math.cos(t * 0.6662) * 2 * run, 0, (Math.cos(t * 0.2812) - 1) * run);
            P.leg0.rotation.x = Math.cos(t * 0.6662) * 1.4 * run; P.leg1.rotation.x = Math.cos(t * 0.6662 + Math.PI) * 1.4 * run;
            P.arm0.rotation.z += Math.cos(bob * 0.09) * 0.05 + 0.05; P.arm1.rotation.z -= Math.cos(bob * 0.09) * 0.05 + 0.05;
            P.arm0.rotation.x += Math.sin(bob * 0.067) * 0.05; P.arm1.rotation.x -= Math.sin(bob * 0.067) * 0.05;
            const att = Math.sin(Math.max(0, this.attackTime - a) / 5 * Math.PI);
            P.arm0.rotation.z = 0; P.arm1.rotation.z = 0;
            P.arm0.rotation.y = -(0.1 - att * 0.6); P.arm1.rotation.y = 0.1 - att * 0.6;
            P.arm0.rotation.x = -Math.PI / 2; P.arm1.rotation.x = -Math.PI / 2;
        }
        const lv = this.sv.game.level;
        let b = lv.isLit(Math.floor(this.x), Math.floor(this.y), Math.floor(this.z)) ? 0.8 : 0.5;
        if (this.def.explodes) { const f = (20 - this.health) / 20; b *= (Math.sin(this.tickCount + a) * 0.5 + 0.5) * f * 0.5 + 0.25 + f * 0.25; }
        if (this.invulnerableTime > 20) b *= 1.75;
        this.mat.color.setScalar(b);
    }
}
class Arrow024 {
    constructor(sv, owner, x, y, z, yRot, xRot, speed, pickable = false, harmless = false) {
        this.sv = sv; this.owner = owner; this.pickable = pickable; this.harmless = harmless;
        const f7 = Math.cos(rad024(-yRot) - Math.PI), f8 = Math.sin(rad024(-yRot) - Math.PI), c = Math.cos(rad024(-xRot)), s = Math.sin(rad024(-xRot));
        this.x = x - f7 * 0.2; this.y = y; this.z = z + f8 * 0.2;
        this.xd = f8 * c * speed; this.yd = s * speed; this.zd = f7 * c * speed;
        this.xo = this.x; this.yo = this.y; this.zo = this.z;
        this.hasHit = false; this.stickTime = 0; this.time = 0; this.removed = false;
        this.mesh = sv.arrowMesh(); sv.game.scene.add(this.mesh);
        this.dir = new THREE.Vector3(this.xd, this.yd, this.zd).normalize();
    }
    tick() {
        this.time++; this.xo = this.x; this.yo = this.y; this.zo = this.z;
        if (this.hasHit) {
            if (++this.stickTime >= (this.pickable ? 6000 : 20)) this.removed = true;
            const p = this.sv.player;
            if (this.pickable && p.health > 0 && p.arrows < 99) {
                const pos = p.position, feet = pos.y - PLAYER_HEIGHT;
                if (Math.abs(this.x - pos.x) < 1.3 && Math.abs(this.z - pos.z) < 1.3 && this.y > feet - 0.5 && this.y < feet + 2.3) { p.arrows = Math.min(99, p.arrows + (this.bundle || 1)); this.removed = true; }
            }
            return;
        }
        this.xd *= 0.992; this.yd *= 0.992; this.zd *= 0.992; this.yd -= 0.02;
        const sp = Math.hypot(this.xd, this.yd, this.zd), n = Math.floor(sp / 0.2 + 1);
        const sx = this.xd / n, sy = this.yd / n, sz = this.zd / n, lv = this.sv.game.level;
        let hit = false;
        for (let i = 0; i < n && !hit; i++) {
            const nx = this.x + sx, ny = this.y + sy, nz = this.z + sz;
            if (lv.isSolidTile(Math.floor(nx), Math.floor(ny), Math.floor(nz))) { hit = true; break; }
            const pl = this.sv.player;
            if (this.time <= 20 && !this.harmless && this.owner !== pl && pl.health > 0) {
                const pp = pl.position, feet = pp.y - PLAYER_HEIGHT, hw = PLAYER_WIDTH / 2;
                if (nx + 0.125 > pp.x - hw && nx - 0.125 < pp.x + hw && ny + 0.25 > feet && ny - 0.25 < feet + 1.8 && nz + 0.125 > pp.z - hw && nz - 0.125 < pp.z + hw) {
                    this.sv.hurt(pl, { x: this.x - this.xd * 3, z: this.z - this.zd * 3 }, 3); hit = true; this.stickTime = 20; this.pickable = false; break;
                }
            }
            if (this.time <= 20 && !this.harmless) for (const m of this.sv.mobs) {
                if (m.health <= 0 || m === this.owner) continue;
                const b = m.bb;
                if (nx + 0.125 > b[0] && nx - 0.125 < b[3] && ny + 0.25 > b[1] && ny - 0.25 < b[4] && nz + 0.125 > b[2] && nz - 0.125 < b[5]) { m.hurt(this, 3); hit = true; this.stickTime = 20; break; }
            }
            if (hit) break;
            this.x = nx; this.y = ny; this.z = nz;
        }
        if (hit) { this.hasHit = true; this.xd = this.yd = this.zd = 0; }
        else this.dir.set(this.xd, this.yd, this.zd).normalize();
    }
    frame(a) {
        this.mesh.position.set(this.xo + (this.x - this.xo) * a, this.yo + (this.y - this.yo) * a, this.zo + (this.z - this.zo) * a);
        this.mesh.quaternion.setFromUnitVectors(new THREE.Vector3(1, 0, 0), this.dir);
    }
}
class Sign024 {
    constructor(sv, p) {
        this.sv = sv;
        this.rot = -sv.yRot(p);
        this.x = p.position.x; this.feet = p.position.y - PLAYER_HEIGHT + 0.2; this.z = p.position.z;
        this.xd = -Math.sin(rad024(this.rot)) * 0.05; this.yd = 0.2; this.zd = -Math.cos(rad024(this.rot)) * 0.05;
        this.xo = this.x; this.feeto = this.feet; this.zo = this.z; this.removed = false;
        this.mesh = sv.signMesh(); this.mesh.rotation.y = rad024(this.rot); sv.game.scene.add(this.mesh);
    }
    tick() {
        this.xo = this.x; this.feeto = this.feet; this.zo = this.z;
        this.yd -= 0.04;
        const bb = [this.x - 0.25, this.feet, this.z - 0.25, this.x + 0.25, this.feet + 1.5, this.z + 0.25];
        const m = moveBox024(this.sv.game.level, bb, this.xd, this.yd, this.zd);
        this.x = (bb[0] + bb[3]) / 2; this.feet = bb[1]; this.z = (bb[2] + bb[5]) / 2;
        if (m.hitX) this.xd = 0; if (m.hitZ) this.zd = 0; if (m.yd !== this.yd) this.yd = 0;
        this.xd *= 0.98; this.yd *= 0.98; this.zd *= 0.98;
        if (m.onGround) { this.xd *= 0.7; this.zd *= 0.7; this.yd *= -0.5; }
    }
    frame(a) { this.mesh.position.set(this.xo + (this.x - this.xo) * a, this.feeto + (this.feet - this.feeto) * a + 0.75, this.zo + (this.z - this.zo) * a); }
}
class Survival024 {
    constructor(game) {
        this.game = game;
        this.items = [];
        this.mobs = []; this.arrows = []; this.signs = [];
        this.mine = { x: -1, y: -1, z: -1, count: 0, ticks: 0, cooldown: 0 };
        this.leftHeld = false;
        this.ticks = 0;
        this.img = {};
        this.img.gui = loadImageAny(GUI_PATHS);
        this.img.icons = loadImageAny(ICONS_PATHS);
        this.img.terrain = loadImageAny(TERRAIN_PATHS);
        this.itemGeos = {};
        this.itemMat = new THREE.MeshBasicMaterial({ map: game.solidMaterial.map, alphaTest: 0.1 });
        this.itemMatDark = new THREE.MeshBasicMaterial({ map: game.solidMaterial.map, alphaTest: 0.1, color: 0x999999 });
        this.itemPlantMat = new THREE.MeshBasicMaterial({ map: game.solidMaterial.map, alphaTest: 0.1, side: THREE.DoubleSide });
        const crackGeo = new THREE.BoxGeometry(1.004, 1.004, 1.004);
        this.crackMat = new THREE.MeshBasicMaterial({ map: game.solidMaterial.map.clone(), transparent: true, depthWrite: false,
            blending: THREE.CustomBlending, blendEquation: THREE.AddEquation, blendSrc: THREE.DstColorFactor, blendDst: THREE.SrcColorFactor,
            polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
        this.crackMat.map.needsUpdate = true;
        this.crack = new THREE.Mesh(crackGeo, this.crackMat);
        this.crack.visible = false;
        game.scene.add(this.crack);
        this.crackStage = -1;
    }
    get player() { return this.game.player; }
    setupPlayer(p) {
        p.inventory = new Array(9).fill(BLOCK.AIR);
        p.counts = new Array(9).fill(0);
        p.pops = new Array(9).fill(0);
        p.health = 20; p.lastHealth = 20; p.invulnerableTime = 0; p.hurtTime = 0; p.hurtDuration = 10; p.hurtDir = 0;
        p.deathTime = 0; p.airSupply = 300; p.fallDistance = 0; p.score = 0; p.lastY = null;
        p.arrows = 20;
    }
    hurt(p, source, damage) {
        if (p.health <= 0) return;
        if (p.invulnerableTime > 30 / 2) {
            if (p.lastHealth - damage >= p.health) return;
            p.health = p.lastHealth - damage;
        } else {
            p.lastHealth = p.health;
            p.invulnerableTime = 30;
            p.health -= damage;
            p.hurtDuration = 10; p.hurtTime = 10;
        }
        p.hurtDir = 0;
        if (source) {
            const dx = source.x - p.position.x, dz = source.z - p.position.z;
            p.hurtDir = Math.atan2(dz, dx) * 180 / Math.PI - this.yRot(p);
            if (p.velocity) {
                const d = Math.hypot(dx, dz) || 1, v = p.velocity;
                const g = this.game;
                if (NOTCH_PHYSICS && !(g.lobby && g.lobby.sillyKnockback)) {
                    v.x = v.x / 2 - dx / d * 0.4 * 20; v.z = v.z / 2 - dz / d * 0.4 * 20;
                } else {
                    p.knockX = (p.knockX || 0) / 2 - dx / d * 0.4 * 20; p.knockZ = (p.knockZ || 0) / 2 - dz / d * 0.4 * 20;
                }
                v.y = Math.min(v.y / 2 + 0.4 * 20, 0.4 * 20);
            }
        } else p.hurtDir = Math.floor(Math.random() * 2) * 180;
        if (p.health <= 0) this.die(p);
    }
    heal(p, n) {
        if (p.health <= 0) return;
        p.health = Math.min(20, p.health + n);
        p.invulnerableTime = 30 / 2;
    }
    yRot(p) { return -p.rotation.y * 180 / Math.PI; }
    die(p) {
        p.deathTime = 0;
        this.leftHeld = false;
        const x = p.position.x, y = p.position.y - PLAYER_HEIGHT + 1, z = p.position.z;
        const shared = [];
        for (let i = 0; i < 9; i++) {
            if (p.inventory[i] !== BLOCK.AIR && p.counts[i] > 0) {
                const it = this.addItem(x, y, z, p.inventory[i], p.counts[i], 0.2);
                if (this.inLobby) { it.netId = this.game.netId + ':' + (++this.dropSeq || (this.dropSeq = 1)); shared.push({ id: it.netId, type: it.type, count: it.count, x, y, z, xd: it.xd, yd: it.yd, zd: it.zd }); }
            }
            p.inventory[i] = BLOCK.AIR; p.counts[i] = 0; p.pops[i] = 0;
        }
        this.game.blockPreview.setType(BLOCK.AIR);
        if (this.arrowsOn && p.arrows > 0) {
            for (let i = 0; i < Math.min(p.arrows, 30); i++) {
                const a = new Arrow024(this, p, x, y, z, Math.random() * 360, -(20 + Math.random() * 45), 0.2 + Math.random() * 0.25, true, true);
                this.arrows.push(a);
            }
            if (p.arrows > 30) this.arrows[this.arrows.length - 1].bundle = p.arrows - 29;
            p.arrows = 0;
        }
        this.game.sendNet({ t: 'dead', on: true });
        if (shared.length) this.game.sendNet({ t: 'drop', items: shared });
    }
    respawn() {
        const g = this.game, p = this.player;
        this.setupPlayer(p);
        if (!this.arrowsOn) p.arrows = 0;
        g.frozen = false;
        g.sendNet({ t: 'dead', on: false });
        if (g.spawnPoint) p.position.set(g.spawnPoint.x, g.spawnPoint.y, g.spawnPoint.z);
        p.velocity.set(0, 0, 0); p.knockX = p.knockZ = 0;
        g.blockPreview.setType(BLOCK.AIR);
        g.closeMenu(); g.lockPointer();
    }
    bodyIn(p, type, grow) {
        const lv = this.game.level, x = p.position.x, feet = p.position.y - PLAYER_HEIGHT, z = p.position.z, hw = PLAYER_WIDTH / 2 + grow;
        for (let bx = Math.floor(x - hw); bx <= Math.floor(x + hw - 1e-6); bx++)
            for (let by = Math.floor(feet + 0.4); by <= Math.floor(feet + 1.8 - 0.4 - 1e-6); by++)
                for (let bz = Math.floor(z - hw); bz <= Math.floor(z + hw - 1e-6); bz++)
                    if (lv.getTile(bx, by, bz) === type) return true;
        return false;
    }
    healthTick() {
        const p = this.player, g = this.game;
        g.frozen = p.health <= 0;
        if (p.hurtTime > 0) p.hurtTime--;
        if (p.invulnerableTime > 0) p.invulnerableTime--;
        if (p.health <= 0) {
            p.deathTime++;
            g.frozen = true;
            if (!g.menu && !g.statusMessage) { g.openMenu('gameover'); if (document.pointerLockElement) document.exitPointerLock(); }
            return;
        }
        const e = p.getEyePosition();
        if (g.level.getTile(Math.floor(e.x), Math.floor(e.y + 0.12), Math.floor(e.z)) === BLOCK.WATER) {
            if (p.airSupply > 0) p.airSupply--; else this.hurt(p, null, 2);
        } else p.airSupply = 300;
        const inWater = this.bodyIn(p, BLOCK.WATER, 0);
        if (inWater) p.fallDistance = 0;
        if (this.bodyIn(p, BLOCK.LAVA, -0.1)) this.hurt(p, null, 10);
        p.inWaterNow = inWater;
    }
    trackFall(y0) {
        const p = this.player;
        if (!p || p.health == null || p.health <= 0) return;
        const dy = p.position.y - y0;
        if (p.inWaterNow) { p.fallDistance = 0; return; }
        if (dy < 0) p.fallDistance -= dy;
        if (p.onGround) {
            if (p.fallDistance > 0) { const d = Math.ceil(p.fallDistance - 3); if (d > 0) this.hurt(p, null, d); }
            p.fallDistance = 0;
        }
    }
    adjustCamera(camera, a) {
        const p = this.player;
        if (!p) return;
        const hasHealth = p.health != null;
        camera.rotation.z = 0;
        const Y = new THREE.Vector3(0, 1, 0), Z = new THREE.Vector3(0, 0, 1);
        let q = new THREE.Quaternion();
        if (hasHealth && p.health <= 0) {
            camera.position.y -= PLAYER_HEIGHT - 0.1;
            q.multiply(new THREE.Quaternion().setFromAxisAngle(Z, (40 - 8000 / (p.deathTime + a + 200)) * Math.PI / 180));
        }
        let f = hasHealth ? p.hurtTime - a : -1;
        if (f >= 0) {
            f /= p.hurtDuration;
            f = Math.sin(f * f * f * f * Math.PI);
            const dir = p.hurtDir * Math.PI / 180;
            q.multiply(new THREE.Quaternion().setFromAxisAngle(Y, -dir))
             .multiply(new THREE.Quaternion().setFromAxisAngle(Z, -f * 14 * Math.PI / 180))
             .multiply(new THREE.Quaternion().setFromAxisAngle(Y, dir));
        }
        const pb = p.oBob != null ? p.oBob + (p.bob - p.oBob) * a : 0, pt = p.oTilt != null ? p.oTilt + (p.tilt - p.oTilt) * a : 0;
        const wd = p.walkDist != null ? p.walkDistO + (p.walkDist - p.walkDistO) * a : 0;
        const X = new THREE.Vector3(1, 0, 0);
        const qb = new THREE.Quaternion().setFromAxisAngle(Z, Math.sin(wd * Math.PI) * pb * 3 * Math.PI / 180)
            .multiply(new THREE.Quaternion().setFromAxisAngle(X, Math.abs(Math.cos(wd * Math.PI + 0.2) * pb) * 5 * Math.PI / 180))
            .multiply(new THREE.Quaternion().setFromAxisAngle(X, pt * Math.PI / 180));
        const tb = new THREE.Vector3(Math.sin(wd * Math.PI) * pb * 0.5, -Math.abs(Math.cos(wd * Math.PI) * pb), 0);
        const qView = camera.quaternion.clone(), qbInv = qb.clone().invert();
        camera.position.add(tb.negate().applyQuaternion(qbInv).applyQuaternion(qView));
        camera.quaternion.copy(qView).multiply(qbInv).multiply(q.invert());
    }
    setupHand() {
        const g = this.game;
        this.hand = { c: 0, d: 0, swinging: false, e: 0, shown: BLOCK.AIR };
        this.handScene = new THREE.Scene();
        this.handCamera = new THREE.PerspectiveCamera(70, 1, 0.05, 10);
        this.handSwingT = new THREE.Group(); this.handBase = new THREE.Group(); this.handTurn = new THREE.Group(); this.handSwingR = new THREE.Group();
        this.handTurn.rotation.y = Math.PI / 4;
        this.handSwingR.rotation.order = 'YXZ';
        this.handScene.add(this.handSwingT); this.handSwingT.add(this.handBase); this.handBase.add(this.handTurn); this.handTurn.add(this.handSwingR);
        this.handBlock = new THREE.Group(); this.handBlock.scale.setScalar(0.4 * 4);
        this.handSwingR.add(this.handBlock);
        this.handPlant = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: g.solidMaterial.map, alphaTest: 0.1, side: THREE.DoubleSide }));
        this.handPlant.scale.setScalar(0.5); this.handPlant.rotation.y = -Math.PI / 4; this.handPlant.position.set(0, 0.3, 0);
        this.handSwingR.add(this.handPlant);
        this.armMat = new THREE.MeshBasicMaterial({ map: g.playerView.material.map, alphaTest: 0.5, side: THREE.DoubleSide });
        const a1 = new THREE.Group(), a2 = new THREE.Group(), a3 = new THREE.Group(), a4 = new THREE.Group();
        a1.scale.set(1, -1, -1); a2.position.set(0, 0.2, 0); a3.rotation.z = -120 * Math.PI / 180; a4.scale.setScalar(1 / 16);
        const armGeo = buildModelBox(40, 16, -1, -2, -2, 4, 12, 4);
        armGeo.applyMatrix4(new THREE.Matrix4().makeScale(-1, 1, 1)).applyMatrix4(new THREE.Matrix4().makeTranslation(2, 0, 0));
        a4.add(new THREE.Mesh(armGeo, this.armMat));
        a1.add(a2); a2.add(a3); a3.add(a4);
        this.handArm = a1;
        this.handSwingR.add(this.handArm);
    }
    swing() { if (!this.hand) return; this.hand.e = -1; this.hand.swinging = true; }
    handTick() {
        const h = this.hand;
        h.d = h.c;
        if (h.swinging && ++h.e === 7) { h.e = 0; h.swinging = false; }
        const type = this.player.getSelectedBlock();
        let step = (type === h.shown ? 1 : 0) - h.c;
        step = Math.max(-0.4, Math.min(0.4, step));
        h.c += step;
        if (h.c < 0.1) h.shown = type;
        const g = this.game, rightHeld = g.buttonsHeld && g.buttonsHeld[2] && g.pointerLocked && !g.menu;
        if ((this.leftHeld || rightHeld) && !this.hand.swinging) this.swing();
    }
    renderHand(renderer, a) {
        if (!this.hand) this.setupHand();
        const g = this.game, h = this.hand, p = this.player;
        if (!h || p.health <= 0 || g.thirdPerson) return;
        const eq = h.d + (h.c - h.d) * a;
        this.handSwingT.position.set(0, 0, 0); this.handSwingR.rotation.set(0, 0, 0);
        if (h.swinging) {
            const t = (h.e + a) / 7, s1 = Math.sin(t * Math.PI), s2 = Math.sin(Math.sqrt(t) * Math.PI);
            this.handSwingT.position.set(-s2 * 0.4, Math.sin(Math.sqrt(t) * Math.PI * 2) * 0.2, -s1 * 0.2);
            this.handSwingR.rotation.y = s2 * 80 * Math.PI / 180;
            this.handSwingR.rotation.x = -Math.sin(t * t * Math.PI) * 20 * Math.PI / 180;
        }
        this.handBase.position.set(0.7 * 0.8, -0.65 * 0.8 - (1 - eq) * 0.6, -0.9 * 0.8);
        if (this.handShownType !== h.shown) {
            this.handShownType = h.shown;
            this.handBlock.clear();
            if (h.shown !== BLOCK.AIR) this.handBlock.add(new THREE.Mesh(this.itemGeo(h.shown, true), isPlant(h.shown) && !this.crossedPlants ? this.itemPlantMat : this.itemMat));
        }
        const plant = isPlant(h.shown) && !this.crossedPlants;
        this.handBlock.visible = h.shown !== BLOCK.AIR && !plant;
        this.handPlant.visible = plant;
        this.handArm.visible = h.shown === BLOCK.AIR;
        if (plant && this.handPlantType !== h.shown) {
            this.handPlantType = h.shown;
            const [c, r] = faceUV(h.shown, 0), uv = this.handPlant.geometry.attributes.uv, u0 = c / 16, u1 = (c + 1) / 16, v0 = 1 - (r + 1) / 16, v1 = 1 - r / 16;
            uv.setXY(0, u0, v1); uv.setXY(1, u1, v1); uv.setXY(2, u0, v0); uv.setXY(3, u1, v0); uv.needsUpdate = true;
        }
        if (this.armMat.map !== g.playerView.material.map) { this.armMat.map = g.playerView.material.map; this.armMat.needsUpdate = true; }
        const e = p.getEyePosition(), lit = g.level.isLit(Math.floor(e.x), Math.floor(e.y), Math.floor(e.z));
        this.armMat.color.setScalar(lit ? 1 : 0.6);
        this.handPlant.material.color.setScalar(lit ? 1 : 0.6);
        for (const m of this.handBlock.children) m.material = plant ? this.itemPlantMat : lit ? this.itemMat : this.itemMatDark;
        const cam = this.handCamera;
        cam.fov = g.camera.fov; cam.aspect = g.camera.aspect; cam.updateProjectionMatrix();
        cam.quaternion.identity(); cam.position.set(0, 0, 0);
        this.adjustCamera(cam, a);
        if (this.handLight030) for (const m of this.handBlock.children) this.handLight030(m);
        renderer.clearDepth();
        renderer.render(this.handScene, cam);
    }
    addResource(type) {
        const p = this.player;
        let i = p.inventory.indexOf(type);
        if (i < 0) i = p.inventory.indexOf(BLOCK.AIR);
        if (i < 0 || p.counts[i] >= 99) return false;
        p.inventory[i] = type; p.counts[i]++; p.pops[i] = 5;
        if (i === p.selectedSlot) this.game.blockPreview.setType(type);
        return true;
    }
    roomFor(type) {
        const p = this.player, i = p.inventory.indexOf(type);
        if (i >= 0) return 99 - p.counts[i];
        return p.inventory.indexOf(BLOCK.AIR) >= 0 ? 99 : 0;
    }
    get inLobby() { const g = this.game; return !!(g.lobby && g.net === g.lobby); }
    claimItem(id, n) {
        const g = this.game;
        if (g.lobby.isHost) this.grantItem(g.netId, id, n);
        else g.sendNet({ t: 'claim', item: id, n });
    }
    remoteTargets() {
        const g = this.game, out = [];
        if (!(this.inLobby && g.lobby.isHost)) return out;
        for (const r of g.remotePlayers.values()) if (!r.deadAt) out.push({ remoteId: r.id, name: r.name, position: { x: r.pos.x, y: r.pos.y, z: r.pos.z }, health: 20 });
        return out;
    }
    nearestPlayer(x, y, z) {
        let best = this.player && this.player.health > 0 ? this.player : null;
        let bd = best ? Math.hypot(best.position.x - x, best.position.z - z) : Infinity;
        for (const t of this.remoteTargets()) { const d = Math.hypot(t.position.x - x, t.position.z - z); if (d < bd) { bd = d; best = t; } }
        return best;
    }
    hurtTarget(t, src, dmg) {
        if (!t.remoteId) { this.hurt(t, src, dmg); return; }
        const by = src && src.def ? 'a ' + src.kind[0].toUpperCase() + src.kind.slice(1) : src && src.kind === 'creeper' ? 'a Creeper' : 'something';
        this.game.sendNet({ t: 'pvp', target: t.remoteId, dmg, x: src ? src.x : t.position.x, z: src ? src.z : t.position.z, by });
    }
    addSharedItem(x, y, z, type, count = 1, fling = 0) {
        const it = this.addItem(x, y, z, type, count, fling);
        if (this.inLobby) {
            it.netId = this.game.netId + ':' + (this.dropSeq = (this.dropSeq || 0) + 1);
            (this.pendingDrops || (this.pendingDrops = [])).push({ id: it.netId, type, count, x, y, z, xd: it.xd, yd: it.yd, zd: it.zd });
        }
        return it;
    }
    flushDrops() {
        if (!this.pendingDrops || !this.pendingDrops.length) return;
        for (let i = 0; i < this.pendingDrops.length; i += 40) this.game.sendNet({ t: 'drop', items: this.pendingDrops.slice(i, i + 40) });
        this.pendingDrops = [];
    }
    sendMobs() {
        const g = this.game, ps = [this.player.position, ...[...g.remotePlayers.values()].map(r => r.pos)], k = ['zombie', 'skeleton', 'creeper', 'pig'];
        const r2 = v => Math.round(v * 100) / 100, list = [];
        for (const m of this.mobs) {
            if (!ps.some(p => Math.abs(m.x - p.x) < 64 && Math.abs(m.z - p.z) < 64)) continue;
            list.push([m.id, k.indexOf(m.kind), r2(m.x), r2(m.feet), r2(m.z), Math.round(m.yRot), Math.round(m.yBodyRot), Math.round(m.xRot), m.health, m.hurtTime, m.deathTime, m.attackTime, (m.helmet ? 1 : 0) | (m.armour ? 2 : 0)]);
        }
        g.sendNet({ t: 'mobs', list });
    }
    netMobs(list) {
        const now = performance.now(), k = ['zombie', 'skeleton', 'creeper', 'pig'], seen = new Set();
        this.puppets = this.puppets || new Map();
        for (const a of list) {
            if (!Array.isArray(a) || a.length < 13 || !k[a[1]]) continue;
            let m = this.puppets.get(a[0]);
            if (!m) { m = new Mob024(this, k[a[1]], a[2], a[3], a[4]); m.netId = a[0]; m.puppet = true; m.helmet = !!(a[12] & 1); m.armour = !!(a[12] & 2); this.puppets.set(a[0], m); }
            m.xo = m.x; m.feeto = m.feet; m.zo = m.z; m.yRotO = m.yRot; m.yBodyRotO = m.yBodyRot; m.xRotO = m.xRot; m.animStepO = m.animStep; m.oRun = m.run;
            const moved = Math.hypot(a[2] - m.x, a[4] - m.z);
            m.x = a[2]; m.feet = a[3]; m.z = a[4]; m.yRot = a[5]; m.yBodyRot = a[6]; m.xRot = a[7];
            if (a[9] > m.hurtTime) m.invulnerableTime = 30;
            m.health = a[8]; m.hurtTime = a[9]; m.deathTime = a[10]; m.attackTime = a[11];
            m.animStep += moved * 3; m.run += ((moved > 0.15 ? 1 : 0) - m.run) * 0.5; m.tickCount += 3;
            m.netGap = Math.max(60, Math.min(400, now - (m.netAt || now - 150))); m.netAt = now; m.seenAt = now;
            seen.add(a[0]);
        }
        for (const [id, m] of this.puppets) if (!seen.has(id) && now - m.seenAt > 1500) { m.dropMesh(); this.puppets.delete(id); }
    }
    netHitMob(from, id, dmg, x, z) {
        const m = this.mobs.find(q => q.id === id);
        if (m && m.health > 0) m.hurt({ x, z, remoteId: from }, Math.max(1, Math.min(7, dmg | 0)));
    }
    grantItem(by, id, n) {
        const it = this.items.find(i => i.netId === id);
        if (!it || !(it.count > 0)) return;
        n = Math.max(0, Math.min(it.count, Math.floor(Number(n) || 0)));
        if (!n) return;
        const left = it.count - n, msg = { t: 'taken', item: id, by, n, left };
        this.game.sendNet(msg);
        this.netItem({ ...msg, id: this.game.netId });
    }
    netItem(m) {
        const g = this.game;
        if (m.t === 'drop' && Array.isArray(m.items)) {
            for (const d of m.items.slice(0, 9)) {
                if (!BLOCK_UVS[d.type] && d.type !== BLOCK.GRASS) continue;
                const it = this.addItem(Number(d.x), Number(d.y), Number(d.z), d.type, Math.max(1, Math.min(99, d.count | 0)));
                it.xd = Number(d.xd) || 0; it.yd = Number(d.yd) || 0; it.zd = Number(d.zd) || 0; it.netId = String(d.id);
            }
        } else if (m.t === 'claim' && g.lobby && g.lobby.isHost) {
            this.grantItem(m.id, String(m.item), m.n);
        } else if (m.t === 'taken') {
            const it = this.items.find(i => i.netId === String(m.item));
            if (!it) return;
            if (m.by === g.netId) for (let k = 0; k < m.n; k++) this.addResource(it.type);
            it.count = Math.max(0, m.left | 0);
            if (it.count <= 0) {
                if (m.by === g.netId) { it.taking = 1; it.tx = it.x; it.ty = it.y; it.tz = it.z; }
                else it.age = 1e9;
            }
        }
    }
    useOne(type) {
        const p = this.player, i = p.inventory.indexOf(type);
        if (i < 0) return false;
        if (--p.counts[i] <= 0) { p.counts[i] = 0; p.inventory[i] = BLOCK.AIR; if (i === p.selectedSlot) this.game.blockPreview.setType(BLOCK.AIR); }
        return true;
    }
    target() {
        const g = this.game, hit = g.raycaster.cast(g.player.getEyePosition(), g.player.getLookDirection(), REACH_DISTANCE);
        return hit.hit ? hit : null;
    }
    mouseDown(button) {
        if (this.player.health <= 0) return;
        if (button === 0) {
            this.leftHeld = true;
            this.swing();
            if (this.attack()) return;
            const hit = this.target();
            if (hit && hardTicks024(this.game.level.getTile(hit.blockPos.x, hit.blockPos.y, hit.blockPos.z)) === 0) this.destroy(hit.blockPos);
        } else if (button === 2) {
            this.swing();
            const p = this.player, id = p.getSelectedBlock();
            if (id === BLOCK.RED_MUSHROOM && this.useOne(id)) { this.hurt(p, null, 3); return; }
            if (id === BLOCK.BROWN_MUSHROOM && this.useOne(id)) { this.heal(p, 5); return; }
            if (this.attack()) return;
            if (id !== BLOCK.AIR && this.game.placeBlock()) { this.useOne(id); if (this.hand) this.hand.c = 0; }
        }
    }
    mouseUp(button) { if (button === 0) this.leftHeld = false; }
    mineTick() {
        const m = this.mine, g = this.game;
        const hit = this.leftHeld && g.pointerLocked && !g.menu && !g.chatOpen ? this.target() : null;
        if (this.leftHeld && g.pointerLocked && !g.menu && this.pickMob()) { m.count = 0; if (this.ticks % 5 === 0) this.attack(); return; }
        if (!hit) { m.count = 0; m.cooldown = 0; return; }
        if (m.cooldown > 0) { m.cooldown--; return; }
        const { x, y, z } = hit.blockPos;
        if (x === m.x && y === m.y && z === m.z) {
            const type = g.level.getTile(x, y, z);
            if (type === BLOCK.AIR || UNBREAKABLE_024.has(type) || (y <= 0)) return;
            m.ticks = hardTicks024(type);
            this.crackParticle(x, y, z, type, hit);
            if (++m.count === m.ticks + 1) { this.destroy(hit.blockPos); m.count = 0; }
            return;
        }
        m.count = 0; m.x = x; m.y = y; m.z = z;
    }
    crackParticle(x, y, z, type, hit) {
        const e = 0.1, r = () => Math.random() * (1 - e * 2) + e;
        let px = x + r(), py = y + r(), pz = z + r();
        const p = hit.prevPos;
        if (p.y < y) py = y - e; if (p.y > y) py = y + 1 + e;
        if (p.z < z) pz = z - e; if (p.z > z) pz = z + 1 + e;
        if (p.x < x) px = x - e; if (p.x > x) px = x + 1 + e;
        this.game.particles.spawnOne(px, py, pz, type, 0.2, 0.6);
    }
    destroy({ x, y, z }) {
        const g = this.game, type = g.level.getTile(x, y, z);
        if (UNBREAKABLE_024.has(type) || y <= 0) return;
        const [drop, n] = drops024(type);
        for (let i = 0; i < n; i++) {
            const s = 0.7, o = (1 - s) * 0.5;
            this.addSharedItem(x + Math.random() * s + o, y + Math.random() * s + o, z + Math.random() * s + o, drop);
        }
        g.particles.spawn(x, y, z, type);
        g.level.setTile(x, y, z, BLOCK.AIR);
        g.sendNet({ t: 'set', x, y, z, b: BLOCK.AIR });
    }
    itemGeo(type, plantShape = false) {
        const key = type + (plantShape ? ':plant' : '');
        if (this.itemGeos[key]) return this.itemGeos[key];
        const pos = [], uv = [], idx = [], add = (verts, [c, r], flipV = false) => {
            const e = 0.5 / 256, b = pos.length / 3, u0 = c / 16 + e, u1 = (c + 1) / 16 - e, v0 = 1 - (r + 1) / 16 + e, v1 = 1 - r / 16 - e;
            for (const v of verts) pos.push(...v);
            if (flipV) uv.push(u0, v1, u1, v1, u1, v0, u0, v0); else uv.push(u0, v0, u1, v0, u1, v1, u0, v1);
            idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
        };
        const s = 0.125;
        if (plantShape && isPlant(type)) {
            add([[-s, -s, 0], [s, -s, 0], [s, s, 0], [-s, s, 0]], faceUV(type, 0));
            add([[s, -s, 0], [-s, -s, 0], [-s, s, 0], [s, s, 0]], faceUV(type, 0));
        } else {
            add([[-s, -s, s], [s, -s, s], [s, s, s], [-s, s, s]], faceUV(type, 0));
            add([[s, -s, -s], [-s, -s, -s], [-s, s, -s], [s, s, -s]], faceUV(type, 0));
            add([[s, -s, s], [s, -s, -s], [s, s, -s], [s, s, s]], faceUV(type, 0));
            add([[-s, -s, -s], [-s, -s, s], [-s, s, s], [-s, s, -s]], faceUV(type, 0));
            add([[-s, s, s], [s, s, s], [s, s, -s], [-s, s, -s]], faceUV(type, 1));
            add([[-s, -s, -s], [s, -s, -s], [s, -s, s], [-s, -s, s]], faceUV(type, -1));
        }
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
        geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
        geo.setIndex(idx);
        return (this.itemGeos[key] = geo);
    }
    addItem(x, y, z, type, count = 1, fling = 0) {
        const mesh = new THREE.Mesh(this.itemGeo(type), this.itemMat);
        const glowMat = new THREE.MeshBasicMaterial({ map: this.game.solidMaterial.map, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0 });
        const glow = new THREE.Mesh(this.itemGeo(type), glowMat);
        mesh.add(glow);
        if (isPlant(type)) { mesh.material = mesh.material.clone(); mesh.material.side = THREE.DoubleSide; }
        this.game.scene.add(mesh);
        const f = 0.1 + fling;
        const it = { type, count, mesh, glow, x, y, z, xo: x, yo: y, zo: z, xd: (Math.random() * 2 - 1) * f, yd: 0.2 + fling, zd: (Math.random() * 2 - 1) * f,
            rot: Math.random() * 360, age: 0, onGround: false, taking: 0 };
        this.items.push(it);
        return it;
    }
    itemTick(it) {
        it.xo = it.x; it.yo = it.y; it.zo = it.z;
        if (it.taking) {
            const p = this.player.position, t = (++it.taking - 1) / 3, f = t * t;
            it.x = it.tx + (p.x - it.tx) * f; it.y = it.ty + (p.y - 1 - it.ty) * f; it.z = it.tz + (p.z - it.tz) * f;
            return it.taking <= 3;
        }
        it.yd -= 0.04;
        const bb = [it.x - 0.125, it.y - 0.125, it.z - 0.125, it.x + 0.125, it.y + 0.125, it.z + 0.125];
        const m = moveBox024(this.game.level, bb, it.xd, it.yd, it.zd);
        it.x = (bb[0] + bb[3]) / 2; it.y = (bb[1] + bb[4]) / 2; it.z = (bb[2] + bb[5]) / 2;
        if (m.hitX) it.xd = 0; if (m.hitZ) it.zd = 0; if (m.yd !== it.yd) it.yd = 0;
        it.onGround = m.onGround;
        it.xd *= 0.98; it.yd *= 0.98; it.zd *= 0.98;
        if (it.onGround) { it.xd *= 0.7; it.zd *= 0.7; it.yd *= -0.5; }
        it.rot += 3;
        if (++it.age >= 6000 || it.y < -10) return false;
        const p = this.player.position, feet = p.y - PLAYER_HEIGHT, hw = PLAYER_WIDTH / 2 + 1;
        if (this.player.health > 0 && bb[3] > p.x - hw && bb[0] < p.x + hw && bb[4] > feet && bb[1] < feet + 1.8 && bb[5] > p.z - hw && bb[2] < p.z + hw) {
            if (it.count == null) it.count = 1;
            if (it.netId && this.inLobby) {
                const n = Math.min(it.count, this.roomFor(it.type)), now = performance.now();
                if (n > 0 && !(now - (it.claimedAt || 0) < 1000)) { it.claimedAt = now; this.claimItem(it.netId, n); }
            } else {
                while (it.count > 0 && this.addResource(it.type)) it.count--;
                if (it.count <= 0) { it.taking = 1; it.tx = it.x; it.ty = it.y; it.tz = it.z; }
            }
        }
        return true;
    }
    removeItem(it) {
        this.game.scene.remove(it.mesh);
        it.glow.material.dispose();
        if (it.mesh.material !== this.itemMat) it.mesh.material.dispose();
    }
    tick() {
        this.ticks++;
        const p = this.player;
        for (let i = 0; i < 9; i++) if (p.pops[i] > 0) p.pops[i]--;
        this.healthTick();
        this.bobTick();
        this.mobsTick();
        if (this.hand) this.handTick();
        if (p.health <= 0) { this.items = this.items.filter(it => this.itemTick(it) || (this.removeItem(it), false)); return; }
        this.mineTick();
        this.items = this.items.filter(it => this.itemTick(it) || (this.removeItem(it), false));
    }
    frame(a) {
        const lv = this.game.level;
        this.mobsFrame(a);
        for (const it of this.items) {
            const x = it.xo + (it.x - it.xo) * a, y = it.yo + (it.y - it.yo) * a, z = it.zo + (it.z - it.zo) * a;
            const rot = it.rot + a * 3, bob = Math.sin(rot / 10) * 0.1 + 0.1;
            it.mesh.position.set(x, y + (it.taking ? 0 : bob), z);
            it.mesh.rotation.y = rot * Math.PI / 180;
            if (it.mesh.material === this.itemMat || it.mesh.material === this.itemMatDark)
                it.mesh.material = lv.isLit(Math.floor(x), Math.floor(y), Math.floor(z)) ? this.itemMat : this.itemMatDark;
            let gl = Math.sin(rot / 10) * 0.5 + 0.5; gl *= gl; gl *= gl;
            it.glow.material.opacity = gl;
        }
        const m = this.mine;
        if (m.count > 0 && m.ticks > 0) {
            const stage = Math.max(0, Math.min(9, Math.floor((m.count + a - 1) / m.ticks * 10)));
            this.crack.visible = true;
            this.crack.position.set(m.x + 0.5, m.y + 0.5, m.z + 0.5);
            if (stage !== this.crackStage) {
                this.crackStage = stage;
                const t = this.crackMat.map;
                t.repeat.set(1 / 16, 1 / 16); t.offset.set(stage / 16, 0);
            }
        } else this.crack.visible = false;
    }
    loadTex(src) {
        const t = new THREE.TextureLoader().load(src);
        t.magFilter = t.minFilter = THREE.NearestFilter; t.generateMipmaps = false;
        return t;
    }
    loadTexAny(paths, fallback) {
        const t = new THREE.Texture(); t.magFilter = t.minFilter = THREE.NearestFilter; t.generateMipmaps = false;
        const tryNext = i => {
            if (i >= paths.length) {
                if (fallback) { const c = document.createElement('canvas'); fallback(c); t.image = c; t.needsUpdate = true; }
                console.warn('Survival Test: couldn\'t find ' + paths[0] + (fallback ? ' (drawing a stand-in)' : ''));
                return;
            }
            const im = new Image();
            im.onload = () => { t.image = im; t.needsUpdate = true; };
            im.onerror = () => tryNext(i + 1);
            im.src = paths[i];
        };
        tryNext(0);
        return t;
    }
    static itemPaths(file) { return ['./items/' + file, './Items/' + file, './item/' + file, '../items/' + file, './' + file]; }
    mobMaterial(name) {
        if (!this.mobTex) this.mobTex = {};
        if (!this.mobTex[name]) this.mobTex[name] = this.loadTex('./mob/' + name + '.png');
        return new THREE.MeshBasicMaterial({ map: this.mobTex[name], alphaTest: 0.5, side: THREE.DoubleSide });
    }
    partGeo(kind, name, p, grow) {
        if (!this.geoCache) this.geoCache = {};
        const k = kind + ':' + name + ':' + grow;
        return this.geoCache[k] || (this.geoCache[k] = partGeo024(p, grow));
    }
    get armourMat() {
        return this._armour || (this._armour = new THREE.MeshBasicMaterial({ alphaTest: 0.5, side: THREE.DoubleSide,
            map: this.loadTexAny(['./armour/plate.png', './Armour/plate.png', './armor/plate.png', '../armour/plate.png']) }));
    }
    arrowMesh() {
        if (!this.arrowMat) this.arrowMat = new THREE.MeshBasicMaterial({ side: THREE.DoubleSide, alphaTest: 0.5,
            map: this.loadTexAny(Survival024.itemPaths('arrows.png'), c => {
                c.width = c.height = 32; const x = c.getContext('2d');
                x.fillStyle = '#a07850'; x.fillRect(2, 2, 12, 1);
                x.fillStyle = '#d8d8d8'; x.fillRect(0, 0, 2, 1); x.fillRect(0, 4, 2, 1); x.fillRect(1, 1, 2, 1); x.fillRect(1, 3, 2, 1); x.fillRect(0, 2, 2, 1);
                x.fillStyle = '#909090'; x.fillRect(13, 1, 2, 3); x.fillRect(15, 2, 1, 1);
            }) });
        if (!this.arrowGeo) {
            const g = new THREE.PlaneGeometry(16, 4), uv = g.attributes.uv;
            uv.setXY(0, 0, 1); uv.setXY(1, 0.5, 1); uv.setXY(2, 0, 1 - 0.15625); uv.setXY(3, 0.5, 1 - 0.15625);
            this.arrowGeo = g;
        }
        const root = new THREE.Group(), s = new THREE.Group();
        s.scale.setScalar(0.05625); s.rotation.x = Math.PI / 4; root.add(s);
        for (let i = 0; i < 4; i++) { const m = new THREE.Mesh(this.arrowGeo, this.arrowMat); m.rotation.x = i * Math.PI / 2; s.add(m); }
        return root;
    }
    signMesh() {
        if (!this.signMat) this.signMat = new THREE.MeshBasicMaterial({ alphaTest: 0.5, side: THREE.DoubleSide,
            map: this.loadTexAny(Survival024.itemPaths('sign.png'), c => { c.width = 64; c.height = 32; const x = c.getContext('2d'); x.fillStyle = '#b08850'; x.fillRect(0, 0, 64, 32); }) });
        const root = new THREE.Group(), flip = new THREE.Group();
        flip.scale.set(1 / 16, -1 / 16, -1 / 16); root.add(flip);
        flip.add(new THREE.Mesh(buildModelBox(0, 0, -12, -14, -1, 24, 12, 2), this.signMat));
        flip.add(new THREE.Mesh(buildModelBox(0, 14, -1, -2, -1, 2, 14, 2), this.signMat));
        if (!this.signTextTex) {
            const g = this.game, lines = ['This is a test', 'of the signs.', 'Each line can', 'be 15 chars!'];
            const c = document.createElement('canvas'); c.width = 128; c.height = 64;
            const saved = g.hudCtx; g.hudCtx = c.getContext('2d');
            const tw = t => [...t].reduce((n, ch) => n + g.fontSheets.widths[ch.charCodeAt(0)], 0);
            lines.forEach((t, i) => g.drawText(t, 64 - tw(t) / 2, 12 + i * 10, 1, 0x202020));
            g.hudCtx = saved;
            this.signTextTex = new THREE.CanvasTexture(c); this.signTextTex.magFilter = THREE.NearestFilter;
        }
        const text = new THREE.Mesh(new THREE.PlaneGeometry(128 / 60, 64 / 60), new THREE.MeshBasicMaterial({ map: this.signTextTex, transparent: true }));
        text.position.set(0, 0.5 + 0.5 - 32 / 60 + 0.05, 0.09 + 0.001);
        root.add(text);
        return root;
    }
    blocked(x1, y1, z1, x2, y2, z2) {
        const lv = this.game.level, d = Math.hypot(x2 - x1, y2 - y1, z2 - z1), n = Math.ceil(d / 0.2);
        for (let i = 1; i < n; i++) { const t = i / n; if (lv.isSolidTile(Math.floor(x1 + (x2 - x1) * t), Math.floor(y1 + (y2 - y1) * t), Math.floor(z1 + (z2 - z1) * t))) return true; }
        return false;
    }
    spawnMobs() {
        const lv = this.game.level, w = lv.width, h = lv.height, d = lv.depth, r = () => Math.random(), ri = n => Math.floor(Math.random() * n);
        const kinds = ['zombie', 'skeleton', 'pig', 'creeper'];
        const liquid = (x, y, z) => { const t = lv.getTile(x, y, z); return t === BLOCK.WATER || t === BLOCK.LAVA; };
        const n = w * h * d / 800 | 0;
        for (let i = 0; i < n; ++i) {
            const kind = kinds[ri(4)], x0 = ri(w), y0 = Math.floor(Math.min(r(), r()) * d), z0 = ri(h);
            if (lv.isSolidTile(x0, y0, z0) || liquid(x0, y0, z0) || (lv.isLit(x0, y0, z0) && ri(5) !== 0)) continue;
            for (let j = 0; j < 3; ++j) {
                let x = x0, y = y0, z = z0;
                for (let k = 0; k < 3; ++k) {
                    if ((x += ri(6) - ri(6)) < 0 || (z += ri(6) - ri(6)) < 1 || y < 0 || y >= d - 2 || x >= w || z >= h
                        || !lv.isSolidTile(x, y - 1, z) || lv.isSolidTile(x, y, z) || lv.isSolidTile(x, y + 1, z)) continue;
                    const m = new Mob024(this, kind, x + 0.5, y, z + 0.5);
                    if (!m.free(0, 0, 0) || this.mobs.some(o => Math.abs(o.x - m.x) < (o.w + m.w) / 2 && Math.abs(o.z - m.z) < (o.w + m.w) / 2 && Math.abs(o.feet - m.feet) < 1.8)) continue;
                    this.mobs.push(m);
                }
            }
        }
    }
    newLevel() {
        const g = this.game;
        if (this.puppets) { for (const m of this.puppets.values()) m.dropMesh(); this.puppets.clear(); }
        if (g.menu === 'gameover') g.closeMenu();
        g.frozen = false;
        for (const m of this.mobs || []) m.dropMesh();
        for (const a of this.arrows || []) this.game.scene.remove(a.mesh);
        for (const s of this.signs || []) this.game.scene.remove(s.mesh);
        for (const it of this.items) this.removeItem(it);
        this.mobs = []; this.arrows = []; this.signs = []; this.items = [];
        if (!g.lobby || g.lobby.isHost) this.spawnMobs();
    }
    explode(src, x, y, z, r) {
        const blown = [], g = this.game, lv = g.level, x0 = Math.trunc(x - r - 1), x1 = Math.trunc(x + r + 1), y0 = Math.trunc(y - r - 1), y1 = Math.trunc(y + r + 1), z0 = Math.trunc(z - r - 1), z1 = Math.trunc(z + r + 1);
        for (let bx = x0; bx < x1; bx++) for (let by = y1 - 1; by >= y0; by--) for (let bz = z0; bz < z1; bz++) {
            const dx = bx + 0.5 - x, dy = by + 0.5 - y, dz = bz + 0.5 - z;
            if (bx < 0 || by < 0 || bz < 0 || bx >= lv.width || by >= lv.depth || bz >= lv.height || !(dx * dx + dy * dy + dz * dz < r * r)) continue;
            const t = lv.getTile(bx, by, bz);
            if (t <= 0 || t === BLOCK.BARRIER) continue;
            if (!UNBREAKABLE_024.has(t)) { const [drop, n] = drops024(t); for (let i = 0; i < n; i++) if (Math.random() <= 0.3) this.addSharedItem(bx + 0.5, by + 0.5, bz + 0.5, drop); }
            lv.setTile(bx, by, bz, BLOCK.AIR);
            blown.push(bx, by, bz, BLOCK.AIR);
        }
        if (blown.length) g.sendNet({ t: 'sets', list: blown });
        const hurtNear = (ex, ey, ez, hurtFn) => { const d = Math.hypot(ex - x, ey - y, ez - z) / r; if (d <= 1) hurtFn(Math.floor((1 - d) * 15 + 1)); };
        for (const m of this.mobs) if (m !== src && m.health > 0) hurtNear(m.x, m.y, m.z, n => m.hurt(src, n));
        const p = this.player; hurtNear(p.position.x, p.position.y, p.position.z, n => this.hurt(p, src, n));
        for (const t of this.remoteTargets()) hurtNear(t.position.x, t.position.y, t.position.z, n => this.hurtTarget(t, src, n));
        g.sendNet({ t: 'boom', x, y, z, r });
        this.boomParticles(x, y, z, r);
    }
    boomParticles(x, y, z, r) {
        const g = this.game;
        for (let i = 0; i < 500; i++) {
            const gauss = () => { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
            const fx = gauss() * r / 4, fy = gauss() * r / 4, fz = gauss() * r / 4, l = Math.hypot(fx, fy, fz) || 1;
            g.particles.spawnOne(x + fx, y + fy, z + fz, BLOCK.LEAVES, 1, 1, [fx / l / l, fy / l / l, fz / l / l]);
        }
    }
    pickMob() {
        const g = this.game, e = g.player.getEyePosition(), dir = g.player.getLookDirection();
        const hit = g.raycaster.cast(e, dir, REACH_DISTANCE);
        let best = hit.hit ? Math.hypot(hit.blockPos.x + 0.5 - e.x, hit.blockPos.y + 0.5 - e.y, hit.blockPos.z + 0.5 - e.z) : REACH_DISTANCE, found = null;
        const targets = this.mobs.filter(m => m.health > 0);
        if (this.puppets) for (const m of this.puppets.values()) if (m.health > 0) targets.push(m);
        if (g.lobby && g.net === g.lobby) for (const r of g.remotePlayers.values()) {
            if (r.deadAt) continue;
            const c = r.pos, feet = c.y - PLAYER_HEIGHT, hw = PLAYER_WIDTH / 2;
            targets.push({ player: r, x: c.x, z: c.z, bb: [c.x - hw, feet, c.z - hw, c.x + hw, feet + 1.8, c.z + hw] });
        }
        for (const m of targets) {
            if (Math.abs(m.x - e.x) > 6 || Math.abs(m.z - e.z) > 6) continue;
            const b = m.bb; let t0 = 0, t1 = REACH_DISTANCE;
            for (let k = 0; k < 3; k++) {
                const o = [e.x, e.y, e.z][k], v = [dir.x, dir.y, dir.z][k], lo = b[k] - 0.1, hi = b[k + 3] + 0.1;
                if (Math.abs(v) < 1e-9) { if (o < lo || o > hi) { t0 = Infinity; break; } continue; }
                let a1 = (lo - o) / v, a2 = (hi - o) / v; if (a1 > a2) [a1, a2] = [a2, a1];
                t0 = Math.max(t0, a1); t1 = Math.min(t1, a2);
            }
            if (t0 <= t1 && t0 < best) { best = t0; found = m; }
        }
        return found;
    }
    attack() {
        const m = this.pickMob();
        if (!m) return false;
        if (m.puppet) {
            const p = this.player.position;
            this.game.sendNet({ t: 'hitmob', mob: m.netId, dmg: 4, x: p.x, z: p.z });
        } else if (m.player) {
            const p = this.player.position;
            this.game.sendNet({ t: 'pvp', target: m.player.id, dmg: 4, x: p.x, z: p.z, by: this.game.playerName || 'Someone' });
        } else m.hurt(this.player, 4);
        this.swing();
        return true;
    }
    get arrowsOn() { return !this.game.lobby; }
    shootArrow() {
        const p = this.player;
        if (!this.arrowsOn || p.health <= 0 || !(p.arrows > 0)) return;
        p.arrows--;
        this.arrows.push(new Arrow024(this, p, p.position.x, p.position.y, p.position.z, this.yRot(p), -p.rotation.x * 180 / Math.PI, 0.8, true));
    }
    skeletonShoot(m, target) {
        const p = target || this.player, tx = p.position.x, ty = p.position.y - 0.6, tz = p.position.z;
        const dx = tx - m.x, dz = tz - m.z, dy = ty - m.y, flat = Math.hypot(dx, dz);
        const yRot = Math.atan2(dx, -dz) * 180 / Math.PI + (Math.random() - 0.5) * 12;
        const xRot = -Math.atan2(dy, flat) * 180 / Math.PI - (4 + flat * 0.6) - Math.random() * 4;
        this.arrows.push(new Arrow024(this, m, m.x, m.y, m.z, yRot, xRot, 1.0));
        this.game.sendNet({ t: 'arrow', x: m.x, y: m.y, z: m.z, yRot, xRot, speed: 1.0 });
    }
    skeletonBurst(m) {
        const n = Math.floor((Math.random() + Math.random()) * 3 + 4);
        for (let i = 0; i < n; i++) this.arrows.push(new Arrow024(this, m, m.x, m.feet + 1.0, m.z, Math.random() * 360, -(20 + Math.random() * 45), 0.35 + Math.random() * 0.25, true, true));
    }
    throwSign() { if (this.player.health > 0) this.signs.push(new Sign024(this, this.player)); }
    mobsTick() {
        const p = this.player.position, others = this.inLobby ? [...this.game.remotePlayers.values()].map(r => r.pos) : [];
        for (const m of this.mobs) if ([p, ...others].some(q => Math.abs(m.x - q.x) < 64 && Math.abs(m.z - q.z) < 64)) m.tick();
        if (this.inLobby && this.game.lobby.isHost && this.ticks % 3 === 0) this.sendMobs();
        this.flushDrops();
        this.mobs = this.mobs.filter(m => !m.removed || (m.dropMesh(), false));
        for (const a of this.arrows) a.tick();
        this.arrows = this.arrows.filter(a => !a.removed || (this.game.scene.remove(a.mesh), false));
        for (const s of this.signs) s.tick();
    }
    mobsFrame(a) {
        const p = this.player.position;
        for (const m of this.mobs) {
            if (Math.abs(m.x - p.x) < 64 && Math.abs(m.z - p.z) < 64) m.frame(a); else m.dropMesh();
        }
        if (this.puppets) for (const m of this.puppets.values()) m.frame(Math.min(1, (performance.now() - m.netAt) / m.netGap));
        for (const ar of this.arrows) ar.frame(a);
        for (const s of this.signs) s.frame(a);
    }
    bobTick() {
        const p = this.player, pos = p.position;
        if (this.lastPos) {
            const dx = pos.x - this.lastPos.x, dz = pos.z - this.lastPos.z, dy = pos.y - this.lastPos.y;
            p.walkDistO = p.walkDist || 0; p.walkDist = p.walkDistO + Math.hypot(dx, dz) * 0.6;
            p.oBob = p.bob || 0; p.oTilt = p.tilt || 0;
            let speed = Math.min(0.1, Math.hypot(dx, dz)), tilt = Math.atan(-dy * 0.2) * 15;
            if (!p.onGround || p.health <= 0) speed = 0;
            if (p.onGround || p.health <= 0) tilt = 0;
            p.bob = p.oBob + (speed - p.oBob) * 0.4;
            p.tilt = p.oTilt + (tilt - p.oTilt) * 0.8;
        }
        this.lastPos = { x: pos.x, y: pos.y, z: pos.z };
    }
    drawHUD(ctx, gs, W, H) {
        const g = this.game, im = this.img, p = this.player;
        ctx.imageSmoothingEnabled = false;
        const draw = (img, sx, sy, sw, sh, x, y) => { if (img.complete && img.naturalWidth) ctx.drawImage(img, sx, sy, sw, sh, Math.round(x * gs), Math.round(y * gs), sw * gs, sh * gs); };
        draw(im.gui, 0, 0, 182, 22, W / 2 - 91, H - 22);
        draw(im.gui, 0, 22, 24, 22, W / 2 - 91 - 1 + p.selectedSlot * 20, H - 22 - 1);
        const health = p.health ?? 20, last = p.lastHealth ?? health, inv = p.invulnerableTime ?? 0;
        const blink = Math.floor(inv / 3) % 2 === 1 && inv >= 10;
        let seed = (this.ticks * 312871) >>> 0;
        const rnd = () => { seed = (seed * 1103515245 + 12345) >>> 0; return (seed >>> 16) & 1; };
        for (let i = 0; i < 10; i++) {
            const x = W / 2 - 91 + i * 8, y = H - 32 + (health <= 4 ? rnd() : 0);
            draw(im.icons, 16 + (blink ? 9 : 0), 0, 9, 9, x, y);
            if (blink) { if (i * 2 + 1 < last) draw(im.icons, 70, 0, 9, 9, x, y); if (i * 2 + 1 === last) draw(im.icons, 79, 0, 9, 9, x, y); }
            if (i * 2 + 1 < health) draw(im.icons, 52, 0, 9, 9, x, y);
            if (i * 2 + 1 === health) draw(im.icons, 61, 0, 9, 9, x, y);
        }
        if (p.airSupply != null && p.airSupply < 300) {
            const full = Math.ceil((p.airSupply - 2) * 10 / 300), pop = Math.ceil(p.airSupply * 10 / 300) - full;
            for (let i = 0; i < full + pop; i++) draw(im.icons, i < full ? 16 : 25, 18, 9, 9, W / 2 - 91 + i * 8, H - 41);
        }
        const lob = g.lobby;
        if (lob && lob.state === 'ready') g.drawText('Lobby ' + lob.code + ' (' + lob.playerCount + '/' + LOBBY_MAX + ')', 2 * gs, 22 * gs, gs, 0xFFFF55);
        if (this.arrowsOn) g.drawText('Arrows: ' + (p.arrows ?? 0), (W / 2 + 8) * gs, (H - 33) * gs, gs, 0xFFFFFF);
        const a = Math.min(1, g.tickAccumulator / MS_PER_TICK);
        for (let i = 0; i < 9; i++) {
            const type = p.inventory[i];
            if (type === BLOCK.AIR) continue;
            const x = W / 2 - 90 + i * 20, y = H - 16;
            ctx.save();
            if (p.pops[i] > 0) {
                const t = (p.pops[i] - a) / 5, dy = -Math.sin(t * t * Math.PI) * 8;
                const sx = Math.sin(t * t * Math.PI) + 1, sy = Math.sin(t * Math.PI) + 1;
                ctx.translate((x + 10) * gs, (y + 10 + dy) * gs); ctx.scale(sx, sy); ctx.translate(-(x + 10) * gs, -(y + 10) * gs);
            }
            this.drawIcon(ctx, type, (x + 10) * gs, (y - 3) * gs, gs);
            ctx.restore();
            if (p.counts[i] > 1) {
                const s = String(p.counts[i]), tw = [...s].reduce((n, c) => n + g.fontSheets.widths[c.charCodeAt(0)], 0);
                g.drawText(s, (x + 19 - tw) * gs, (y + 6) * gs, gs, 0xFFFFFF);
            }
        }
    }
    drawIcon(ctx, type, cx, cy, gs) {
        const img = this.img.terrain;
        if (!img.complete || !img.naturalWidth) return;
        const face = (uv, a, b, c, d, e, f, shade) => {
            ctx.save(); ctx.setTransform(a, b, c, d, e, f);
            ctx.drawImage(img, uv[0] * 16 + 0.5, uv[1] * 16 + 0.5, 15, 15, 0, 0, 16, 16);
            if (shade) { ctx.fillStyle = 'rgba(0,0,0,' + shade + ')'; ctx.fillRect(0, 0, 16, 16); }
            ctx.restore();
        };
        const base = ctx.getTransform();
        const T = (x, y) => [base.a * x + base.c * y + base.e, base.b * x + base.d * y + base.f];
        if (isPlant(type)) {
            const [ox, oy] = T(cx - 8 * gs, cy - 1 * gs);
            face(faceUV(type, 0), base.a * gs, base.b * gs, base.c * gs, base.d * gs, ox, oy, 0);
            return;
        }
        const s = 7.07 * gs, v = 8.66 * gs;
        const [Wx, Wy] = T(cx - s, cy + s / 2), [Sx, Sy] = T(cx, cy + s);
        const k = 1 / 16, A = base.a, D = base.d;
        face(faceUV(type, 1), s * k * A, -s / 2 * k * D, s * k * A, s / 2 * k * D, Wx, Wy, 0);
        face(faceUV(type, 0), s * k * A, s / 2 * k * D, 0, v * k * D, Wx, Wy, 0.2);
        face(faceUV(type, 0), s * k * A, -s / 2 * k * D, 0, v * k * D, Sx, Sy, 0.4);
    }
}
const LOBBY_PARAM = SURVIVAL_024 && typeof location !== 'undefined' ? new URLSearchParams(location.search).get('lobby') : null;
const LOBBY_MAX = 5;
const LOBBY_CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
class Lobby024 {
    constructor(game, code) {
        this.game = game;
        this.isLobby = true;
        this.readyState = 1;
        this.isHost = !code;
        this.code = code ? String(code).toUpperCase() : Lobby024.newCode();
        this.id = 'p' + Math.random().toString(36).slice(2, 10);
        this.peers = new Map();
        this.changes = [];
        this.state = 'connecting';
        this.lastMove = 0;
        this.transport = (typeof window !== 'undefined' && window.CC_LOBBY_TRANSPORT) || Lobby024.parentTransport();
        this.transport.onmessage = m => { try { this.receive(m); } catch (e) { console.error('Lobby message failed:', e); } };
        this.transport.join('cc-lobby-' + this.code);
        this.tellPage();
        this.timer = setInterval(() => this.heartbeat(), 3000);
        if (this.isHost) this.startHost(); else this.startJoin();
    }
    static newCode() { let s = ''; for (let i = 0; i < 5; i++) s += LOBBY_CODE_CHARS[Math.floor(Math.random() * LOBBY_CODE_CHARS.length)]; return s; }
    static validCode(c) { return /^[A-Z0-9]{5}$/i.test(String(c || '')); }
    static parentTransport() {
        const t = { onmessage: null, topic: null,
            join(topic) { this.topic = topic; window.parent.postMessage({ type: 'cc-lobby', op: 'join', topic }, '*'); },
            send(payload) { window.parent.postMessage({ type: 'cc-lobby', op: 'send', topic: this.topic, payload }, '*'); },
            leave() { window.parent.postMessage({ type: 'cc-lobby', op: 'leave', topic: this.topic }, '*'); } };
        window.addEventListener('message', e => {
            if (e.source !== window.parent || !e.data || e.data.type !== 'cc-lobby-in' || e.data.topic !== t.topic) return;
            if (t.onmessage) t.onmessage(e.data.payload);
        });
        return t;
    }
    out(k, data) { this.transport.send({ k, from: this.id, ...data }); }
    tellPage() {
        if (typeof window !== 'undefined' && window.parent !== window)
            window.parent.postMessage({ type: 'cc-lobby-status', code: this.code, host: this.isHost, state: this.state, players: this.peers.size + 1 }, '*');
    }
    get name() { return this.game.playerName || 'Player'; }
    get playerCount() { return this.peers.size + 1; }
    startHost() {
        this.seed = Math.floor(Math.random() * 2147483647);
        this.w = 256; this.h = 256;
        this.game.generateLevel({ label: 'Normal', w: this.w, h: this.h, d: 64 }, false, { seed: this.seed, keepNet: true, done: () => this.ready() });
    }
    startJoin() {
        this.state = 'joining';
        this.game.statusMessage = 'Joining lobby ' + this.code + '..';
        let tries = 0;
        const ask = () => {
            if (this.state !== 'joining') return;
            if (++tries > 5) { this.fail('There\'s no lobby with the code ' + this.code + '.'); return; }
            this.out('hello', { name: this.name, skin: this.game.mySkin || null });
            setTimeout(ask, 2000);
        };
        ask();
    }
    fail(why) {
        this.state = 'failed'; this.tellPage();
        this.close(true);
        const g = this.game;
        g.statusMessage = null;
        g.generateLevel(LEVEL_SIZES.find(s => s.label === 'Normal'), false);
        setTimeout(() => g.addChat(why + ' Playing on your own instead.', 0xFF5555), 1500);
    }
    ready() {
        const g = this.game;
        this.state = 'ready';
        g.net = this; g.netId = this.id;
        g.serverBuild = true; g.serverHasChat = true;
        this.tellPage();
        if (this.isHost) g.addChat('Your lobby code is ' + this.code + ': friends can join with it (up to ' + LOBBY_MAX + ' players).', 0xFFFF55);
        else { const p = g.player.position; this.out('join', { name: this.name, skin: g.mySkin || null, x: p.x, y: p.y, z: p.z }); g.addChat('You joined lobby ' + this.code + '.', 0xFFFF55); }
    }
    receive(m) {
        if (!m || m.from === this.id || typeof m.k !== 'string') return;
        const g = this.game, peer = this.peers.get(m.from);
        if (peer) peer.seen = Date.now();
        if (m.to && m.to !== this.id) return;
        if (m.k === 'hello' && this.isHost && this.state === 'ready') {
            if (!this.peers.has(m.from) && this.playerCount >= LOBBY_MAX) { this.out('full', { to: m.from }); return; }
            this.peers.set(m.from, { name: String(m.name || 'Player').slice(0, 24), seen: Date.now(), skin: m.skin });
            const players = [{ id: this.id, name: this.name, skin: g.mySkin || null, ...this.pos() }];
            for (const [id, p] of this.peers) if (id !== m.from) { const r = g.remotePlayers.get(id); players.push({ id, name: p.name, skin: p.skin || null, ...(r ? { x: r.target.x, y: r.target.y, z: r.target.z } : {}) }); }
            const parts = [];
            for (let i = 0; i < this.changes.length; i += 8000) parts.push(this.changes.slice(i, i + 8000));
            this.out('welcome', { to: m.from, seed: this.seed, w: this.w, h: this.h, players, parts: parts.length, silly: !!this.sillyKnockback });
            parts.forEach((list, part) => this.out('changes', { to: m.from, part, list }));
            this.tellPage();
        } else if (m.k === 'welcome' && this.state === 'joining') {
            this.sillyKnockback = !!m.silly;
            this.state = 'loading'; this.hostId = m.from; this.seed = m.seed; this.w = m.w; this.h = m.h;
            this.peers.set(m.from, { name: 'host', seen: Date.now() });
            this.welcome = m; this.welcomeParts = new Array(m.parts || 0); this.welcomeGot = 0;
            this.maybeBuild();
        } else if (m.k === 'changes' && this.welcomeParts) {
            if (this.welcomeParts[m.part] == null) { this.welcomeParts[m.part] = m.list; this.welcomeGot++; }
            this.maybeBuild();
        } else if (m.k === 'full' && this.state === 'joining') {
            this.fail('Lobby ' + this.code + ' is full (' + LOBBY_MAX + ' players).');
        } else if (m.k === 'join' && this.state === 'ready') {
            this.peers.set(m.from, { name: String(m.name || 'Player').slice(0, 24), seen: Date.now(), skin: m.skin });
            g.addRemotePlayer({ id: m.from, name: m.name, skin: m.skin, x: m.x, y: m.y, z: m.z });
            g.addChat(String(m.name || 'Someone') + ' joined the lobby', 0xFFFF55);
            this.tellPage();
        } else if (m.k === 'net' && this.state === 'ready' && m.m) {
            const msg = { ...m.m };
            if (msg.t === 'move') msg.id = m.from;
            if (!['move', 'set', 'sets', 'chat', 'skin', 'held', 'swing', 'dead', 'pvp', 'drop', 'claim', 'taken', 'mobs', 'hitmob', 'score', 'arrow', 'boom'].includes(msg.t)) return;
            if (['skin', 'held', 'swing', 'dead', 'claim', 'taken', 'hitmob', 'mobs'].includes(msg.t)) msg.id = m.from;
            if ((msg.t === 'mobs' || msg.t === 'arrow' || msg.t === 'boom' || msg.t === 'taken') && m.from !== this.hostId && !this.isHost) return;
            if (this.isHost) this.record(msg);
            g.onNetMessage(this, JSON.stringify(msg));
        } else if (m.k === 'bye') {
            this.dropPeer(m.from);
        } else if (m.k === 'rules' && m.from === this.hostId) {
            this.sillyKnockback = !!m.silly;
            g.addChat('The host turned ' + (this.sillyKnockback ? 'on silly knockback!' : 'knockback back to normal.'), 0xFFFF55);
        } else if (m.k === 'closed' && m.from === this.hostId) {
            this.hostGone('The host closed the lobby.');
        }
    }
    maybeBuild() {
        if (!this.welcomeParts || this.welcomeGot < this.welcomeParts.length) return;
        const changes = [].concat(...this.welcomeParts), players = this.welcome.players || [];
        this.welcomeParts = null;
        this.game.generateLevel({ label: 'Normal', w: this.w, h: this.h, d: 64 }, false, { seed: this.seed, keepNet: true,
            edit: blocks => { for (let i = 0; i + 3 < changes.length; i += 4) blocks[(changes[i + 1] * this.h + changes[i + 2]) * this.w + changes[i]] = changes[i + 3]; },
            done: () => { this.ready(); for (const p of players) { this.peers.set(p.id, { name: p.name, seen: Date.now(), skin: p.skin }); if (p.x != null) this.game.addRemotePlayer(p); } } });
    }
    record(msg) {
        if (msg.t === 'set') this.changes.push(msg.x, msg.y, msg.z, msg.b);
        if (msg.t === 'sets' && Array.isArray(msg.list)) for (const v of msg.list) this.changes.push(v);
    }
    pos() { const p = this.game.player && this.game.player.position; return p ? { x: p.x, y: p.y, z: p.z } : {}; }
    setSillyKnockback(on) {
        if (!this.isHost) return;
        this.sillyKnockback = on;
        this.out('rules', { silly: on });
        this.game.addChat(on ? 'Silly knockback is on: hits send people flying!' : 'Knockback is back to normal.', 0xFFFF55);
    }
    dropPeer(id) {
        if (!this.peers.has(id)) return;
        const name = this.game.remotePlayers.get(id) ? this.game.remotePlayers.get(id).name : this.peers.get(id).name;
        this.peers.delete(id);
        this.game.removeRemotePlayer(id);
        if (id === this.hostId) { this.hostGone('The host left, so the lobby closed.'); return; }
        if (this.state === 'ready') this.game.addChat(name + ' left the lobby', 0xFFFF55);
        this.tellPage();
    }
    hostGone(why) {
        const g = this.game;
        this.state = 'closed'; this.tellPage();
        this.close(true);
        if (g.net === this) { g.net = null; g.clearRemotePlayers(); }
        g.addChat(why + ' You can keep playing this world on your own.', 0xFF5555);
    }
    heartbeat() {
        if (this.state !== 'ready' && this.state !== 'joining' && this.state !== 'loading') return;
        if (this.state === 'ready') this.out('alive', {});
        const now = Date.now();
        for (const [id, p] of [...this.peers]) if (now - p.seen > 12000) this.dropPeer(id);
    }
    send(str) {
        if (this.state !== 'ready') return;
        let msg; try { msg = JSON.parse(str); } catch { return; }
        if (msg.t === 'move') {
            const now = Date.now(); if (now - this.lastMove < 125) return; this.lastMove = now;
            this.out('net', { m: msg });
        } else if (msg.t === 'set' || msg.t === 'sets') {
            if (this.isHost) this.record(msg);
            this.out('net', { m: msg });
        } else if (msg.t === 'chat' && msg.killed) {
            const text = this.name + ' was killed by ' + msg.killed;
            this.out('net', { m: { t: 'chat', text, color: 0xFF5555 } });
            this.game.addChat(text, 0xFF5555);
        } else if (msg.t === 'chat') {
            const text = '<' + this.name + '> ' + String(msg.text || '').slice(0, 200);
            this.out('net', { m: { t: 'chat', text } });
            this.game.addChat(text);
        } else if (['skin', 'held', 'swing', 'dead', 'pvp', 'drop', 'claim', 'taken', 'mobs', 'hitmob', 'score', 'arrow', 'boom'].includes(msg.t)) this.out('net', { m: msg });
    }
    close(quiet) {
        if (this.closed) return;
        this.closed = true; this.readyState = 3;
        clearInterval(this.timer);
        if (!quiet || this.state === 'ready') this.out(this.isHost ? 'closed' : 'bye', {});
        this.transport.leave();
    }
}
class WaterFX023 {
    constructor() { this.c = new Float32Array(256); this.d = new Float32Array(256); this.e = new Float32Array(256); this.f = new Float32Array(256); this.px = new Uint8ClampedArray(1024); }
    tick() {
        const { e, f } = this;
        for (let x = 0; x < 16; x++) for (let y = 0; y < 16; y++) {
            let s = 0;
            for (let i = x - 1; i <= x + 1; i++) s += this.c[(i & 15) + ((y & 15) << 4)];
            this.d[x + (y << 4)] = s / 3.3 + e[x + (y << 4)] * 0.8;
        }
        for (let x = 0; x < 16; x++) for (let y = 0; y < 16; y++) {
            const k = x + (y << 4);
            e[k] += f[k] * 0.05;
            if (e[k] < 0) e[k] = 0;
            f[k] -= 0.1;
            if (Math.random() < 0.05) f[k] = 0.5;
        }
        const t = this.d; this.d = this.c; this.c = t;
        for (let i = 0; i < 256; i++) {
            const v = Math.min(1, Math.max(0, this.c[i])), v2 = v * v;
            this.px[i * 4] = 32 + v2 * 32; this.px[i * 4 + 1] = 50 + v2 * 64; this.px[i * 4 + 2] = 255; this.px[i * 4 + 3] = 146 + v2 * 50;
        }
    }
}
class LavaFX023 {
    constructor() { this.c = new Float32Array(256); this.d = new Float32Array(256); this.e = new Float32Array(256); this.f = new Float32Array(256); this.px = new Uint8ClampedArray(1024); }
    tick() {
        const { e, f } = this;
        for (let x = 0; x < 16; x++) for (let y = 0; y < 16; y++) {
            let s = 0;
            const ox = Math.trunc(Math.sin(y * Math.PI * 2 / 16) * 1.2), oy = Math.trunc(Math.sin(x * Math.PI * 2 / 16) * 1.2);
            for (let i = x - 1; i <= x + 1; i++) for (let j = y - 1; j <= y + 1; j++) s += this.c[((i + ox) & 15) + (((j + oy) & 15) << 4)];
            this.d[x + (y << 4)] = s / 10 + (e[(x & 15) + ((y & 15) << 4)] + e[((x + 1) & 15) + ((y & 15) << 4)] +
                e[((x + 1) & 15) + (((y + 1) & 15) << 4)] + e[(x & 15) + (((y + 1) & 15) << 4)]) / 4 * 0.8;
            const k = x + (y << 4);
            e[k] += f[k] * 0.01;
            if (e[k] < 0) e[k] = 0;
            f[k] -= 0.06;
            if (Math.random() < 0.005) f[k] = 1.5;
        }
        const t = this.d; this.d = this.c; this.c = t;
        for (let i = 0; i < 256; i++) {
            const v = Math.min(1, Math.max(0, this.c[i] * 2));
            this.px[i * 4] = v * 100 + 155; this.px[i * 4 + 1] = v * v * 255; this.px[i * 4 + 2] = v * v * v * v * 128; this.px[i * 4 + 3] = 255;
        }
    }
}
class ClassicHand030 {
    constructor(game) {
        this.game = game;
        this.leftHeld = false;
        this.itemGeos = {};
        this.itemMat = new THREE.MeshBasicMaterial({ map: game.solidMaterial.map, alphaTest: 0.1, vertexColors: true });
        this.itemMatDark = new THREE.MeshBasicMaterial({ map: game.solidMaterial.map, alphaTest: 0.1, color: 0x999999, vertexColors: true });
        this.itemPlantMat = new THREE.MeshBasicMaterial({ map: game.solidMaterial.map, alphaTest: 0.1, side: THREE.DoubleSide });
        this.crossedPlants = true;
    }
    get player() { return this.game.player; }
    placed() { if (this.hand) this.hand.c = 0; }
    handTick() {
        const h = this.hand;
        if (!h) return;
        h.d = h.c;
        if (h.swinging && ++h.e === 7) { h.e = 0; h.swinging = false; }
        const type = this.player.getSelectedBlock();
        let step = (type === h.shown ? 1 : 0) - h.c;
        step = Math.max(-0.4, Math.min(0.4, step));
        h.c += step;
        if (h.c < 0.1) h.shown = type;
    }
}
for (const k of ['setupHand', 'swing', 'renderHand', 'adjustCamera', 'bobTick']) ClassicHand030.prototype[k] = Survival024.prototype[k];
ClassicHand030.prototype.plantGeo030 = function (type) {
    const key = 'handplant:' + type;
    if (this.itemGeos[key]) return this.itemGeos[key];
    const S = 0.25, at = (x, y, z) => [(x - 0.5) * S, (y - 0.5) * S, (z - 0.5) * S];
    const [c, r] = faceUV(type, 0), e = 1 / 8192;
    const uL = c / 16 + e, uR = (c + 1) / 16 - e, vT = 1 - r / 16 - e, vB = 1 - (r + 1) / 16 + e;
    const pos = [], uv = [], col = [], idx = [], ox = 0, oy = 0.4, oz = -0.3;
    const quad = (vs) => {
        const b = pos.length / 3;
        for (const [x, y, z, u, v] of vs) { pos.push(...at(x, y, z)); uv.push(u, v); col.push(1, 1, 1); }
        idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
    };
    for (let i = 0; i < 2; i++) {
        const a = i * Math.PI / 2 + Math.PI / 4, dx = Math.sin(a) * 0.5, dz = Math.cos(a) * 0.5;
        const x0 = ox + 0.5 - dx, x1 = ox + 0.5 + dx, z0 = oz + 0.5 - dz, z1 = oz + 0.5 + dz, y0 = oy, y1 = oy + 1;
        quad([[x0, y1, z0, uR, vT], [x1, y1, z1, uL, vT], [x1, y0, z1, uL, vB], [x0, y0, z0, uR, vB]]);
        quad([[x1, y1, z1, uR, vT], [x0, y1, z0, uL, vT], [x0, y0, z0, uL, vB], [x1, y0, z1, uR, vB]]);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.setIndex(idx);
    g.userData.faceNormals = [0, 1, 2, 3].map(() => new THREE.Vector3(0, -1, 0));
    return (this.itemGeos[key] = g);
};
const HAND_LIGHT_030 = new THREE.Vector3(0, 1, -0.5).normalize();
ClassicHand030.prototype.handLight030 = function (mesh) {
    const geo = mesh.geometry, normals = geo.userData.faceNormals;
    if (!normals) return;
    const p = this.player;
    const view = new THREE.Quaternion().setFromEuler(new THREE.Euler(p.rotation.x, p.rotation.y, 0, 'YXZ')).invert();
    const light = HAND_LIGHT_030.clone().applyQuaternion(view);
    this.handScene.updateMatrixWorld(true);
    const col = geo.attributes.color, n = new THREE.Vector3();
    for (let f = 0; f < normals.length; f++) {
        n.copy(normals[f]).transformDirection(mesh.matrixWorld);
        const v = shade(Math.min(1, 0.7 + 0.3 * Math.max(0, n.dot(light))));
        for (let k = 0; k < 4; k++) col.setXYZ(f * 4 + k, v, v, v);
    }
    col.needsUpdate = true;
};
ClassicHand030.prototype.itemGeo = function (type, plantShape = false) {
    if (isPlant(type)) return this.plantGeo030(type);
    const key = 'hand:' + type;
    if (this.itemGeos[key]) return this.itemGeos[key];
    const s = 0.125, top = type === BLOCK.SLAB ? 0 : s, pos = [], uv = [], col = [], idx = [];
    const face = (verts, [c, r], shade, half = false, flipV = false) => {
        const e = 1 / 8192, b = pos.length / 3, u0 = c / 16 + e, u1 = (c + 1) / 16 - e, v0 = 1 - (r + 1) / 16 + e;
        const v1 = half ? 1 - (r + 0.5) / 16 : 1 - r / 16 - e;
        for (const v of verts) { pos.push(...v); col.push(shade, shade, shade); }
        if (flipV) uv.push(u0, v1, u1, v1, u1, v0, u0, v0); else uv.push(u0, v0, u1, v0, u1, v1, u0, v1);
        idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
    };
    const half = type === BLOCK.SLAB;
    face([[-s, -s, s], [s, -s, s], [s, top, s], [-s, top, s]], faceUV(type, 0), 0.8, half);
    face([[s, -s, -s], [-s, -s, -s], [-s, top, -s], [s, top, -s]], faceUV(type, 0), 0.8, half);
    face([[s, -s, s], [s, -s, -s], [s, top, -s], [s, top, s]], faceUV(type, 0), 0.6, half);
    face([[-s, -s, -s], [-s, -s, s], [-s, top, s], [-s, top, -s]], faceUV(type, 0), 0.6, half);
    face([[-s, top, s], [s, top, s], [s, top, -s], [-s, top, -s]], faceUV(type, 1), 1.0);
    face([[-s, -s, -s], [s, -s, -s], [s, -s, s], [-s, -s, s]], faceUV(type, -1), 0.5);
    const g = new THREE.BufferGeometry();
    g.userData.faceNormals = [[0, 0, 1], [0, 0, -1], [1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0]].map(n => new THREE.Vector3(...n));
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.setIndex(idx);
    return (this.itemGeos[key] = g);
};
const SOUND_OF = (() => {
    const m = {}, set = (kind, ...ids) => { for (const id of ids) m[id] = kind; };
    set('sand', BLOCK.SAND);
    set('dirt', BLOCK.GRASS, BLOCK.DIRT, BLOCK.GRAVEL, BLOCK.LEAVES, BLOCK.SAPLING, BLOCK.DANDELION, BLOCK.ROSE,
        BLOCK.BROWN_MUSHROOM, BLOCK.RED_MUSHROOM, BLOCK.SPONGE, BLOCK.TNT);
    set('stone', BLOCK.ROCK, BLOCK.COBBLESTONE, BLOCK.BEDROCK, BLOCK.COAL_ORE, BLOCK.IRON_ORE, BLOCK.GOLD_ORE, BLOCK.BRICK,
        BLOCK.SLAB, BLOCK.DOUBLE_SLAB, BLOCK.MOSSY_COBBLE, BLOCK.OBSIDIAN, BLOCK.GLASS);
    set('wood', BLOCK.PLANKS, BLOCK.LOG, BLOCK.BOOKSHELF);
    set('metal', BLOCK.IRON_BLOCK, BLOCK.GOLD_BLOCK);
    for (const id of CLOTH_BLOCKS) m[id] = 'wool';
    return m;
})();
const SOUND_URLS = {
    'calm1.ogg': ['https://files.catbox.moe/76xr3o.ogg'], 'calm2.ogg': ['https://files.catbox.moe/poqhk6.ogg'],
    'calm3.ogg': ['https://files.catbox.moe/ezugsi.ogg'],
    'grass1.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/grass1.ogg'],
    'grass2.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/grass2.ogg'],
    'grass3.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/grass3.ogg', 'https://files.catbox.moe/u10ym2.ogg'],
    'grass4.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/grass4.ogg', 'https://files.catbox.moe/sisoxn.ogg'],
    'gravel1.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/gravel1.ogg', 'https://files.catbox.moe/w1yc5h.ogg'],
    'gravel2.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/gravel2.ogg', 'https://files.catbox.moe/rlfob5.ogg'],
    'gravel3.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/gravel3.ogg', 'https://files.catbox.moe/io2933.ogg'],
    'gravel4.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/gravel4.ogg', 'https://files.catbox.moe/38zp1h.ogg'],
    'stone1.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/stone1.ogg', 'https://files.catbox.moe/7wcrra.ogg'],
    'stone2.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/stone2.ogg', 'https://files.catbox.moe/ivmlma.ogg'],
    'stone3.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/stone3.ogg', 'https://files.catbox.moe/1qv0d6.ogg'],
    'stone4.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/stone4.ogg', 'https://files.catbox.moe/r0i4wa.ogg'],
    'wood1.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/wood1.ogg'],
    'wood2.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/wood2.ogg'],
    'wood3.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/wood3.ogg'],
    'wood4.ogg': ['https://nebularkxd.github.io/claudecraft-bridge/sound/step/wood4.ogg']
};
const soundUrls = name => [...(SOUND_URLS[name] || []), './' + name];
const soundUrl = name => soundUrls(name)[0];
function fetchSound(ctx, name) {
    const get = url => fetch(url).then(r => { if (!r.ok) throw new Error('missing'); return r.arrayBuffer(); }).then(b => ctx.decodeAudioData(b));
    return soundUrls(name).reduce((p, url) => p.catch(() => get(url)), Promise.reject(new Error('start')));
}
function soundElement(name) {
    const one = url => new Promise((ok, fail) => {
        const a = new Audio(); a.preload = 'auto';
        a.addEventListener('canplaythrough', () => ok(a), { once: true });
        a.addEventListener('error', () => fail(new Error('missing')), { once: true });
        a.src = url;
    });
    return soundUrls(name).reduce((p, url) => p.catch(() => one(url)), Promise.reject(new Error('start')));
}
const STEP_FILE_GROUPS = ['grass', 'gravel', 'stone', 'wood'];
const RecordAudio = {
    ctx: null, dest: null, taps: [],
    start(outs) {
        const AC = typeof window !== 'undefined' && (window.AudioContext || window.webkitAudioContext);
        if (!AC) return null;
        try {
            this.ctx = new AC(); this.dest = this.ctx.createMediaStreamDestination();
            if (this.ctx.state === 'suspended') this.ctx.resume();
            for (const o of outs) this.tap(o.ctx, o.out);
            return this.dest.stream.getAudioTracks()[0] || null;
        } catch { this.stop(); return null; }
    },
    tap(ctx, out) {
        if (!this.ctx || !ctx || !out) return;
        try {
            const d = ctx.createMediaStreamDestination(); out.connect(d);
            const src = this.ctx.createMediaStreamSource(d.stream); src.connect(this.dest);
            this.taps.push({ out, d, src });
        } catch {  }
    },
    element(el) {
        if (!this.ctx) return;
        try {
            const st = el.captureStream ? el.captureStream() : el.mozCaptureStream ? el.mozCaptureStream() : null;
            if (!st || !st.getAudioTracks().length) return;
            const src = this.ctx.createMediaStreamSource(st); src.connect(this.dest);
            const done = () => { try { src.disconnect(); } catch {  } };
            el.addEventListener('ended', done, { once: true }); el.addEventListener('pause', done, { once: true });
        } catch {  }
    },
    resume() { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); },
    stop() {
        for (const t of this.taps) { try { t.out.disconnect(t.d); } catch {  } }
        this.taps = [];
        if (this.ctx) this.ctx.close().catch(() => {  });
        this.ctx = this.dest = null;
    }
};
const SOUND_TYPES_030 = {
    grass: ['grass', 0.6, 1.0], cloth: ['grass', 0.7, 1.2], gravel: ['gravel', 1.0, 1.0],
    stone: ['stone', 1.0, 1.0], metal: ['stone', 1.0, 2.0], wood: ['wood', 1.0, 1.0]
};
let soundTypeOf030 = null;
function soundType030(type) {
    if (!soundTypeOf030) {
        const m = {}, set = (k, ...ids) => { for (const id of ids) m[id] = k; }, B = BLOCK;
        set('grass', B.GRASS, B.DIRT, B.LEAVES, B.SAPLING, B.DANDELION, B.ROSE, B.BROWN_MUSHROOM, B.RED_MUSHROOM);
        set('gravel', B.SAND, B.GRAVEL);
        set('stone', B.ROCK, B.COBBLESTONE, B.BEDROCK, B.COAL_ORE, B.IRON_ORE, B.GOLD_ORE, B.DOUBLE_SLAB, B.SLAB,
            B.BRICK, B.MOSSY_COBBLE, B.OBSIDIAN);
        set('wood', B.PLANKS, B.LOG, B.BOOKSHELF);
        set('cloth', B.SPONGE, B.TNT, ...CLOTH_BLOCKS);
        set('metal', B.GLASS, B.GOLD_BLOCK, B.IRON_BLOCK);
        soundTypeOf030 = m;
    }
    return SOUND_TYPES_030[soundTypeOf030[type]] || null;
}
class ClassicSounds {
    constructor() { this.ctx = null; this.buffers = null; this.enabled = true; }
    wake() {
        RecordAudio.resume();
        if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
        const AC = typeof window !== 'undefined' && (window.AudioContext || window.webkitAudioContext);
        if (!AC) return;
        this.ctx = new AC();
        this.out = this.ctx.createGain(); this.out.gain.value = 0.7; this.out.connect(this.ctx.destination);
        RecordAudio.tap(this.ctx, this.out);
        this.loadFiles();
        const make = (fn, secs) => { const n = Math.floor(this.ctx.sampleRate * secs), b = this.ctx.createBuffer(1, n, this.ctx.sampleRate); fn(b.getChannelData(0), this.ctx.sampleRate); return b; };
        const takes = (fn, secs, peak = 0.6) => [0, 1, 2, 3].map(k => make((d, sr) => {
            fn(d, sr, k);
            let m = 0; for (let i = 0; i < d.length; i++) m = Math.max(m, Math.abs(d[i]));
            if (m > 0) for (let i = 0; i < d.length; i++) d[i] *= peak / m;
        }, secs));
        this.buffers = {
            dirt: takes((d, sr, k) => {
                const len = d.length, grains = 26 + k * 4;
                let rl = 0;
                const ar = 1 - Math.exp(-2 * Math.PI * 700 / sr);
                for (let i = 0; i < len; i++) {
                    const t = i / sr, env = Math.min(1, t / 0.01) * Math.exp(-t / 0.07);
                    rl += ar * ((Math.random() * 2 - 1) - rl);
                    d[i] = rl * env * 0.5;
                }
                for (let g = 0; g < grains; g++) {
                    const at = Math.pow(Math.random(), 1.8) * 0.17, n = Math.floor(sr * (0.002 + Math.random() * 0.004));
                    const s0 = Math.floor(at * sr), amp = (0.4 + Math.random() * 0.6) * Math.exp(-at / 0.09);
                    const ag = 1 - Math.exp(-2 * Math.PI * (900 + Math.random() * 1800) / sr);
                    let lp = 0;
                    for (let i = 0; i < n && s0 + i < len; i++) {
                        lp += ag * ((Math.random() * 2 - 1) - lp);
                        d[s0 + i] += lp * amp * Math.exp(-i / (n * 0.35));
                    }
                }
            }, 0.24),
            stone: takes((d, sr, k) => {
                let l1 = 0, l2 = 0, cl = 0;
                const a = 1 - Math.exp(-2 * Math.PI * (1100 + k * 120) / sr), ac = 1 - Math.exp(-2 * Math.PI * 2500 / sr);
                for (let i = 0; i < d.length; i++) {
                    const t = i / sr, x = Math.random() * 2 - 1;
                    cl += ac * (x - cl);
                    const click = t < 0.0025 ? (x - cl) * (1 - t / 0.0025) * 1.2 : 0;
                    l1 += a * (x - l1); l2 += a * (l1 - l2);
                    const knock = l2 * Math.min(1, t / 0.0008) * Math.exp(-t / (0.011 + k * 0.0015)) * 2.4;
                    const thump = Math.sin(2 * Math.PI * (135 - t * 900) * t) * Math.exp(-t / 0.013) * 0.55;
                    d[i] = click + knock + thump;
                }
            }, 0.07),
            sand: takes((d, sr, k) => {
                let l1 = 0, l2 = 0, h = 0;
                const a1 = 1 - Math.exp(-2 * Math.PI * (850 + k * 120) / sr), ah = 1 - Math.exp(-2 * Math.PI * 150 / sr);
                for (let i = 0; i < d.length; i++) {
                    const t = i / sr, env = Math.min(1, t / 0.018) * Math.exp(-Math.max(0, t - 0.018) / (0.06 + k * 0.008));
                    const grain = Math.random() < 0.08 ? 1.6 : 1;
                    const x = (Math.random() * 2 - 1) * grain;
                    l1 += a1 * (x - l1); l2 += a1 * (l1 - l2);
                    h += ah * (l2 - h);
                    d[i] = (l2 - h) * env;
                }
            }, 0.24),
            wood: takes((d, sr, k) => {
                const modes = [[170, 0.022, 0.35], [350, 0.026, 0.7], [640, 0.034, 1], [1080, 0.026, 0.9], [1750, 0.014, 0.6]]
                    .map(([f, dec, g]) => [f * (1 + (k - 1.5) * 0.035), dec, g]);
                const st = modes.map(() => [0, 0]);
                let lp = 0;
                const al = 1 - Math.exp(-2 * Math.PI * 3200 / sr), echo = Math.round(sr * (0.0038 + k * 0.0003));
                for (let i = 0; i < d.length; i++) {
                    const t = i / sr, x = Math.random() * 2 - 1;
                    lp += al * (x - lp);
                    const tap = t < 0.008 ? lp * (1 - t / 0.008) : 0;
                    let v = 0;
                    modes.forEach(([f, dec, g], j) => {
                        const r = Math.exp(-1 / (dec * sr)), w = 2 * Math.PI * f / sr, s0 = st[j];
                        const y = 2 * r * Math.cos(w) * s0[0] - r * r * s0[1] + tap;
                        s0[1] = s0[0]; s0[0] = y;
                        v += y * g;
                    });
                    d[i] = v * 0.12 + tap * 0.9;
                    if (i >= echo) d[i] += d[i - echo] * 0.38;
                }
            }, 0.2),
            metal: takes((d, sr, k) => {
                const parts = [1840, 2710, 3390, 4460, 5230].map(f => f * (1 + k * 0.03)), amp = [1, 0.8, 0.65, 0.5, 0.35];
                let hp = 0;
                for (let i = 0; i < d.length; i++) {
                    const t = i / sr;
                    let v = 0;
                    for (let j = 0; j < parts.length; j++) v += Math.sin(2 * Math.PI * parts[j] * t + j * 1.3) * amp[j] * Math.exp(-t / (0.016 - j * 0.0018));
                    v *= 0.55;
                    v += Math.sin(2 * Math.PI * (190 + k * 12) * t) * Math.exp(-t / 0.02) * 0.7;
                    if (t < 0.004) { const x = Math.random() * 2 - 1; hp = x - hp * 0.2; v += hp * (1 - t / 0.004) * 0.9; }
                    d[i] = v * Math.min(1, t / 0.0004);
                }
            }, 0.1)
        };
    }
    loadFiles() {
        this.files = {}; this.fileEls = {};
        for (const g of STEP_FILE_GROUPS) for (const i of [1, 2, 3, 4]) {
            const name = g + i + '.ogg';
            fetchSound(this.ctx, name)
                .then(buf => { (this.files[g] = this.files[g] || []).push(buf); })
                .catch(() => soundElement(name)
                    .then(el => { (this.fileEls[g] = this.fileEls[g] || []).push(el); })
                    .catch(() => console.warn('Claudecraft: the sound ' + name + ' could not be loaded from ' + soundUrls(name).join(' or '))));
        }
    }
    playFile(group, volume, pitch) {
        if (!(this.files[group] && this.files[group].length)) {
            const els = this.fileEls[group], a = els[Math.floor(Math.random() * els.length)].cloneNode();
            a.volume = Math.min(1, volume * 0.7); a.preservesPitch = false; a.mozPreservesPitch = false; a.playbackRate = pitch;
            a.play().then(() => RecordAudio.element(a)).catch(() => {  });
            return;
        }
        const set = this.files[group], src = this.ctx.createBufferSource(), g = this.ctx.createGain();
        src.buffer = set[Math.floor(Math.random() * set.length)];
        src.playbackRate.value = pitch;
        g.gain.value = volume;
        src.connect(g); g.connect(this.out);
        src.start();
    }
    fileFor(type) {
        const t = soundType030(type), has = list => list && list.length;
        return t && this.files && (has(this.files[t[0]]) || has(this.fileEls[t[0]])) ? t : null;
    }
    haveFiles() { return STEP_FILE_GROUPS.some(g => (this.files && this.files[g] && this.files[g].length) || (this.fileEls && this.fileEls[g] && this.fileEls[g].length)); }
    vol030(t) { return t[1] / (Math.random() * 0.4 + 1) * 0.5; }
    pitch030(t) { return t[2] / (Math.random() * 0.2 + 0.9); }
    play(type, volume, pitch) {
        if (!this.enabled || !this.ctx || !this.buffers) return;
        const kind = SOUND_OF[type];
        if (!kind) return;
        const set = this.buffers[kind === 'wool' ? 'dirt' : kind];
        const src = this.ctx.createBufferSource(), g = this.ctx.createGain();
        src.buffer = set[Math.floor(Math.random() * set.length)];
        src.playbackRate.value = (kind === 'wool' ? 1.6 : 1) * pitch * (0.9 + Math.random() * 0.2);
        g.gain.value = volume;
        src.connect(g); g.connect(this.out);
        src.start();
    }
    step(type) {
        if (!this.enabled || !this.ctx) return;
        const t = this.fileFor(type);
        if (t) this.playFile(t[0], this.vol030(t) * 0.75, this.pitch030(t));
        else if (soundType030(type) || !this.haveFiles()) this.play(type, 0.25, 1.0);
    }
    dig(type) {
        if (!this.enabled || !this.ctx) return;
        const t = this.fileFor(type);
        if (t) this.playFile(t[0], (this.vol030(t) + 1) / 2, this.pitch030(t) * 0.8);
        else if (soundType030(type) || !this.haveFiles()) this.play(type, 0.9, 0.8);
    }
}
class BlockIcons {
    constructor() {
        this.cache = new Map();
        this.renderer = null;
        this.geos = {};
    }
    geo(type) {
        if (this.geos[type]) return this.geos[type];
        const top = type === BLOCK.SLAB ? 0 : 0.5, pos = [], uv = [], col = [], idx = [];
        const face = (verts, [c, r], light, half = false) => {
            const lc = shade(light);
            const e = 1 / 8192, b = pos.length / 3, u0 = c / 16 + e, u1 = (c + 1) / 16 - e, v0 = 1 - (r + 1) / 16 + e;
            const v1 = half ? 1 - (r + 0.5) / 16 : 1 - r / 16 - e;
            for (const v of verts) { pos.push(...v); col.push(lc, lc, lc); }
            uv.push(u0, v0, u1, v0, u1, v1, u0, v1);
            idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
        };
        const s = 0.5, half = type === BLOCK.SLAB;
        face([[-s, -s, s], [s, -s, s], [s, top, s], [-s, top, s]], faceUV(type, 0), 0.8, half);
        face([[s, -s, -s], [-s, -s, -s], [-s, top, -s], [s, top, -s]], faceUV(type, 0), 0.8, half);
        face([[s, -s, s], [s, -s, -s], [s, top, -s], [s, top, s]], faceUV(type, 0), 0.6, half);
        face([[-s, -s, -s], [-s, -s, s], [-s, top, s], [-s, top, -s]], faceUV(type, 0), 0.6, half);
        face([[-s, top, s], [s, top, s], [s, top, -s], [-s, top, -s]], faceUV(type, 1), 1.0);
        const g = new THREE.BufferGeometry();
        g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
        g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
        g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
        g.setIndex(idx);
        return (this.geos[type] = g);
    }
    get(type, size, width, texture, renderer) {
        const key = type + ':' + size + ':' + width;
        if (this.cache.has(key)) return this.cache.get(key);
        if (!texture || !texture.image || !texture.image.width || !renderer) return null;
        if (!this.scene) {
            this.scene = new THREE.Scene();
            this.mat = new THREE.MeshBasicMaterial({ map: texture, vertexColors: true, alphaTest: 0.1 });
            this.mesh = new THREE.Mesh(this.geo(BLOCK.ROCK), this.mat);
            this.mesh.rotation.set(30 * Math.PI / 180, 45 * Math.PI / 180, 0, 'XYZ');
            this.scene.add(this.mesh);
            this.camera = new THREE.OrthographicCamera(-1, 1, 1, -1, -10, 10);
        }
        if (this.mat.map !== texture) { this.mat.map = texture; this.mat.needsUpdate = true; }
        this.mesh.geometry = this.geo(BLOCK.ROCK);
        this.mesh.updateMatrixWorld(true);
        const box = new THREE.Box3().setFromObject(this.mesh), c = box.getCenter(new THREE.Vector3()), sz = box.getSize(new THREE.Vector3());
        this.mesh.geometry = this.geo(type);
        const perPx = sz.x / width, half = size * perPx / 2;
        Object.assign(this.camera, { left: c.x - half, right: c.x + half, top: c.y + half, bottom: c.y - half });
        this.camera.updateProjectionMatrix();
        if (!this.target || this.target.width !== size) {
            if (this.target) this.target.dispose();
            this.target = new THREE.WebGLRenderTarget(size, size);
            this.target.texture.colorSpace = THREE.SRGBColorSpace;
        }
        const prev = renderer.getRenderTarget(), clear = renderer.getClearColor(new THREE.Color()), alpha = renderer.getClearAlpha();
        renderer.setRenderTarget(this.target);
        renderer.setClearColor(0x000000, 0);
        renderer.clear();
        renderer.render(this.scene, this.camera);
        const px = new Uint8Array(size * size * 4);
        renderer.readRenderTargetPixels(this.target, 0, 0, size, size, px);
        renderer.setRenderTarget(prev);
        renderer.setClearColor(clear, alpha);
        const cv = document.createElement('canvas');
        cv.width = cv.height = size;
        const img = cv.getContext('2d').createImageData(size, size);
        for (let y = 0; y < size; y++) img.data.set(px.subarray((size - 1 - y) * size * 4, (size - y) * size * 4), y * size * 4);
        cv.getContext('2d').putImageData(img, 0, 0);
        this.cache.set(key, cv);
        return cv;
    }
}
class Game {
    constructor() {
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(SKY_COLOR);
        this.renderSetting = 0;
        this.showFps = this.loadOption('showfps', false);
        this.viewBobbing = this.loadOption('bobbing', true);
        this.invertMouse = this.loadOption('invert', false);
        this.renderDistance = CLASSIC_0011A ? 1024 : RENDER_DISTANCES[0].dist;
        this.airFog = CLASSIC_0011A ? new THREE.FogExp2(srgb(0.5, 0.8, 1).getHex(), 0.001)
            : new THREE.Fog(RENDER_DISTANCES[0].fogColor ?? FOG_COLOR, RENDER_DISTANCES[0].fogStart, RENDER_DISTANCES[0].fogEnd);
        this.skyColor = new THREE.Color(SKY_COLOR);
        this.liquidFog = new THREE.FogExp2(0x050533, 0.15);
        this.scene.fog = this.airFog;
        this.camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.05, 2000);
        this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
        this.dpr = Math.min(2, window.devicePixelRatio || 1);
        this.renderer.setSize(innerWidth, innerHeight);
        this.renderer.setPixelRatio(this.dpr);
        this.renderer.autoClear = false;
        document.body.appendChild(this.renderer.domElement);
        this.hudCanvas = document.createElement('canvas');
        this.sizeHud = () => {
            this.hudCanvas.width = Math.round(innerWidth * this.dpr);
            this.hudCanvas.height = Math.round(innerHeight * this.dpr);
            this.hudCanvas.style.width = innerWidth + 'px'; this.hudCanvas.style.height = innerHeight + 'px';
        };
        this.sizeHud();
        Object.assign(this.hudCanvas.style, { position: 'absolute', top: '0', left: '0', pointerEvents: 'none', imageRendering: 'pixelated' });
        document.body.appendChild(this.hudCanvas);
        this.hudCtx = this.hudCanvas.getContext('2d');
        this.hudCtx.imageSmoothingEnabled = false;
        this.hudScale = Math.max(1, Math.round(3 * this.dpr));
        const fontImg = loadImageAny(CLASSIC_0011A ? ['./default.gif'] : ['./default.png', './default.gif'],
            () => { this.fontSheets = this.prepareFont(fontImg); this.lastHudKey = null; });
        this.fpsFrames = 0; this.fpsTimeAccum = 0; this.displayFps = 0;
        this.chunksUpdatedCounter = 0; this.displayChunkUpdates = 0;
        const pixelTexture = url => {
            const t = new THREE.Texture();
            const img = loadImageAny(url === TERRAIN_FILE ? TERRAIN_PATHS : [url], () => {
                if (url === TERRAIN_FILE && !CLASSIC_0011A) {
                    const cv = document.createElement('canvas');
                    cv.width = img.naturalWidth; cv.height = img.naturalHeight;
                    cv.getContext('2d').drawImage(img, 0, 0);
                    t.image = cv; this.terrainCanvas = cv;
                }
                t.needsUpdate = true;
            });
            t.image = img;
            t.magFilter = t.minFilter = THREE.NearestFilter;
            t.colorSpace = THREE.SRGBColorSpace;
            return t;
        };
        const tex = pixelTexture(TERRAIN_FILE);
        this.terrainTex = tex;
        this.solidMaterial = new THREE.MeshBasicMaterial({ map: tex, vertexColors: true, alphaTest: 0.1, side: THREE.FrontSide });
        this.plantMaterial = new THREE.MeshBasicMaterial({ map: tex, vertexColors: true, alphaTest: 0.1, side: THREE.DoubleSide });
        this.survival = SURVIVAL_024 ? new Survival024(this) : null;
        this.classicHand = !SURVIVAL_024 && !OLD_UI ? new ClassicHand030(this) : null;
        this.sounds = this.classicHand ? new ClassicSounds() : null;
        if (this.sounds) {
            this.sounds.enabled = this.loadOption('sound', true);
            const wake = () => this.sounds.wake();
            document.addEventListener('mousedown', wake, true); document.addEventListener('keydown', wake, true);
        }
        this.waterMaterial = new THREE.MeshBasicMaterial({
            map: tex, color: 0xFFFFFF, vertexColors: true, transparent: true, opacity: 1,
            side: THREE.DoubleSide, depthWrite: false
        });
        this.lavaMaterial = new THREE.MeshBasicMaterial({ map: tex, vertexColors: true, side: THREE.DoubleSide });
        this.glassMaterial = new THREE.MeshBasicMaterial({ map: tex, vertexColors: true, transparent: true, depthWrite: false, side: THREE.FrontSide });
        if (CLASSIC_0011A) {
            Object.assign(this.lavaMaterial, { transparent: true, depthWrite: false });
            for (const m of [this.solidMaterial, this.plantMaterial, this.waterMaterial, this.lavaMaterial]) classic012Shader(m);
        }
        this.sections = new Map();
        this.dirtySections = new Set();
        this.backgroundDirty = new Set();
        this.bulkChanges = false;
        this.netChanges = [];
        this.netChangesHead = 0;
        this.buildQueue = [];
        this.columnTops = new Map();
        this.queueStale = true;
        this.lastPlayerChunk = null;
        this.outerWorld = null;
        this.outerTextures = null;
        this.buildMode = false;
        this.particles = new BlockParticles(this.scene, tex);
        const charTex = makeSkinTexture('./char.png');
        this.mobMaterial = new THREE.MeshBasicMaterial({ map: charTex, alphaTest: 0.5, side: THREE.DoubleSide, vertexColors: true });
        this.zombieModel = new ZombieModel(this.mobMaterial);
        this.thirdPerson = false;
        this.playerView = this.zombieModel.create();
        this.playerView.root.visible = false;
        this.localAnim = { limbAmount: 0, limbPos: 0 };
        this.net = null;
        this.netPending = null;
        this.remotePlayers = new Map();
        this.playerName = 'Player' + Math.floor(100 + Math.random() * 900);
        this.signedIn = false;
        this.loggedIn = window.parent === window;
        this.frozen = false; this.blind = false; this.blindText = '';
        this.serverBuild = true; this.hideNametags = false;
        this.isGuest = false;
        this.music = new MusicPlayer();
        if (OLD_UI) this.music.enabled = false;
        if (typeof window !== 'undefined') for (const ev of ['mousedown', 'keydown', 'touchstart']) window.addEventListener(ev, () => this.music.unlock(), { passive: true });
        this.autoJoin = null;
        this.readJoinLink();
        if (typeof window !== 'undefined' && window.parent !== window && this.autoJoin)
            window.parent.postMessage({ type: 'claudecraft-version', version: CLASSIC_019 ? '0.0.19a' : null }, '*');
        this.mySkin = null;
        this.skinWaitUntil = performance.now() + 4000;
        window.addEventListener('message', e => {
            if (e.source !== window.parent || e.source === window) return;
            if (e.data && e.data.type === 'claudecraft-skin' && isSkinData(e.data.skin)) this.setMySkin(e.data.skin);
            if (e.data && e.data.type === 'claudecraft-settings' && e.data.values && typeof e.data.values === 'object') this.applySettings(e.data.values);
            if (e.data && e.data.type === 'claudecraft-screenshot') this.shotWanted = true;
            if (e.data && e.data.type === 'claudecraft-record') { if (e.data.on) this.startRecording(); else this.stopRecording(); }
            if (e.data && e.data.type === 'claudecraft-account') {
                const user = typeof e.data.user === 'string' && /^[A-Za-z0-9_]{2,16}$/.test(e.data.user) ? e.data.user : null;
                if (!this.autoJoin && !this.net) {
                    this.loggedIn = !!user;
                    if (user) { this.playerName = user; this.signedIn = true; this.isGuest = false; }
                }
            }
        });
        if (window.parent !== window) window.parent.postMessage({ type: 'claudecraft-want-skin' }, '*');
        this.lastNetSend = 0;
        this.chatOpen = false;
        this.chatInput = '';
        this.chatLines = [];
        this.scene.add(this.playerView.root);
        this.zombies = [];
        this.menu = null;
        this.statusMessage = null;
        this.loadingStage = null;
        this.loadingProgress = null;
        this.mouseX = 0; this.mouseY = 0;
        this.menuButtons = [];
        this.serverAddress = '';
        this.saveName = ''; this.saveDesc = '';
        this.saveField = 'name';
        this.joinMessage = null;
        this.createClouds();
        this.level = null;
        this.player = null;
        this.blockPreview = new BlockPreview(tex);
        this.blockPreview.setType(HOTBAR[0]);
        const brkMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.45, depthWrite: false });
        this.breakHighlight = new THREE.Mesh(new THREE.BoxGeometry(1.002, 1.002, 1.002), brkMat);
        this.breakHighlight.visible = false;
        this.scene.add(this.breakHighlight);
        this.selectOutline = new THREE.LineSegments(
            new THREE.EdgesGeometry(new THREE.BoxGeometry(1.004, 1.004, 1.004)),
            new THREE.LineBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.45 }));
        this.selectOutline.visible = false;
        this.scene.add(this.selectOutline);
        this.ghostGeos = {};
        for (const id of new Set(HOTBAR.concat(SELECTABLE_BLOCKS, EXTRA_BLOCKS))) this.ghostGeos[id] = isPlant(id) ? this.makePlantGhost(BLOCK_UVS[id]) : this.makeGhost(id);
        const gMat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.45, depthWrite: false, side: THREE.DoubleSide });
        this.placeHighlight = new THREE.Mesh(this.ghostGeos[BLOCK.DIRT], gMat);
        this.placeHighlight.visible = false;
        this.scene.add(this.placeHighlight);
        const texImg = new Image();
        let terrainTry = 0;
        const tryTerrain = src => { texImg.crossOrigin = /^https?:/.test(src) ? 'anonymous' : null; texImg.src = src; };
        texImg.onerror = () => { if (++terrainTry < TERRAIN_PATHS.length) tryTerrain(TERRAIN_PATHS[terrainTry]); };
        tryTerrain(TERRAIN_PATHS[0]);
        texImg.onload = () => {
            const createRepeatingTexture = (img, u, v) => {
                const canvas = document.createElement('canvas');
                canvas.width = 16; canvas.height = 16;
                canvas.getContext('2d').drawImage(img, u * 16, v * 16, 16, 16, 0, 0, 16, 16);
                const t = new THREE.CanvasTexture(canvas);
                t.magFilter = t.minFilter = THREE.NearestFilter;
                t.wrapS = t.wrapT = THREE.RepeatWrapping;
                t.colorSpace = THREE.SRGBColorSpace;
                return t;
            };
            const waterTex = createRepeatingTexture(texImg, WATER_UV[0], WATER_UV[1]);
            const bedrockTex = createRepeatingTexture(texImg, BEDROCK_UV[0], BEDROCK_UV[1]);
            this.outerTextures = [waterTex, bedrockTex];
            if (CLASSIC_0011A) {
                this.rockTex = createRepeatingTexture(texImg, BEDROCK_UV[0], BEDROCK_UV[1]);
            }
            this.terrainImg = texImg;
            this.buildOuterWorld(waterTex, bedrockTex);
        };
        this.input = { forward: false, backward: false, left: false, right: false, jump: false };
        this.pointerLocked = false;
        this.lastTime = performance.now();
        this.tickAccumulator = 0;
        this.setupInput();
        this.loop = this.loop.bind(this);
        this.frameChannel = new MessageChannel();
        this.frameChannel.port1.onmessage = () => this.extraFrame();
        this.vsyncInterval = 1000 / 60; this.lastVsync = 0; this.frameCost = 4; this.extrasPausedUntil = 0;
        this.vsyncPending = false; this.extraPending = false;
        this.extraCost = 8;
        this.syncPixel = new Uint8Array(4);
        this.uncapped = UNCAPPED_FPS;
        try { const m = localStorage.getItem('claudecraft-maxfps'); if (m) this.uncapped = m === 'unlimited'; } catch {  }
        try { const r = localStorage.getItem('claudecraft-render'); if (r) this.useRenderSetting(r, false); } catch {  }
        if (window.parent !== window) window.parent.postMessage({ type: 'claudecraft-settings-get' }, '*');
        this.scheduleFrame();
        const levelLink = typeof location !== 'undefined' ? new URLSearchParams(location.search) : null;
        if (levelLink && levelLink.get('level') && !this.autoJoin) {
            this.loadSharedLevel(levelLink.get('level'), (levelLink.get('title') || 'level').replace(/[^\x20-\x7E]/g, '').slice(0, SAVE_NAME_MAX));
        } else {
            if (CLASSIC_0011A && this.loadClassicLevel()) {  }
            else if (LOBBY_PARAM && (LOBBY_PARAM === 'new' || Lobby024.validCode(LOBBY_PARAM))) {
                this.lobby = new Lobby024(this, LOBBY_PARAM === 'new' ? null : LOBBY_PARAM);
                addEventListener('beforeunload', () => this.lobby && this.lobby.close());
            }
            else if (this.autoJoin) {
                this.autoJoinNoLevel = true;
                this.statusMessage = 'Connecting..';
                this.loadingStage = null;
            }
            else this.generateLevel(LEVEL_SIZES.find(sz => sz.label === 'Normal'), false);
        }
    }
    loadLevel(level) {
        this.autoJoinNoLevel = false;
        this.ownSpawn = false;
        if (this.survival) setTimeout(() => this.survival.newLevel(), 0);
        for (const sec of this.sections.values()) this.disposeSection(sec);
        this.sections.clear();
        this.dirtySections.clear();
        this.buildQueue = [];
        this.columnTops.clear();
        this.queueStale = true;
        this.lastPlayerChunk = null;
        MAP_WIDTH = level.width;
        MAP_HEIGHT = level.height;
        MAP_DEPTH = level.depth;
        this.level = level;
        this.meshBuilder = new ChunkMeshBuilder(level, this.solidMaterial, this.waterMaterial, this.lavaMaterial, this.plantMaterial, this.glassMaterial);
        level.addListener({
            tileChanged: (x, y, z) => this.queueChunkUpdate(x, y, z),
            lightColumnChanged: (x, z, y0, y1) => this.queueLightUpdate(x, z, y0, y1)
        });
        const slot = this.player ? this.player.selectedSlot : 0;
        this.player = new Player(level);
        this.player.selectedSlot = slot;
        if (level.savedPlayer) {
            const sp = level.savedPlayer;
            this.player.position.set(sp.x, sp.y, sp.z);
            this.player.rotation.x = sp.rotX;
            this.player.rotation.y = sp.rotY;
        }
        if (CLASSIC_0011A && !level.savedPlayer) this.player.position.set(Math.random() * level.width, level.depth + 10, Math.random() * level.height);
        while (this.player.collides(PLAYER_WIDTH / 2) && this.player.position.y < level.depth + PLAYER_HEIGHT) {
            this.player.position.y += 1;
        }
        this.raycaster = new BlockRaycaster(level);
        this.particles.setLevel(level);
        for (const zb of this.zombies) this.scene.remove(zb.view.root);
        this.zombies = [];
        if (CLASSIC_0011A) for (let i = 0; i < 10; i++) {
            const zb = new Zombie(level, this.zombieModel, Math.random() * level.width, level.depth + 10, Math.random() * level.height);
            this.zombies.push(zb); this.scene.add(zb.view.root);
        }
        this.updateChunks(Infinity, 48);
        if (this.blockPreview) this.blockPreview.setType(this.player.getSelectedBlock());
        if (this.outerTextures) this.buildOuterWorld(this.outerTextures[0], this.outerTextures[1]);
        if (this.clouds) this.clouds.position.set(MAP_WIDTH / 2, CLOUD_Y, MAP_HEIGHT / 2);
        const pp = this.player.position;
        this.spawnPoint = { x: pp.x, y: pp.y, z: pp.z, rotX: this.player.rotation.x, rotY: this.player.rotation.y };
    }
    applyExtraBlocks() {
        if (!this.player || this.survival) return;
        const held = this.player.getSelectedBlock();
        if (OLD_UI) this.player.inventory = HOTBAR.concat(this.net ? (this.extraBlocks || []) : []);
        else {
            const ok = new Set(this.selectableBlocks());
            this.player.inventory = this.player.inventory.slice(0, 9).map((b, i) => ok.has(b) ? b : HOTBAR[i]);
            while (this.player.inventory.length < 9) this.player.inventory.push(HOTBAR[this.player.inventory.length]);
        }
        const i = this.player.inventory.indexOf(held);
        this.player.selectedSlot = i >= 0 ? i : Math.min(this.player.selectedSlot, this.player.inventory.length - 1);
        if (this.blockPreview) this.blockPreview.setType(this.player.getSelectedBlock());
    }
    openBlockMenu() {
        if (!this.player || this.statusMessage || this.menu) return;
        this.openMenu('blocks');
        if (this.pointerLocked && document.exitPointerLock) document.exitPointerLock();
    }
    selectableBlocks() { return [...new Set(SELECTABLE_BLOCKS.concat(this.net ? (this.extraBlocks || []) : []))]; }
    layoutBlockMenu() {
        if (!CLASSIC_0011A) return this.layoutSelectBlock();
        const gs = this.guiScale();
        const W = this.hudCanvas.width, H = this.hudCanvas.height;
        const blocks = this.player.inventory, cols = Math.min(9, blocks.length), rows = Math.ceil(blocks.length / 9);
        const slot = 22 * gs, padX = 8 * gs, top = 26 * gs, bottom = 10 * gs;
        const pw = cols * slot + padX * 2, ph = top + rows * slot + bottom;
        const px = Math.floor((W - pw) / 2), py = Math.floor((H - ph) / 2);
        this.blockPanel = { x: px, y: py, w: pw, h: ph };
        this.menuTitleY = py + 9 * gs;
        this.blockSlots = blocks.map((id, i) => ({ id, index: i, size: slot,
            x: px + padX + (i % 9) * slot, y: py + top + Math.floor(i / 9) * slot }));
        this.menuButtons = [];
        return gs;
    }
    layoutSelectBlock() {
        const gs = this.guiScale(), W = this.hudCanvas.width / gs, H = this.hudCanvas.height / gs;
        const list = this.selectableBlocks();
        const rows = Math.ceil(list.length / 9), textLines = FOG_023 && !this.showFps ? 1 : 2;
        const lineH = this.fontSheets ? (this.fontSheets.charH * this.hudScale + 4) / gs : 12;
        const above = 4 / gs + textLines * lineH + 2, below = H - 22 - 2;
        const rowH = Math.max(18, Math.min(24, Math.floor((below - above - 30) / rows)));
        const panelH = 22 + rows * rowH + 8, top = Math.max(above, Math.round((above + below - panelH) / 2));
        this.blockPanel = { x: (W / 2 - 120) * gs, y: top * gs, w: 240 * gs, h: panelH * gs };
        this.menuTitleY = (top + 7) * gs;
        this.selectGrid = { top: top + 22 + 8, rowH };
        if (this.menuHidesHotbar) { this.menuHidesHotbar = false; this.lastHudKey = null; }
        this.blockSlots = list.map((id, i) => {
            const g0 = this.selectGrid, x = W / 2 + (i % 9) * 24 - 108, y = g0.top + Math.floor(i / 9) * g0.rowH;
            return { id, index: i, x: (x - 3) * gs, y: (y - 8) * gs, size: 26 * gs, h: 26 * gs,
                hitY: (y - 9) * gs, hitW: 24 * gs, hitH: this.selectGrid.rowH * gs, cx: (x + 10) * gs, cy: (y + 5) * gs };
        });
        this.menuButtons = [];
        return gs;
    }
    renderSelectBlock() {
        const ctx = this.hudCtx, gs = this.layoutSelectBlock(), pnl = this.blockPanel;
        const grad = (x, y, w, h, top, bottom) => { const g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, top); g.addColorStop(1, bottom); ctx.fillStyle = g; ctx.fillRect(x, y, w, h); };
        grad(pnl.x, pnl.y, pnl.w, pnl.h, 'rgba(5, 5, 0, 0.565)', 'rgba(48, 48, 96, 0.753)');
        this.drawTextCentered('Select block', Math.floor(this.hudCanvas.width / 2), this.menuTitleY, gs, 0xFFFFFF);
        const hov = this.blockSlots.find(b => this.mouseX >= b.x && this.mouseX < b.x + b.hitW && this.mouseY >= b.hitY && this.mouseY < b.hitY + b.hitH);
        if (hov) grad(hov.x, hov.y, hov.size, hov.h, 'rgba(255, 255, 255, 0.565)', 'rgba(255, 255, 255, 0.753)');
        for (const b of this.blockSlots) this.drawBlockIcon(b.id, b.cx, b.cy, (b === hov ? 1.6 : 1) * 7 * gs);
    }
    renderBlockMenu() {
        if (!CLASSIC_0011A) { this.renderSelectBlock(); return; }
        const ctx = this.hudCtx, gs = this.layoutBlockMenu(), pnl = this.blockPanel;
        ctx.fillStyle = 'rgba(32, 32, 48, 0.75)';
        ctx.fillRect(pnl.x, pnl.y, pnl.w, pnl.h);
        this.drawTextCentered('Select block', Math.floor(this.hudCanvas.width / 2), this.menuTitleY, gs, 0xFFFFFF);
        for (const b of this.blockSlots) {
            const hover = this.mouseX >= b.x && this.mouseX < b.x + b.size && this.mouseY >= b.y && this.mouseY < b.y + b.size;
            if (hover) { ctx.fillStyle = 'rgba(255, 255, 255, 0.25)'; ctx.fillRect(b.x, b.y, b.size, b.size); }
            else if (b.index === this.player.selectedSlot) {
                ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)'; ctx.lineWidth = gs;
                ctx.strokeRect(b.x + gs / 2, b.y + gs / 2, b.size - gs, b.size - gs);
            }
            this.drawBlockIcon(b.id, b.x + b.size / 2, b.y + b.size / 2, (hover ? 8 : 6.5) * gs);
        }
    }
    drawBlockIcon(id, cx, cy, w) {
        if (!this.iconTerrain) this.iconTerrain = loadImageAny(TERRAIN_PATHS, () => { this.lastHudKey = null; });
        const it = this.iconTerrain, img = it.complete && it.naturalWidth ? it : this.terrainTex && this.terrainTex.image;
        if (!img || !img.width) return;
        const ctx = this.hudCtx, ts = img.width / 16;
        ctx.save();
        ctx.imageSmoothingEnabled = false;
        if (isPlant(id)) {
            const [c, r] = faceUV(id, 0);
            const e = ts / 32;
            ctx.drawImage(img, c * ts + e, r * ts + e, ts - 2 * e, ts - 2 * e, Math.round(cx - w), Math.round(cy - w), Math.round(w * 2), Math.round(w * 2));
            ctx.restore();
            return;
        }
        if (this.classicHand && this.terrainCanvas && !(this.blockIcons && this.blockIcons.failed)) {
            if (!this.blockIcons) this.blockIcons = new BlockIcons();
            const width = Math.round(w * 2), size = Math.round(w * 2.6);
            const icon = this.blockIcons.get(id, size, width, this.terrainTex, this.renderer);
            if (icon) {
                ctx.drawImage(icon, Math.round(cx - size / 2), Math.round(cy - size / 2));
                ctx.restore();
                return;
            }
        }
        const h = w, H = w * 1.15, top = cy - (h + H) / 2;
        const T = [cx, top], R = [cx + w, top + h / 2], B = [cx, top + h], L = [cx - w, top + h / 2];
        const face = (uv, a, b, c, d, e, f, shade) => {
            ctx.setTransform(a / ts, b / ts, c / ts, d / ts, e, f);
            ctx.drawImage(img, uv[0] * ts + ts / 32, uv[1] * ts + ts / 32, ts - ts / 16, ts - ts / 16, 0, 0, ts, ts);
            if (shade) { ctx.fillStyle = `rgba(0, 0, 0, ${shade})`; ctx.fillRect(0, 0, ts, ts); }
        };
        if (id === BLOCK.SLAB) {
            const d = H / 2, sideHalf = (uv, a, b, e, f, shade) => {
                ctx.setTransform(a / ts, b / ts, 0, d / (ts / 2), e, f + d);
                ctx.drawImage(img, uv[0] * ts + ts / 32, uv[1] * ts + ts / 2, ts - ts / 16, ts / 2 - ts / 32, 0, 0, ts, ts / 2);
                if (shade) { ctx.fillStyle = `rgba(0, 0, 0, ${shade})`; ctx.fillRect(0, 0, ts, ts / 2); }
            };
            face(faceUV(id, 1), T[0] - L[0], T[1] - L[1], B[0] - L[0], B[1] - L[1], L[0], L[1] + d, 0);
            sideHalf(faceUV(id, 0), B[0] - L[0], B[1] - L[1], L[0], L[1], 0.2);
            sideHalf(faceUV(id, 0), R[0] - B[0], R[1] - B[1], B[0], B[1], 0.4);
            ctx.restore();
            return;
        }
        face(faceUV(id, 1), T[0] - L[0], T[1] - L[1], B[0] - L[0], B[1] - L[1], L[0], L[1], 0);
        face(faceUV(id, 0), B[0] - L[0], B[1] - L[1], 0, H, L[0], L[1], 0.2);
        face(faceUV(id, 0), R[0] - B[0], R[1] - B[1], 0, H, B[0], B[1], 0.4);
        ctx.restore();
    }
    async saveClassicLevel() {
        if (!this.level || this.statusMessage) return;
        try {
            const buf = new Uint8Array(await (await encodeLevel(this.level, this.player)).arrayBuffer());
            let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
            localStorage.setItem('claudecraft-0.0.11a-level', btoa(bin));
        } catch (e) { console.warn('Couldn\'t save the level:', e); }
    }
    loadClassicLevel() {
        let saved = null; try { saved = localStorage.getItem('claudecraft-0.0.11a-level'); } catch {  }
        if (!saved) return false;
        const bytes = Uint8Array.from(atob(saved), c => c.charCodeAt(0));
        this.statusMessage = 'Loading level..';
        decodeLevel(new Blob([bytes])).then(level => { this.statusMessage = null; this.loadLevel(level); })
            .catch(() => { this.statusMessage = null; this.generateLevel(LEVEL_SIZES[1], false); });
        return true;
    }
    respawn() {
        if (CLASSIC_0011A && this.player && this.level && !this.statusMessage) {
            const l = this.level;
            this.player.position.set(Math.random() * l.width, l.depth + 10, Math.random() * l.height);
            this.player.velocity.set(0, 0, 0);
            return;
        }
        if (!this.player || !this.spawnPoint || this.frozen || this.statusMessage) return;
        const sp = this.spawnPoint;
        this.player.position.set(sp.x, sp.y, sp.z);
        this.player.velocity.set(0, 0, 0);
        this.player.rotation.x = sp.rotX || 0;
        this.player.rotation.y = sp.rotY || 0;
        this.sendNet({ t: 'move', x: sp.x, y: sp.y, z: sp.z, rx: this.player.rotation.x, ry: this.player.rotation.y });
    }
    setSpawnHere() {
        if (!this.player || this.statusMessage) return;
        const p = this.player.position;
        this.spawnPoint = { x: p.x, y: p.y, z: p.z, rotX: this.player.rotation.x, rotY: this.player.rotation.y };
        this.ownSpawn = true;
        if (this.net && this.netLevelName) this.visitHomes[this.netLevelName] = this.spawnPoint;
        this.addChat('Spawn point set! Press R to come back here.', 0xFFFF55);
    }
    createClouds() {
        if (CLASSIC_0011A) return;
        const size = 6000;
        const tex = new THREE.TextureLoader().load('./clouds.png');
        tex.magFilter = tex.minFilter = THREE.NearestFilter;
        tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
        tex.colorSpace = THREE.SRGBColorSpace;
        const tileBlocks = 256 * CLOUD_BLOCKS_PER_PIXEL;
        tex.repeat.set(size / tileBlocks, size / tileBlocks);
        this.cloudTex = tex;
        const mat = new THREE.MeshBasicMaterial({
            map: tex, alphaTest: 0.5, side: THREE.DoubleSide
        });
        this.clouds = new THREE.Mesh(new THREE.PlaneGeometry(size, size), mat);
        this.clouds.rotation.x = -Math.PI / 2;
        this.clouds.renderOrder = 2;
        this.scene.add(this.clouds);
    }
    openMenu(name) {
        this.menu = name;
        this.menuOpenedAt = performance.now();
        if (name === 'load') {
            if (!this.slotNames) this.slotNames = new Array(LEVEL_SLOTS).fill(null);
            LevelStore.slotNames()
                .then(names => { this.slotNames = names; })
                .catch(err => console.error('Could not read saved levels:', err));
        }
        for (const k in this.input) this.input[k] = false;
    }
    closeMenu() {
        this.menu = null;
    }
    lockPointer() {
        try {
            const r = this.renderer.domElement.requestPointerLock();
            if (r && r.catch) r.catch(() => { });
        } catch (err) {  }
    }
    backToGame() {
        this.closeMenu();
        this.lockPointer();
    }
    guiScale() {
        const w = this.hudCanvas.width, h = this.hudCanvas.height;
        return Math.max(1, Math.min(Math.floor(w / 220), Math.floor(h / 186)));
    }
    layoutMenu() {
        if (this.menu === 'blocks') return this.layoutBlockMenu();
        const gs = this.guiScale();
        const W = this.hudCanvas.width / gs, H = this.hudCanvas.height / gs;
        const TITLE_GAP = 20;
        let items = [];
        if (this.menu === 'main') {
            const online = !!this.net;
            items = [
                { label: 'Generate new level...', enabled: !online, action: () => this.openMenu('generate') },
                { label: 'Save level..', enabled: !online && this.loggedIn, action: () => this.openSavePage() },
                { label: 'Load level..', enabled: !online && this.loggedIn, action: () => this.openMenu('load') },
                { label: FOG_023 ? 'Options...' : 'Settings...', action: () => this.openMenu('settings') },
                { label: 'Back to game', action: () => this.backToGame() }
            ];
            if (online) items.splice(items.length - 1, 0, { label: 'Disconnect', action: () => this.disconnectToNewLevel() });
            if (CLASSIC_019) {
                items = [{ label: 'Generate new level...', y: 0, enabled: !online, action: () => this.generateLevel(LEVEL_SIZES[1]) },
                    { label: 'Save level..', y: 32, enabled: false }, { label: 'Load level..', y: 64, enabled: false },
                    { label: 'Back to game', y: 96, action: () => this.backToGame() }];
                this.menuFromTop = 'third';
            }
            else if (CLASSIC_0011A) items = [{ label: 'Generate new level', action: () => this.generateLevel(LEVEL_SIZES[1]) },
                { label: 'Save level..', enabled: this.loggedIn || window.parent === window, action: () => this.openSavePage() },
                { label: 'Load level..', action: () => this.openMenu('load') },
                { label: 'Back to game', action: () => this.backToGame() }];
            if (CLASSIC_019) {  }
            else if (FOG_023) {
                const all = items, get = re => all.find(it => re.test(it.label));
                items = [{ ...get(/^Options/), y: 0 }, { ...get(/^Generate/), y: 24 }, { ...get(/^Save/), y: 48 }, { ...get(/^Load/), y: 72 }];
                if (online) items.push({ ...get(/^Disconnect/), y: 96 });
                if (SANDBOX && !online) items.push({ label: 'Sandbox settings...', y: 96, action: () => this.openSandbox() });
                items.push({ ...get(/^Back/), y: SANDBOX && !online ? 132 : 120 });
                this.menuFromTop = 'quarter';
            }
            else {
            const back = items.pop(), BW = 120, GAP = 4, ROW = 22, BH = 18;
            items = items.map((it, i) => {
                const lone = i === items.length - 1 && items.length % 2 === 1;
                const xOff = lone ? 100 - BW / 2 : i % 2 === 0 ? 100 - BW - GAP / 2 : 100 + GAP / 2;
                return { ...it, y: Math.floor(i / 2) * ROW, xOff, w: BW, h: BH };
            });
            items.push({ ...back, y: Math.ceil(items.length / 2) * ROW + 6, xOff: 100 - BW / 2, w: BW, h: BH });
            }
        } else if (this.menu === 'sandbox') {
            items = [];
        } else if (this.menu === 'gameover') {
            items = [this.lobby && this.net === this.lobby
                ? { label: 'Respawn', action: () => this.survival.respawn(), y: 72 }
                : { label: 'Generate new level...', action: () => this.openMenu('generate'), y: 72 }];
        } else if (this.menu === 'settings' && FOG_023) {
            const onOff = v => v ? 'ON' : 'OFF', re = () => this.openMenu('settings');
            items = [
                { label: 'Music: ' + onOff(this.music.enabled), action: () => { this.music.setEnabled(!this.music.enabled); re(); } },
                ...(this.sounds ? [{ label: 'Sound: ' + onOff(this.sounds.enabled), action: () => { this.sounds.enabled = !this.sounds.enabled; this.saveOption('sound', this.sounds.enabled); re(); } }] : []),
                { label: 'Invert mouse: ' + onOff(this.invertMouse), action: () => { this.invertMouse = !this.invertMouse; this.saveOption('invert', this.invertMouse); re(); } },
                { label: 'Show FPS: ' + onOff(this.showFps), action: () => { this.showFps = !this.showFps; this.saveOption('showfps', this.showFps); this.lastHudKey = null; re(); } },
                { label: 'Render distance: ' + RENDER_DISTANCES[this.renderSetting].name.toUpperCase(), action: () => { this.cycleRenderDistance(); re(); } },
                { label: 'View bobbing: ' + onOff(this.viewBobbing), action: () => { this.viewBobbing = !this.viewBobbing; this.saveOption('bobbing', this.viewBobbing); re(); } },
                { label: 'Limit framerate: ' + onOff(!this.uncapped), action: () => {
                    this.uncapped = !this.uncapped;
                    storeSetting('claudecraft-maxfps', this.uncapped ? 'unlimited' : 'refresh');
                    re(); } }
            ];
            if (this.lobby && this.net === this.lobby && this.lobby.isHost) {
                const lb = this.lobby;
                items.push({ label: 'Knockback: ' + (lb.sillyKnockback ? 'Silly' : 'Normal'), action: () => { lb.setSillyKnockback(!lb.sillyKnockback); re(); } });
            }
            items = items.map((it, i) => (this.survival ? { ...it, y: i * 24 } : { ...it, w: 150, xOff: 100 - 155 + (i % 2) * 160, y: 24 * (i >> 1) }));
            const last = Math.max(...items.map(it => it.y)), controlsY = Math.max(132, last + 36);
            items.push({ label: 'Controls...', y: controlsY, action: () => this.openMenu('controls') });
            items.push({ label: 'Done', y: controlsY + 36, action: () => this.openMenu('main') });
            this.menuFromTop = true;
        } else if (this.menu === 'controls') {
            const keys = [['Forward', 'W'], ['Left', 'A'], ['Back', 'S'], ['Right', 'D'], ['Jump', 'SPACE'], ['Build', 'B'], ['Chat', 'T'],
                ['Toggle fog', 'F'], ['Save location', 'ENTER'], ['Load location', 'R'], ['Toggle rain', 'P']];
            items = keys.map(([k, v], i) => ({ label: k + ': ' + v, xOff: 100 - 155 + (i % 2) * 160, w: 150, y: 24 * (i >> 1), action: () => {} }));
            items.push({ label: 'Done', y: 168, action: () => this.openMenu('settings') });
            this.menuFromTop = true;
        } else if (this.menu === 'settings') {
            items = [
                { label: 'Music: ' + (this.music.enabled ? 'ON' : 'OFF'), action: () => { this.music.setEnabled(!this.music.enabled); this.openMenu('settings'); } },
                { label: 'View distance: ' + RENDER_DISTANCES[this.renderSetting].name, action: () => { this.cycleRenderDistance(); this.openMenu('settings'); } },
                { label: 'Max FPS: ' + (this.uncapped ? 'Unlimited' : 'Screen refresh'), action: () => {
                    this.uncapped = !this.uncapped;
                    storeSetting('claudecraft-maxfps', this.uncapped ? 'unlimited' : 'refresh');
                    this.openMenu('settings'); } },
                { label: 'Done', action: () => this.openMenu('main') }
            ].map((it, i) => ({ ...it, y: i * 32 }));
        } else if (this.menu === 'generate') {
            items = LEVEL_SIZES.map(size => ({ label: size.label, action: () => this.generateLevel(size) }));
            items.push({ label: 'Cancel', action: () => this.openMenu('main') });
            items = items.map((it, i) => ({ ...it, y: i * 32 }));
        } else if (this.menu === 'load') {
            const names = this.slotNames || [];
            for (let i = 0; i < LEVEL_SLOTS; i++) {
                const name = names[i];
                items.push({ label: name || '-', y: i * 24, w: name ? 176 : 200,
                    action: () => { if (name) this.loadSlot(i); else this.importLevelFile(i); } });
                if (name) items.push({ label: 'X', y: i * 24, xOff: 180, w: 20,
                    action: () => { this.deleteSlot = i; this.openMenu('delete'); } });
            }
            const after = LEVEL_SLOTS * 24 + 6;
            items.push({ label: 'Cancel', y: after, action: () => this.openMenu('main') });
        } else if (this.menu === 'join') {
            items = [
                { label: 'Connect', y: 48, enabled: this.serverAddress.trim().length > 0, action: () => this.joinServer() },
                { label: 'Cancel', y: 72, action: () => this.openMenu('load') }
            ];
        } else if (this.menu === 'save') {
            items = [
                { label: 'Save', y: 86, enabled: this.saveName.trim().length > 0 && !this.saving, action: () => this.saveToLevels() },
                { label: 'Cancel', y: 110, action: () => this.openMenu('main') }
            ];
        } else if (this.menu === 'signin') {
            items = [
                { label: 'Sign in', y: 20, action: () => {} },
                { label: 'Play as Guest', y: 44, action: () => this.playAsGuest() },
                { label: 'Cancel', y: 76, action: () => this.openMenu('load') }
            ];
        } else if (this.menu === 'delete') {
            items = [
                { label: 'Delete', y: 0, action: () => this.deleteSavedLevel(this.deleteSlot) },
                { label: 'Cancel', y: 32, action: () => this.openMenu('load') }
            ];
        }
        let height = 0;
        for (const it of items) height = Math.max(height, it.y + (it.h || 20));
        const fromTop = this.menuFromTop; this.menuFromTop = false;
        let top = fromTop === 'quarter' || fromTop === 'third' ? 40 : fromTop ? 20 : Math.max(0, Math.floor((H - TITLE_GAP - height) / 2));
        let by = fromTop === 'quarter' ? Math.floor(H / 4) : fromTop === 'third' ? Math.floor(H / 3) : fromTop ? Math.floor(H / 6) : top + TITLE_GAP;
        const lift = fromTop && this.player && !OLD_UI ? Math.max(0, by + height - (H - 22 - 6)) : 0;
        if (lift) { by = Math.max(TITLE_GAP + 4, by - lift); top = Math.max(2, Math.min(top, by - TITLE_GAP)); }
        if (fromTop && by + height > H - 4 && height > 20) {
            const f = Math.max(0.85, (H - 4 - by - 20) / (height - 20));
            for (const it of items) it.y = Math.round(it.y * f);
            height = Math.round((height - 20) * f) + 20;
        }
        const hide = fromTop && by + height > H - 22;
        if (hide !== this.menuHidesHotbar) { this.menuHidesHotbar = hide; this.lastHudKey = null; }
        const bx = Math.floor(W / 2) - 100;
        this.menuTitleY = top * gs;
        this.menuBodyY = by * gs;
        if (this.menu === 'join') this.addressBox = { x: bx * gs, y: (by + 12) * gs, w: 200 * gs, h: 20 * gs };
        if (this.menu === 'save') {
            this.saveBoxes = { name: { x: bx * gs, y: (by + 10) * gs, w: 200 * gs, h: 20 * gs },
                desc: { x: bx * gs, y: (by + 46) * gs, w: 200 * gs, h: 20 * gs } };
        }
        this.menuButtons = items.map(it => ({
            enabled: true, ...it,
            x: (bx + (it.xOff || 0)) * gs, y: (by + it.y) * gs, w: (it.w || 200) * gs, h: (it.h || 20) * gs
        }));
        return gs;
    }
    renderPlayerList() {
        if (!this.fontSheets) return;
        const ctx = this.hudCtx, gs = this.guiScale(), cx = Math.floor(this.hudCanvas.width / 2);
        const names = [this.playerName, ...[...this.remotePlayers.values()].map(r => r.name)].sort((a, b) => a.localeCompare(b));
        const lineH = (this.fontSheets.charH + 3) * gs, top = 40 * gs;
        const widest = Math.max(...names.map(n => [...n].reduce((s, c) => s + this.fontSheets.widths[c.charCodeAt(0)], 0)), 90) * gs;
        const w = widest + 16 * gs, h = lineH * (names.length + 1) + 10 * gs;
        ctx.fillStyle = 'rgba(0, 0, 0, 0.55)'; ctx.fillRect(cx - w / 2, top, w, h);
        this.drawTextCentered('Players online (' + names.length + ')', cx, top + 5 * gs, gs, 0xFFFF55);
        names.forEach((n, i) => this.drawTextCentered(n, cx, top + 5 * gs + lineH * (i + 1), gs, n === this.playerName ? 0xFFFFFF : 0xE0E0E0));
    }
    menuTitle() {
        if (this.menu === 'blocks') return 'Select block';
        if (this.menu === 'main') return 'Game menu';
        if (this.menu === 'generate') return 'Generate new level';
        if (this.menu === 'settings') return FOG_023 ? 'Options' : 'Settings';
        if (this.menu === 'main' && FOG_023) return 'Game menu';
        if (this.menu === 'controls') return 'Controls';
        if (this.menu === 'gameover') return '';
        if (this.menu === 'load') return 'Load level';
        if (this.menu === 'join') return 'Join server';
        if (this.menu === 'save') return 'Save level';
        if (this.menu === 'signin') return 'Join server';
        if (this.menu === 'delete') {
            const name = this.slotNames && this.slotNames[this.deleteSlot];
            return 'Delete ' + (name || 'level') + '?';
        }
        return '';
    }
    menuClick(x, y) {
        this.layoutMenu();
        if (this.menu === 'blocks') {
            const slot = this.blockSlots.find(b => b.hitH ? (x >= b.x && x < b.x + b.hitW && y >= b.hitY && y < b.hitY + b.hitH)
                : (x >= b.x && x < b.x + b.size && y >= b.y && y < b.y + (b.h || b.size)));
            if (slot && !CLASSIC_0011A) {
                const inv = this.player.inventory, cur = this.player.selectedSlot, at = inv.indexOf(slot.id);
                if (at >= 0) inv[at] = inv[cur];
                inv[cur] = slot.id;
                this.blockPreview.setType(this.player.getSelectedBlock());
                this.backToGame();
            } else if (slot) {
                this.player.selectedSlot = slot.index;
                this.blockPreview.setType(this.player.getSelectedBlock());
                this.backToGame();
            }
            return;
        }
        if (this.menu === 'save' && this.saveBoxes) {
            for (const key of ['name', 'desc']) {
                const b = this.saveBoxes[key];
                if (x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) { this.saveField = key; return; }
            }
        }
        for (const b of this.menuButtons) {
            if (b.enabled && x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) {
                b.action();
                return;
            }
        }
    }
    renderMenu() {
        if (this.menu === 'blocks') { this.renderBlockMenu(); return; }
        const ctx = this.hudCtx;
        const gs = this.layoutMenu();
        if (this.menu === 'gameover') {
            const W = this.hudCanvas.width, H = this.hudCanvas.height, grad = ctx.createLinearGradient(0, 0, 0, H);
            grad.addColorStop(0, 'rgba(80,0,0,0.38)'); grad.addColorStop(1, 'rgba(128,48,48,0.63)');
            ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);
            this.drawTextCentered('Game over!', Math.floor(W / 2), 60 * gs, gs * 2, 0xFFFFFF);
            const score = String(this.player && this.player.score || 0), label = 'Score: ';
            const tw = t => [...t].reduce((n, c) => n + this.fontSheets.widths[c.charCodeAt(0)], 0) * gs;
            const x0 = Math.floor(W / 2 - (tw(label) + tw(score)) / 2);
            this.drawText(label, x0, 100 * gs, gs, 0xFFFFFF);
            this.drawText(score, x0 + tw(label), 100 * gs, gs, 0xFFFF55);
        }
        this.drawTextCentered(this.menuTitle(), Math.floor(this.hudCanvas.width / 2), this.menuTitleY, gs, 0xFFFFFF);
        for (const b of this.menuButtons) {
            const hover = b.enabled && this.mouseX >= b.x && this.mouseX < b.x + b.w &&
                this.mouseY >= b.y && this.mouseY < b.y + b.h;
            if (FOG_023 && !this.survival && !this.guiImg) this.guiImg = loadImageAny(GUI_PATHS, () => { this.lastHudKey = null; });
            const gui = this.survival ? this.survival.img.gui : FOG_023 ? this.guiImg : null;
            if (gui && gui.complete && gui.naturalWidth) {
                const v = 46 + (!b.enabled ? 0 : hover ? 2 : 1) * 20, half = Math.round(b.w / gs / 2), h = Math.round(b.h / gs);
                ctx.imageSmoothingEnabled = false;
                ctx.drawImage(gui, 0, v, half, h, b.x, b.y, half * gs, b.h);
                ctx.drawImage(gui, 200 - half, v, half, h, b.x + half * gs, b.y, half * gs, b.h);
            } else {
                ctx.fillStyle = b.enabled ? '#000000' : '#8080A0';
                ctx.fillRect(b.x - gs, b.y - gs, b.w + gs * 2, b.h + gs * 2);
                ctx.fillStyle = !b.enabled ? '#909090' : hover ? '#7070A0' : '#707070';
                ctx.fillRect(b.x, b.y, b.w, b.h);
            }
            const textY = b.y + Math.floor((b.h - this.fontSheets.charH * gs) / 2);
            const color = !b.enabled ? 0xA0A0A0 : hover ? 0xFFFFA0 : 0xE0E0E0;
            this.drawTextCentered(b.label, b.x + b.w / 2, textY, gs, color);
        }
        if (this.menu === 'signin') {
            this.drawTextCentered("You aren't signed in", Math.floor(this.hudCanvas.width / 2), this.menuBodyY + 4 * gs, gs, 0xFF5555);
        }
        if (this.menu === 'join' && this.isGuest) {
            const last = this.menuButtons[this.menuButtons.length - 1];
            this.drawTextCentered('Playing as ' + this.playerName, Math.floor(this.hudCanvas.width / 2), last.y + last.h + 6 * gs, gs, 0xA0A0A0);
        }
        if (this.menu === 'save' && this.saveBoxes) {
            const cxm = Math.floor(this.hudCanvas.width / 2);
            for (const [key, label, value] of [['name', 'Name:', this.saveName], ['desc', 'Description:', this.saveDesc]]) {
                const ab = this.saveBoxes[key];
                const active = this.saveField === key;
                ctx.fillStyle = active ? '#FFFFFF' : '#A0A0A0';
                ctx.fillRect(ab.x - gs, ab.y - gs, ab.w + gs * 2, ab.h + gs * 2);
                ctx.fillStyle = '#000000';
                ctx.fillRect(ab.x, ab.y, ab.w, ab.h);
                const cursor = active && Math.floor(performance.now() / 300) % 2 === 0 ? '_' : '';
                let shown = value;
                const room = ab.w - 8 * gs - this.textWidth('_', gs);
                while (shown.length > 0 && this.textWidth(shown, gs) > room) shown = shown.slice(1);
                this.drawText(shown + cursor, ab.x + 4 * gs, ab.y + Math.floor((ab.h - this.fontSheets.charH * gs) / 2), gs, 0xE0E0E0);
                this.drawText(label, ab.x, ab.y - 10 * gs, gs, 0xA0A0A0);
            }
            if (this.saveMessage) this.drawTextCentered(this.saveMessage, cxm, this.saveBoxes.desc.y + 26 * gs, gs, this.saveMessageColor || 0xFF5555);
        }
        if (this.menu === 'join' && this.addressBox) {
            const ab = this.addressBox;
            ctx.fillStyle = '#A0A0A0';
            ctx.fillRect(ab.x - gs, ab.y - gs, ab.w + gs * 2, ab.h + gs * 2);
            ctx.fillStyle = '#000000';
            ctx.fillRect(ab.x, ab.y, ab.w, ab.h);
            const cursor = Math.floor(performance.now() / 300) % 2 === 0 ? '_' : '';
            const textY = ab.y + Math.floor((ab.h - this.fontSheets.charH * gs) / 2);
            let shown = this.serverAddress;
            const room = ab.w - 8 * gs - this.textWidth('_', gs);
            while (shown.length > 0 && this.textWidth(shown, gs) > room) shown = shown.slice(1);
            this.drawText(shown + cursor, ab.x + 4 * gs, textY, gs, 0xE0E0E0);
            this.drawTextCentered('Server address:', Math.floor(this.hudCanvas.width / 2), ab.y - 12 * gs, gs, 0xA0A0A0);
            if (this.joinMessage) this.drawTextCentered(this.joinMessage, Math.floor(this.hudCanvas.width / 2), ab.y + 24 * gs, gs, 0xFF5555);
            if (this.joinHint && this.joinMessage) {
                const last = this.menuButtons[this.menuButtons.length - 1];
                this.drawTextCentered(this.joinHint, Math.floor(this.hudCanvas.width / 2), last.y + last.h + (this.isGuest ? 18 : 6) * gs, gs, 0xA0A0A0);
            }
        }
    }
    openSavePage() {
        this.saveThumb = null;
        this.thumbRequested = true;
        this.saveField = 'name';
        this.saveMessage = null;
        this.saving = false;
        this.openMenu('save');
    }
    copyThumbnail() {
        try {
            const c = document.createElement('canvas');
            c.width = 320; c.height = 180;
            const src = this.renderer.domElement, sw = src.width, sh = src.height;
            const scale = Math.max(c.width / sw, c.height / sh);
            const w = c.width / scale, h = c.height / scale;
            c.getContext('2d').drawImage(src, (sw - w) / 2, (sh - h) / 2, w, h, 0, 0, c.width, c.height);
            return c.toDataURL('image/jpeg', 0.85);
        } catch (err) { console.error('Could not take a thumbnail:', err); return null; }
    }
    handleSaveKey(e) {
        if (e.code === 'Tab') { e.preventDefault(); this.saveField = this.saveField === 'name' ? 'desc' : 'name'; return; }
        if (e.code === 'Enter') { e.preventDefault(); if (this.saveName.trim() && !this.saving) this.saveToLevels(); return; }
        const key = this.saveField === 'name' ? 'saveName' : 'saveDesc', max = this.saveField === 'name' ? SAVE_NAME_MAX : SAVE_DESC_MAX;
        if (e.code === 'Backspace') { this[key] = this[key].slice(0, -1); }
        else if (!e.ctrlKey && !e.metaKey && e.key.length === 1 && e.key >= ' ' && e.key <= '~' && this[key].length < max) this[key] += e.key;
        else return;
        this.saveMessage = null;
        e.preventDefault();
    }
    async saveToLevels() {
        const name = this.saveName.trim(), description = (CLASSIC_0011A ? C12_LEVEL_TAG : '') + this.saveDesc.trim();
        if (!name || this.saving) return;
        this.saving = true;
        for (let i = 0; i < 20 && !this.saveThumb; i++) await new Promise(r => setTimeout(r, 50));
        this.saveMessage = 'Saving..'; this.saveMessageColor = 0xE0E0E0;
        let blob;
        try { blob = await encodeLevel(this.level, this.player); }
        catch (err) { this.saving = false; this.saveMessage = 'Couldn\'t save the level'; this.saveMessageColor = 0xFF5555; return; }
        if (CLASSIC_0011A) {
            try {
                const names = await LevelStore.slotNames();
                let slot = names.indexOf(name);
                if (slot < 0) slot = names.indexOf(null);
                if (slot < 0) slot = LEVEL_SLOTS - 1;
                await LevelStore.put(slotKey('data', slot), blob);
                await LevelStore.put(slotKey('meta', slot), { name, w: this.level.width, h: this.level.height, d: this.level.depth });
                this.slotNames = null;
            } catch (err) { console.warn('Could not keep it in a Load slot', err); }
        }
        const download = () => {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = (name.replace(/[^A-Za-z0-9 _-]/g, '') || 'level') + '.dat';
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
        };
        if (window.parent === window) {
            download();
            this.saving = false;
            this.addChat('Level saved', 0xFFFF55);
            this.openMenu('main');
            return;
        }
        const bytes = new Uint8Array(await blob.arrayBuffer());
        let bin = '';
        for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
        const result = await new Promise(resolve => {
            const id = 'save-' + Date.now();
            const onReply = e => {
                if (e.source !== window.parent || !e.data || e.data.type !== 'claudecraft-publish-result' || e.data.id !== id) return;
                window.removeEventListener('message', onReply);
                resolve(e.data);
            };
            window.addEventListener('message', onReply);
            window.parent.postMessage({ type: 'claudecraft-publish', id, name, description, dat: btoa(bin), thumb: this.saveThumb }, '*');
            setTimeout(() => { window.removeEventListener('message', onReply); resolve({ ok: false, error: 'No server answered' }); }, 30000);
        });
        this.saving = false;
        if (result.ok) {
            this.addChat('Level saved to the Levels page: ' + name, 0xFFFF55);
            this.saveName = ''; this.saveDesc = '';
            this.openMenu('main');
        } else {
            const why = String(result.error || 'the Levels page isn\'t available').slice(0, 60);
            this.addChat('Couldn\'t save to the Levels page: ' + why, 0xFF5555);
            this.saveMessage = 'Couldn\'t save. Try again?'; this.saveMessageColor = 0xFF5555;
        }
    }
    async loadSharedLevel(url, title) {
        this.statusMessage = 'Loading ' + title + '..';
        this.loadingStage = null;
        this.loadingProgress = 0;
        try {
            const res = await fetch(url);
            if (!res.ok) throw new Error('not found');
            const total = Number(res.headers.get('content-length')) || 0;
            const reader = res.body.getReader(), parts = [];
            let got = 0;
            for (;;) {
                const { done, value } = await reader.read();
                if (done) break;
                parts.push(value); got += value.length;
                if (total) this.loadingProgress = Math.min(0.9, got / total * 0.9);
            }
            let bytes = new Uint8Array(await new Blob(parts).arrayBuffer());
            if (!(bytes[0] === 0x1f && bytes[1] === 0x8b)) bytes = Uint8Array.from(atob(new TextDecoder().decode(bytes).trim()), ch => ch.charCodeAt(0));
            this.loadingProgress = 0.95;
            const level = await decodeLevel(new Blob([bytes]));
            this.loadingProgress = 1;
            this.loadLevel(level);
        } catch (err) {
            console.error('Could not load that level:', err);
            this.statusMessage = null;
            this.addChat('Couldn\'t load that level', 0xFF5555);
            this.generateLevel(LEVEL_SIZES.find(sz => sz.label === 'Normal'), false);
            return;
        }
        this.statusMessage = null; this.loadingProgress = null;
    }
    handleAddressKey(e) {
        if (e.code === 'Enter') {
            e.preventDefault();
            if (this.serverAddress.trim()) this.joinServer();
            return;
        } else if (e.code === 'Backspace') {
            this.serverAddress = this.serverAddress.slice(0, -1);
        } else if (!e.ctrlKey && !e.metaKey && e.key.length === 1 && e.key >= ' ' && e.key <= '~' && this.serverAddress.length < SERVER_ADDRESS_MAX) {
            this.serverAddress += e.key;
        } else {
            return;
        }
        this.joinMessage = null;
        e.preventDefault();
    }
    generateLevel(size, lockMouse = true, opts = {}) {
        if (!opts.keepNet) this.leaveServer();
        this.closeMenu();
        if (lockMouse) this.lockPointer();
        this.statusMessage = 'Generating level..';
        this.loadingStage = 'Raising..';
        this.loadingProgress = 0;
        if (OLD_UI) size = { label: 'Normal', w: 256, h: 256, d: 64 };
        const T = SANDBOX ? Sandbox.s.terrain : null;
        if (T && opts.sandboxSize) size = { label: 'Sandbox', w: T.width, h: T.length };
        const seed = opts.seed ?? (T && opts.sandboxSize ? sandboxSeed(T.seed) : undefined);
        if (!CLASSIC_0011A) size = { ...size, d: 64 };
        const gen = CLASSIC_0011A ? new LevelGen012(size.w, size.h, size.d) : CLASSIC_019 ? new LevelGen019(size.w, size.h, seed) : SURVIVAL_024 ? new LevelGen024(size.w, size.h, seed)
            : new LevelGen024(size.w, size.h, seed, T);
        const steps = gen.generateSteps();
        const finish = () => {
            this.statusMessage = null;
            this.loadingStage = null;
            this.loadingProgress = null;
        };
        const work = () => {
            const start = performance.now();
            let r;
            try {
                do {
                    r = steps.next();
                    if (!r.done) [this.loadingStage, this.loadingProgress] = r.value;
                } while (!r.done && performance.now() - start < 30);
            } catch (err) {
                console.error('Level generation failed:', err);
                finish();
                return;
            }
            if (!r.done) { setTimeout(work, 0); return; }
            setTimeout(() => {
                try {
                    if (opts.edit) opts.edit(r.value);
                    const lv = new Level(size.w, size.h, size.d, r.value);
                    if (T) lv.seaLevel = gen.water;
                    this.loadLevel(lv);
                } catch (err) {
                    console.error('Level generation failed:', err);
                }
                finish();
                if (opts.done) opts.done();
            }, 0);
        };
        setTimeout(work, 30);
    }
    downloadLevel() {
        const lv = this.level;
        this.statusMessage = 'Saving level..';
        encodeLevel(lv, this.player)
            .then(blob => {
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'level.dat';
                document.body.appendChild(a);
                a.click();
                a.remove();
                setTimeout(() => URL.revokeObjectURL(url), 1000);
                this.addChat('Level saved', 0xFFFF55);
            })
            .catch(err => { console.error('Could not save level:', err); this.addChat('Couldn\'t save the level', 0xFF5555); })
            .finally(() => { this.statusMessage = null; });
    }
    importLevelFile(slot) {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.dat,.lvl';
        input.onchange = async () => {
            const file = input.files && input.files[0];
            if (!file) return;
            this.statusMessage = 'Adding level..';
            try {
                const level = await decodeLevel(file);
                const name = file.name.replace(/\.dat$/i, '').slice(0, LEVEL_NAME_MAX) || 'Level ' + (slot + 1);
                await LevelStore.put(slotKey('data', slot), file);
                await LevelStore.put(slotKey('meta', slot), { name, w: level.width, h: level.height, d: level.depth });
                if (!this.slotNames) this.slotNames = new Array(LEVEL_SLOTS).fill(null);
                this.slotNames[slot] = name;
            } catch (err) {
                console.error('Could not add level file:', err);
            }
            this.statusMessage = null;
        };
        input.click();
    }
    deleteSavedLevel(slot) {
        Promise.all([LevelStore.remove(slotKey('data', slot)), LevelStore.remove(slotKey('meta', slot))])
            .then(() => { if (this.slotNames) this.slotNames[slot] = null; })
            .catch(err => console.error('Could not delete level:', err))
            .finally(() => this.openMenu('load'));
    }
    loadSlot(slot) {
        this.leaveServer();
        this.closeMenu();
        this.lockPointer();
        this.statusMessage = 'Loading level..';
        LevelStore.get(slotKey('data', slot))
            .then(data => {
                if (!data) throw new Error('Slot ' + slot + ' is empty');
                return decodeLevel(data);
            })
            .then(level => this.loadLevel(level))
            .catch(err => console.error('Could not load level:', err))
            .finally(() => { this.statusMessage = null; });
    }
    buildOuterWorld(waterTex, bedrockTex) {
        if (CLASSIC_0011A) { this.buildClassicOuter(waterTex); return; }
        if (this.outerWorld) {
            this.scene.remove(this.outerWorld);
            this.outerWorld.traverse(o => { if (o.geometry) o.geometry.dispose(); });
        }
        this.outerWorld = new THREE.Group();
        this.scene.add(this.outerWorld);
        const waterMat = new THREE.MeshBasicMaterial({
            map: waterTex, color: 0xFFFFFF, transparent: true, opacity: 1,
            side: THREE.DoubleSide, depthWrite: false
        });
        const bedrockMat = new THREE.MeshBasicMaterial({ map: bedrockTex, side: THREE.FrontSide });
        const W = 4000, mapW = MAP_WIDTH, halfMap = mapW / 2, ext = W / 2;
        const wallMat = new THREE.MeshBasicMaterial({ map: bedrockTex, side: THREE.DoubleSide });
        const plane = (mat, pw, ph, x, y, z, rotX, rotY, order) => {
            const geo = new THREE.PlaneGeometry(pw, ph);
            const uvs = geo.attributes.uv;
            for (let i = 0; i < uvs.count; i++) { uvs.setX(i, uvs.getX(i) * pw); uvs.setY(i, uvs.getY(i) * ph); }
            const mesh = new THREE.Mesh(geo, mat);
            mesh.rotation.set(rotX, rotY, 0);
            mesh.position.set(x, y, z);
            if (order) mesh.renderOrder = order;
            this.outerWorld.add(mesh);
        };
        const strips = [[mapW + W, ext, halfMap, -ext / 2], [mapW + W, ext, halfMap, mapW + ext / 2],
            [ext, mapW, -ext / 2, halfMap], [ext, mapW, mapW + ext / 2, halfMap]];
        const SEA = (this.level && this.level.seaLevel) || SEA_LEVEL;
        for (const [pw, ph, x, z] of strips) {
            plane(waterMat, pw, ph, x, SEA - 1 / 16, z, -Math.PI / 2, 0, 1);
            plane(bedrockMat, pw, ph, x, Math.max(1, SEA - MAX_WATER_DEPTH), z, -Math.PI / 2, 0);
        }
        const wh = Math.max(1, SEA - MAX_WATER_DEPTH);
        for (const [x, z, ry] of [[halfMap, 0, 0], [halfMap, mapW, Math.PI], [0, halfMap, Math.PI / 2], [mapW, halfMap, -Math.PI / 2]])
            plane(wallMat, mapW, wh, x, wh / 2, z, 0, ry);
        plane(bedrockMat, mapW, MAP_HEIGHT, halfMap, 0, MAP_HEIGHT / 2, -Math.PI / 2, 0);
    }
    openSandbox() {
        if (!this.sandboxPanel) this.sandboxPanel = buildSandboxPanel(this);
        this.sandboxPanel.refresh();
        this.sandboxPanel.el.hidden = false;
        this.openMenu('sandbox');
    }
    closeSandbox() {
        if (this.sandboxPanel) this.sandboxPanel.el.hidden = true;
        this.openMenu('main');
    }
    applySandbox() {
        const R = Sandbox.s.render, P = Sandbox.s.player;
        if (this.net) { SANDBOX_PHYS.speed = SANDBOX_PHYS.jump = SANDBOX_PHYS.gravity = 1; }
        else { SANDBOX_PHYS.speed = P.speed; SANDBOX_PHYS.jump = P.jump; SANDBOX_PHYS.gravity = P.gravity; }
        if (this.camera.fov !== R.fov) { this.camera.fov = R.fov; this.camera.updateProjectionMatrix(); }
        this.renderDistance = Math.max(R.viewDistance + 16, 32);
        if (this.airFog && this.airFog.isFog) {
            this.airFog.near = R.fog ? 0 : 1e6; this.airFog.far = R.fog ? R.viewDistance : 1e6 + 1;
            this.airFog.color.set(R.fogColor);
        }
        this.skyColor.set(R.fogColor);
        if (this.skyPlane) this.skyPlane.material.color.set(R.skyColor);
        if (this.clouds) { this.clouds.visible = R.clouds; this.clouds.position.y = R.cloudHeight; }
        this.raining = R.rain;
        const key = [R.shadeTop, R.shadeNS, R.shadeEW, R.shadeBottom, R.shadow].join();
        if (key !== this.sandboxShadeKey) {
            const first = this.sandboxShadeKey === undefined;
            this.sandboxShadeKey = key;
            FACE_SHADE.top = R.shadeTop; FACE_SHADE.northSouth = R.shadeNS; FACE_SHADE.eastWest = R.shadeEW; FACE_SHADE.bottom = R.shadeBottom;
            SHADOW_SHADE = R.shadow;
            if (!first || key !== SANDBOX_SHADE_DEFAULT_KEY) this.redrawAllChunks();
        }
    }
    redrawAllChunks() {
        if (!this.level || !this.sections) return;
        for (const sec of this.sections.values()) this.disposeSection(sec);
        this.sections.clear(); this.dirtySections.clear(); this.buildQueue = [];
        this.queueStale = true; this.lastPlayerChunk = null;
        this.updateChunks(Infinity, 48);
    }
    updateRain() {
        if (!this.raining || !this.player || !this.level) { if (this.rainMesh) this.rainMesh.visible = false; return; }
        if (!this.rainTex) {
            this.rainTex = null;
            const tex = new THREE.Texture();
            tex.magFilter = tex.minFilter = THREE.NearestFilter; tex.generateMipmaps = false;
            tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.colorSpace = THREE.SRGBColorSpace;
            tex.image = loadImageAny(RAIN_PATHS, () => { tex.needsUpdate = true; this.rainReady = true; });
            this.rainTex = tex;
            const n = 121 * 2 * 4, g = new THREE.BufferGeometry();
            g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3));
            g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(n * 2), 2));
            g.setAttribute('color', new THREE.BufferAttribute(new Float32Array(n * 4), 4));
            const idx = []; for (let q = 0; q < 121 * 2; q++) { const b = q * 4; idx.push(b, b + 1, b + 2, b, b + 2, b + 3); }
            g.setIndex(idx);
            this.rainMesh = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false,
                side: THREE.DoubleSide, vertexColors: true, fog: false }));
            this.rainMesh.frustumCulled = false; this.rainMesh.renderOrder = 5;
            this.scene.add(this.rainMesh);
        }
        if (!this.rainReady) { this.rainMesh.visible = false; return; }
        const L = this.level, p = this.player.position;
        const px = p.x, pz = p.z, feetY = p.y - PLAYER_HEIGHT;
        const ix = Math.floor(px), iy = Math.floor(feetY + PLAYER_HEIGHT * 0), iz = Math.floor(pz);
        const ticks = performance.now() / 50, tick = Math.floor(ticks), part = ticks - tick;
        const g = this.rainMesh.geometry, P = g.attributes.position.array, U = g.attributes.uv.array, C = g.attributes.color.array;
        const top = (x, z) => {
            if (x < 0 || z < 0 || x >= L.width || z >= L.height) return 0;
            for (let y = L.depth - 1; y >= 0; y--) { const t = L.getTile(x, y, z); if (t !== BLOCK.AIR && t !== BLOCK.WATER && t !== BLOCK.LAVA) return y + 1; }
            return 0;
        };
        let q = 0;
        for (let x = ix - 5; x <= ix + 5; x++) for (let z = iz - 5; z <= iz + 5; z++) {
            const h = top(x, z);
            const y0 = Math.max(iy - 5, h), y1 = Math.max(iy + 5, h);
            if (y0 === y1) continue;
            const off = ((((tick + x * 3121 + z * 418711) % 32) + 32) % 32 + part) / 32;
            const dx = x + 0.5 - px, dz = z + 0.5 - pz, d = Math.sqrt(dx * dx + dz * dz) / 5;
            const a = Math.max(0, (1 - d * d) * 0.7);
            const vb = -(y0 / 4 + off * 2), vt = -(y1 / 4 + off * 2);
            for (const [xa, za, xb, zb] of [[x, z, x + 1, z + 1], [x, z + 1, x + 1, z]]) {
                const b = q * 4;
                const verts = [[xa, y0, za, 0, vb], [xb, y0, zb, 2, vb], [xb, y1, zb, 2, vt], [xa, y1, za, 0, vt]];
                verts.forEach(([vx, vy, vz, u, v], k) => {
                    P.set([vx, vy, vz], (b + k) * 3); U.set([u, v], (b + k) * 2); C.set([1, 1, 1, a], (b + k) * 4);
                });
                q++;
            }
        }
        g.setDrawRange(0, q * 6);
        g.attributes.position.needsUpdate = g.attributes.uv.needsUpdate = g.attributes.color.needsUpdate = true;
        this.rainMesh.visible = q > 0;
    }
    drawCrosshair030(w, h) {
        if (!this.crossIcons) this.crossIcons = loadImageAny(ICONS_PATHS);
        const im = this.crossIcons;
        if (!im.complete || !im.naturalWidth) return false;
        if (this.crossOk === undefined) {
            try {
                const c = document.createElement('canvas'); c.width = c.height = 16;
                const cx2 = c.getContext('2d'); cx2.drawImage(im, 0, 0, 16, 16, 0, 0, 16, 16);
                const d = cx2.getImageData(0, 0, 16, 16).data;
                let any = false; for (let i = 3; i < d.length; i += 4) if (d[i] > 0) { any = true; break; }
                this.crossOk = any;
            } catch { this.crossOk = true; }
        }
        if (!this.crossOk) return false;
        const gs = this.guiScale(), ctx = this.hudCtx;
        const x = (Math.floor(Math.floor(w / gs) / 2) - 7) * gs, y = (Math.floor(Math.floor(h / gs) / 2) - 7) * gs;
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(im, 0, 0, 16, 16, x, y, 16 * gs, 16 * gs);
        return true;
    }
    prepareFont(img) {
        const charW = Math.floor(img.width / 16);
        const charH = Math.floor(img.height / 16);
        const canvas = document.createElement('canvas');
        canvas.width = img.width; canvas.height = img.height;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(img, 0, 0);
        const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const whiteCanvas = document.createElement('canvas');
        whiteCanvas.width = img.width; whiteCanvas.height = img.height;
        const whiteCtx = whiteCanvas.getContext('2d');
        whiteCtx.imageSmoothingEnabled = false;
        const whiteData = whiteCtx.createImageData(canvas.width, canvas.height);
        const shadowCanvas = document.createElement('canvas');
        shadowCanvas.width = img.width; shadowCanvas.height = img.height;
        const shadowCtx = shadowCanvas.getContext('2d');
        shadowCtx.imageSmoothingEnabled = false;
        const shadowData = shadowCtx.createImageData(canvas.width, canvas.height);
        for (let i = 0; i < data.data.length; i += 4) {
            const r = data.data[i], g = data.data[i + 1], b = data.data[i + 2], a = data.data[i + 3];
            const isCyan = (r < 50 && g > 200 && b > 200);
            const isText = (a > 128) && !isCyan && (r > 100 || g > 100 || b > 100);
            if (isText) {
                whiteData.data[i] = whiteData.data[i + 1] = whiteData.data[i + 2] = 255; whiteData.data[i + 3] = 255;
                shadowData.data[i] = shadowData.data[i + 1] = shadowData.data[i + 2] = 63; shadowData.data[i + 3] = 255;
            } else {
                whiteData.data[i + 3] = 0; shadowData.data[i + 3] = 0;
            }
        }
        whiteCtx.putImageData(whiteData, 0, 0);
        shadowCtx.putImageData(shadowData, 0, 0);
        const widths = new Array(256).fill(charW);
        const pixels = whiteData.data;
        for (let c = 0; c < 256; c++) {
            const cx = (c % 16) * charW, cy = Math.floor(c / 16) * charH;
            let maxX = -1;
            for (let py = 0; py < charH; py++)
                for (let px = 0; px < charW; px++)
                    if (pixels[((cy + py) * canvas.width + (cx + px)) * 4 + 3] > 0 && px > maxX) maxX = px;
            widths[c] = maxX >= 0 ? maxX + 2 : Math.floor(charW / 2);
            if (c === 32) widths[c] = 4;
        }
        return { white: whiteCanvas, shadow: shadowCanvas, charW, charH, widths };
    }
    tintedSheet(color) {
        const fs = this.fontSheets;
        if (!fs.tints) fs.tints = {};
        if (fs.tints[color]) return fs.tints[color];
        const c = document.createElement('canvas');
        c.width = fs.white.width; c.height = fs.white.height;
        const cx = c.getContext('2d');
        cx.drawImage(fs.white, 0, 0);
        cx.globalCompositeOperation = 'source-in';
        cx.fillStyle = '#' + color.toString(16).padStart(6, '0');
        cx.fillRect(0, 0, c.width, c.height);
        fs.tints[color] = c;
        return c;
    }
    dirtPattern(gs) {
        if (!this.terrainImg) return null;
        if (this.dirtPatternCache && this.dirtPatternCache.gs === gs) return this.dirtPatternCache.pattern;
        const size = 16 * gs * 2;
        const c = document.createElement('canvas');
        c.width = size; c.height = size;
        const cx = c.getContext('2d');
        cx.imageSmoothingEnabled = false;
        const [col, row] = BLOCK_UVS[BLOCK.DIRT];
        cx.drawImage(this.terrainImg, col * 16, row * 16, 16, 16, 0, 0, size, size);
        cx.fillStyle = 'rgba(0, 0, 0, 0.75)';
        cx.fillRect(0, 0, size, size);
        const pattern = this.hudCtx.createPattern(c, 'repeat');
        this.dirtPatternCache = { gs, pattern };
        return pattern;
    }
    textWidth(text, scale) {
        if (!this.fontSheets) return 0;
        let wSum = 0;
        for (let i = 0; i < text.length; i++) wSum += this.fontSheets.widths[text.charCodeAt(i)];
        return wSum * scale;
    }
    drawTextCentered(text, cx, y, scale, color) {
        this.drawText(text, Math.floor(cx - this.textWidth(text, scale) / 2), y, scale, color);
    }
    drawText(text, x, y, scale, color) {
        if (!this.fontSheets) return;
        let white = this.fontSheets.white, shadow = this.fontSheets.shadow;
        if (color != null && color !== 0xFFFFFF) {
            white = this.tintedSheet(color);
            shadow = this.tintedSheet((color & 0xFCFCFC) >> 2);
        }
        const s = scale == null ? this.hudScale : scale;
        this.blitText(this.hudCtx, shadow, text, x + s, y + s, s);
        this.blitText(this.hudCtx, white, text, x, y, s);
    }
    blitText(ctx, sheet, text, x, y, s) {
        const { charW, charH, widths } = this.fontSheets;
        let cursor = 0;
        for (let i = 0; i < text.length; i++) {
            const code = text.charCodeAt(i);
            ctx.drawImage(sheet, (code % 16) * charW, Math.floor(code / 16) * charH, charW, charH,
                Math.floor(x + cursor * s), Math.floor(y), charW * s, charH * s);
            cursor += widths[code];
        }
    }
    renderHUD() {
        this.hudScale = this.guiScale();
        const w = this.hudCanvas.width, h = this.hudCanvas.height;
        const hudKey = [w, h, !!this.fontSheets, this.displayFps, this.displayChunkUpdates,
            this.player && !OLD_UI ? this.player.selectedSlot + ':' + this.player.inventory.join(',') : '',
            !!(this.menu && this.menuHidesHotbar)].join('|');
        const nowT = performance.now();
        const chatShowing = this.chatOpen || this.chatLines.some(l => nowT - l.time < CHAT_SHOW_SECONDS * 1000);
        const animating = this.menu || this.statusMessage || chatShowing || this.chatWasShowing || this.blind || this.wasBlind
            || this.tabHeld || this.tabWasHeld || SURVIVAL_024;
        this.tabWasHeld = this.tabHeld;
        this.wasBlind = this.blind;
        this.chatWasShowing = chatShowing;
        if (!animating && hudKey === this.lastHudKey) return;
        this.lastHudKey = animating ? null : hudKey;
        this.hudCtx.clearRect(0, 0, w, h);
        this.hudCtx.imageSmoothingEnabled = false;
        const cx = Math.floor(w / 2), cy = Math.floor(h / 2);
        if (this.statusMessage) {
            this.hudCtx.fillStyle = this.dirtPattern(this.guiScale()) || '#000000';
            this.hudCtx.fillRect(0, 0, w, h);
            if (this.fontSheets) {
                const gs = this.guiScale();
                this.drawTextCentered(this.statusMessage, cx, cy - (4 + 16) * gs, gs, 0xFFFFFF);
                if (this.loadingStage) this.drawTextCentered(this.loadingStage, cx, cy + (8 - 4) * gs, gs, 0xFFFFFF);
                if (this.loadingProgress != null) {
                    const bw = 100 * gs, bh = 2 * gs;
                    const bx = cx - bw / 2, by = cy + 16 * gs;
                    this.hudCtx.fillStyle = '#808080';
                    this.hudCtx.fillRect(bx, by, bw, bh);
                    this.hudCtx.fillStyle = '#80FF80';
                    this.hudCtx.fillRect(bx, by, Math.round(bw * Math.max(0, Math.min(1, this.loadingProgress))), bh);
                }
            }
            return;
        }
        if (this.menu === 'blocks') {
        } else if (this.menu) {
            const grad = this.hudCtx.createLinearGradient(0, 0, 0, h);
            grad.addColorStop(0, 'rgba(5, 5, 0, 0.38)');
            grad.addColorStop(1, 'rgba(48, 48, 96, 0.63)');
            this.hudCtx.fillStyle = grad;
            this.hudCtx.fillRect(0, 0, w, h);
        } else if (CLASSIC_019) {
            const u = h / 240, x = Math.round(cx), y = Math.round(cy);
            this.hudCtx.fillStyle = '#FFFFFF';
            this.hudCtx.fillRect(x, Math.round(y - 4 * u), Math.max(1, Math.round(u)), Math.round(9 * u));
            this.hudCtx.fillRect(Math.round(x - 4 * u), y, Math.round(9 * u), Math.max(1, Math.round(u)));
        } else if (!this.drawCrosshair030(w, h)) {
            const arm = 14, thick = 4;
            this.hudCtx.fillStyle = '#FFFFFF';
            this.hudCtx.fillRect(cx - arm, cy - Math.floor(thick / 2), arm * 2, thick);
            this.hudCtx.fillRect(cx - Math.floor(thick / 2), cy - arm, thick, arm * 2);
        }
        if (!this.fontSheets) return;
        const line1 = CLASSIC_0011A ? '0.0.12a_03' : SURVIVAL_024 ? '0.24_SURVIVAL_TEST_03' : CLASSIC_019 ? '0.0.19a' : VERSION;
        const line2 = `${this.displayFps} fps, ${this.displayChunkUpdates} chunk updates`;
        const lineHeight = Math.floor(this.fontSheets.charH * this.hudScale + 4);
        this.drawText(line1, 4, 4);
        if (!FOG_023 || this.showFps || CLASSIC_019) this.drawText(line2, 4, 4 + lineHeight);
        if (this.blind && !this.menu) {
            this.hudCtx.fillStyle = '#000000';
            this.hudCtx.fillRect(0, 0, w, h);
            this.drawTextCentered(this.blindText, cx, cy - Math.floor(this.fontSheets.charH * this.hudScale / 2), this.hudScale, 0xFFFFFF);
        }
        if (!this.menu) this.renderChat();
        if (this.tabHeld && this.net && !this.menu) this.renderPlayerList();
        if (this.survival && this.player) { if (!(this.menu && this.menuHidesHotbar)) { const gs = this.guiScale(); this.survival.drawHUD(this.hudCtx, gs, w / gs, h / gs); } }
        else if (this.player && !OLD_UI) this.drawCreativeHotbar(w, h);
        if (this.menu) this.renderMenu();
    }
    makeGhost(type) {
        const geo = new THREE.BoxGeometry(1.002, 1.002, 1.002);
        const a = geo.attributes.uv;
        const e = 0.0005;
        const faceNy = [0, 0, 1, -1, 0, 0];
        for (let f = 0; f < 6; f++) {
            const [u0, v0, u1, v1] = tileUV(...faceUV(type, faceNy[f]), e);
            for (let k = f * 4; k < f * 4 + 4; k++) {
                a.setXY(k, u0 + a.getX(k) * (u1 - u0), v0 + a.getY(k) * (v1 - v0));
            }
        }
        return geo;
    }
    makePlantGhost(uv) { return plantCrossGeometry(uv[0], uv[1], 0.0005, false); }
    makeNametag(text, color = 0xFFFFFF) {
        const fs = this.fontSheets, sc = 4;
        let tw = 0;
        for (let i = 0; i < text.length; i++) tw += fs.widths[text.charCodeAt(i)];
        tw -= 1;
        const pw = tw + 1, ph = fs.charH + 1;
        const c = document.createElement('canvas');
        c.width = pw * sc; c.height = ph * sc;
        const cx = c.getContext('2d');
        cx.imageSmoothingEnabled = false;
        const white = color === 0xFFFFFF ? fs.white : this.tintedSheet(color);
        const shadow = color === 0xFFFFFF ? fs.shadow : this.tintedSheet((color & 0xFCFCFC) >> 2);
        this.blitText(cx, shadow, text, sc, sc, sc);
        this.blitText(cx, white, text, 0, 0, sc);
        const tex = new THREE.CanvasTexture(c);
        tex.magFilter = tex.minFilter = THREE.NearestFilter;
        tex.colorSpace = THREE.SRGBColorSpace;
        const tag = new THREE.Mesh(
            new THREE.PlaneGeometry(pw * NAMETAG_PIXEL, ph * NAMETAG_PIXEL),
            new THREE.MeshBasicMaterial({ map: tex, transparent: true, alphaTest: 0.05, depthWrite: false, fog: false, side: THREE.FrontSide }));
        tag.renderOrder = 3;
        tag.visible = false;
        return tag;
    }
    poseHumanoid(v, st, fx, fy, fz, headYaw, pitch, dt) {
        if (st.lastX !== undefined && dt > 0) {
            const dx = fx - st.lastX, dz = fz - st.lastZ;
            const perTick = Math.sqrt(dx * dx + dz * dz) / (dt * 20);
            const target = Math.min(1, perTick * 4);
            st.limbAmount += (target - st.limbAmount) * (1 - Math.pow(1 - LIMB_EASE, dt * 20));
            st.limbPos += st.limbAmount * dt * 20 * LIMB_SPEED;
        }
        st.lastX = fx; st.lastZ = fz;
        const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));
        if (st.bodyYaw === undefined) st.bodyYaw = headYaw;
        if (dt > 0 && st.limbAmount > 0.1) st.bodyYaw += wrap(headYaw - st.bodyYaw) * (1 - Math.pow(1 - BODY_TURN_EASE, dt * 20));
        const diff = wrap(headYaw - st.bodyYaw);
        if (diff > HEAD_TURN_LIMIT) st.bodyYaw = headYaw - HEAD_TURN_LIMIT;
        if (diff < -HEAD_TURN_LIMIT) st.bodyYaw = headYaw + HEAD_TURN_LIMIT;
        v.root.position.set(fx, fy, fz);
        const t = st.limbPos, amt = st.limbAmount;
        v.body.position.y = -Math.abs(Math.sin(t * 0.6662)) * 5.0 * amt - 23.0;
        v.body.rotation.y = st.bodyYaw;
        v.parts.arm0.rotation.x = Math.sin(t * 0.6662 + Math.PI) * 2.0 * amt;
        v.parts.arm0.rotation.z = (Math.sin(t * 0.2312) + 1.0) * amt;
        v.parts.arm1.rotation.x = Math.sin(t * 0.6662) * 2.0 * amt;
        v.parts.arm1.rotation.z = (Math.sin(t * 0.2812) - 1.0) * amt;
        v.parts.leg0.rotation.x = Math.sin(t * 0.6662) * 1.4 * amt;
        v.parts.leg1.rotation.x = Math.sin(t * 0.6662 + Math.PI) * 1.4 * amt;
        v.parts.head.rotation.y = wrap(headYaw - st.bodyYaw);
        v.parts.head.rotation.x = -pitch;
        const bx = Math.floor(fx), bz = Math.floor(fz), by = Math.floor(fy + 1.2);
        const sky = this.level.isLit(bx, by, bz) ? 1.0 : SHADOW_SHADE;
        const c = shade(sky * liquidDarkness(this.level, bx, by, bz));
        v.material.color.setRGB(c, c, c);
    }
    drawCreativeHotbar(w, h) {
        if (this.menu && this.menuHidesHotbar) return;
        if (!this.guiImg) this.guiImg = loadImageAny(GUI_PATHS, () => { this.lastHudKey = null; });
        const ctx = this.hudCtx, gs = this.guiScale(), W = w / gs, H = h / gs, img = this.guiImg, p = this.player;
        ctx.imageSmoothingEnabled = false;
        if (img.complete && img.naturalWidth) {
            ctx.drawImage(img, 0, 0, 182, 22, Math.round((W / 2 - 91) * gs), Math.round((H - 22) * gs), 182 * gs, 22 * gs);
            ctx.drawImage(img, 0, 22, 24, 22, Math.round((W / 2 - 92 + p.selectedSlot * 20) * gs), Math.round((H - 23) * gs), 24 * gs, 22 * gs);
        } else {
            const x0 = Math.round((W / 2 - 91) * gs), y0 = Math.round((H - 22) * gs);
            ctx.fillStyle = 'rgba(0, 0, 0, 0.6)'; ctx.fillRect(x0, y0, 182 * gs, 22 * gs);
            ctx.fillStyle = 'rgba(140, 140, 140, 0.55)';
            for (let i = 0; i < 9; i++) ctx.fillRect(x0 + (1 + i * 20 + 2) * gs, y0 + 3 * gs, 16 * gs, 16 * gs);
            ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2 * gs;
            ctx.strokeRect(x0 + (p.selectedSlot * 20) * gs + gs, y0 + gs, 20 * gs, 20 * gs);
        }
        for (let i = 0; i < Math.min(9, p.inventory.length); i++) {
            const id = p.inventory[i];
            if (id) this.drawBlockIcon(id, (W / 2 - 80 + i * 20) * gs, (H - 11) * gs, 7 * gs);
        }
    }
    saveOption(k, v) { storeSetting('claudecraft-' + k, v ? 'on' : 'off'); }
    applySettings(values) {
        for (const k of SETTING_KEYS) if (typeof values[k] === 'string') { try { localStorage.setItem(k, values[k]); } catch {  } }
        const on = (k, d) => typeof values['claudecraft-' + k] === 'string' ? values['claudecraft-' + k] === 'on' : d;
        this.showFps = on('showfps', this.showFps);
        this.invertMouse = on('invert', this.invertMouse);
        this.viewBobbing = on('bobbing', this.viewBobbing);
        if (this.sounds) this.sounds.enabled = on('sound', this.sounds.enabled);
        const music = on('music', this.music.enabled);
        if (music !== this.music.enabled && !CLASSIC_0011A) { this.music.enabled = music; if (!music) this.music.stop(); else if (this.music.ctx) this.music.nextAt = this.music.ctx.currentTime + 2; }
        if (values['claudecraft-maxfps']) this.uncapped = values['claudecraft-maxfps'] === 'unlimited';
        if (values['claudecraft-render']) this.useRenderSetting(values['claudecraft-render'], false);
        this.lastHudKey = null;
    }
    useRenderSetting(name, save = true) {
        for (let i = 0; i < RENDER_DISTANCES.length && RENDER_DISTANCES[this.renderSetting].name !== name; i++) this.cycleRenderDistance(save);
    }
    loadOption(k, dflt) { try { const v = localStorage.getItem('claudecraft-' + k); return v ? v === 'on' : dflt; } catch { return dflt; } }
    tickLiquidFX() {
        const cv = this.terrainCanvas, tex = this.terrainTex;
        if (!cv || CLASSIC_0011A || !tex) return;
        const ts = cv.width / 16;
        if (!this.liquidFX) {
            const square = n => { const t = new THREE.DataTexture(new Uint8Array(n * n * 4), n, n, THREE.RGBAFormat); t.needsUpdate = true; return t; };
            this.liquidFX = [[new WaterFX023(), WATER_UV, square(ts)], [new LavaFX023(), LAVA_UV, square(ts)]];
            this.edgeWaterSquare = square(16);
            this.fxPos = new THREE.Vector2();
        }
        if (!this.renderer.properties.get(tex).__webglTexture) return;
        for (const [fx, [u, v], sq] of this.liquidFX) {
            fx.tick();
            const d = sq.image.data;
            if (ts === 16) d.set(fx.px);
            else for (let y = 0; y < ts; y++) for (let x = 0; x < ts; x++) {
                const s0 = ((Math.floor(y * 16 / ts) << 4) + Math.floor(x * 16 / ts)) * 4, o = (y * ts + x) * 4;
                d[o] = fx.px[s0]; d[o + 1] = fx.px[s0 + 1]; d[o + 2] = fx.px[s0 + 2]; d[o + 3] = fx.px[s0 + 3];
            }
            this.fxPos.set(u * ts, cv.height - (v + 1) * ts);
            this.renderer.copyTextureToTexture(this.fxPos, sq, tex);
            if (fx instanceof WaterFX023 && this.outerTextures && this.renderer.properties.get(this.outerTextures[0]).__webglTexture) {
                this.edgeWaterSquare.image.data.set(fx.px);
                this.fxPos.set(0, 0);
                this.renderer.copyTextureToTexture(this.fxPos, this.edgeWaterSquare, this.outerTextures[0]);
            }
        }
    }
    updateSkyPlane() {
        const lv = this.level;
        if (!this.skyPlane) {
            this.skyPlane = new THREE.Mesh(new THREE.PlaneGeometry(1, 1, 8, 8), new THREE.MeshBasicMaterial({ color: SKY_COLOR, fog: true, side: THREE.FrontSide, depthWrite: false }));
            this.skyPlane.rotation.x = Math.PI / 2;
            this.skyPlane.renderOrder = -10;
            this.scene.add(this.skyPlane);
        }
        if (this.skyPlaneFor !== lv) {
            this.skyPlaneFor = lv;
            this.skyPlane.scale.set(lv.width + 4096, lv.height + 4096, 1);
            this.skyPlane.position.set(lv.width / 2, CLOUD_Y + 8, lv.height / 2);
        }
    }
    buildClassicOuter(waterTex) {
        const SEABED_LIGHT = [1.45, 1.0, 0.7];
        const lv = this.level;
        if (!lv || !this.rockTex) return;
        if (this.outerWorld) { this.scene.remove(this.outerWorld); this.outerWorld.traverse(o => { if (o.geometry) o.geometry.dispose(); }); }
        const W = lv.width, H = lv.height, F = 640, R = 30, group = new THREE.Group();
        const quads = (list, dark) => {
            const p = [], u = [], c = [], i = [], k = [];
            for (const [corners, light] of list) {
                const b = p.length / 3, lc = Array.isArray(light) ? light.map(shade) : [shade(light), shade(light), shade(light)];
                for (const [x, y, z, uu, vv] of corners) { p.push(x, y, z); u.push(uu, vv); c.push(...lc); k.push(dark); }
                i.push(b, b + 1, b + 2, b, b + 2, b + 3);
            }
            return makeGeometry(p, u, c, i, k);
        };
        const flat = (x0, z0, x1, z1, y, l = 0.6) => [[[x0, y, z0, x0, z0], [x1, y, z0, x1, z0], [x1, y, z1, x1, z1], [x0, y, z1, x0, z1]], l];
        const outside = y => [flat(-F, -F, W + F, 0, y), flat(-F, H, W + F, H + F, y), flat(-F, 0, 0, H, y), flat(W, 0, W + F, H, y)];
        const rockMat = new THREE.MeshBasicMaterial({ map: this.rockTex, vertexColors: true, side: THREE.DoubleSide });
        classic012Shader(rockMat);
        const floor = [...outside(R).map(([c]) => [c, SEABED_LIGHT]), flat(0, 0, W, H, 0)];
        const walls = [
            [[[0, 0, 0, 0, 0], [W, 0, 0, W, 0], [W, R, 0, W, R], [0, R, 0, 0, R]], 0.48], [[[0, 0, H, 0, 0], [W, 0, H, W, 0], [W, R, H, W, R], [0, R, H, 0, R]], 0.48],
            [[[0, 0, 0, 0, 0], [0, 0, H, H, 0], [0, R, H, H, R], [0, R, 0, 0, R]], 0.36], [[[W, 0, 0, 0, 0], [W, 0, H, H, 0], [W, R, H, H, R], [W, R, 0, 0, R]], 0.36]];
        group.add(new THREE.Mesh(quads([...floor, ...walls], 0), rockMat));
        const waterMat = new THREE.MeshBasicMaterial({ map: waterTex, vertexColors: true, transparent: true, depthWrite: false, side: THREE.DoubleSide });
        classic012Shader(waterMat);
        const sea = new THREE.Mesh(quads(outside(31.9).map(([c]) => [c, 1]), 0), waterMat);
        sea.renderOrder = 1;
        group.add(sea);
        this.outerWorld = group;
        this.scene.add(group);
    }
    ghostGeo(id) {
        if (!this.ghostGeos[id]) this.ghostGeos[id] = isPlant(id) ? this.makePlantGhost(BLOCK_UVS[id] || [2, 0]) : this.makeGhost(id);
        return this.ghostGeos[id];
    }
    poseDead(v, t) {
        if (t == null) { if (v.root.rotation.z) v.root.rotation.z = 0; return; }
        v.root.rotation.order = 'YXZ';
        v.root.rotation.z = Math.min(90, t * t * 800) * Math.PI / 180;
    }
    startSwing(now = performance.now()) {
        this.armSwingAt = now;
        if (this.survival) this.sendNet({ t: 'swing' });
    }
    poseHeld(v, type, swingAt, now) {
        const arm = v.parts.arm1;
        if (!v.heldMesh) {
            if (!this.heldGeos) this.heldGeos = { itemGeos: {} };
            v.heldMat = new THREE.MeshBasicMaterial({ map: this.solidMaterial.map, alphaTest: 0.1, side: THREE.DoubleSide });
            v.heldMesh = new THREE.Mesh(new THREE.BufferGeometry(), v.heldMat);
            v.heldMesh.position.set(1, 11, -2.5);
            v.heldMesh.rotation.set(Math.PI, Math.PI / 4, 0);
            v.heldMesh.scale.setScalar(1.0 / ZOMBIE_SIZE);
            arm.add(v.heldMesh);
            v.heldType = -1;
        }
        const holding = type != null && type !== BLOCK.AIR;
        if (holding && type !== v.heldType) {
            v.heldType = type;
            v.heldMesh.geometry = Survival024.prototype.itemGeo.call(this.heldGeos, type, isPlant(type));
        }
        v.heldMesh.visible = holding;
        v.heldMat.color.copy(v.material.color);
        if (holding) arm.rotation.x = arm.rotation.x * 0.5 - Math.PI / 10;
        const t = swingAt ? (now - swingAt) / 350 : 1;
        if (t >= 0 && t < 1) {
            const ease = Math.sin((1 - Math.pow(1 - t, 4)) * Math.PI);
            const aim = Math.sin(t * Math.PI) * -(v.parts.head.rotation.x - 0.7) * 0.75;
            arm.rotation.x -= ease * 1.2 + aim;
            arm.rotation.y = -Math.sin(Math.sqrt(t) * Math.PI * 2) * 0.4;
            arm.rotation.z -= Math.sin(t * Math.PI) * 0.4;
        } else arm.rotation.y = 0;
    }
    updateThirdPerson(eye, now) {
        const dt = this.lastAnimTime ? Math.min(0.25, (now - this.lastAnimTime) / 1000) : 0;
        this.lastAnimTime = now;
        const p = this.player.position;
        this.poseHumanoid(this.playerView, this.localAnim, p.x, p.y - PLAYER_HEIGHT, p.z, this.player.rotation.y, this.player.rotation.x, dt);
        const held = this.buttonsHeld && (this.buttonsHeld[0] || this.buttonsHeld[2]) && this.pointerLocked && !this.menu;
        if (this.buttonsHeld && (!this.pointerLocked || this.menu)) this.buttonsHeld[0] = this.buttonsHeld[2] = false;
        if (held && now - (this.armSwingAt || 0) >= 350) this.startSwing(now);
        if (this.survival) this.poseHeld(this.playerView, this.player.getSelectedBlock(), this.armSwingAt, now);
        const pl = this.player;
        this.poseDead(this.playerView, this.survival && pl.health <= 0 ? (pl.deathTime + Math.min(1, this.tickAccumulator / MS_PER_TICK)) / 20 : null);
        this.playerView.root.visible = this.thirdPerson;
        if (!this.thirdPerson) return;
        const dir = this.player.getLookDirection();
        let dist = THIRD_PERSON_DISTANCE;
        for (let d = 0.1; d <= THIRD_PERSON_DISTANCE; d += 0.1) {
            const px = eye.x - dir.x * d, py = eye.y - dir.y * d, pz = eye.z - dir.z * d;
            if (this.level.isSolidTile(Math.floor(px), Math.floor(py), Math.floor(pz))) { dist = Math.max(0, d - 0.3); break; }
        }
        this.camera.position.set(eye.x - dir.x * dist, eye.y - dir.y * dist, eye.z - dir.z * dist);
    }
    updateAutoJoin(now) {
        if (!this.autoJoin) return;
        const skinReady = !this.waitForSkin || this.mySkin || now > this.skinWaitUntil;
        const readyToJoin = this.autoJoin && skinReady && (!this.statusMessage || this.autoJoinNoLevel) && !this.net && !this.netPending;
        if (readyToJoin && !this.loggedIn) {
            this.autoJoin = null;
            if (this.autoJoinNoLevel) { this.joinFailedNoLevel('Log in to join servers', 'Log in on the Claudecraft website first'); return; }
            this.openMenu('join');
            this.joinMessage = 'Log in to join servers';
            this.joinHint = 'Log in on the Claudecraft website first';
        }
        if (readyToJoin && this.autoJoin) {
            this.serverAddress = this.autoJoin.slice(0, SERVER_ADDRESS_MAX);
            this.autoJoin = null;
            this.joinMessage = null;
            if (!this.autoJoinNoLevel) this.openMenu('join');
            this.joinServer();
        }
    }
    joinFailedNoLevel(message, hint) {
        this.autoJoinNoLevel = false;
        this.statusMessage = null; this.loadingStage = null;
        this.generateLevel(LEVEL_SIZES.find(sz => sz.label === 'Normal'), false, { done: () => {
            this.openMenu('join');
            this.joinMessage = message || 'Couldn\'t connect to the server';
            this.joinHint = hint || null;
        } });
    }
    joinServer() {
        this.joinAddress = this.serverAddressToUrl(this.serverAddress);
        const addr = this.joinAddress;
        this.joinHint = null;
        const securePage = typeof location !== 'undefined' && location.protocol === 'https:';
        const plain = /^ws:\/\//i.test(addr) && !/^ws:\/\/(localhost|127\.0\.0\.1|\[::1\])(:|\/|$)/i.test(addr);
        if (securePage && plain) {
            this.joinMessage = 'Use the https:// tunnel link';
            this.joinHint = 'Secure websites can\'t join plain IP addresses';
            return;
        }
        if (this.netPending) this.netPending.close();
        this.leaveServer();
        let ws;
        try { ws = new WebSocket(addr); } catch (err) { this.joinMessage = 'That address isn\'t valid'; return; }
        this.joinMessage = 'Connecting..';
        this.netPending = ws;
        ws.binaryType = 'arraybuffer';
        ws.onopen = () => ws.send(JSON.stringify({ t: 'hello', name: this.playerName, skin: this.mySkin || undefined,
            version: CLASSIC_019 ? '0.0.19a' : undefined }));
        ws.onmessage = ev => this.onNetMessage(ws, ev.data);
        ws.onclose = () => this.onNetClose(ws);
        ws.onerror = () => { if (ws === this.netPending) this.joinMessage = 'Couldn\'t connect to the server'; };
    }
    playAsGuest() {
        this.playerAsGuestName();
        this.joinMessage = null;
        this.openMenu('join');
    }
    readJoinLink() {
        if (typeof location === 'undefined' || !location.search) return;
        const q = new URLSearchParams(location.search);
        if (!q.has('join')) return;
        this.autoJoin = q.get('join') || location.origin;
        const name = q.get('name');
        this.loggedIn = !!(name && /^[A-Za-z0-9_]{2,16}$/.test(name));
        if (this.loggedIn) { this.playerName = name; this.signedIn = true; this.isGuest = false; }
        else this.playerAsGuestName();
        this.waitForSkin = q.has('skin');
    }
    playerAsGuestName() {
        if (!this.isGuest) this.playerName = 'Guest' + Math.floor(100 + Math.random() * 900);
        this.isGuest = true;
    }
    setMySkin(dataUrl) {
        this.mySkin = dataUrl;
        this.playerView.material.map = makeSkinTexture(dataUrl);
        this.playerView.material.needsUpdate = true;
        this.sendNet({ t: 'skin', skin: dataUrl });
    }
    openChat() {
        this.chatOpen = true;
        this.chatInput = '';
        for (const k in this.input) this.input[k] = false;
    }
    closeChat() { this.chatOpen = false; this.chatInput = ''; }
    addChat(text, color) {
        this.chatLines.push({ text: text.slice(0, 120), color: typeof color === 'number' ? color : 0xFFFFFF, time: performance.now() });
        if (this.chatLines.length > CHAT_HISTORY) this.chatLines.shift();
    }
    handleChatKey(e) {
        if ((e.ctrlKey || e.metaKey) && e.code === 'KeyV') return;
        e.preventDefault();
        if (e.code === 'Escape') { this.closeChat(); return; }
        if (e.code === 'Enter') {
            const text = this.chatInput.trim();
            if (text) this.sendNet({ t: 'chat', text });
            this.closeChat();
            return;
        }
        if (e.code === 'Backspace') { this.chatInput = this.chatInput.slice(0, -1); return; }
        if (!e.ctrlKey && !e.metaKey && e.key.length === 1 && e.key >= ' ' && e.key <= '~' && this.chatInput.length < CHAT_MAX) this.chatInput += e.key;
    }
    renderChat() {
        const ctx = this.hudCtx, s = this.hudScale, fs = this.fontSheets;
        const lineH = fs.charH * s + 2 * s;
        const h = this.hudCanvas.height;
        let y = h - (SURVIVAL_024 ? 44 : CLASSIC_0011A ? 4 : CLASSIC_019 ? 14 : 26) * s - lineH;
        if (this.chatOpen) {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
            ctx.fillRect(2 * s, y - s, this.hudCanvas.width - 4 * s, lineH);
            const cursor = Math.floor(performance.now() / 300) % 2 === 0 ? '_' : '';
            let shown = this.chatInput;
            const room = this.hudCanvas.width - 12 * s - this.textWidth('> _', s);
            while (shown.length > 0 && this.textWidth(shown, s) > room) shown = shown.slice(1);
            this.drawText('> ' + shown + cursor, 4 * s, y, s, 0xE0E0E0);
            y -= lineH + 2 * s;
        }
        const now = performance.now();
        const shown = this.chatOpen ? this.chatLines.slice(-CHAT_LINES_OPEN)
            : this.chatLines.filter(l => now - l.time < CHAT_SHOW_SECONDS * 1000).slice(-10);
        const maxW = Math.min(CHAT_WIDTH * s, this.hudCanvas.width - 12 * s);
        for (let i = shown.length - 1; i >= 0 && y > lineH * 3; i--) {
            const rows = this.wrapText(shown[i].text, maxW, s);
            for (let r = rows.length - 1; r >= 0 && y > lineH * 3; r--) {
                ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
                ctx.fillRect(2 * s, y - s, this.textWidth(rows[r], s) + 4 * s, lineH);
                this.drawText(rows[r], 4 * s, y, s, shown[i].color);
                y -= lineH;
            }
        }
    }
    wrapText(text, maxW, s) {
        const rows = [];
        let line = '';
        for (const word of String(text).split(' ')) {
            const tryLine = line ? line + ' ' + word : word;
            if (this.textWidth(tryLine, s) <= maxW) { line = tryLine; continue; }
            if (line) rows.push(line);
            line = word;
            while (this.textWidth(line, s) > maxW && line.length > 1) {
                let cut = line.length - 1;
                while (cut > 1 && this.textWidth(line.slice(0, cut), s) > maxW) cut--;
                rows.push(line.slice(0, cut));
                line = line.slice(cut);
            }
        }
        if (line || !rows.length) rows.push(line);
        return rows;
    }
    serverAddressToUrl(typed) {
        let addr = typed.trim().replace(/\/+$/, '');
        if (/^https?:\/\//i.test(addr)) addr = addr.replace(/^http/i, 'ws');
        else if (!/^wss?:\/\//i.test(addr)) {
            const host = addr.split('/')[0];
            addr = (/\.trycloudflare\.com$/i.test(host) ? 'wss://' : 'ws://') + addr;
        }
        if (/^ws:\/\//i.test(addr) && !/^ws:\/\/[^/]*:\d+/i.test(addr)) addr = addr.replace(/^(ws:\/\/[^/]*)/i, '$1:' + DEFAULT_PORT);
        return addr;
    }
    sendNet(msg) { if (this.net && this.net.readyState === 1) this.net.send(JSON.stringify(msg)); }
    onNetMessage(ws, data) {
        if (typeof data !== 'string') {
            if (ws === this.net && this.changingLevel) {
                const spawn = this.changingLevel.spawn;
                this.loadingProgress = 0.7;
                decodeLevel(new Blob([data])).then(level => {
                    if (ws !== this.net) return;
                    level.savedPlayer = spawn;
                    this.loadingProgress = 1;
                    const respawn = this.changingLevel && this.changingLevel.respawn;
                    const name = this.changingLevel ? this.changingLevel.name : '';
                    this.loadLevel(level);
                    this.netLevelName = name;
                    const home = this.visitHomes && this.visitHomes[name];
                    if (home || respawn) this.spawnPoint = home || respawn;
                    this.ownSpawn = !!home;
                    this.applyExtraBlocks();
                }).catch(err => {
                    console.error('Bad level from server:', err);
                    this.addChat('That level couldn\'t be loaded', 0xFF5555);
                }).finally(() => { this.changingLevel = null; this.statusMessage = null; this.loadingStage = null; this.loadingProgress = null; });
                return;
            }
            if (ws !== this.netPending) return;
            if (!this.statusMessage) this.statusMessage = 'Loading level..';
            this.loadingProgress = 0.7;
            decodeLevel(new Blob([data])).then(level => {
                this.loadingProgress = 1;
                if (ws !== this.netPending) return;
                level.savedPlayer = this.netSpawn;
                this.net = ws; this.netPending = null;
                this.loadLevel(level);
                if (this.netRespawn) this.spawnPoint = this.netRespawn;
                this.applyExtraBlocks();
                this.closeMenu();
            }).catch(err => {
                console.error('Bad level from server:', err);
                this.joinMessage = 'The server sent a bad level';
                ws.close();
            }).finally(() => { this.statusMessage = null; this.loadingStage = null; this.loadingProgress = null; });
            return;
        }
        let m;
        try { m = JSON.parse(data); } catch { return; }
        if (m.t === 'welcome') {
            this.netId = m.id; this.netSpawn = m.spawn; this.joinMessage = 'Downloading level..';
            this.netRespawn = m.respawn || null;
            this.netLevelName = String(m.level || '');
            this.netMinigame = !!m.minigame;
            this.visitHomes = {};
            this.statusMessage = String(m.serverName || 'Loading level..').replace(/[^\x20-\x7E]/g, '').slice(0, 40);
            this.loadingStage = String(m.description || '').replace(/[^\x20-\x7E]/g, '').slice(0, 120) || null;
            this.loadingProgress = 0.2;
            this.serverHasChat = Array.isArray(m.features) && m.features.includes('chat');
            this.serverBuild = m.building !== false;
            this.serverLiquids = !!m.liquids;
            this.extraBlocks = Array.isArray(m.extraBlocks) ? m.extraBlocks.filter(b => EXTRA_BLOCKS.includes(b))
                : this.serverLiquids ? LIQUID_BLOCKS.slice() : [];
            this.hideNametags = !!m.hideNametags;
            if (!this.serverHasChat) this.addChat(OLD_SERVER_WARNING, 0xFFFF55);
        }
        else if (m.t === 'players') m.list.forEach(p => this.addRemotePlayer(p));
        else if (m.t === 'join') this.addRemotePlayer(m);
        else if (m.t === 'leave') this.removeRemotePlayer(m.id);
        else if (m.t === 'move') {
            const r = this.remotePlayers.get(m.id);
            if (r) Object.assign(r.target, { x: m.x, y: m.y, z: m.z, rx: m.rx, ry: m.ry });
        } else if (m.t === 'set') {
            if (ws !== this.net || !this.level) return;
            if (this.netChanges.length) this.netChanges.push(m.x, m.y, m.z, m.b);
            else this.level.setTile(m.x, m.y, m.z, m.b, true);
        } else if (m.t === 'sets' && Array.isArray(m.list)) {
            if (ws !== this.net || !this.level) return;
            for (const v of m.list) this.netChanges.push(v);
        } else if (m.t === 'changeLevel') {
            const name = String(m.name || 'level').replace(/[^\x20-\x7E]/g, '').slice(0, 40);
            this.changingLevel = { name, spawn: m.spawn, respawn: m.respawn || null };
            this.netChanges = []; this.netChangesHead = 0;
            this.clearRemotePlayers();
            this.statusMessage = 'Going to ' + name;
            this.loadingStage = null;
            this.loadingProgress = 0.3;
            if (this.pointerLocked) document.exitPointerLock();
        } else if (m.t === 'extraBlocks' && Array.isArray(m.list)) {
            this.extraBlocks = m.list.filter(b => EXTRA_BLOCKS.includes(b));
            this.applyExtraBlocks();
        } else if (m.t === 'rank') {
            const r = this.remotePlayers.get(m.id);
            if (r && Number.isInteger(m.tagColor)) {
                r.tagColor = m.tagColor;
                if (r.tag) { this.scene.remove(r.tag); r.tag.material.map.dispose(); r.tag.material.dispose(); r.tag.geometry.dispose(); r.tag = null; }
            }
        } else if (m.t === 'levelRules') {
            this.serverBuild = !!m.building;
            this.hideNametags = !!m.hideNametags;
            if ('minigame' in m) this.netMinigame = !!m.minigame;
            if (!this.frozen) this.blind = false;
        } else if (m.t === 'canBuild') {
            this.serverBuild = !!m.on;
        } else if (m.t === 'teleport') {
            if (this.player && [m.x, m.y, m.z].every(Number.isFinite)) {
                this.player.position.set(m.x, m.y, m.z);
                this.player.velocity.set(0, 0, 0);
                if (Number.isFinite(m.rx)) this.player.rotation.x = m.rx;
                if (Number.isFinite(m.ry)) this.player.rotation.y = m.ry;
            } else if (Number.isFinite(m.x)) {
                this.netSpawn = { x: m.x, y: m.y, z: m.z, rotX: m.rx || 0, rotY: m.ry || 0 };
            }
        } else if (m.t === 'freeze') {
            this.frozen = !!m.on;
            this.blind = !!(m.on && m.blind);
            this.blindText = String(m.text || '');
            if (this.frozen) for (const k in this.input) this.input[k] = false;
        } else if (m.t === 'switchVersion') {
            if (typeof location === 'undefined') return;
            const q = new URLSearchParams(location.search);
            if (m.version) q.set('version', String(m.version).replace(/[^0-9a-z._]/gi, '')); else q.delete('version');
            this.statusMessage = 'Switching to ' + (m.version || VERSION) + '..';
            this.loadingStage = null; this.loadingProgress = null;
            if (this.pointerLocked) document.exitPointerLock();
            setTimeout(() => location.replace(location.pathname + '?' + q.toString()), 300);
        } else if (m.t === 'fly') {
            this.flyOn = !!m.on;
        } else if (m.t === 'setSpawn') {
            if ([m.x, m.y, m.z].every(Number.isFinite) && !this.ownSpawn)
                this.spawnPoint = { x: m.x, y: m.y, z: m.z, rotX: Number(m.rx) || 0, rotY: Number(m.ry) || 0 };
        } else if (m.t === 'held') {
            const r = this.remotePlayers.get(m.id);
            if (r) r.held = (Number.isInteger(m.b) && BLOCK_UVS[m.b] !== undefined) || m.b === BLOCK.GRASS ? m.b : 0;
        } else if (m.t === 'swing') {
            const r = this.remotePlayers.get(m.id);
            if (r) r.swingAt = performance.now();
        } else if (m.t === 'drop' || m.t === 'claim' || m.t === 'taken') {
            if (this.survival && this.net && this.net.isLobby) this.survival.netItem(m);
        } else if (this.survival && this.net && this.net.isLobby && ['mobs', 'hitmob', 'score', 'arrow', 'boom'].includes(m.t)) {
            const sv = this.survival;
            if (m.t === 'mobs' && Array.isArray(m.list)) sv.netMobs(m.list);
            else if (m.t === 'hitmob' && this.lobby.isHost) sv.netHitMob(m.id, m.mob, m.dmg, Number(m.x), Number(m.z));
            else if (m.t === 'score' && m.target === this.netId && this.player) this.player.score = (this.player.score || 0) + Math.max(0, Math.min(250, m.add | 0));
            else if (m.t === 'arrow') sv.arrows.push(new Arrow024(sv, {}, +m.x, +m.y, +m.z, +m.yRot, +m.xRot, Math.min(2, +m.speed || 1)));
            else if (m.t === 'boom') sv.boomParticles(+m.x, +m.y, +m.z, Math.min(8, +m.r || 4));
        } else if (m.t === 'pvp') {
            if (m.target !== this.netId || !this.survival || !this.player || this.player.health <= 0) return;
            const dmg = Math.max(1, Math.min(7, Number(m.dmg) || 4)), p = this.player;
            this.survival.hurt(p, { x: Number(m.x) || p.position.x, z: Number(m.z) || p.position.z }, dmg);
            if (p.health <= 0) this.sendNet({ t: 'chat', text: '', killed: String(m.by || 'someone').slice(0, 24) });
        } else if (m.t === 'dead') {
            const r = this.remotePlayers.get(m.id);
            if (r) r.deadAt = m.on ? performance.now() : null;
        } else if (m.t === 'skin') {
            const r = this.remotePlayers.get(m.id);
            if (r) { r.view.material.map = isSkinData(m.skin) ? makeSkinTexture(m.skin) : this.mobMaterial.map; r.view.material.needsUpdate = true; }
        } else if (m.t === 'chat') {
            this.addChat(String(m.text || ''), m.color);
        } else if (m.t === 'kick') {
            this.joinMessage = m.reason || 'Kicked from the server';
        }
    }
    onNetClose(ws) {
        if (ws === this.netPending) {
            this.netPending = null;
            if (this.joinMessage === 'Connecting..' || this.joinMessage === 'Downloading level..') {
                this.joinMessage = 'Couldn\'t connect to the server';
                this.joinHint = 'Is the server running? Check the address';
            }
            if (this.autoJoinNoLevel && !this.level) this.joinFailedNoLevel(this.joinMessage, this.joinHint);
        }
        if (ws === this.net) {
            this.net = null;
            this.changingLevel = null;
            this.netChanges = []; this.netChangesHead = 0;
            this.clearRemotePlayers();
            this.closeChat();
            this.resetServerRules();
            this.addChat('Disconnected from the server', 0xFFFF55);
            if (this.pointerLocked) document.exitPointerLock();
            this.disconnectToNewLevel(false);
        }
    }
    disconnectToNewLevel(lockMouse = true) {
        this.leaveServer();
        this.generateLevel(LEVEL_SIZES.find(sz => sz.label === 'Normal'), lockMouse);
    }
    resetServerRules() {
        this.serverLiquids = false;
        this.extraBlocks = [];
        if (this.player) { this.player.inventory = HOTBAR.slice(); this.player.selectedSlot = Math.min(this.player.selectedSlot, HOTBAR.length - 1); }
        this.frozen = false; this.blind = false; this.blindText = '';
        this.serverBuild = true; this.hideNametags = false;
    }
    leaveServer() {
        this.resetServerRules();
        const ws = this.net;
        this.net = null;
        if (ws) ws.close();
        this.clearRemotePlayers();
        this.closeChat();
    }
    addRemotePlayer(p) {
        if (p.id === this.netId || this.remotePlayers.has(p.id)) return;
        const view = this.zombieModel.create();
        this.scene.add(view.root);
        if (isSkinData(p.skin)) { view.material.map = makeSkinTexture(p.skin); view.material.needsUpdate = true; }
        const r = { id: p.id, name: String(p.name || 'Player'), owner: !!p.owner, view, tag: null,
            tagColor: Number.isInteger(p.tagColor) ? p.tagColor : p.owner ? OWNER_TAG_COLOR : 0xFFFFFF,
            pos: { x: p.x, y: p.y, z: p.z, rx: p.rx || 0, ry: p.ry || 0 },
            target: { x: p.x, y: p.y, z: p.z, rx: p.rx || 0, ry: p.ry || 0 },
            anim: { limbAmount: 0, limbPos: 0 } };
        this.remotePlayers.set(p.id, r);
    }
    removeRemotePlayer(id) {
        const r = this.remotePlayers.get(id);
        if (!r) return;
        this.scene.remove(r.view.root);
        if (r.tag) { this.scene.remove(r.tag); r.tag.material.map.dispose(); r.tag.material.dispose(); r.tag.geometry.dispose(); }
        this.remotePlayers.delete(id);
    }
    clearRemotePlayers() { for (const id of [...this.remotePlayers.keys()]) this.removeRemotePlayer(id); }
    updateNetwork(now, dt) {
        this.updateAutoJoin(now);
        if (this.net && this.player && this.survival) {
            const held = this.player.getSelectedBlock() || 0;
            if (held !== this.heldSent || now - (this.heldSentAt || 0) > 5000) { this.heldSent = held; this.heldSentAt = now; this.sendNet({ t: 'held', b: held }); }
        }
        if (this.net && this.flyOn && this.shiftHeld && !this.menu && !this.chatOpen && now - (this.flyDownSent || 0) >= 250) {
            this.flyDownSent = now; this.sendNet({ t: 'flyDown' });
        }
        if (this.net && now - this.lastNetSend >= NET_SEND_MS) {
            this.lastNetSend = now;
            const p = this.player.position;
            this.sendNet({ t: 'move', x: p.x, y: p.y, z: p.z, rx: this.player.rotation.x, ry: this.player.rotation.y });
        }
        const follow = 1 - Math.pow(0.001, dt);
        const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));
        for (const r of this.remotePlayers.values()) {
            const c = r.pos, tg = r.target;
            c.x += (tg.x - c.x) * follow; c.y += (tg.y - c.y) * follow; c.z += (tg.z - c.z) * follow;
            c.rx += (tg.rx - c.rx) * follow; c.ry += wrap(tg.ry - c.ry) * follow;
            this.poseHumanoid(r.view, r.anim, c.x, c.y - PLAYER_HEIGHT, c.z, c.ry, c.rx, dt);
            if (this.survival) this.poseHeld(r.view, r.held || 0, r.swingAt, now);
            this.poseDead(r.view, r.deadAt ? (now - r.deadAt) / 1000 : null);
            if (!r.tag && this.fontSheets) { r.tag = this.makeNametag(r.name, r.tagColor); this.scene.add(r.tag); }
            if (r.tag && this.hideNametags) { r.tag.visible = false; continue; }
            if (r.tag) {
                r.tag.position.set(c.x, c.y - PLAYER_HEIGHT + 2.3, c.z);
                r.tag.rotation.set(0, this.camera.rotation.y, 0);
                r.tag.visible = true;
            }
        }
    }
    spawnZombie() {
        if (this.net) return;
        const p = this.player.position;
        const zb = new Zombie(this.level, this.zombieModel, p.x, p.y, p.z);
        this.zombies.push(zb);
        this.scene.add(zb.view.root);
    }
    cycleRenderDistance(save = true) {
        this.renderSetting = (this.renderSetting + 1) % RENDER_DISTANCES.length;
        const rs = RENDER_DISTANCES[this.renderSetting];
        if (CLASSIC_0011A) {
            this.renderDistance = [1024, 128, 64, 32][this.renderSetting];
            C12.fogNear.value = this.renderSetting === 0 ? 0 : this.renderDistance * 0.6;
            C12.fogFar.value = this.renderSetting === 0 ? 0 : this.renderDistance;
            this.queueStale = true;
            if (save) storeSetting('claudecraft-render', rs.name);
            return;
        }
        this.renderDistance = rs.dist;
        this.airFog.near = rs.fogStart;
        this.airFog.far = rs.fogEnd;
        if (this.airFog.isFogExp2) this.airFog.density = this.renderSetting === 0 ? 0.0028 : 2.15 / rs.fogEnd;
        if (FOG_023) this.airFog.color.setHex(rs.fogColor);
        this.skyColor.set(SKY_COLOR).lerp(new THREE.Color(CLASSIC_0011A ? 0xFEFBFA : FOG_023 ? rs.fogColor : FOG_COLOR), rs.skyFog * (CLASSIC_0011A ? [0, 0.55, 0.85, 1][this.renderSetting] : 1));
        this.queueStale = true;
        if (save) storeSetting('claudecraft-render', rs.name);
        if (SANDBOX && save && rs.fogColor != null) {
            Sandbox.s.render.viewDistance = rs.fogEnd; Sandbox.s.render.fogColor = '#' + new THREE.Color(rs.fogColor).getHexString();
            Sandbox.save(); if (this.sandboxPanel) this.sandboxPanel.refresh();
        }
    }
    sectionKey(cx, cy, cz) { return cx + ',' + cy + ',' + cz; }
    chunkColumnTop(cx, cz) {
        const k = cx + ',' + cz;
        let top = this.columnTops.get(k);
        if (top !== undefined) return top;
        top = -1;
        const lv = this.level, blocks = lv.blocks, layer = lv.width * lv.height;
        for (let lx = 0; lx < CHUNK_SIZE; lx++) {
            const x = cx * CHUNK_SIZE + lx;
            if (x >= lv.width) break;
            for (let lz = 0; lz < CHUNK_SIZE; lz++) {
                const z = cz * CHUNK_SIZE + lz;
                if (z >= lv.height) break;
                const base = z * lv.width + x;
                for (let y = lv.depth - 1; y > top; y--) {
                    if (blocks[y * layer + base] !== BLOCK.AIR) { top = y; break; }
                }
            }
        }
        this.columnTops.set(k, top);
        return top;
    }
    chunkDistance(cx, cz) {
        if (CLASSIC_0011A) {
            const p = this.player.position, x0 = cx * CHUNK_SIZE, z0 = cz * CHUNK_SIZE;
            const dx = Math.max(x0 - p.x, 0, p.x - (x0 + CHUNK_SIZE)), dz = Math.max(z0 - p.z, 0, p.z - (z0 + CHUNK_SIZE));
            return Math.sqrt(dx * dx + dz * dz);
        }
        const dx = cx * CHUNK_SIZE + CHUNK_SIZE / 2 - this.player.position.x;
        const dz = cz * CHUNK_SIZE + CHUNK_SIZE / 2 - this.player.position.z;
        return Math.sqrt(dx * dx + dz * dz);
    }
    applyNetChanges(budgetMs = NET_APPLY_MS) {
        const L = this.netChanges;
        if (!L.length) return;
        const start = performance.now();
        let h = this.netChangesHead;
        this.bulkChanges = true;
        try {
            while (h + 3 < L.length) {
                const x = L[h], y = L[h + 1], z = L[h + 2], b = L[h + 3];
                h += 4;
                if ([x, y, z, b].every(Number.isInteger) && b >= 0 && b <= 63 &&
                    x >= 0 && y >= 0 && z >= 0 && x < MAP_WIDTH && y < MAP_DEPTH && z < MAP_HEIGHT) this.level.setTile(x, y, z, b, true);
                if ((h & 3) === 0 && performance.now() - start > budgetMs) break;
            }
        } finally { this.bulkChanges = false; }
        if (h + 3 >= L.length) { this.netChanges = []; this.netChangesHead = 0; } else this.netChangesHead = h;
    }
    markSectionDirty(cx, cy, cz) {
        const key = this.sectionKey(cx, cy, cz);
        if (this.sections.has(key)) (this.bulkChanges ? this.backgroundDirty : this.dirtySections).add(key);
    }
    queueChunkUpdate(x, y, z) {
        const lx = ((x % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const ly = ((y % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const lz = ((z % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const cx = Math.floor(x / CHUNK_SIZE), cy = Math.floor(y / CHUNK_SIZE), cz = Math.floor(z / CHUNK_SIZE);
        const colKey = cx + ',' + cz;
        const top = this.columnTops.get(colKey);
        if (top !== undefined && y > top && this.level.getTile(x, y, z) !== BLOCK.AIR) {
            this.columnTops.set(colKey, y);
            this.queueStale = true;
        }
        const xs = [cx], ys = [cy], zs = [cz];
        if (lx === 0) xs.push(cx - 1);
        if (lx === CHUNK_SIZE - 1) xs.push(cx + 1);
        if (ly === 0) ys.push(cy - 1);
        if (ly === CHUNK_SIZE - 1) ys.push(cy + 1);
        if (lz === 0) zs.push(cz - 1);
        if (lz === CHUNK_SIZE - 1) zs.push(cz + 1);
        for (const sx of xs) for (const sy of ys) for (const sz of zs) {
            if (sx === cx || sy === cy || sz === cz) {
                const diff = (sx !== cx) + (sy !== cy) + (sz !== cz);
                if (diff <= 1) this.markSectionDirty(sx, sy, sz);
            }
        }
    }
    queueLightUpdate(x, z, y0, y1) {
        const cy0 = Math.max(0, Math.floor(y0 / CHUNK_SIZE));
        const cy1 = Math.floor(y1 / CHUNK_SIZE);
        const cols = new Set();
        for (const [dx, dz] of [[0, 0], [-1, 0], [1, 0], [0, -1], [0, 1]]) {
            cols.add(Math.floor((x + dx) / CHUNK_SIZE) + ',' + Math.floor((z + dz) / CHUNK_SIZE));
        }
        for (const col of cols) {
            const [cx, cz] = col.split(',').map(Number);
            for (let cy = cy0; cy <= cy1; cy++) {
                const key = this.sectionKey(cx, cy, cz);
                if (this.sections.has(key)) (this.bulkChanges ? this.backgroundDirty : this.dirtySections).add(key);
            }
        }
    }
    disposeSection(sec) {
        if (!sec.group) return;
        this.scene.remove(sec.group);
        sec.group.traverse(o => { if (o.geometry) o.geometry.dispose(); });
    }
    buildSection(cx, cy, cz) {
        this.chunksUpdatedCounter++;
        const key = this.sectionKey(cx, cy, cz);
        const old = this.sections.get(key);
        if (old) this.disposeSection(old);
        const group = this.meshBuilder.buildChunkMesh(cx, cy, cz);
        if (group) {
            group.visible = this.chunkDistance(cx, cz) <= this.renderDistance;
            this.scene.add(group);
        }
        this.sections.set(key, { cx, cy, cz, group });
    }
    refreshChunkQueue() {
        for (const [key, sec] of this.sections) {
            const dist = this.chunkDistance(sec.cx, sec.cz);
            if (dist > this.renderDistance + UNLOAD_MARGIN) {
                this.disposeSection(sec);
                this.sections.delete(key);
                this.dirtySections.delete(key);
            } else if (sec.group) {
                sec.group.visible = dist <= this.renderDistance;
            }
        }
        const queue = [];
        const chunksX = Math.ceil(MAP_WIDTH / CHUNK_SIZE), chunksZ = Math.ceil(MAP_HEIGHT / CHUNK_SIZE);
        const pcx = Math.floor(this.player.position.x / CHUNK_SIZE);
        const pcz = Math.floor(this.player.position.z / CHUNK_SIZE);
        const rad = Math.ceil(this.renderDistance / CHUNK_SIZE) + 1;
        for (let cx = Math.max(0, pcx - rad); cx <= Math.min(chunksX - 1, pcx + rad); cx++) {
            for (let cz = Math.max(0, pcz - rad); cz <= Math.min(chunksZ - 1, pcz + rad); cz++) {
                const dist = this.chunkDistance(cx, cz);
                if (dist > this.renderDistance) continue;
                const topSection = Math.floor(this.chunkColumnTop(cx, cz) / CHUNK_SIZE);
                for (let cy = 0; cy <= topSection; cy++) {
                    if (!this.sections.has(this.sectionKey(cx, cy, cz))) queue.push({ cx, cy, cz, dist });
                }
            }
        }
        queue.sort((a, b) => b.dist - a.dist);
        this.buildQueue = queue;
        this.queueStale = false;
    }
    updateChunks(budgetMs = CHUNK_BUILD_BUDGET_MS, maxDist = Infinity) {
        const start = performance.now();
        const pcx = Math.floor(this.player.position.x / CHUNK_SIZE);
        const pcz = Math.floor(this.player.position.z / CHUNK_SIZE);
        const pkey = pcx + ',' + pcz;
        const now = performance.now();
        if (pkey !== this.lastPlayerChunk || (this.queueStale && now - (this.lastQueueRefresh || 0) > 250)) {
            this.lastPlayerChunk = pkey;
            this.lastQueueRefresh = now;
            this.refreshChunkQueue();
        }
        let rebuilt = 0;
        for (const key of this.dirtySections) {
            if (rebuilt >= 2 && performance.now() - start > budgetMs) break;
            this.dirtySections.delete(key);
            const sec = this.sections.get(key);
            if (sec) this.buildSection(sec.cx, sec.cy, sec.cz);
            rebuilt++;
        }
        const bgStart = performance.now();
        while (this.backgroundDirty.size && performance.now() - bgStart < Math.min(BACKGROUND_BUILD_MS, budgetMs)) {
            let best = null, bestD = Infinity;
            for (const key of this.backgroundDirty) {
                if (this.dirtySections.has(key)) { this.backgroundDirty.delete(key); continue; }
                const sec = this.sections.get(key);
                if (!sec) { this.backgroundDirty.delete(key); continue; }
                const d = this.chunkDistance(sec.cx, sec.cz) + Math.abs(sec.cy * CHUNK_SIZE - this.player.position.y) * 0.5;
                if (d < bestD) { bestD = d; best = key; }
            }
            if (best === null) break;
            this.backgroundDirty.delete(best);
            const sec = this.sections.get(best);
            this.buildSection(sec.cx, sec.cy, sec.cz);
        }
        while (this.buildQueue.length && performance.now() - start < budgetMs) {
            const next = this.buildQueue[this.buildQueue.length - 1];
            if (next.dist > maxDist) break;
            this.buildQueue.pop();
            if (!this.sections.has(this.sectionKey(next.cx, next.cy, next.cz))) {
                this.buildSection(next.cx, next.cy, next.cz);
            }
        }
    }
    setupInput() {
        this.renderer.domElement.addEventListener('click', () => {
            if (!this.pointerLocked && !this.menu && !this.statusMessage) this.lockPointer();
        });
        document.addEventListener('pointerlockchange', () => {
            this.pointerLockChangedAt = performance.now();
            const wasLocked = this.pointerLocked;
            this.pointerLocked = document.pointerLockElement === this.renderer.domElement;
            if (wasLocked && !this.pointerLocked && this.lookBeforeMouse &&
                performance.now() - this.lookBeforeMouse.at < 50) {
                this.player.rotation.x = this.lookBeforeMouse.x;
                this.player.rotation.y = this.lookBeforeMouse.y;
            }
            if (wasLocked && !this.pointerLocked) this.closeChat();
            const dead = this.survival && this.player && this.player.health <= 0;
            if (wasLocked && !this.pointerLocked && !this.statusMessage && this.menu !== 'blocks' && this.menu !== 'gameover')
                this.openMenu(dead ? 'gameover' : 'main');
            if (this.pointerLocked) this.closeMenu();
        });
        document.addEventListener('mousemove', e => {
            this.mouseX = e.clientX * this.dpr; this.mouseY = e.clientY * this.dpr;
            if (!this.pointerLocked || document.pointerLockElement !== this.renderer.domElement || this.chatOpen) return;
            if (performance.now() - (this.pointerLockChangedAt || 0) < MOUSE_SETTLE_MS) return;
            if (Math.abs(e.movementX) > MOUSE_MAX_JUMP || Math.abs(e.movementY) > MOUSE_MAX_JUMP) return;
            this.lookBeforeMouse = { x: this.player.rotation.x, y: this.player.rotation.y, at: performance.now() };
            this.player.rotation.y -= e.movementX * 0.002;
            this.player.rotation.x -= e.movementY * 0.002 * (this.invertMouse ? -1 : 1);
            this.player.rotation.x = Math.max(-1.57, Math.min(1.57, this.player.rotation.x));
        });
        document.addEventListener('mousedown', e => {
            if (!this.player) return;
            if (this.menu && !this.pointerLocked) {
                if (e.button === 0) this.menuClick(e.clientX * this.dpr, e.clientY * this.dpr);
                return;
            }
            if (!this.pointerLocked || this.chatOpen) return;
            if (e.button === 0 || e.button === 2) { this.startSwing(); this.buttonsHeld = this.buttonsHeld || {}; this.buttonsHeld[e.button] = true; }
            if (this.survival) {
                if (e.button === 1) { e.preventDefault(); this.pickBlock(); } else this.survival.mouseDown(e.button);
                return;
            }
            if (!OLD_UI && e.button === 0) this.breakBlock();
            else if (!OLD_UI && e.button === 2) this.placeBlock();
            else if (e.button === 2) this.buildMode = !this.buildMode;
            else if (e.button === 0) { if (this.buildMode) this.placeBlock(); else this.breakBlock(); this.heldClickAt = performance.now(); }
            else if (e.button === 1 && !CLASSIC_0011A) { e.preventDefault(); this.pickBlock(); }
        });
        document.addEventListener('mouseup', e => { if (this.buttonsHeld) this.buttonsHeld[e.button] = false; if (this.survival) this.survival.mouseUp(e.button); });
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('wheel', e => {
            if (!this.player) { e.preventDefault(); return; }
            e.preventDefault();
            if (this.menu) return;
            const dir = e.deltaY > 0 ? 1 : -1;
            this.player.cycleSlot(dir);
            this.blockPreview.setType(this.player.getSelectedBlock());
        }, { passive: false });
        document.addEventListener('keydown', e => { if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') this.shiftHeld = true; });
        document.addEventListener('keyup', e => { if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') this.shiftHeld = false; });
        window.addEventListener('blur', () => { this.shiftHeld = false; });
        document.addEventListener('keydown', e => {
            if (e.code === 'F5') { e.preventDefault(); return; }
            if (this.menu === 'sandbox') { if (e.code === 'Escape') { e.preventDefault(); this.closeSandbox(); } return; }
            if (!this.player) return;
            if (this.chatOpen) { this.handleChatKey(e); return; }
            if (e.code === 'KeyP' && !this.menu && !OLD_UI && !SURVIVAL_024 && !this.statusMessage) {
                this.raining = !this.raining;
                if (SANDBOX) { Sandbox.s.render.rain = this.raining; Sandbox.save(); }
                return;
            }
            if (e.code === 'KeyT' && this.net && !this.menu && !this.statusMessage) {
                e.preventDefault();
                if (this.serverHasChat) this.openChat();
                else this.addChat(OLD_SERVER_WARNING, 0xFFFF55);
                return;
            }
            if (this.menu === 'join' && e.code !== 'Escape') { this.handleAddressKey(e); return; }
            if (this.menu === 'save' && e.code !== 'Escape') { this.handleSaveKey(e); return; }
            if (this.menu === 'blocks') {
                if (e.code === 'KeyB' || (e.code === 'Escape' && performance.now() - this.menuOpenedAt > 300)) this.backToGame();
                return;
            }
            if (this.menu) {
                if (e.code === 'Escape' && performance.now() - this.menuOpenedAt > 300) {
                    if (this.menu === 'gameover') return;
                    if (this.menu === 'controls') { this.openMenu('settings'); return; }
                    if (this.menu === 'main') this.backToGame();
                    else if (this.menu === 'delete' || this.menu === 'join' || this.menu === 'signin') this.openMenu('load');
                    else if (this.menu === 'save') this.openMenu('main');
                    else this.openMenu('main');
                }
                return;
            }
            if (e.code === 'KeyF') this.cycleRenderDistance();
            if (this.survival) {
                if (e.code === 'Tab') { e.preventDefault(); this.survival.shootArrow(); }
                if (e.code === 'KeyB') this.survival.throwSign();
            }
            if (e.code === 'KeyG' && !this.survival) this.spawnZombie();
            if (e.code === 'KeyN' && CLASSIC_0011A) this.generateLevel(LEVEL_SIZES[1]);
            const onServer = !!this.net && !!this.netMinigame;
            if (e.code === 'KeyR' && !this.survival && !onServer) this.respawn();
            if (e.code === 'KeyB' && !OLD_UI && !SURVIVAL_024) this.openBlockMenu();
            if (e.code === 'KeyY' && !this.survival) { if (OLD_UI) this.invertMouse = !this.invertMouse; else if (!onServer) this.setSpawnHere(); }
            if (e.code === 'Enter' && CLASSIC_0011A) this.saveClassicLevel();
            if (e.code === 'Enter' && !CLASSIC_0011A && !this.survival && !onServer) this.setSpawnHere();
            if (e.code === 'Tab' && !CLASSIC_0011A) { e.preventDefault(); this.tabHeld = true; }
            if (MOVE_KEYS[e.code]) this.input[MOVE_KEYS[e.code]] = true;
            const digit = e.code.match(/^Digit([0-9])$/) || (e.code === 'Minus' ? [null, '-'] : null);
            if (digit) {
                let slot = digit[1] === '0' ? 9 : digit[1] === '-' ? 10 : Number(digit[1]) - 1;
                if (CLASSIC_0011A) slot = { 1: 0, 2: 1, 3: 2, 4: 3, 6: 4 }[digit[1]] ?? 99;
                if (slot < this.player.inventory.length) {
                    this.player.selectedSlot = slot;
                    this.blockPreview.setType(this.player.getSelectedBlock());
                }
            }
        });
        document.addEventListener('paste', e => {
            const text = ((e.clipboardData && e.clipboardData.getData('text')) || '').replace(/[^\x20-\x7E]/g, '').trim();
            if (!text) return;
            if (this.menu === 'save') {
                const max = this.saveField === 'name' ? SAVE_NAME_MAX : SAVE_DESC_MAX;
                if (this.saveField === 'name') this.saveName = (this.saveName + text).slice(0, max);
                else this.saveDesc = (this.saveDesc + text).slice(0, max);
            } else if (this.menu === 'join') {
                this.serverAddress = (this.serverAddress + text).slice(0, SERVER_ADDRESS_MAX);
                this.joinMessage = null;
            } else if (this.chatOpen) {
                this.chatInput = (this.chatInput + text).slice(0, CHAT_MAX);
            } else return;
            e.preventDefault();
        });
        document.addEventListener('keyup', e => {
            if (MOVE_KEYS[e.code]) this.input[MOVE_KEYS[e.code]] = false;
            if (e.code === 'Tab') this.tabHeld = false;
        });
        window.addEventListener('resize', () => {
            this.camera.aspect = innerWidth / innerHeight;
            this.camera.updateProjectionMatrix();
            this.dpr = Math.min(2, window.devicePixelRatio || 1);
            this.renderer.setPixelRatio(this.dpr);
            this.renderer.setSize(innerWidth, innerHeight);
            this.sizeHud(); this.hudScale = Math.max(1, Math.round(3 * this.dpr));
            this.hudCtx.imageSmoothingEnabled = false;
        });
    }
    breakBlock() {
        if (this.net && this.serverBuild === false) return;
        const hit = this.raycaster.cast(this.player.getEyePosition(), this.player.getLookDirection(), REACH_DISTANCE);
        if (!hit.hit || (hit.blockPos.y <= 0 && !CLASSIC_0011A)) return;
        const { x, y, z } = hit.blockPos;
        const type = this.level.getTile(x, y, z);
        if (type === BLOCK.AIR || type === BLOCK.WATER || type === BLOCK.LAVA || type === BLOCK.BEDROCK) return;
        this.particles.spawn(x, y, z, type);
        if (this.classicHand) this.classicHand.swing();
        if (this.sounds) this.sounds.dig(type);
        this.level.setTile(x, y, z, BLOCK.AIR);
        this.sendNet({ t: 'set', x, y, z, b: BLOCK.AIR });
    }
    someoneInBlock(x, y, z) {
        const hw = PLAYER_WIDTH / 2;
        const overlaps = (px, eyeY, pz) => x + 1 > px - hw && x < px + hw && y + 1 > eyeY - PLAYER_HEIGHT && y < eyeY + 0.1 && z + 1 > pz - hw && z < pz + hw;
        const me = this.player.position;
        if (overlaps(me.x, me.y, me.z)) return true;
        for (const r of this.remotePlayers.values()) {
            if (overlaps(r.pos.x, r.pos.y, r.pos.z) || overlaps(r.target.x, r.target.y, r.target.z)) return true;
        }
        for (const zb of this.survival ? this.zombies.concat(this.survival.mobs) : this.zombies) {
            const b = zb.bb;
            if (x + 1 > b[0] && x < b[3] && y + 1 > b[1] && y < b[4] && z + 1 > b[2] && z < b[5]) return true;
        }
        return false;
    }
    pickBlock() {
        const hit = this.raycaster.cast(this.player.getEyePosition(), this.player.getLookDirection(), REACH_DISTANCE);
        if (!hit.hit) return;
        let t = this.level.getTile(hit.blockPos.x, hit.blockPos.y, hit.blockPos.z);
        if ((SURVIVAL_024 || CLASSIC_019) && t === BLOCK.GRASS) t = BLOCK.DIRT;
        if (t === BLOCK.DOUBLE_SLAB) t = BLOCK.SLAB;
        const i = this.player.inventory.indexOf(t);
        if (i >= 0) this.player.selectedSlot = i;
        else if (!SURVIVAL_024 && !OLD_UI && this.selectableBlocks().includes(t)) this.player.inventory[this.player.selectedSlot] = t;
        else return;
        this.blockPreview.setType(this.player.getSelectedBlock());
    }
    placeBlock() {
        if (this.net && this.serverBuild === false) return;
        const hit = this.raycaster.cast(this.player.getEyePosition(), this.player.getLookDirection(), REACH_DISTANCE);
        if (!hit.hit) return;
        const { x, y, z } = hit.prevPos;
        if (x < 0 || y < 0 || z < 0 || x >= MAP_WIDTH || y >= MAP_DEPTH || z >= MAP_HEIGHT) return;
        if (y > BUILD_LIMIT_Y) return;
        const id = this.player.getSelectedBlock();
        if (id === BLOCK.BEDROCK) return;
        const liquid = id === BLOCK.WATER || id === BLOCK.LAVA;
        if (id === BLOCK.AIR || !this.player.inventory.includes(id)) return;
        if (!isPlant(id) && !liquid && this.someoneInBlock(x, y, z)) return;
        this.level.setTile(x, y, z, id);
        this.sendNet({ t: 'set', x, y, z, b: id });
        if (this.classicHand) this.classicHand.placed();
        return true;
    }
    scheduleFrame() {
        if (!this.vsyncPending) { this.vsyncPending = true; requestAnimationFrame(t => { this.vsyncPending = false; this.onVsync(t); }); }
        if (this.uncapped && !document.hidden && !this.extraPending && this.extraFits()) { this.extraPending = true; this.frameChannel.port2.postMessage(0); }
    }
    onVsync(t) {
        if (this.lastVsync) {
            const d = t - this.lastVsync;
            if (d > 3 && d < 100) this.vsyncInterval = this.vsyncInterval * 0.9 + d * 0.1;
            if (d > Math.max(50, this.vsyncInterval * 3)) this.extrasPausedUntil = t + HITCH_PAUSE_MS;
        }
        this.lastVsync = t;
        this.loop(performance.now());
    }
    extraFits() {
        const now = performance.now();
        if (now < this.extrasPausedUntil) return false;
        return now - this.lastVsync + this.extraCost < this.vsyncInterval + FRAME_LATE_MS;
    }
    extraFrame() {
        this.extraPending = false;
        if (!this.extraFits()) return;
        const start = performance.now();
        this.loop(start);
        const gl = this.renderer.getContext();
        gl.readPixels(0, 0, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, this.syncPixel);
        this.extraCost = this.extraCost * 0.7 + (performance.now() - start) * 0.3;
    }
    loop(now) {
        const frameStart = performance.now();
        this.scheduleFrame();
        this.music.update();
        let dtMs = now - this.lastTime;
        if (dtMs < 0) dtMs = 0;
        if (dtMs > 250) dtMs = 250;
        const dt = dtMs / 1000;
        this.lastTime = now;
        this.fpsFrames++;
        this.fpsTimeAccum += dtMs;
        if (this.fpsTimeAccum >= 500) {
            this.displayFps = Math.round((this.fpsFrames * 1000) / this.fpsTimeAccum);
            this.fpsFrames = 0;
            this.displayChunkUpdates = this.chunksUpdatedCounter;
            this.chunksUpdatedCounter = 0;
            this.fpsTimeAccum = 0;
        }
        if (!this.level || !this.player) {
            this.updateAutoJoin(now);
            this.renderer.setViewport(0, 0, innerWidth, innerHeight);
            this.renderer.clear();
            this.renderHUD();
            return;
        }
        if (this.net) this.applyNetChanges();
        this.tickAccumulator += dtMs;
        let ticksRun = 0;
        while (this.tickAccumulator >= MS_PER_TICK && ticksRun < 5) {
            if (!this.net || this.net.isLobby) {
                this.bulkChanges = true;
                try { this.level.tick(now); } finally { this.bulkChanges = false; }
            }
            for (const zb of this.zombies) zb.tick();
            if (this.survival && this.player) this.survival.tick();
            if (this.sounds && this.player) {
                const p = this.player, last = this.stepFrom || p.position.clone();
                const moved = Math.hypot(p.position.x - last.x, p.position.z - last.z);
                this.stepFrom = p.position.clone();
                if (p.onGround && moved < 2) {
                    this.stepDist = (this.stepDist || 0) + moved * 0.6;
                    if (this.stepDist > (this.nextStep || 1)) {
                        this.nextStep = Math.floor(this.stepDist) + 1;
                        const feet = p.position.y - PLAYER_HEIGHT;
                        let t = this.level.getTile(Math.floor(p.position.x), Math.floor(feet - 0.2), Math.floor(p.position.z));
                        if (!SOUND_OF[t]) t = this.level.getTile(Math.floor(p.position.x), Math.floor(feet - 1.2), Math.floor(p.position.z));
                        this.sounds.step(t);
                    }
                }
            }
            if (this.classicHand && this.player) {
                if (!this.classicHand.hand) this.classicHand.setupHand();
                this.classicHand.handTick();
                if (this.viewBobbing) this.classicHand.bobTick(); else { const p = this.player; p.bob = p.oBob = p.tilt = p.oTilt = 0; }
            }
            this.tickLiquidFX();
            this.tickAccumulator -= MS_PER_TICK;
            ticksRun++;
        }
        if (this.tickAccumulator > MS_PER_TICK * 5) this.tickAccumulator = 0;
        this.particles.update(dt, this.camera);
        if (this.survival) this.survival.frame(Math.min(1, this.tickAccumulator / MS_PER_TICK));
        if (this.zombies.length) {
            this.zombies = this.zombies.filter(zb => {
                if (zb.removed) this.scene.remove(zb.view.root);
                return !zb.removed;
            });
            const a = Math.min(1, this.tickAccumulator / MS_PER_TICK);
            const nowSeconds = now / 1000;
            for (const zb of this.zombies) {
                zb.updateView(this.zombieModel, a, nowSeconds);
                const bx = Math.floor(zb.x), bz = Math.floor(zb.z), by = Math.floor(zb.y + 1.2);
                const sky = this.level.isLit(bx, by, bz) ? 1.0 : SHADOW_SHADE;
                const v = shade(sky * liquidDarkness(this.level, bx, by, bz));
                zb.view.material.color.setRGB(v, v, v);
            }
        }
        this.updateNetwork(now, dt);
        if (SANDBOX) this.applySandbox();
        if (this.cloudTex) {
            const tileBlocks = 256 * CLOUD_BLOCKS_PER_PIXEL;
            this.cloudTex.offset.x = ((now / 1000) * (SANDBOX ? Sandbox.s.render.cloudSpeed : CLOUD_SPEED) / tileBlocks) % 1;
        }
        this.updateChunks();
        const yBeforeMove = this.player.position.y;
        this.player.update(dt, this.frozen ? {} : this.input);
        if (this.survival) this.survival.trackFall(yBeforeMove);
        const eye = this.player.getEyePosition();
        this.camera.position.copy(eye);
        if (this.player.ySlide) {
            this.camera.position.y -= this.player.ySlide;
            this.player.ySlide *= Math.pow(0.4, Math.min(0.25, dt) * 20);
            if (this.player.ySlide < 0.001) this.player.ySlide = 0;
        }
        this.camera.rotation.order = 'YXZ';
        this.camera.rotation.y = this.player.rotation.y;
        this.camera.rotation.x = this.player.rotation.x;
        if (this.survival) this.survival.adjustCamera(this.camera, Math.min(1, this.tickAccumulator / MS_PER_TICK));
        else if (this.classicHand && this.viewBobbing && !this.thirdPerson) this.classicHand.adjustCamera(this.camera, Math.min(1, this.tickAccumulator / MS_PER_TICK));
        this.updateThirdPerson(eye, now);
        if (CLASSIC_019 && this.buttonsHeld && this.buttonsHeld[0] && this.pointerLocked && !this.menu && !this.chatOpen &&
            now - (this.heldClickAt || 0) >= 250) {
            this.heldClickAt = now;
            if (this.buildMode) this.placeBlock(); else this.breakBlock();
        }
        const cam = this.camera.position;
        const eyeBlock = this.level.getTile(Math.floor(cam.x), Math.floor(cam.y), Math.floor(cam.z));
        if (CLASSIC_0011A) {
            const f = this.airFog, w = eyeBlock === BLOCK.WATER, lv = eyeBlock === BLOCK.LAVA;
            this.scene.fog = f;
            f.color.copy(w ? srgb(0.02, 0.02, 0.2) : lv ? srgb(0.5, 0.3, 0) : srgb(0.5, 0.8, 1));
            f.density = w ? 0.1 : lv ? 0.2 : 0.001;
            C12.litAmb.value.copy(w ? srgb(0.3, 0.3, 0.5) : lv ? srgb(0.4, 0.3, 0.3) : srgb(1, 1, 1));
            C12.darkAmb.value.copy(w || lv ? C12.litAmb.value : srgb(0.6, 0.6, 0.6));
            C12.darkFogColor.value.copy(w || lv ? f.color : srgb(14 / 255, 11 / 255, 10 / 255));
            C12.darkFogDensity.value = w || lv ? f.density : 0.01;
            this.scene.background.copy(srgb(0.5, 0.8, 1));
        } else if (eyeBlock === BLOCK.WATER) {
            this.scene.fog = this.liquidFog;
            this.liquidFog.color.setHex(0x050533);
            this.liquidFog.density = FOG_023 ? 0.1 : 0.15;
            this.scene.background.setHex(0x050533);
        } else if (eyeBlock === BLOCK.LAVA) {
            this.scene.fog = this.liquidFog;
            this.liquidFog.color.setHex(FOG_023 ? 0x991A00 : 0xb82600);
            this.liquidFog.density = 2.0;
            this.scene.background.setHex(FOG_023 ? 0x991A00 : 0xb82600);
        } else {
            this.scene.fog = this.airFog;
            if (FOG_023) this.scene.background.copy(this.airFog.color); else this.scene.background.copy(this.skyColor);
        }
        if (FOG_023 && this.level) this.updateSkyPlane();
        this.breakHighlight.visible = false;
        this.placeHighlight.visible = false;
        this.selectOutline.visible = false;
        const hit = this.raycaster.cast(eye, this.player.getLookDirection(), REACH_DISTANCE);
        if (hit.hit) {
            const slabY = this.level.getTile(hit.blockPos.x, hit.blockPos.y, hit.blockPos.z) === BLOCK.SLAB;
            const hy = hit.blockPos.y + (slabY ? 0.25 : 0.5), sy = slabY ? 0.5 : 1;
            this.selectOutline.visible = true;
            this.selectOutline.position.set(hit.blockPos.x + 0.5, hy, hit.blockPos.z + 0.5);
            this.selectOutline.scale.y = sy; this.breakHighlight.scale.y = sy;
            const pulse = 0.3 + 0.3 * Math.abs(Math.sin(now * 0.002));
            if (SURVIVAL_024 || this.classicHand) {  } else if (!this.buildMode) {
                this.breakHighlight.visible = true;
                this.breakHighlight.position.set(hit.blockPos.x + 0.5, hy, hit.blockPos.z + 0.5);
                this.breakHighlight.material.opacity = pulse;
            } else {
                this.placeHighlight.visible = true;
                this.placeHighlight.position.set(hit.prevPos.x + 0.5, hit.prevPos.y + 0.5, hit.prevPos.z + 0.5);
                this.placeHighlight.material.opacity = pulse;
                this.placeHighlight.geometry = this.ghostGeo(this.player.getSelectedBlock());
            }
        }
        if (this.thumbRequested) {
            this.thumbRequested = false;
            const gui = [this.breakHighlight, this.placeHighlight, this.selectOutline, this.nametag,
                ...[...this.remotePlayers.values()].map(r => r.tag)].filter(Boolean);
            const shown = gui.map(o => o.visible);
            for (const o of gui) o.visible = false;
            this.renderer.setViewport(0, 0, innerWidth, innerHeight);
            this.renderer.clear();
            this.renderer.render(this.scene, this.camera);
            this.saveThumb = this.copyThumbnail();
            gui.forEach((o, i) => { o.visible = shown[i]; });
        }
        this.updateRain();
        this.renderer.setViewport(0, 0, innerWidth, innerHeight);
        this.renderer.clear();
        this.renderer.render(this.scene, this.camera);
        this.blockPreview.setType(this.player.getSelectedBlock());
        if (this.survival) this.survival.renderHand(this.renderer, Math.min(1, this.tickAccumulator / MS_PER_TICK));
        else if (this.classicHand) this.classicHand.renderHand(this.renderer, Math.min(1, this.tickAccumulator / MS_PER_TICK));
        else if (OLD_UI) {
            const BIG = 1.75, bp = this.blockPreview, unit = innerHeight / 240 * BIG, S = Math.round(48 * unit);
            const edge = 12 * innerHeight / 240;
            const cx = innerWidth - edge - 11.31 * unit, cy = edge + 12.35 * unit;
            if (bp.mesh) { bp.mesh.rotation.set(30 * Math.PI / 180, 45 * Math.PI / 180, 0, 'XYZ'); bp.mesh.scale.set(1, 1, 1); }
            const half = (S / 2) / (16 * unit);
            Object.assign(bp.camera, { left: -half, right: half, top: half, bottom: -half });
            bp.camera.position.set(0, 0, 10); bp.camera.lookAt(0, 0, 0); bp.camera.updateProjectionMatrix();
            this.renderer.clearDepth();
            this.renderer.setViewport(Math.round(cx - S / 2), Math.round(innerHeight - cy - S / 2), S, S);
            this.renderer.render(bp.scene, bp.camera);
        } else {
            this.renderer.clearDepth();
            const pSize = this.blockPreview.size;
            const pMargin = this.blockPreview.margin;
            this.renderer.setViewport(innerWidth - pSize - pMargin, innerHeight - pSize - pMargin, pSize, pSize);
            this.renderer.render(this.blockPreview.scene, this.blockPreview.camera);
        }
        this.renderHUD();
        this.captureFrame();
        this.frameCost = this.frameCost * 0.8 + (performance.now() - frameStart) * 0.2;
    }
    composeFrame(canvas) {
        const gl = this.renderer.domElement;
        if (canvas.width !== gl.width || canvas.height !== gl.height) { canvas.width = gl.width; canvas.height = gl.height; }
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(gl, 0, 0);
        ctx.drawImage(this.hudCanvas, 0, 0, canvas.width, canvas.height);
        return canvas;
    }
    captureFrame() {
        if (!this.shotWanted && !this.recorder) return;
        const menu = this.menu;
        if (menu && !this.statusMessage) { this.menu = null; this.lastHudKey = null; this.renderHUD(); }
        if (this.shotWanted) {
            this.shotWanted = false;
            this.composeFrame(document.createElement('canvas')).toBlob(blob => this.tellPage({ type: 'claudecraft-screenshot-done', blob }), 'image/png');
        }
        if (this.recorder) this.composeFrame(this.recordCanvas);
        if (menu && !this.statusMessage) { this.menu = menu; this.lastHudKey = null; this.renderHUD(); }
    }
    tellPage(msg) { if (window.parent !== window) window.parent.postMessage(msg, '*'); }
    startRecording() {
        if (this.recorder) return;
        try {
            const gl = this.renderer.domElement;
            this.recordCanvas = document.createElement('canvas'); this.recordCanvas.width = gl.width; this.recordCanvas.height = gl.height;
            const outs = [this.sounds, this.music].filter(x => x && x.ctx && x.out).map(x => ({ ctx: x.ctx, out: x.out }));
            const audio = RecordAudio.start(outs);
            const stream = new MediaStream([...this.recordCanvas.captureStream(30).getVideoTracks(), ...(audio ? [audio] : [])]);
            const types = audio ? ['video/webm;codecs=vp8,opus', 'video/webm;codecs=vp9,opus', 'video/webm', 'video/mp4'] : ['video/webm;codecs=vp8', 'video/webm;codecs=vp9', 'video/webm', 'video/mp4'];
            const type = types.find(t => window.MediaRecorder && MediaRecorder.isTypeSupported(t));
            const rec = new MediaRecorder(stream, type ? { mimeType: type, videoBitsPerSecond: 8000000, audioBitsPerSecond: 128000 } : undefined);
            const chunks = [];
            rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
            rec.onstop = () => { RecordAudio.stop(); this.tellPage({ type: 'claudecraft-record-done', blob: new Blob(chunks, { type: rec.mimeType || 'video/webm' }) }); };
            rec.start(1000);
            this.recorder = rec;
            this.tellPage({ type: 'claudecraft-record-state', on: true });
        } catch (e) {
            this.recorder = null; RecordAudio.stop();
            this.tellPage({ type: 'claudecraft-record-state', on: false, error: 'Your browser can\'t record video.' });
        }
    }
    stopRecording() {
        if (!this.recorder) return;
        const rec = this.recorder; this.recorder = null;
        try { rec.stop(); } catch {  }
        this.tellPage({ type: 'claudecraft-record-state', on: false });
    }
}
new Game();
