// ============================================================
// LAVA SURVIVAL MAPS
// The maps the server puts in the "lava survival" folder. Each is 64 x 64 blocks, built from
// simple shapes, with a spawn spot (feet position). Lava pours in from above the middle; the
// 6x6x6 area around the spawn stays safe.
// The maps are drawn as if 64 high, then raised by RAISE so their floor sits at sea level (the
// edge water and bedrock wall around every level are at y = 32), on solid stone. Levels are
// DEPTH high, so the tallest maps still fit.
// ============================================================
const W = 64, D = 64;          // the space the maps are drawn in
const RAISE = 31, DEPTH = 96;  // where they really go
const PRESET_VERSION = 4;      // bump when the maps change, so servers remake them

module.exports = function lavaMaps(B) {
    // ---- drawing helpers for one map ----
    function canvas() {
        const blocks = new Uint8Array(W * W * DEPTH);
        // underneath every map: bedrock, then solid stone up to the map's own floor
        for (let y = 0; y < RAISE; y++) blocks.fill(y === 0 ? B.BEDROCK : B.ROCK, y * W * W, (y + 1) * W * W);
        const ok = (x, y, z) => x >= 0 && y >= 0 && z >= 0 && x < W && y < D && z < W;
        const at = (x, y, z) => ((y + RAISE) * W + z) * W + x;
        const c = {
            blocks,
            set(x, y, z, b) { if (ok(x, y, z)) blocks[at(x, y, z)] = b; },
            get(x, y, z) { return ok(x, y, z) ? blocks[at(x, y, z)] : B.AIR; },
            box(x0, y0, z0, x1, y1, z1, b) {
                for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++)
                    for (let z = Math.min(z0, z1); z <= Math.max(z0, z1); z++)
                        for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) c.set(x, y, z, b);
            },
            // walls only (no floor or roof)
            walls(x0, y0, z0, x1, y1, z1, b) {
                c.box(x0, y0, z0, x1, y1, z0, b); c.box(x0, y0, z1, x1, y1, z1, b);
                c.box(x0, y0, z0, x0, y1, z1, b); c.box(x1, y0, z0, x1, y1, z1, b);
            },
            // a solid ground up to height h (stone, dirt, grass on top)
            ground(h, top = B.GRASS) {
                c.box(0, 1, 0, W - 1, h - 4, W - 1, B.ROCK);
                c.box(0, Math.max(1, h - 3), 0, W - 1, h - 1, W - 1, B.DIRT);
                c.box(0, h, 0, W - 1, h, W - 1, top);
            },
            // a tree like the game's: a trunk, two 3x3 layers of leaves round its top, a + on top
            tree(x, y, z, h = 5) {
                const top = y + h;
                c.box(x - 1, top - 2, z - 1, x + 1, top - 1, z + 1, B.LEAVES);
                for (const [dx, dz] of [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]]) c.set(x + dx, top, z + dz, B.LEAVES);
                c.box(x, y, z, x, y + h - 1, z, B.LOG);
            },
            cylinder(cx, cz, r, y0, y1, b, hollow = false) {
                for (let y = y0; y <= y1; y++) for (let z = cz - r; z <= cz + r; z++) for (let x = cx - r; x <= cx + r; x++) {
                    const d = Math.hypot(x - cx, z - cz);
                    if (d <= r + 0.3 && (!hollow || d > r - 1)) c.set(x, y, z, b);
                }
            },
            // the top of the solid ground in a column (or 0)
            top(x, z) { for (let y = D - 1; y > 0; y--) if (c.get(x, y, z) !== B.AIR) return y; return 0; }
        };
        c.box(0, 0, 0, W - 1, 0, W - 1, B.BEDROCK);                 // bedrock floor everywhere
        return c;
    }
    // a seeded random so a map comes out the same each time
    const seeded = seed => () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
    // smooth hills from seeded random values
    function hills(rnd, cell, amp, base) {
        const n = Math.ceil(W / cell) + 2, g = Array.from({ length: n * n }, rnd), sm = t => t * t * (3 - 2 * t);
        return (x, z) => {
            const gx = x / cell, gz = z / cell, ix = Math.floor(gx), iz = Math.floor(gz), fx = sm(gx - ix), fz = sm(gz - iz), v = (a, b) => g[b * n + a];
            return Math.round(base + amp * ((v(ix, iz) * (1 - fx) + v(ix + 1, iz) * fx) * (1 - fz) + (v(ix, iz + 1) * (1 - fx) + v(ix + 1, iz + 1) * fx) * fz));
        };
    }
    function terrain(c, height, opts = {}) {
        for (let z = 0; z < W; z++) for (let x = 0; x < W; x++) {
            const h = Math.max(2, Math.min(D - 8, height(x, z)));
            c.box(x, 1, z, x, h - 3, z, B.ROCK);
            c.box(x, Math.max(1, h - 2), z, x, h - 1, z, opts.under || B.DIRT);
            c.set(x, h, z, opts.top || B.GRASS);
        }
    }

    const maps = [];
    const map = (name, build, spawn) => maps.push({ name, build, spawn });

    // 1. Last Man Standing: one small platform on a tall pillar, nothing else
    map('Last Man Standing', c => {
        c.box(28, 1, 28, 35, 14, 35, B.ROCK);
        c.box(25, 15, 25, 38, 15, 38, B.COBBLESTONE);
    }, [31, 16, 31]);

    // 2. Kitchen: a giant kitchen (you're tiny)
    map('Kitchen', c => {
        // checkered floor
        for (let z = 0; z < W; z++) for (let x = 0; x < W; x++) c.set(x, 1, z, ((x >> 2) + (z >> 2)) % 2 ? B.PLANKS : B.COBBLESTONE);
        // walls
        c.walls(0, 2, 0, W - 1, 40, W - 1, B.PLANKS);
        // counters along the back wall, with cupboards underneath
        c.box(1, 2, 1, 62, 13, 10, B.LOG); c.box(1, 14, 1, 62, 14, 11, B.ROCK);
        for (let x = 4; x < 60; x += 10) c.box(x, 4, 11, x + 6, 11, 11, B.PLANKS);
        // fridge in the corner
        c.box(1, 2, 12, 10, 38, 22, B.ROCK); c.box(11, 20, 15, 11, 30, 16, B.COBBLESTONE);
        // stove with burners
        c.box(40, 15, 2, 52, 16, 9, B.COBBLESTONE);
        for (const [x, z] of [[42, 4], [49, 4], [42, 7], [49, 7]]) c.box(x, 17, z, x + 1, 17, z + 1, B.GRAVEL);
        // big table with legs, and chairs
        c.box(22, 16, 28, 44, 17, 46, B.PLANKS);
        for (const [x, z] of [[23, 29], [43, 29], [23, 45], [43, 45]]) c.box(x, 2, z, x, 15, z, B.LOG);
        for (const [x0, z0] of [[16, 32], [16, 40], [47, 32], [47, 40]]) {
            c.box(x0, 9, z0, x0 + 4, 9, z0 + 4, B.PLANKS);
            for (const [dx, dz] of [[0, 0], [4, 0], [0, 4], [4, 4]]) c.box(x0 + dx, 2, z0 + dz, x0 + dx, 8, z0 + dz, B.LOG);
            const back = x0 < 32 ? x0 : x0 + 4; c.box(back, 10, z0, back, 18, z0 + 4, B.PLANKS);
        }
        // a cereal box and a mug on the table
        c.box(26, 18, 31, 30, 28, 33, B.SAND); c.walls(37, 18, 40, 40, 21, 43, B.ROCK);
    }, [33, 18, 37]);

    // 3. Outdoors: rolling hills and trees
    map('Outdoors', c => {
        const r = seeded(3), h = hills(r, 14, 10, 14);
        terrain(c, h);
        for (let i = 0; i < 22; i++) { const x = 3 + Math.floor(r() * 58), z = 3 + Math.floor(r() * 58); if (Math.hypot(x - 32, z - 32) > 6) c.tree(x, c.top(x, z) + 1, z, 4 + Math.floor(r() * 3)); }
    }, [32, null, 32]);

    // 4. Box: inside a big closed stone box
    map('Box', c => {
        c.box(2, 1, 2, 61, 1, 61, B.ROCK);
        c.walls(2, 2, 2, 61, 46, 61, B.ROCK);
        c.box(2, 47, 2, 61, 47, 61, B.ROCK);
        c.box(31, 47, 31, 32, 47, 32, B.AIR);              // a small hole in the roof: the lava comes in here
    }, [32, 2, 40]);

    // 5. Pyramid: a sand pyramid in the desert
    map('Pyramid', c => {
        c.ground(6, B.SAND);
        for (let i = 0; i < 24; i++) c.box(8 + i, 7 + i, 8 + i, 55 - i, 7 + i, 55 - i, B.SAND);
    }, [4, null, 4]);

    // 6. Volcano: a mountain with a crater (fitting)
    map('Volcano', c => {
        terrain(c, (x, z) => Math.round(Math.max(8, 40 - Math.hypot(x - 32, z - 32) * 1.2)), { top: B.GRAVEL, under: B.ROCK });
        c.cylinder(32, 32, 5, 30, 41, B.AIR);
    }, [8, null, 8]);

    // 7. Towers: stone towers of different heights
    map('Towers', c => {
        c.ground(6);
        const r = seeded(7);
        for (let i = 0; i < 9; i++) { const x = 6 + (i % 3) * 20, z = 6 + Math.floor(i / 3) * 20, h = 14 + Math.floor(r() * 26); c.box(x, 7, z, x + 7, 7 + h, z + 7, i % 2 ? B.COBBLESTONE : B.ROCK); }
    }, [16, null, 16]);

    // 8. Floating Islands: grass islands in the sky
    map('Floating Islands', c => {
        const r = seeded(8);
        for (let i = 0; i < 12; i++) {
            const x = 6 + Math.floor(r() * 52), z = 6 + Math.floor(r() * 52), y = 8 + Math.floor(r() * 18), rad = 3 + Math.floor(r() * 4);
            for (let d = 0; d <= rad; d++) c.cylinder(x, z, rad - d, y - d, y - d, d === 0 ? B.DIRT : B.ROCK);
            c.cylinder(x, z, rad, y + 1, y + 1, B.GRASS);
        }
        c.cylinder(32, 32, 5, 16, 16, B.DIRT); c.cylinder(32, 32, 5, 17, 17, B.GRASS);
    }, [32, 18, 32]);

    // 9. City: blocks of buildings and roads
    map('City', c => {
        c.ground(4, B.GRAVEL);
        const r = seeded(9);
        for (let bx = 0; bx < 4; bx++) for (let bz = 0; bz < 4; bz++) {
            if (bx === 1 && bz === 1) continue;                  // a park in the middle-ish
            const x = 3 + bx * 16, z = 3 + bz * 16, h = 8 + Math.floor(r() * 30), b = [B.COBBLESTONE, B.ROCK, B.PLANKS][Math.floor(r() * 3)];
            c.box(x, 5, z, x + 10, 4 + h, z + 10, b);
            for (let y = 7; y < 4 + h; y += 4) c.box(x, y, z + 3, x, y + 1, z + 7, B.AIR);
        }
        c.box(19, 4, 19, 31, 4, 31, B.GRASS); c.tree(25, 5, 25);
    }, [22, null, 22]);

    // 10. Castle: walls, corner towers and a keep
    map('Castle', c => {
        c.ground(5);
        c.walls(8, 6, 8, 55, 18, 55, B.COBBLESTONE);
        for (const [x, z] of [[8, 8], [51, 8], [8, 51], [51, 51]]) c.box(x, 6, z, x + 4, 24, z + 4, B.ROCK);
        c.box(24, 6, 24, 39, 30, 39, B.ROCK); c.box(25, 6, 25, 38, 29, 38, B.AIR); c.box(30, 6, 24, 33, 10, 24, B.AIR);
        c.box(29, 6, 8, 34, 11, 8, B.AIR);
    }, [32, null, 16]);

    // 11. Canyon: two cliffs with a deep gap
    map('Canyon', c => {
        terrain(c, (x) => (Math.abs(x - 32) < 6 ? 4 : 18 + ((x * 7) % 3)), { top: B.SAND, under: B.ROCK });
    }, [12, null, 32]);

    // 12. Maze: a hedge maze
    map('Maze', c => {
        c.ground(4);
        // a real maze: 14 x 14 cells of 4 blocks, carved by a random walk
        const N = 14, r = seeded(12), seen = new Uint8Array(N * N);
        c.box(4, 5, 4, 60, 9, 60, B.LEAVES);
        const stack = [[0, 0]]; seen[0] = 1;
        const cellAir = (i, j) => c.box(5 + i * 4, 5, 5 + j * 4, 7 + i * 4, 9, 7 + j * 4, B.AIR);
        cellAir(0, 0);
        while (stack.length) {
            const [i, j] = stack[stack.length - 1];
            const next = [[1, 0], [-1, 0], [0, 1], [0, -1]].map(([a, b]) => [i + a, j + b]).filter(([a, b]) => a >= 0 && b >= 0 && a < N && b < N && !seen[b * N + a]);
            if (!next.length) { stack.pop(); continue; }
            const [a, b] = next[Math.floor(r() * next.length)];
            seen[b * N + a] = 1; cellAir(a, b);
            c.box(Math.min(5 + i * 4, 5 + a * 4), 5, Math.min(5 + j * 4, 5 + b * 4), Math.max(7 + i * 4, 7 + a * 4), 9, Math.max(7 + j * 4, 7 + b * 4), B.AIR);   // knock down the wall between
            stack.push([a, b]);
        }
        c.box(28, 5, 28, 36, 9, 36, B.AIR);                     // an open middle to start in
    }, [32, null, 32]);

    // 13. Staircase: giant stairs up one side
    map('Staircase', c => {
        c.ground(4);
        for (let i = 0; i < 14; i++) c.box(4, 5, 4 + i * 4, 59, 5 + i * 3, 7 + i * 4, i % 2 ? B.PLANKS : B.COBBLESTONE);
    }, [32, null, 6]);

    // 14. Pillars: a field of pillars
    map('Pillars', c => {
        c.ground(4);
        const r = seeded(14);
        for (let x = 4; x < 60; x += 6) for (let z = 4; z < 60; z += 6) if (Math.hypot(x - 32, z - 32) > 5) c.box(x, 5, z, x + 1, 5 + Math.floor(r() * 40), z + 1, B.ROCK);
    }, [32, null, 32]);

    // 15. Crater: a big bowl in the ground
    map('Crater', c => {
        terrain(c, (x, z) => Math.round(Math.min(30, 6 + Math.hypot(x - 32, z - 32) * 0.9)), { top: B.GRAVEL });
    }, [32, null, 16]);

    // 16. Forest: lots of trees
    map('Forest', c => {
        const r = seeded(16), h = hills(r, 20, 5, 10);
        terrain(c, h);
        for (let i = 0; i < 55; i++) { const x = 2 + Math.floor(r() * 60), z = 2 + Math.floor(r() * 60); if (Math.hypot(x - 32, z - 32) > 5) c.tree(x, c.top(x, z) + 1, z, 5 + Math.floor(r() * 4)); }
    }, [32, null, 32]);

    // 17. Desert: sand dunes and cacti-like pillars
    map('Desert', c => {
        const r = seeded(17);
        terrain(c, hills(r, 10, 8, 10), { top: B.SAND, under: B.SAND });
        for (let i = 0; i < 14; i++) { const x = 3 + Math.floor(r() * 58), z = 3 + Math.floor(r() * 58), y = c.top(x, z) + 1; c.box(x, y, z, x, y + 3, z, B.LEAVES); }
    }, [32, null, 32]);

    // 18. Arena: a colosseum ring with seats
    map('Arena', c => {
        c.ground(4, B.SAND);
        for (let i = 0; i < 10; i++) c.cylinder(32, 32, 30 - i, 5 + i, 5 + i, i % 2 ? B.COBBLESTONE : B.ROCK, true);
        c.cylinder(32, 32, 30, 5, 16, B.ROCK, true);
    }, [32, null, 32]);

    // 19. Checkerboard: a flat checkered floor high up
    map('Checkerboard', c => {
        c.box(1, 1, 1, 62, 18, 62, B.ROCK);
        for (let z = 0; z < W; z++) for (let x = 0; x < W; x++) c.set(x, 19, z, ((x >> 3) + (z >> 3)) % 2 ? B.PLANKS : B.COBBLESTONE);
    }, [32, null, 32]);

    // 20. Spiral: a ramp spiralling round a tower
    map('Spiral', c => {
        c.ground(4);
        c.cylinder(32, 32, 4, 5, 50, B.ROCK);
        for (let a = 0; a < Math.PI * 10; a += 0.05) {
            const r = 9, x = Math.round(32 + Math.cos(a) * r), z = Math.round(32 + Math.sin(a) * r), y = 5 + Math.floor(a * 1.4);
            if (y < 52) c.cylinder(x, z, 2, y, y, B.PLANKS);
        }
    }, [32, null, 44]);

    // 21. Cliffs: terraces stepping up
    map('Cliffs', c => {
        terrain(c, (x, z) => 6 + Math.floor((x + z) / 12) * 4);
    }, [8, null, 8]);

    // 22. Village: little houses around a well
    map('Village', c => {
        c.ground(5);
        const house = (x, z) => { c.walls(x, 6, z, x + 7, 9, z + 7, B.PLANKS); c.box(x, 10, z, x + 7, 10, z + 7, B.LOG); c.box(x + 3, 6, z, x + 4, 7, z, B.AIR); };
        for (const [x, z] of [[6, 6], [24, 6], [44, 8], [6, 26], [46, 28], [8, 46], [26, 48], [46, 46]]) house(x, z);
        c.walls(30, 6, 30, 33, 7, 33, B.COBBLESTONE);
    }, [36, null, 36]);

    // 23. Skyscraper: a tall building with open floors
    map('Skyscraper', c => {
        c.ground(4, B.GRAVEL);
        c.walls(20, 5, 20, 43, 56, 43, B.ROCK);
        for (let y = 5; y < 56; y += 6) c.box(21, y, 21, 42, y, 42, B.COBBLESTONE);
        for (let y = 8; y < 56; y += 6) { c.box(20, y, 25, 20, y + 1, 38, B.AIR); c.box(43, y, 25, 43, y + 1, 38, B.AIR); }
        for (let y = 5; y < 50; y += 6) c.box(22 + ((y / 6) % 2) * 15, y + 1, 22, 26 + ((y / 6) % 2) * 15, y + 5, 26, B.AIR);
        c.box(30, 6, 20, 33, 8, 20, B.AIR);
    }, [32, null, 14]);

    // 24. Bridges: platforms joined by bridges over a pit
    map('Bridges', c => {
        for (const [x, z] of [[8, 8], [48, 8], [8, 48], [48, 48], [28, 28]]) c.box(x, 1, z, x + 7, 16, z + 7, B.ROCK);
        for (const [x0, z0, x1, z1] of [[15, 11, 48, 12], [15, 51, 48, 52], [11, 15, 12, 48], [51, 15, 52, 48], [15, 15, 28, 16], [35, 35, 48, 36]]) c.box(x0, 16, z0, x1, 16, z1, B.PLANKS);
    }, [31, 17, 31]);

    // 25. Mountain: one big mountain
    map('Mountain', c => {
        const r = seeded(25), bumps = hills(r, 8, 4, 0);
        terrain(c, (x, z) => Math.round(Math.max(6, 50 - Math.hypot(x - 32, z - 32) * 1.6 + bumps(x, z))), { top: B.GRASS });
        for (let z = 0; z < W; z++) for (let x = 0; x < W; x++) { const t = c.top(x, z); if (t > 38) c.set(x, t, z, B.ROCK); }
    }, [6, null, 6]);

    // 26. Lake: a lake (water and lava make stone!)
    map('Lake', c => {
        terrain(c, (x, z) => (Math.hypot(x - 32, z - 32) < 18 ? 6 : 12));
        for (let z = 0; z < W; z++) for (let x = 0; x < W; x++) if (Math.hypot(x - 32, z - 32) < 18) c.box(x, 7, z, x, 11, z, B.WATER);
        c.cylinder(32, 32, 3, 1, 12, B.SAND); c.cylinder(32, 32, 3, 13, 13, B.GRASS);
    }, [6, null, 6]);

    // 27. Ruins: broken walls
    map('Ruins', c => {
        c.ground(4);
        const r = seeded(27);
        for (let i = 0; i < 26; i++) {
            const x = 3 + Math.floor(r() * 54), z = 3 + Math.floor(r() * 54), len = 4 + Math.floor(r() * 9), h = 2 + Math.floor(r() * 9);
            if (r() < 0.5) c.box(x, 5, z, x + len, 4 + h, z, B.COBBLESTONE); else c.box(x, 5, z, x, 4 + h, z + len, B.COBBLESTONE);
        }
        c.box(28, 5, 28, 36, 12, 36, B.AIR);
    }, [32, null, 32]);

    // 28. Temple: a stepped temple
    map('Temple', c => {
        c.ground(4);
        for (let i = 0; i < 8; i++) c.box(10 + i * 2, 5 + i * 3, 10 + i * 2, 53 - i * 2, 7 + i * 3, 53 - i * 2, i % 2 ? B.COBBLESTONE : B.ROCK);
        c.box(29, 5, 10, 34, 28, 10, B.COBBLESTONE);
    }, [32, null, 6]);

    // 29. Bowl: a giant dish on a stand
    map('Bowl', c => {
        c.cylinder(32, 32, 3, 1, 14, B.ROCK);
        // each layer a solid ring from the layer below's edge out to its own, so there are no gaps
        let inner = 0;
        for (let y = 15; y < 30; y++) {
            const outer = Math.round(4 + (y - 15) * 1.8);
            for (let z = 32 - outer; z <= 32 + outer; z++) for (let x = 32 - outer; x <= 32 + outer; x++) {
                const d = Math.hypot(x - 32, z - 32);
                if (d <= outer + 0.3 && d >= inner - 1) c.set(x, y, z, B.ROCK);
            }
            inner = outer;
        }
    }, [32, 16, 32]);

    // 30. Treehouse: one giant tree
    map('Treehouse', c => {
        c.ground(5);
        c.cylinder(32, 32, 3, 6, 40, B.LOG);
        c.cylinder(32, 32, 16, 38, 44, B.LEAVES); c.cylinder(32, 32, 11, 45, 48, B.LEAVES);
        c.cylinder(32, 32, 9, 24, 24, B.PLANKS); c.cylinder(32, 32, 9, 25, 27, B.PLANKS, true);
        for (let y = 6; y < 24; y++) c.set(36, y, 32, B.PLANKS);
    }, [32, null, 12]);

    // 31. Bedroom: a giant bedroom
    map('Bedroom', c => {
        c.box(0, 1, 0, W - 1, 1, W - 1, B.PLANKS);
        c.walls(0, 2, 0, W - 1, 40, W - 1, B.PLANKS);
        c.box(4, 2, 4, 30, 9, 40, B.LOG); c.box(5, 10, 5, 29, 12, 39, B.SAND); c.box(6, 13, 6, 28, 14, 12, B.LEAVES);   // bed with a pillow
        c.box(40, 2, 4, 58, 26, 14, B.PLANKS);                   // wardrobe
        c.box(42, 2, 40, 56, 12, 56, B.LOG); c.box(42, 13, 40, 56, 13, 56, B.PLANKS);   // desk
    }, [35, null, 50]);

    // 32. Islands: little islands in the sea
    map('Islands', c => {
        c.box(0, 1, 0, W - 1, 4, W - 1, B.SAND);
        c.box(0, 5, 0, W - 1, 9, W - 1, B.WATER);
        const r = seeded(32);
        for (let i = 0; i < 7; i++) { const x = 8 + Math.floor(r() * 48), z = 8 + Math.floor(r() * 48), rad = 3 + Math.floor(r() * 4); c.cylinder(x, z, rad, 5, 10, B.SAND); c.cylinder(x, z, rad - 1, 11, 11, B.GRASS); }
        c.cylinder(32, 32, 5, 5, 10, B.SAND); c.cylinder(32, 32, 4, 11, 11, B.GRASS);
    }, [32, null, 32]);

    // ---- make one map: its blocks and spawn (feet position, standing on solid ground) ----
    return {
        size: { w: W, h: W, d: DEPTH },
        version: PRESET_VERSION,
        names: maps.map(m => m.name),
        build(name) {
            const m = maps.find(x => x.name === name);
            const c = canvas();
            m.build(c);
            let [sx, sy, sz] = m.spawn;
            if (sy === null) sy = c.top(sx, sz) + 1;
            c.box(sx - 1, sy, sz - 1, sx + 1, sy + 2, sz + 1, B.AIR);           // room to stand
            if (c.get(sx, sy - 1, sz) === B.AIR) c.set(sx, sy - 1, sz, B.COBBLESTONE);
            return { blocks: c.blocks, spawn: { x: sx + 0.5, y: sy + RAISE, z: sz + 0.5 } };
        }
    };
};
